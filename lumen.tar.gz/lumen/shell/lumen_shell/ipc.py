"""Client for the Lumen compositor IPC socket (see compositor/src/ipc.c)."""
import json
import os
import socket

from gi.repository import Gio, GLib, GObject


def socket_path():
    p = os.environ.get("LUMEN_SOCK")
    if p:
        return p
    rt = os.environ.get("XDG_RUNTIME_DIR", "/tmp")
    wd = os.environ.get("WAYLAND_DISPLAY", "wayland-0")
    return f"{rt}/lumen-{wd}.sock"


def send(cmd: str) -> bool:
    """Fire-and-forget command, e.g. send('toggle 3')."""
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            s.connect(socket_path())
            s.sendall((cmd + "\n").encode())
            s.recv(64)
        return True
    except OSError:
        return False


def request(cmd: str, timeout=1.5) -> str:
    """Send a command and return the compositor's reply line ('' on failure)."""
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect(socket_path())
            s.sendall((cmd + "\n").encode())
            data = b""
            while not data.endswith(b"\n") and len(data) < 1_000_000:
                chunk = s.recv(65536)
                if not chunk:
                    break
                data += chunk
            return data.decode(errors="replace").strip()
    except OSError:
        return ""


class Compositor(GObject.Object):
    """Subscribes to window/workspace state and re-emits it as a GObject signal."""

    __gsignals__ = {"changed": (GObject.SignalFlags.RUN_FIRST, None, (object,)),
                    # compositor-originated requests, e.g. {"event": "shell", "what": "start"}
                    "event": (GObject.SignalFlags.RUN_FIRST, None, (object,))}

    def __init__(self, fake_state=None):
        super().__init__()
        self.state = fake_state or {"workspace": 1, "workspaces": 4, "focused": 0, "windows": []}
        self._stream = None
        if fake_state is None:
            GLib.idle_add(self._connect)

    def _connect(self):
        try:
            addr = Gio.UnixSocketAddress.new(socket_path())
            conn = Gio.SocketClient().connect(addr, None)
        except GLib.Error:
            GLib.timeout_add_seconds(1, self._connect)   # compositor not up yet
            return False
        self._conn = conn
        conn.get_output_stream().write_all(b"subscribe\n", None)
        self._stream = Gio.DataInputStream.new(conn.get_input_stream())
        self._read()
        return False

    def _read(self):
        self._stream.read_line_async(GLib.PRIORITY_DEFAULT, None, self._on_line)

    def _on_line(self, stream, res):
        try:
            line, _ = stream.read_line_finish_utf8(res)
        except GLib.Error:
            line = None
        if line is None:                               # socket closed: reconnect
            GLib.timeout_add_seconds(1, self._connect)
            return
        if line.startswith("{"):
            try:
                obj = json.loads(line)
            except ValueError:
                obj = None
            if isinstance(obj, dict) and "event" in obj:
                self.emit("event", obj)
            elif isinstance(obj, dict):
                self.state = obj
                self.emit("changed", self.state)
        self._read()

    @property
    def focused(self):
        for w in self.state.get("windows", []):
            if w.get("focused"):
                return w
        return None
