"""Clipboard history (Super+V): the last 60 things you copied, text and images.

`wl-paste --watch lumen-clip-store` (started by the shell) saves each copy in
~/.cache/lumen/clipboard; this panel lists them, newest first. Pick one (click,
or arrows + Enter) and it's copied back and pasted into the window you were in.
Type to filter, Delete removes the selected item.
"""
import os
import shlex
import shutil
import subprocess
import time

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("GdkPixbuf", "2.0")
gi.require_version("Pango", "1.0")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk, Pango  # noqa: E402

from . import ipc, system  # noqa: E402

DIR = os.path.join(GLib.get_user_cache_dir(), "lumen", "clipboard")
MIME = {"png": "image/png", "jpg": "image/jpeg", "webp": "image/webp", "gif": "image/gif", "bmp": "image/bmp"}


def A():
    from . import app
    return app


def start_watcher(preview=False):
    """one `wl-paste --watch` per session (a shell restart replaces it)"""
    if preview or not shutil.which("wl-paste") or not shutil.which("lumen-clip-store"):
        return
    subprocess.run(["pkill", "-f", "wl-paste --watch lumen-clip-store"],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    system.spawn("wl-paste --watch lumen-clip-store")


def entries():
    try:
        names = [n for n in os.listdir(DIR) if not n.startswith(".") and "-" in n]
    except OSError:
        return []
    out = []
    for n in names:
        p = os.path.join(DIR, n)
        try:
            mt = os.path.getmtime(p)
        except OSError:
            continue
        ext = n.rsplit(".", 1)[-1].lower()
        out.append({"path": p, "time": mt, "image": ext in MIME, "ext": ext})
    out.sort(key=lambda e: e["time"], reverse=True)
    return out


def read_text(path, limit=4000):
    try:
        with open(path, "rb") as f:
            return f.read(limit).decode("utf-8", "replace")
    except OSError:
        return ""


def ago(ts):
    d = max(0, time.time() - ts)
    if d < 60:
        return "now"
    if d < 3600:
        return f"{int(d // 60)}m ago"
    if d < 86400:
        return f"{int(d // 3600)}h ago"
    return time.strftime("%b %-d", time.localtime(ts))


def thumb(path, w=300, h=130):
    try:
        pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, w * 2, h * 2, True)
        return Gdk.Texture.new_for_pixbuf(pb), pb.get_width() // 2, pb.get_height() // 2
    except Exception:   # noqa: BLE001 — unreadable image: show a placeholder
        return None, 0, 0


class ClipboardPanel:
    @staticmethod
    def make(shell):
        L = A()

        class Panel(L.Popup):
            def __init__(self):
                self.shell = shell
                self.items = []
                self.rows = []
                self.sel = 0
                self.search = Gtk.SearchEntry(placeholder_text="Search clipboard", hexpand=True)
                self.search.add_css_class("clip-search")
                self.search.connect("search-changed", lambda *_: self.refresh())
                self.search.connect("activate", lambda *_: self.pick(self.sel))
                clear = L.button(L.lbl("Clear all"), "n-clear-all", self.clear_all)
                head = L.box(Gtk.Orientation.HORIZONTAL, 8, "nc-head",
                             L.lbl("Clipboard", "nc-title", xalign=0, hexpand=True), clear)
                self.list = L.box(Gtk.Orientation.VERTICAL, 8, "clip-list")
                self.scroller = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER,
                                                   propagate_natural_height=True, max_content_height=470)
                self.scroller.set_child(self.list)
                hint = L.lbl("Enter pastes · Delete removes · Esc closes", "clip-hint", xalign=0)
                card = L.box(Gtk.Orientation.VERTICAL, 10, "glass card nc clip", head, self.search,
                             self.scroller, hint)
                card.set_size_request(400, -1)
                super().__init__(shell, "clipboard", card, Gtk.Align.CENTER, Gtk.Align.END,
                                 {"bottom": 70}, Gtk.RevealerTransitionType.SLIDE_UP)
                self.refresh()

            def build_window(self):
                super().build_window()
                k = Gtk.EventControllerKey()
                k.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
                k.connect("key-pressed", self.on_key)
                self.win.add_controller(k)

            def on_key(self, _c, kv, _code, _state):
                if kv in (Gdk.KEY_Down, Gdk.KEY_Tab):
                    self.select(self.sel + 1)
                elif kv in (Gdk.KEY_Up, Gdk.KEY_ISO_Left_Tab):
                    self.select(self.sel - 1)
                elif kv in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
                    self.pick(self.sel)
                elif kv == Gdk.KEY_Delete:
                    self.remove(self.sel)
                elif kv == Gdk.KEY_Escape:
                    self.close()
                else:
                    return False
                return True

            def on_open(self):
                self.search.set_text("")
                self.refresh()
                GLib.timeout_add(60, lambda: (self.search.grab_focus(), False)[1])

            def refresh(self):
                q = self.search.get_text().strip().lower()
                child = self.list.get_first_child()
                while child:
                    nxt = child.get_next_sibling()
                    self.list.remove(child)
                    child = nxt
                self.items, self.rows = [], []
                for e in entries():
                    if not e["image"]:
                        e["text"] = read_text(e["path"])
                        if q and q not in e["text"].lower():
                            continue
                    elif q:
                        continue
                    self.items.append(e)
                    self.rows.append(self.row(e, len(self.items) - 1))
                    self.list.append(self.rows[-1])
                if not self.items:
                    self.list.append(L.box(Gtk.Orientation.VERTICAL, 6, "nc-empty",
                                           L.icon("edit-paste-symbolic", 30),
                                           L.lbl("Nothing here yet" if not q else "No matches", "nc-empty-title"),
                                           L.lbl("Things you copy show up here." if not q else "", "nc-empty-sub")))
                self.select(0)

            def row(self, e, i):
                if e["image"]:
                    tex, w, h = thumb(e["path"])
                    body = Gtk.Picture.new_for_paintable(tex) if tex else L.icon("image-x-generic-symbolic", 32)
                    if tex:
                        body.set_size_request(w, h)
                        body.set_can_shrink(True)
                        body.set_halign(Gtk.Align.START)
                    kind = "Image"
                else:
                    t = e["text"].strip("\n")
                    body = Gtk.Label(label=t[:600], xalign=0, wrap=True, wrap_mode=Pango.WrapMode.WORD_CHAR,
                                     lines=3, ellipsize=Pango.EllipsizeMode.END, max_width_chars=44)
                    body.add_css_class("clip-text")
                    kind = "Link" if t.startswith(("http://", "https://")) else "Text"
                x = L.button(L.icon("window-close-symbolic", 12), "n-close", lambda i=i: self.remove(i), "Remove")
                head = L.box(Gtk.Orientation.HORIZONTAL, 6, "clip-head",
                             L.lbl(kind, "clip-kind", xalign=0, hexpand=True), L.lbl(ago(e["time"]), "n-time"), x)
                card = L.box(Gtk.Orientation.VERTICAL, 6, "clip-item", head, body)
                g = Gtk.GestureClick()
                g.connect("released", lambda *_a, i=i: self.pick(i))
                card.add_controller(g)
                card.set_cursor(Gdk.Cursor.new_from_name("pointer"))
                return card

            def select(self, i):
                if not self.rows:
                    self.sel = 0
                    return
                self.sel = max(0, min(i, len(self.rows) - 1))
                for k, r in enumerate(self.rows):
                    (r.add_css_class if k == self.sel else r.remove_css_class)("selected")
                r = self.rows[self.sel]

                def scroll():
                    ok, b = r.compute_bounds(self.list)
                    if ok:
                        adj = self.scroller.get_vadjustment()
                        top, bot = b.origin.y, b.origin.y + b.size.height
                        if top < adj.get_value():
                            adj.set_value(top)
                        elif bot > adj.get_value() + adj.get_page_size():
                            adj.set_value(bot - adj.get_page_size())
                    return False
                GLib.idle_add(scroll)

            def pick(self, i):
                if not (0 <= i < len(self.items)):
                    return
                e = self.items[i]
                mime = MIME.get(e["ext"], "text/plain;charset=utf-8")
                os.utime(e["path"])          # back to the top of the list
                if not self.shell.preview:
                    system.spawn(f"wl-copy --type {shlex.quote(mime)} < {shlex.quote(e['path'])}")
                self.close()
                # once the window under us has the keyboard back: paste
                if not self.shell.preview:
                    GLib.timeout_add(240, lambda: (ipc.send("paste"), False)[1])

            def remove(self, i):
                if 0 <= i < len(self.items):
                    try:
                        os.remove(self.items[i]["path"])
                    except OSError:
                        pass
                    keep = self.sel
                    self.refresh()
                    self.select(min(keep, len(self.rows) - 1))

            def clear_all(self):
                for e in entries():
                    try:
                        os.remove(e["path"])
                    except OSError:
                        pass
                self.refresh()

        return Panel()
