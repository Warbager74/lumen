"""Offscreen preview renderer (no compositor needed).

Renders the real shell widgets into a 1920×1080 PNG. The compositor's backdrop
blur is emulated: a second "mask" pass marks every glass pixel, and the
wallpaper is blurred + saturated exactly there before the UI is composited on
top. Window frames are mocked with the same metrics the compositor draws
(36px titlebar, 14px radius, traffic lights)."""
import json
import os
import sys
import tempfile

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Graphene", "1.0")
from gi.repository import GLib, Graphene, Gtk  # noqa: E402

from . import app as A  # noqa: E402

W, H = 1920, 1080

FAKE = {"workspace": 1, "workspaces": 4, "focused": 2, "windows": [
    {"id": 1, "app_id": "org.gnome.Nautilus", "title": "Home", "workspace": 1,
     "minimized": False, "maximized": False, "focused": False},
    {"id": 2, "app_id": "kitty", "title": "~ — fastfetch", "workspace": 1,
     "minimized": False, "maximized": False, "focused": True},
    {"id": 3, "app_id": "firefox", "title": "Arch Linux", "workspace": 2,
     "minimized": False, "maximized": False, "focused": False},
]}

FASTFETCH = """<span foreground="#8aa4ff"><b>you</b></span>@<span foreground="#8aa4ff"><b>lumen</b></span>
<span foreground="#ffffff55">──────────────</span>
<span foreground="#b98cff"><b>OS</b></span>        Arch Linux x86_64
<span foreground="#b98cff"><b>Kernel</b></span>    6.17.7-arch1-1
<span foreground="#b98cff"><b>DE</b></span>        Lumen 0.1 (wayland)
<span foreground="#b98cff"><b>WM</b></span>        lumen · scenefx 0.5
<span foreground="#b98cff"><b>Shell</b></span>     zsh 5.9
<span foreground="#b98cff"><b>Terminal</b></span>  kitty 0.44
<span foreground="#b98cff"><b>Theme</b></span>     Liquid Glass [GTK4]
<span foreground="#b98cff"><b>CPU</b></span>       AMD Ryzen 7 7840U (16) @ 5.1 GHz
<span foreground="#b98cff"><b>Memory</b></span>    5.12 GiB / 31.1 GiB (16%)

<span foreground="#ff5f57">●</span> <span foreground="#febc2e">●</span> <span foreground="#28c840">●</span> <span foreground="#8aa4ff">●</span> <span foreground="#b98cff">●</span> <span foreground="#5ee0d0">●</span>

<span foreground="#5ee0d0">~</span> <span foreground="#b98cff">❯</span> """


def mock_window(title, w, h, content, active=True):
    lights = A.box(Gtk.Orientation.HORIZONTAL, 0, None, valign=Gtk.Align.CENTER, margin_start=6)
    for c in ("close", "min", "zoom"):
        d = Gtk.Box()
        d.add_css_class("light")
        d.add_css_class(c)
        lights.append(d)
    tb = Gtk.CenterBox()
    tb.add_css_class("lumen-titlebar")
    tb.set_start_widget(lights)
    tb.set_center_widget(A.lbl(title))
    win = A.box(Gtk.Orientation.VERTICAL, 0, "mockwin" + ("" if active else " inactive"), tb, content)
    win.set_size_request(w, h)
    return win


def files_content():
    side = A.box(Gtk.Orientation.VERTICAL, 4, None, margin_start=14, margin_top=6)
    for ic, name in (("user-home-symbolic", "Home"), ("folder-documents-symbolic", "Documents"),
                     ("folder-download-symbolic", "Downloads"), ("folder-pictures-symbolic", "Pictures"),
                     ("folder-music-symbolic", "Music"), ("user-trash-symbolic", "Trash")):
        side.append(A.box(Gtk.Orientation.HORIZONTAL, 10, None, A.icon(ic, 16), A.lbl(name, xalign=0)))
    grid = Gtk.FlowBox(max_children_per_line=5, selection_mode=Gtk.SelectionMode.NONE,
                       hexpand=True, row_spacing=12, column_spacing=6, margin_top=8)
    for name in ("Desktop", "Documents", "Downloads", "Music", "Pictures", "Projects", "Videos", "dotfiles"):
        grid.append(A.box(Gtk.Orientation.VERTICAL, 4, None, A.icon("folder", 56), A.lbl(name)))
    body = A.box(Gtk.Orientation.HORIZONTAL, 20, "mock-content", side, grid, vexpand=True)
    return body


def render(widget, path):
    w, h = widget.get_width(), widget.get_height()
    p = Gtk.WidgetPaintable.new(widget)
    snap = Gtk.Snapshot()
    p.snapshot(snap, w, h)
    node = snap.to_node()
    if node is None:   # nothing drawn on this layer
        from PIL import Image
        Image.new("RGBA", (max(w, 1), max(h, 1)), (0, 0, 0, 0)).save(path)
        return
    tex = widget.get_native().get_renderer().render_texture(node, Graphene.Rect().init(0, 0, w, h))
    tex.save_to_png(path)


def _still(wallpaper):
    """previews composite the wallpaper themselves: a video falls back to a still"""
    if wallpaper.lower().endswith((".mp4", ".webm", ".mkv", ".mov", ".m4v")):
        return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "data", "wallpapers",
                                            "lumen-flow.jpg"))
    return wallpaper


def composite(layers, wallpaper, out, glass_from=99):
    wallpaper = _still(wallpaper)
    """layers: [(ui_png, mask_png)] bottom→top. Each layer's glass blurs the
    accumulated image beneath it — the same thing SceneFX backdrop blur does."""
    from PIL import Image, ImageEnhance, ImageFilter
    wall = Image.open(wallpaper).convert("RGB")
    s = max(W / wall.width, H / wall.height)
    wall = wall.resize((round(wall.width * s), round(wall.height * s)), Image.LANCZOS)
    l, t = (wall.width - W) // 2, (wall.height - H) // 2
    wall = wall.crop((l, t, l + W, t + H))
    canvas = wall.convert("RGBA")
    liquid = A.glass_style() == "liquid"
    backdrop = None
    for idx, (ui_png, mask_png) in enumerate(layers):
        if liquid and idx == glass_from:
            backdrop = canvas.copy()          # what the compositor captures behind the panes
        if liquid and idx >= glass_from:      # the glass is drawn by the lens pass instead
            canvas = Image.alpha_composite(canvas, Image.open(ui_png).convert("RGBA"))
            continue
        # mirrors the compositor: frosted 3 passes radius 6 (~σ 24); liquid ~σ 7 and
        # only surfaces above the 0.2 alpha threshold get frosted
        sigma, sat, thr = (7, 1.55, 51) if liquid else (24, 1.35, 8)
        blur = ImageEnhance.Color(canvas.convert("RGB").filter(ImageFilter.GaussianBlur(sigma))).enhance(sat)
        mask = Image.open(mask_png).split()[-1].point(lambda a: 255 if a > thr else 0)
        canvas = Image.composite(blur.convert("RGBA"), canvas, mask)
        canvas = Image.alpha_composite(canvas, Image.open(ui_png).convert("RGBA"))
    canvas.convert("RGB").save(out, quality=95)
    return backdrop


def liquid(path, wallpaper_img, items):
    """Lumen's real Liquid Glass pass (liquid_gl.c) in a mini compositor: start
    from what's behind all glass, then per item bottom → top: capture, lens,
    repaint its content. items: [(content_png, [pane_shape tuples])]"""
    import subprocess
    from PIL import Image
    tool = os.environ.get("LUMEN_LIQUID_TOOL")
    if not tool:
        return
    tmp = tempfile.mkdtemp()
    W_, H_ = wallpaper_img.size
    open(os.path.join(tmp, "base.raw"), "wb").write(wallpaper_img.convert("RGBA").tobytes())
    spec = []
    for i, (png, shapes) in enumerate(items):
        im = Image.open(png).convert("RGBA")
        # premultiply, like client buffers
        r, g, b, a = im.split()
        from PIL import ImageChops
        pm = Image.merge("RGBA", [ImageChops.multiply(c, a) for c in (r, g, b)] + [a])
        raw = os.path.join(tmp, f"c{i}.raw")
        open(raw, "wb").write(pm.tobytes())
        spec.append(f"item {raw}")
        spec += [" ".join(f"{v:.2f}" for v in p) for p in shapes if p]
    open(os.path.join(tmp, "spec.txt"), "w").write("\n".join(spec) + "\n")
    subprocess.run([tool, str(W_), str(H_), os.path.join(tmp, "base.raw"), os.path.join(tmp, "spec.txt"),
                    os.path.join(tmp, "out.raw")], check=True)
    out = Image.frombytes("RGBA", (W_, H_), open(os.path.join(tmp, "out.raw"), "rb").read())
    out.convert("RGB").save(path, quality=95)


def wallpaper_canvas(wallpaper):
    wallpaper = _still(wallpaper)
    from PIL import Image
    wall = Image.open(wallpaper).convert("RGB")
    s = max(W / wall.width, H / wall.height)
    wall = wall.resize((round(wall.width * s), round(wall.height * s)), Image.LANCZOS)
    l, t = (wall.width - W) // 2, (wall.height - H) // 2
    return wall.crop((l, t, l + W, t + H))


def seed_notifications(shell):
    """fake notifications: a few in the centre, the newest `LUMEN_PREVIEW_NOTIFY` as pop-ups"""
    import time as _t
    now = _t.time()
    art = os.environ.get("LUMEN_PREVIEW_ART")
    base = {"app_icon": "", "desktop_entry": "", "image": None, "urgency": 1, "live": True, "resident": False,
            "transient": False, "reply": False, "reply_placeholder": "", "timeout": -1,
            "suppress_sound": False, "sound_file": "", "actions": []}
    fake = [
        dict(base, id=1, app_name="Mail", app_icon="mail-unread", summary="Weekly design review",
             body="Slides are in the shared folder — can everyone add notes before Friday?", time=now - 3 * 3600),
        dict(base, id=2, app_name="Discord", app_icon="discord", summary="#lumen-dev",
             body="<b>kai</b>: the liquid glass looks unreal on my ultrawide", time=now - 2 * 3600),
        dict(base, id=3, app_name="Discord", app_icon="discord", summary="#lumen-dev",
             body="<b>mira</b>: pushed the multi-monitor fix", time=now - 50 * 60),
        dict(base, id=4, app_name="Discord", app_icon="discord", summary="Alex",
             body="are we still on for tonight?", time=now - 4 * 60, reply=True,
             reply_placeholder="Message @Alex", actions=[("inline-reply", "Reply")]),
        dict(base, id=5, app_name="Spotify", app_icon="spotify", summary="Midnight City",
             body="M83 · Hurry Up, We're Dreaming", image=art, time=now - 90),
        dict(base, id=6, app_name="Firefox", app_icon="firefox", summary="Download complete",
             body="lumen-0.1.0.tar.gz — 4.2 MB", time=now - 5,
             actions=[("default", "Open"), ("open", "Open"), ("show", "Show in Folder")]),
    ]
    mgr = shell.notify
    mgr.items = list(reversed(fake))
    mgr.unread = 3
    shown = int(os.environ.get("LUMEN_PREVIEW_NOTIFY", "0") or 0)
    for n in fake[len(fake) - shown:]:
        mgr.show_toast(n)
    mgr.changed()
    return bool(shown)


def run_preview(argv):
    out = argv[argv.index("--preview") + 1]
    opened = argv[argv.index("--open") + 1] if "--open" in argv else None
    state = json.loads(json.dumps(FAKE))
    ws = int(os.environ.get("LUMEN_PREVIEW_WS", "1"))
    if ws != 1:   # another workspace: nothing focused there
        state["workspace"] = ws
        for w in state["windows"]:
            w["focused"] = False
    shell = A.Shell(None, preview=True, fake_state=state)
    A.load_css(shell.cfg.get("icon_theme"))
    if os.environ.get("LUMEN_PREVIEW_WIDGETS"):
        shell.cfg.update(json.loads(os.environ["LUMEN_PREVIEW_WIDGETS"]))
    shell.cfg["pinned"] = ["firefox.desktop", "org.lumen.Files.desktop", "kitty.desktop",
                           "visual-studio-code.desktop", "spotify.desktop", "discord.desktop"]
    shell.build_popups()
    toasts = seed_notifications(shell) if os.environ.get("LUMEN_PREVIEW_NOTIFY") else None

    root = Gtk.Overlay()
    root.set_size_request(W, H)
    base = Gtk.Box(hexpand=True, vexpand=True)
    root.set_child(base)

    # desktop widgets: their own layer, under the windows
    widgets_layer = Gtk.Overlay()
    widgets_layer.set_child(Gtk.Box(hexpand=True, vexpand=True))
    dw = A.DesktopWidgets(shell)
    pos = shell.cfg.get("widgets_position", "top-right")
    dw.box.set_halign(Gtk.Align.END if pos.endswith("right") else Gtk.Align.START)
    dw.box.set_valign(Gtk.Align.START if pos.startswith("top") else Gtk.Align.END)
    if pos.startswith("top"):
        dw.box.set_margin_top(31 + 14)
    else:
        dw.box.set_margin_bottom(70 + 14)
    (dw.box.set_margin_end if pos.endswith("right") else dw.box.set_margin_start)(22)
    widgets_layer.add_overlay(dw.box)
    root.add_overlay(widgets_layer)

    win_files, win_term = Gtk.Fixed(), Gtk.Fixed()
    term_text = A.lbl("", "term", xalign=0, yalign=0, vexpand=True)
    term_text.set_markup(FASTFETCH)
    term = A.box(Gtk.Orientation.VERTICAL, 0, "mock-content", term_text, vexpand=True)
    focused = (opened is None)
    mw_files = mock_window("Home", 900, 560, files_content(), active=False)
    mw_term = mock_window("~ — fastfetch", 760, 470, term, active=focused)
    if not os.environ.get("LUMEN_PREVIEW_NOWIN"):
        win_files.put(mw_files, 300, 170)
        win_term.put(mw_term, 820, 330)
    root.add_overlay(win_files)
    root.add_overlay(win_term)
    chrome = Gtk.Overlay()   # bars + popups form the top layer
    chrome.set_child(Gtk.Box(hexpand=True, vexpand=True))
    root.add_overlay(chrome)

    top = A.TopBar(shell).widget
    top.set_valign(Gtk.Align.START)
    bar_obj = A.Taskbar(shell)
    bar = bar_obj.widget
    bar.set_valign(Gtk.Align.END)
    chrome.add_overlay(top)
    chrome.add_overlay(bar)
    if toasts:
        tb = shell.notify.toast_box
        tb.set_halign(Gtk.Align.END)
        tb.set_valign(Gtk.Align.START)
        tb.set_margin_top(44)
        tb.set_margin_end(12)
        chrome.add_overlay(tb)
        for t in shell.notify.toasts.values():
            t["rev"].set_transition_type(Gtk.RevealerTransitionType.NONE)
            t["rev"].set_reveal_child(True)
    popup_layer = None
    if opened:
        popup_layer = Gtk.Overlay()   # popups get their own layer so videos can animate them
        popup_layer.set_child(Gtk.Box(hexpand=True, vexpand=True))
        root.add_overlay(popup_layer)
        p = shell.popups[opened]
        if opened == "stack":   # the folder fan over the Files icon
            e = next(x for x in bar_obj.entries() if A.is_file_manager(x))
            p.show_for(e, int(os.environ.get("LUMEN_PREVIEW_FAN_X", "1003")))
        if opened == "task":    # jump list for the focused terminal (3rd taskbar entry)
            e = [x for x in bar_obj.entries() if x["windows"]][-1]
            p.show_for(e, 1110)
        if opened == "control":
            p.sync()
        if opened == "start":
            p.refresh()
            if os.environ.get("LUMEN_PREVIEW_SEARCH") is not None:
                p.set_search_mode(True)
                p.entry.set_text(os.environ["LUMEN_PREVIEW_SEARCH"])
                p.refresh_grid()
                p.web_rev.set_transition_type(Gtk.RevealerTransitionType.NONE)
                p.web_rev.set_reveal_child(True)
        if opened == "spotlight":
            if os.environ.get("LUMEN_PREVIEW_MODE"):
                p.set_mode(os.environ["LUMEN_PREVIEW_MODE"])
            p.entry.set_text(os.environ.get("LUMEN_PREVIEW_SPOT", "s"))
            if os.environ.get("LUMEN_PREVIEW_SEL"):
                p.set_sel(int(os.environ["LUMEN_PREVIEW_SEL"]))
        if opened == "notifications":
            p.refresh()
        if opened in ("calendar", "battery"):
            p.on_open()
        if os.environ.get("LUMEN_PREVIEW_QUERY"):
            q = os.environ["LUMEN_PREVIEW_QUERY"]
            for t in shell.taskbars + [bar_obj]:
                t.show_query(q)
        p.rev.set_transition_type(Gtk.RevealerTransitionType.NONE)
        if p.origin.startswith("b"):
            p.rev.set_margin_bottom(A.bar_clearance(shell.cfg))
        p.rev.set_reveal_child(True)
        popup_layer.add_overlay(p.rev)

    win = Gtk.Window()
    win.set_decorated(False)
    win.set_default_size(W, H)
    win.set_child(root)
    win.present()

    loop = GLib.MainLoop()
    tmp = tempfile.mkdtemp()
    stack = [widgets_layer, win_files, win_term, chrome] + ([popup_layer] if popup_layer else [])
    files = [(os.path.join(tmp, f"ui{i}.png"), os.path.join(tmp, f"mask{i}.png")) for i in range(len(stack))]
    steps = [(i, m) for m in (False, True) for i in range(len(stack))]

    def step():
        i, masked = steps.pop(0)
        (root.add_css_class if masked else root.remove_css_class)("mask")
        for j, w in enumerate(stack):
            w.set_opacity(1.0 if j == i else 0.0)
        GLib.timeout_add(250, lambda: snap(i, masked))
        return False

    def snap(i, masked):
        render(root, files[i][1 if masked else 0])
        if steps:
            step()
        else:
            composite(files, shell.cfg["wallpaper"], out)
            if A.glass_style() == "liquid":
                tint = (0.11 * 0.30, 0.12 * 0.30, 0.165 * 0.30, 0.30)   # glass_tint × 0.55, premultiplied
                def win_shape(mw):
                    p = A.pane_shape(mw, root, 14, shadow=0, frost=1.0)
                    return p + tint if p else None
                items = [(files[0][0], [A.pane_shape(c, root, 24, shadow=0.8, frost=0.7) for c in dw.cards[:16]]),
                         (files[1][0], [win_shape(mw_files)]), (files[2][0], [win_shape(mw_term)]),
                         (files[3][0], [A.pane_shape(top, root, 0, open_edges="trl", shadow=0, frost=0),
                                        A.pane_shape(bar_obj.pane, root, shadow=1.0, frost=0.5),
                                        A.pane_shape(bar_obj.search, root, shadow=0, frost=0.3)])]
                if opened:
                    card = shell.popups[opened].rev.get_child()
                    items.append((files[4][0], [A.pane_shape(card, root)]))
                liquid(out, wallpaper_canvas(shell.cfg["wallpaper"]), items)
            keep = os.environ.get("LUMEN_PREVIEW_KEEP")
            if keep:
                import shutil
                os.makedirs(keep, exist_ok=True)
                for a, b in files:
                    shutil.copy(a, keep)
                    shutil.copy(b, keep)
            print("wrote", out)
            loop.quit()
        return False

    GLib.timeout_add(1500, step)
    loop.run()
    return 0


if __name__ == "__main__":
    sys.exit(run_preview(sys.argv))
