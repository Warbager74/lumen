"""USB sticks, disks, cards and phones: mounted as soon as they are plugged in,
with a notification that opens them in Files.

GLib's volume monitor (gvfs + udisks2) does the work; Lumen Files lists the
same drives in its sidebar and ejects them. `"automount": false` in
~/.config/lumen/shell.json leaves drives alone until they are clicked there.
"""
import shutil
import subprocess
import threading
import time

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gio, GLib, Gtk  # noqa: E402

from . import system  # noqa: E402


def removable(mount):
    """something the user plugged in (not the system's own partitions)"""
    drive = mount.get_drive()
    if drive is not None:
        return drive.is_removable() or drive.is_media_removable() or drive.can_eject() or drive.can_stop()
    root = mount.get_root()
    # no drive behind it: a phone or a camera (mtp, gphoto2) counts, a network share doesn't
    return root is not None and (root.get_uri_scheme() or "") in ("mtp", "gphoto2", "afc")


class Drives:
    def __init__(self, shell):
        self.shell = shell
        self.started = time.monotonic()
        self.told = set()
        self.vm = Gio.VolumeMonitor.get()
        self.vm.connect("volume-added", lambda _m, v: self.automount(v))
        self.vm.connect("mount-added", lambda _m, m: self.arrived(m))
        self.vm.connect("mount-removed", lambda _m, m: self.told.discard(self.key(m)))
        # what was already plugged in when the session started: mounted quietly
        for v in self.vm.get_volumes():
            self.automount(v)

    def on(self):
        return bool(self.shell.cfg.get("automount", True))

    @staticmethod
    def key(mount):
        root = mount.get_root()
        return root.get_uri() if root is not None else mount.get_name()

    def automount(self, vol):
        if not self.on() or vol.get_mount() is not None or not vol.can_mount() or not vol.should_automount():
            return

        def done(v, res):
            try:
                v.mount_finish(res)
            except GLib.Error as e:
                quiet = (Gio.IOErrorEnum.FAILED_HANDLED, Gio.IOErrorEnum.ALREADY_MOUNTED, Gio.IOErrorEnum.CANCELLED)
                if not any(e.matches(Gio.io_error_quark(), c) for c in quiet):
                    self.notify(v.get_name(), "Couldn't open this drive: " + e.message, None)
        # (an encrypted drive asks for its password in a window of its own)
        vol.mount(Gio.MountMountFlags.NONE, Gtk.MountOperation.new(None), None, done)

    def arrived(self, mount):
        k = self.key(mount)
        if k in self.told or mount.is_shadowed() or not removable(mount):
            return
        self.told.add(k)
        if time.monotonic() - self.started < 4:
            return                      # it was there before we were: nothing new to announce
        root = mount.get_root()
        self.notify(mount.get_name(), "Connected. Click to open it in Files.", root.get_uri() if root else None)

    def notify(self, title, body, uri):
        """through the notification service like everybody else (it keeps the
        history, Do Not Disturb, sounds); the click comes back on stdout"""
        if not shutil.which("notify-send"):
            return
        cmd = ["notify-send", "-a", "Drives", "-i", "drive-removable-media", "-t", "8000"]
        if uri:
            cmd += ["-A", "default=Open"]
        cmd += [title, body]

        def work():
            try:
                out = subprocess.run(cmd, capture_output=True, text=True, timeout=600).stdout.strip()
            except (OSError, subprocess.SubprocessError):
                return
            if uri and out == "default":
                GLib.idle_add(lambda: (system.open_uri(uri), False)[1])
        threading.Thread(target=work, daemon=True).start()
