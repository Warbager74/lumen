"""Lumen shell: macOS-style top bar, Windows 11-style taskbar, Start menu,
control centre, menus and wallpaper, as wlr-layer-shell surfaces (GTK4)."""
import json
import os
import shlex
import shutil
import subprocess
import sys
import threading
import time

# --- clean environment for launched apps --------------------------------
# bin/lumen-shell preloads gtk4-layer-shell into *this* process (already done by
# the time Python runs). Undo it in our environment so apps we start (taskbar,
# Start menu, web search, rofi…) get a normal one: a GTK3 app such as Firefox
# aborts at startup if GTK4 gets loaded into it.
def _clean_env():
    for var in ("LD_PRELOAD", "PYTHONPATH"):
        orig = os.environ.pop("LUMEN_ORIG_" + var, None)
        if orig is None:
            if var == "LD_PRELOAD":   # started some other way: just drop layer-shell
                keep = [p for p in os.environ.get(var, "").split(":") if p and "layer-shell" not in p]
                if keep:
                    os.environ[var] = ":".join(keep)
                else:
                    os.environ.pop(var, None)
            continue
        if orig:
            os.environ[var] = orig
        else:
            os.environ.pop(var, None)


_clean_env()

# (a fixed GTK theme inherited from the session would pin our menus and entries to
# dark whatever Settings → Appearance says)
if os.environ.get("GTK_THEME", "").startswith("Adwaita"):
    os.environ.pop("GTK_THEME", None)

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("Graphene", "1.0")
from gi.repository import Gdk, Gio, GLib, Graphene, Gtk  # noqa: E402

try:
    gi.require_version("Gtk4LayerShell", "1.0")
    from gi.repository import Gtk4LayerShell as LS  # noqa: E402
except (ValueError, ImportError):
    LS = None

from . import ipc, system  # noqa: E402
from . import notifications  # noqa: E402
from . import clipboard  # noqa: E402
from . import extras  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "lumen")
DEFAULTS = {
    "pinned": ["firefox.desktop", "org.lumen.Files.desktop", "kitty.desktop",
               "code.desktop", "spotify.desktop", "lumen-settings.desktop"],
    "wallpaper": "/usr/share/backgrounds/lumen/lumen-flow.jpg",
    "launcher": "lumen-launcher",
    "terminal": "kitty",
    "settings": "lumen-settings",
    "clock_24h": False,
    "automount": True,
    "icon_theme": "Lumen",
    # desktop widgets, top to bottom ([] hides them)
    "widgets": [{"kind": "clock", "size": "wide"}, {"kind": "weather", "size": "small"},
                {"kind": "calendar", "size": "small"}, {"kind": "system", "size": "wide"},
                {"kind": "media", "size": "wide"}],
    "widgets_position": "top-right",   # top-left | top-right | bottom-left | bottom-right
    "widgets_columns": 2,
    "weather_location": "",      # "" = guess from your IP; or e.g. "Toronto"
    "search_url": "https://www.google.com/search?q=%s",
    "weather_units": "c",
    "startup_animation": True,   # the Lumen mark fading into the desktop at login
}


def save_config(changes):
    """merge `changes` into ~/.config/lumen/shell.json"""
    path = os.path.join(CONFIG_DIR, "shell.json")
    try:
        with open(path) as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {}
    data.update(changes)
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def load_config():
    cfg = dict(DEFAULTS)
    try:
        with open(os.path.join(CONFIG_DIR, "shell.json")) as f:
            cfg.update(json.load(f))
    except (OSError, ValueError):
        pass
    # configs written by early versions pointed "System Settings" at the raw text file
    if "lumen.conf" in cfg.get("settings", "") or not cfg.get("settings"):
        cfg["settings"] = "lumen-settings"
    if cfg.get("launcher") == "rofi -show drun -theme lumen":   # → glass-style-aware Spotlight
        cfg["launcher"] = "lumen-launcher"
    # pins from early versions: GNOME apps that usually aren't installed → Lumen's own
    swap = {"org.gnome.Nautilus.desktop": "org.lumen.Files.desktop",
            "lumen-files.desktop": "org.lumen.Files.desktop",
            "org.gnome.Settings.desktop": "lumen-settings.desktop"}
    pins = []
    for did in cfg.get("pinned", []):
        new = swap.get(did)
        if new and (did == "lumen-files.desktop" or not os.path.exists("/usr/share/applications/" + did)):
            did = new
        if did not in pins:
            pins.append(did)
    cfg["pinned"] = pins
    # the Lumen icon set arrived: move people off the old default once
    if cfg.get("icon_theme") in (None, "Papirus-Dark") and not cfg.get("lumen_icons_v1"):
        cfg["icon_theme"] = "Lumen"
        try:
            save_config({"icon_theme": "Lumen", "lumen_icons_v1": True})
        except OSError:
            pass
    global ICON_TILES, ICON_THEME
    ICON_TILES = bool(cfg.get("icon_tiles", True))
    ICON_THEME = cfg.get("icon_theme") or "Lumen"
    cfg["wallpaper"] = os.path.expanduser(cfg["wallpaper"])
    if not os.path.exists(cfg["wallpaper"]):
        local = os.path.join(HERE, "..", "..", "data", "wallpapers", "lumen-flow.jpg")
        cfg["wallpaper"] = os.path.abspath(local)
    return cfg


# ------------------------------------------------------------------ helpers
def lbl(text="", cls=None, **kw):
    w = Gtk.Label(label=text, **kw)
    if cls:
        for c in cls.split():
            w.add_css_class(c)
    return w


def logo_gicon(name):
    """The Lumen logo straight from its SVG file, so a stale icon cache (or a theme
    without it) can never turn it into the 'missing icon' symbol."""
    rel = os.path.join("icons", "hicolor", "scalable", "apps", name + ".svg")
    dirs = [os.path.join(HERE, "..", "..", "data"), os.path.expanduser("~/.local/share"),
            "/usr/share", "/usr/local/share"]
    dirs += [d for d in os.environ.get("XDG_DATA_DIRS", "").split(":") if d]
    for d in dirs:
        p = os.path.join(d, rel)
        if os.path.isfile(p):
            return Gio.FileIcon.new(Gio.File.new_for_path(os.path.realpath(p)))
    return Gio.ThemedIcon.new(name)


def conf_value(key, default):
    """a value from ~/.config/lumen/lumen.conf (the compositor's config)"""
    for path in (os.path.join(CONFIG_DIR, "lumen.conf"), "/etc/lumen/lumen.conf"):
        try:
            with open(path) as f:
                for line in f:
                    k, eq, v = line.partition("=")
                    if not eq or k.strip() != key:
                        continue
                    # comments start with " #"; a value may itself start with "#"
                    # (colours like "#1c1f2a8c"), so look for one after the value
                    v = v.strip()
                    cut = v.find(" #", 1)
                    v = (v[:cut] if cut > 0 else v).strip()
                    if v:
                        return v
        except OSError:
            pass
    return default


_motion = {"t": 0, "k": 1.0}


def motion_ms(base):
    """a UI animation length at the user's speed (Settings → Glass & Motion):
    0 when animations are off or Performance mode is on. Re-read every few s."""
    now = GLib.get_monotonic_time()
    if now - _motion["t"] > 3_000_000:
        _motion["t"] = now
        on = conf_value("animations", "true").lower() != "false" and \
            conf_value("performance_mode", "false").lower() != "true"
        try:
            ms = float(conf_value("anim_ms", "380"))
        except ValueError:
            ms = 380.0
        _motion["k"] = max(0.3, min(2.5, ms / 380.0)) if on else 0.0
    return int(base * _motion["k"])


def _motion_scale():
    """1.0 at the default speed, 0 when animations are off"""
    motion_ms(100)
    return _motion["k"]


def performance_mode():
    return conf_value("performance_mode", "false").lower() == "true"


def set_conf_value(key, value):
    """change one key in ~/.config/lumen/lumen.conf (keeps comments/order)"""
    path = os.path.join(CONFIG_DIR, "lumen.conf")
    try:
        with open(path) as f:
            lines = f.read().splitlines()
    except OSError:
        lines = []
    out, done = [], False
    for line in lines:
        k = line.split(" #", 1)[0].partition("=")[0].strip()
        if k == key and not done:
            out.append(f"{key} = {value}")
            done = True
        else:
            out.append(line)
    if not done:
        out.append(f"{key} = {value}")
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(path + ".tmp", "w") as f:
        f.write("\n".join(out) + "\n")
    os.replace(path + ".tmp", path)
    _motion["t"] = 0


def browser_cmd():
    """the browser Super+B opens"""
    return conf_value("browser", "firefox")


def glass_style():
    return os.environ.get("LUMEN_GLASS") or conf_value("glass_style", "frosted")


def light_mode():
    """Settings → Appearance → Light (lumen.conf: color_scheme = light)"""
    return (os.environ.get("LUMEN_SCHEME") or conf_value("color_scheme", "dark")).strip().lower() == "light"


def ink():
    """what we draw with by hand (rings, clock faces): white on dark glass, dark on light"""
    return (0.09, 0.10, 0.16) if light_mode() else (1.0, 1.0, 1.0)


# ------------------------------------------------------------ liquid glass
class GlassLink:
    """Tells the compositor where our glass panes are, so it can bend the light
    at their rims (glass_style = liquid). One persistent socket; identical
    updates are dropped, so streaming during animations is cheap."""

    def __init__(self):
        self.sock = None
        self.last = {}
        self.enabled = False
        self.hold = False

    def _write(self, line):
        import socket as _s
        for _ in range(2):
            try:
                if self.sock is None:
                    sk = _s.socket(_s.AF_UNIX, _s.SOCK_STREAM)
                    sk.settimeout(0.2)
                    sk.connect(ipc.socket_path())
                    sk.setblocking(False)
                    self.sock = sk
                self.sock.sendall((line + "\n").encode())
                return
            except OSError:
                try:
                    self.sock and self.sock.close()
                except OSError:
                    pass
                self.sock = None

    def send(self, ns, panes):
        """panes: tuples of 12 numbers from pane_shape()"""
        if not self.enabled and panes:
            return
        if self.hold and panes and ns.split("@")[0] in ("lumen-taskbar", "lumen-topbar", "lumen-widgets"):
            return                      # startup: the bars are still hidden
        line = "glass " + ns + "".join(" " + " ".join(f"{v:.1f}" for v in p) for p in panes)
        if self.last.get(ns) == line:
            return
        self.last[ns] = line
        self._write(line)

    def set_enabled(self, on):
        if self.enabled and not on:
            for ns in list(self.last):
                self.send(ns, [])
        self.enabled = on


GLASS = GlassLink()


def glass_ns(base, monitor=None, win=None):
    """The name panes are reported under: per screen ("lumen-taskbar@DP-1"), as
    two screens of different sizes have their docks and widgets in different
    places — under one shared name, whichever bar reported last moved the glass
    on both."""
    conn = getattr(win, "lumen_conn", None)
    if conn is None and monitor is not None and hasattr(monitor, "get_connector"):
        conn = monitor.get_connector()
    return f"{base}@{conn}" if conn else base


def follow_frames(widget, fn):
    """Call fn() after every frame the window of `widget` draws.

    Whatever moves a glass pane (an arrival animation, a CSS transition, the
    dock growing by an icon) draws frames while it does, so reporting the panes
    after each frame keeps the compositor's glass exactly on them. Reporting at
    chosen moments instead left the glass wherever the pane happened to be at
    that moment: the Search pill's lens a few pixels off after login, the dock's
    glass a step behind the dock. No frames, no calls: an idle bar costs nothing,
    and GLASS drops reports that say nothing new."""
    state = {"clock": None}

    def attach(*_a):
        clock = widget.get_frame_clock()
        if clock is None or clock is state["clock"]:
            return
        state["clock"] = clock
        clock.connect("after-paint", lambda *_c: fn())
    if widget.get_realized():
        attach()
    widget.connect("realize", attach)
    widget.connect("map", attach)


def widget_rect(w, relative_to):
    ok, b = w.compute_bounds(relative_to)
    if not ok:
        return None
    x, y = b.origin.x, b.origin.y
    if isinstance(relative_to, Gtk.Native):
        # widget coords → surface coords (GTK may inset the window inside its surface)
        sx, sy = relative_to.get_surface_transform()
        x, y = x + sx, y + sy
    return (x, y, b.size.width, b.size.height)


# corner radii exactly as style.css draws them
RADII = (("startmenu", 22), ("notif", 20), ("preview-card", 20), ("card", 22), ("menu", 14), ("search-pill", None),
         ("dock", 24), ("taskbar", None))
def card_radius(card):
    h = card.get_height()
    for cls, r in RADII:
        if card.has_css_class(cls):
            return h / 2 if r is None else min(r, h / 2)
    return 14


def pane_shape(pane, rel, radius=None, clip=None, open_edges=(), shadow=1.0, frost=1.0):
    """One glass pane as the compositor needs it (14 numbers):
    x y w h · corner radii tl tr br bl · bevel per edge top right bottom left
    (999 = as deep as the pane allows, 0 = flat) · shadow · frost.
    The compositor lenses the *backdrop* and redraws our content on top, so the
    whole pane can refract without ever bending text or icons.
    `clip`: visible area while a revealer slides (hidden edges: square, flat);
    `open_edges`: edges that sit on the screen border."""
    b = widget_rect(pane, rel)
    if not b or b[2] < 8 or b[3] < 8:
        return None
    x, y, w, h = b
    r = card_radius(pane) if radius is None else radius
    m = [999.0, 999.0, 999.0, 999.0]   # top right bottom left
    radii = [r, r, r, r]               # tl tr br bl
    if clip:
        X0, Y0, X1, Y1 = max(x, clip[0]), max(y, clip[1]), min(x + w, clip[0] + clip[2]), min(y + h, clip[1] + clip[3])
        if X1 - X0 < 8 or Y1 - Y0 < 8:
            return None
        cut = (Y0 > y + 0.5, X1 < x + w - 0.5, Y1 < y + h - 0.5, X0 > x + 0.5)  # top right bottom left
        for i, c in enumerate(cut):
            if c:
                m[i] = 0
                for k in ((0, 1), (1, 2), (2, 3), (3, 0))[i]:
                    radii[k] = 0
        x, y, w, h = X0, Y0, X1 - X0, Y1 - Y0
    for e in open_edges:
        m["trbl".index(e)] = 0
        for k in {"t": (0, 1), "r": (1, 2), "b": (2, 3), "l": (3, 0)}[e]:
            radii[k] = 0
    return (x, y, w, h, *radii, *m, shadow, frost)


def browser_name():
    b = os.path.basename(browser_cmd().split()[0])
    return {"firefox": "Firefox", "chromium": "Chromium", "brave": "Brave",
            "google-chrome-stable": "Chrome", "librewolf": "LibreWolf", "zen-browser": "Zen"}.get(b, b.capitalize())


def browser_icon():
    b = os.path.basename(browser_cmd().split()[0])
    theme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default())
    for n in (b, b.replace("-stable", ""), "firefox", "web-browser"):
        if theme.has_icon(n):
            return n
    return "web-browser"


def browser_search_cmd(q):
    """Search the web: a new tab in the running browser (or a new browser).
    --new-tab with a URL is the one remote command every browser honours, so
    it works whether or not the browser is already open."""
    from urllib.parse import quote_plus
    b = browser_cmd()
    if not q:
        return f"{b} --new-window" if any(x in b for x in ("firefox", "librewolf", "zen", "chrom", "brave")) else b
    url = load_config().get("search_url", "https://www.google.com/search?q=%s").replace("%s", quote_plus(q))
    if any(x in b for x in ("firefox", "librewolf", "zen")):
        return f"MOZ_DBUS_REMOTE=1 {b} --new-tab {shlex.quote(url)}"
    return f"{b} {shlex.quote(url)}"


def icon(name, size=None, cls=None):
    if isinstance(name, str) and name.startswith("lumen-logo"):
        name = logo_gicon(name)
    img = Gtk.Image.new_from_gicon(name) if isinstance(name, Gio.Icon) else Gtk.Image.new_from_icon_name(name)
    if size:
        img.set_pixel_size(size)
    if cls:
        img.add_css_class(cls)
    return img


ICON_TILES = True     # set from shell.json "icon_tiles" (Settings → Taskbar)
ICON_THEME = "Lumen"
_lumen_names = None


def lumen_drawn(name):
    """True if this icon is one of Lumen's own designs (already on its glass tile)"""
    global _lumen_names
    if isinstance(name, Gio.ThemedIcon):
        names = name.get_names()
    elif isinstance(name, str):
        names = [name]
    else:
        return False
    if any(n in ("lumen-app-generic", "lumen-files") for n in names):
        return True
    if ICON_THEME != "Lumen":
        return False
    if _lumen_names is None:
        _lumen_names = set()
        for base in (os.path.join(HERE, "..", "..", "data", "icons"), os.path.expanduser("~/.local/share/icons"),
                     "/usr/local/share/icons", "/usr/share/icons"):
            d = os.path.join(base, "Lumen", "scalable", "apps")
            if os.path.isdir(d):
                _lumen_names.update(f[:-4] for f in os.listdir(d) if f.endswith(".svg"))
    return any(n in _lumen_names for n in names)


def app_icon(name, size=None):
    """an app's icon in Lumen's style: seated on a frosted squircle tile so
    every app's icon (whatever its own shape) looks like part of one set.
    Icons the Lumen theme draws itself already sit on their own glass tile."""
    img = icon(name, size)
    if not ICON_TILES or lumen_drawn(name):
        return img
    tile = Gtk.Box(halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
    tile.add_css_class("ico-tile")
    tile.append(img)
    return tile


def box(orient=Gtk.Orientation.HORIZONTAL, spacing=0, cls=None, *children, **kw):
    b = Gtk.Box(orientation=orient, spacing=spacing, **kw)
    if cls:
        for c in cls.split():
            b.add_css_class(c)
    for ch in children:
        b.append(ch)
    return b


def button(child, cls=None, on_click=None, tooltip=None):
    b = Gtk.Button()
    b.set_child(child)
    b.set_has_frame(False)
    if cls:
        for c in cls.split():
            b.add_css_class(c)
    if on_click:
        b.connect("clicked", lambda *_: on_click())
    if tooltip:
        b.set_tooltip_text(tooltip)
    return b


def clickable(widget, on_click):
    g = Gtk.GestureClick()
    g.connect("released", lambda *_: on_click())
    widget.add_controller(g)
    widget.set_cursor(Gdk.Cursor.new_from_name("pointer"))
    return widget


def app_info(desktop_id):
    try:
        return Gio.DesktopAppInfo.new(desktop_id)
    except TypeError:
        return None


_wm_index = None
# games whose window class names no .desktop file: show the launcher they came from
GAME_LAUNCHERS = {
    "minecraft": ["org.prismlauncher.PrismLauncher", "prismlauncher", "lunarclient", "lunar-client",
                  "com.modrinth.ModrinthApp", "modrinth-app", "minecraft-launcher", "atlauncher",
                  "org.polymc.PolyMC", "multimc", "com.atlauncher.ATLauncher"],
    "steam_app": ["steam"],
}


def _wm_class_index():
    """StartupWMClass → app, for apps whose window class isn't their .desktop name"""
    global _wm_index
    if _wm_index is None:
        _wm_index = {}
        for ai in Gio.AppInfo.get_all():
            wm = ai.get_startup_wm_class() if hasattr(ai, "get_startup_wm_class") else None
            if wm:
                _wm_index.setdefault(wm.lower(), ai.get_id())
            exe = (ai.get_executable() or "").split("/")[-1].lower()
            if exe:
                _wm_index.setdefault("exe:" + exe, ai.get_id())
    return _wm_index


def app_for_window(app_id, title=None):
    if not app_id and not title:
        return None
    aid = app_id or ""
    # X11 classes can carry versions and symbols: "Minecraft* 1.21.4" → "minecraft"
    base = "".join(c for c in aid.split(" ")[0] if c.isalnum() or c in ".-_").lower()
    for cand in (aid, aid.lower(), aid.split(".")[-1].lower(), base):
        if cand:
            ai = app_info(cand + ".desktop")
            if ai:
                return ai
    idx = _wm_class_index()
    for key in (aid.lower(), base, "exe:" + base):
        if key and key in idx:
            ai = app_info(idx[key])
            if ai:
                return ai
    probe = f"{aid} {title or ''}".lower()
    for word, launchers in GAME_LAUNCHERS.items():
        if word in probe or (word == "steam_app" and aid.lower().startswith("steam_app_")):
            for lid in launchers:
                ai = app_info(lid + ".desktop")
                if ai:
                    return ai
    for group in Gio.DesktopAppInfo.search(base or aid):
        if group:
            return app_info(group[0])
    return None


def icon_for(appinfo, app_id=None):
    theme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default())
    ic = appinfo.get_icon() if appinfo else None
    if ic is not None:
        # an icon name no theme has would draw as a "broken image": fall through instead
        if not isinstance(ic, Gio.ThemedIcon) or any(theme.has_icon(n) for n in ic.get_names()):
            return ic
        app_id = app_id or (appinfo.get_id() or "").removesuffix(".desktop")
    base = "".join(c for c in (app_id or "").split(" ")[0] if c.isalnum() or c in ".-_").lower()
    for n in filter(None, [app_id, (app_id or "").lower(), (app_id or "").split(".")[-1].lower(), base]):
        if theme.has_icon(n):
            return n
    if "minecraft" in (app_id or "").lower() and theme.has_icon("minecraft"):
        return "minecraft"
    return "lumen-app-generic"   # not a settings gear: a plain Lumen app tile


def desktop_key(desktop_id):
    return desktop_id.removesuffix(".desktop").lower()


# --------------------------------------------------------- layer windows
class LayerWin(Gtk.Window):
    def __init__(self, app, namespace, layer="top", anchors=(), exclusive=None,
                 keyboard="none", monitor=None, margins=None):
        super().__init__(application=app)
        self.set_decorated(False)
        self.add_css_class("lumen")
        self.lumen_conn = (monitor.get_connector() if monitor is not None and hasattr(monitor, "get_connector")
                           else None)
        if LS:
            LS.init_for_window(self)
            LS.set_namespace(self, namespace)
            LS.set_layer(self, {"background": LS.Layer.BACKGROUND, "bottom": LS.Layer.BOTTOM,
                                "top": LS.Layer.TOP, "overlay": LS.Layer.OVERLAY}[layer])
            for e in anchors:
                LS.set_anchor(self, {"t": LS.Edge.TOP, "b": LS.Edge.BOTTOM,
                                     "l": LS.Edge.LEFT, "r": LS.Edge.RIGHT}[e], True)
            for e, m in (margins or {}).items():
                LS.set_margin(self, {"t": LS.Edge.TOP, "b": LS.Edge.BOTTOM,
                                     "l": LS.Edge.LEFT, "r": LS.Edge.RIGHT}[e], m)
            if exclusive == "auto":
                LS.auto_exclusive_zone_enable(self)
            elif exclusive is not None:
                LS.set_exclusive_zone(self, exclusive)
            LS.set_keyboard_mode(self, {"none": LS.KeyboardMode.NONE,
                                        "exclusive": LS.KeyboardMode.EXCLUSIVE,
                                        "on_demand": LS.KeyboardMode.ON_DEMAND}[keyboard])
            if monitor is not None:
                LS.set_monitor(self, monitor)


# ------------------------------------------------------------------ top bar
class TopBar:
    """macOS-style menu bar: logo menu, bold app name, Window menu, workspaces,
    and status items + clock on the right."""

    def __init__(self, shell, monitor=None):
        self.shell = shell
        self.connector = monitor.get_connector() if monitor is not None and hasattr(monitor, "get_connector") else None
        comp = shell.comp
        self.logo = button(icon("lumen-logo-symbolic"), "item logo", lambda: shell.toggle("logo"))
        self.appname = lbl("Finder", "item appname")
        clickable(self.appname, lambda: shell.toggle("window"))
        self.window_item = lbl("Window", "item")
        clickable(self.window_item, lambda: shell.toggle("window"))
        self.go_item = lbl("Go", "item")
        clickable(self.go_item, lambda: system.run(shell.cfg["launcher"]))
        self.dots = box(cls="ws", valign=Gtk.Align.CENTER, margin_start=10)
        self._dots = []
        left = box(Gtk.Orientation.HORIZONTAL, 2, None, self.logo, self.appname,
                   self.go_item, self.window_item, self.dots)

        self.media = lbl("", "item media", max_width_chars=28, ellipsize=3)
        clickable(self.media, lambda: shell.toggle("control"))
        self.wifi = icon("network-wireless-signal-excellent-symbolic")
        self.vol = icon("audio-volume-high-symbolic")
        self.bat_icon = icon("battery-level-80-symbolic")
        self.bat_pct = lbl("", "bat-pct")
        self.battery = box(Gtk.Orientation.HORIZONTAL, 5, "item battery", self.bat_icon, self.bat_pct)
        clickable(self.battery, lambda: shell.toggle("battery"))
        status = box(Gtk.Orientation.HORIZONTAL, 14, "item", self.wifi, self.vol)
        clickable(status, lambda: shell.toggle("control"))
        self.cc = button(icon("open-menu-symbolic"), "item", lambda: shell.toggle("logo-right"),
                         "Lumen menu")
        self.search = button(icon("system-search-symbolic"), "item",
                             lambda: system.run(shell.cfg["launcher"]), "Search")
        self.clock = lbl("", "item clock")
        clickable(self.clock, lambda: shell.toggle("calendar"))
        # notifications: bell with an unread badge (crossed out during Do Not Disturb)
        self.bell_icon = icon("lumen-bell-symbolic")
        self.badge = lbl("", "n-badge", halign=Gtk.Align.END, valign=Gtk.Align.START)
        bell = Gtk.Overlay()
        bell.set_child(self.bell_icon)
        bell.add_overlay(self.badge)
        self.bell = button(bell, "item bell", lambda: shell.toggle("notifications"), "Notifications")
        right = box(Gtk.Orientation.HORIZONTAL, 2, None, self.media, self.battery, status, self.search, self.cc,
                    self.bell, self.clock)
        if getattr(shell, "notify", None):
            shell.track("notify", self.on_notify)
            shell.notify.listeners.append(self.on_notify)
            self.on_notify()

        cb = Gtk.CenterBox()
        cb.add_css_class("topbar")
        cb.set_start_widget(left)
        cb.set_end_widget(right)
        self.widget = cb
        shell.track("comp", comp.connect("changed", lambda *_: self.on_state()))
        self.on_state()
        shell.on_tick(self.tick)

    def on_notify(self):
        n = self.shell.notify
        self.bell_icon.set_from_icon_name("lumen-bell-off-symbolic" if n.silenced()
                                          else "lumen-bell-symbolic")
        self.badge.set_label(str(n.unread) if n.unread < 10 else "9+")
        self.badge.set_visible(n.unread > 0)
        (self.bell.add_css_class if n.unread else self.bell.remove_css_class)("unread")
        if n.unread > getattr(self, "_unread", 0) and not n.silenced():   # something new: the bell rings
            self.bell.add_css_class("ring")
            GLib.timeout_add(900, lambda: (self.bell.remove_css_class("ring"), False)[1])
        self._unread = n.unread

    def on_state(self):
        st = self.shell.comp.state
        f = self.shell.comp.focused
        name = "Desktop"
        if f:
            ai = app_for_window(f.get("app_id"), f.get("title"))
            name = ai.get_name() if ai else (f.get("app_id") or "App").split(".")[-1].capitalize()
        if name != self.appname.get_label():
            self.appname.set_label(name)
            if not self.shell.preview and motion_ms(100) > 0:
                # the new name settles in (two identical classes: an animation only
                # restarts when the class changes)
                nxt = "swap-b" if self.appname.has_css_class("swap-a") else "swap-a"
                self.appname.remove_css_class("swap-a")
                self.appname.remove_css_class("swap-b")
                self.appname.add_css_class(nxt)
        busy = {w["workspace"] for w in st.get("windows", [])}
        # this monitor's workspace (each monitor shows its own)
        outs = st.get("outputs", [])
        mine = next((o for o in outs if o.get("name") == self.connector), None)
        cur = mine["ws"] if mine else st.get("workspace")
        elsewhere = {o["ws"] for o in outs if o is not mine}
        total = st.get("workspaces", 10)
        # the dots stay (so the active one glides): one per desktop in use, plus a spare
        while len(self._dots) < total:
            i = len(self._dots) + 1
            d = Gtk.Box(valign=Gtk.Align.CENTER)
            d.add_css_class("ws-dot")
            d.set_tooltip_text(f"Desktop {i}")
            clickable(d, lambda i=i: ipc.send(f"workspace {i}"))
            self.dots.append(d)
            self._dots.append(d)
        used = [i for i in busy | elsewhere | {cur or 1} if isinstance(i, int)]
        shown = min(total, max(4, max(used, default=1) + 1))
        for i, d in enumerate(self._dots, start=1):
            state = "active" if i == cur else "other" if i in elsewhere else "busy" if i in busy else None
            for c in ("active", "other", "busy"):
                (d.add_css_class if c == state else d.remove_css_class)(c)
            (d.add_css_class if i > shown else d.remove_css_class)("gone")
            d.set_can_target(i <= shown)

    def tick(self, slow):
        fmt = "%a %b %-d  %H:%M" if self.shell.cfg["clock_24h"] else "%a %b %-d  %-I:%M %p"
        self.clock.set_label(time.strftime(fmt))
        if slow:
            self.on_notify()      # quiet hours begin / end
            b = self.shell.sys["battery"]
            self.bat_icon.set_from_icon_name(system.battery_icon(b))
            self.battery.set_visible(b is not None)
            if b:
                self.bat_pct.set_label(f"{b['percent']}%")
                for c in ("low", "charging"):
                    self.battery.remove_css_class(c)
                if b["charging"]:
                    self.battery.add_css_class("charging")
                elif b["percent"] <= 15:
                    self.battery.add_css_class("low")
            self.wifi.set_from_icon_name(system.wifi_icon(self.shell.sys["wifi"]))
            self.vol.set_from_icon_name(system.volume_icon(self.shell.sys["volume"]))
            np = self.shell.sys["media"]
            self.media.set_visible(bool(np))
            if np:
                self.media.set_label(("♪  " if np["playing"] else "❚❚  ") + np["title"])


# ------------------------------------------------------------ window previews
class WindowPreview:
    """Hover a taskbar app → its windows as live thumbnails above it (glass card).
    Click one to switch to it; × closes it."""

    THUMB_W, THUMB_H = 232, 148

    def __init__(self, shell, monitor=None):
        self.shell = shell
        self.win = LayerWin(shell.app, "lumen-preview", "overlay", "bl", None, monitor=monitor) \
            if not shell.preview else None
        self.card = box(Gtk.Orientation.HORIZONTAL, 10, "glass preview-card")
        if self.win:
            self.win.set_child(self.card)
            mc = Gtk.EventControllerMotion()
            mc.connect("enter", lambda *_: self.cancel_hide())
            mc.connect("leave", lambda *_: self.hide_soon())
            self.card.add_controller(mc)
        self._show_src = self._hide_src = None
        self.entry = None
        self.pics = {}

    def cancel_hide(self):
        if self._hide_src:
            GLib.source_remove(self._hide_src)
        self._hide_src = None

    def show_soon(self, e, anchor_x, bar_h):
        self.cancel_hide()
        if self._show_src:
            GLib.source_remove(self._show_src)
        delay = 120 if self.win and self.win.get_visible() else 450
        self._show_src = GLib.timeout_add(delay, lambda: (self.show(e, anchor_x, bar_h), False)[1])

    def hide_soon(self):
        if self._show_src:
            GLib.source_remove(self._show_src)
            self._show_src = None
        if not self._hide_src:
            self._hide_src = GLib.timeout_add(260, lambda: (self.hide(), False)[1])

    def hide(self):
        self._hide_src = None
        if self.win and self.win.get_visible():
            self.win.set_visible(False)
            GLASS.send("lumen-preview", [])
        self.entry = None

    def show(self, e, anchor_x, bar_h):
        self._show_src = None
        wins = e["windows"][:4]
        if not wins or self.win is None:
            return
        for ch in list(_children(self.card)):
            self.card.remove(ch)
        self.pics = {}
        for w in wins:
            pic = Gtk.Picture(content_fit=Gtk.ContentFit.CONTAIN, can_shrink=True)
            frame = WidgetCell(pic, self.THUMB_W, self.THUMB_H)
            frame.add_css_class("preview-thumb")
            close = button(icon("window-close-symbolic", 12), "preview-close",
                           lambda w=w: (ipc.send(f"close {w['id']}"), self.hide()), "Close")
            title = Marquee("preview-title")
            title.set_label(w.get("title") or e["name"])
            head = box(Gtk.Orientation.HORIZONTAL, 6, None, icon(e["icon"], 16), title, close)
            item = box(Gtk.Orientation.VERTICAL, 6, "preview-item" + (" focused" if w.get("focused") else ""),
                       head, frame)
            item.set_size_request(self.THUMB_W, -1)
            g = Gtk.GestureClick()
            g.connect("released", lambda *_a, w=w: (ipc.send(f"focus {w['id']}"), self.hide()))
            frame.add_controller(g)
            frame.set_cursor(Gdk.Cursor.new_from_name("pointer"))
            self.card.append(item)
            self.pics[w["id"]] = pic
        n = len(wins)
        width = n * self.THUMB_W + (n - 1) * 10 + 24
        if LS:
            LS.set_margin(self.win, LS.Edge.LEFT, int(max(8, anchor_x - width / 2)))
            # the compositor already keeps this above the taskbar (its exclusive zone):
            # just a small gap, not the bar's height again
            LS.set_margin(self.win, LS.Edge.BOTTOM, 8)
        self.win.present()
        self.entry = e
        self.fetch(wins)
        GLib.timeout_add(120, lambda: (GLASS.send("lumen-preview", [p for p in [
            pane_shape(self.card, self.win, 18, shadow=1.0, frost=0.9)] if p]), False)[1])

    def fetch(self, wins):
        rt = os.environ.get("XDG_RUNTIME_DIR", "/tmp")
        d = os.path.join(rt, "lumen-thumbs")
        os.makedirs(d, exist_ok=True)

        def work():
            for w in wins:
                path = os.path.join(d, f"{w['id']}.png")
                if ipc.request(f"thumb {w['id']} {self.THUMB_W * 2} {path}") == "ok":
                    GLib.idle_add(lambda i=w["id"], p=path: (self.set_thumb(i, p), False)[1])
        threading.Thread(target=work, daemon=True).start()

    def set_thumb(self, wid, path):
        pic = self.pics.get(wid)
        if pic is None:
            return
        try:
            pic.set_paintable(Gdk.Texture.new_from_filename(path))
        except GLib.Error:
            pass


# ------------------------------------------------------------------ taskbar
_bar_widths = {}


_dock_widths = {}


def _bar_width_css(screen, width, dock=None):
    """`.taskbar.bar.barw<screen>` gets its width (CSS has no "as wide as the screen").
    `dock`: the width the dock is shrinking to while it settles, so the change runs
    over the whole transition instead of stopping dead when it reaches its icons."""
    if _bar_widths.get(screen) == width and (dock is None or _dock_widths.get(screen) == dock):
        return
    _bar_widths[screen] = width
    if dock is not None:
        _dock_widths[screen] = dock
    css = "".join(f".taskbar.bar.barw{s} {{ min-width: {max(100, w)}px; }}\n" for s, w in _bar_widths.items())
    css += "".join(f".taskbar.dock.settling.barw{s} {{ min-width: {max(50, w)}px; }}\n"
                   for s, w in _dock_widths.items())
    if "barw" not in _providers:
        _providers["barw"] = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), _providers["barw"],
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 5)
    p = _providers["barw"]
    p.load_from_string(css) if hasattr(p, "load_from_string") else p.load_from_data(css.encode(), -1)


def taskbar_style(cfg):
    """"dock": a floating island that hugs its icons · "bar": edge to edge"""
    return "bar" if cfg.get("taskbar_style", "dock") == "bar" else "dock"


def bar_clearance(cfg):
    """how far above the screen's bottom edge a popup must sit to clear the taskbar"""
    return 86 if taskbar_style(cfg) == "dock" else 66


def _icon_id(ic):
    return ic.to_string() if isinstance(ic, Gio.Icon) else str(ic)


class Taskbar:
    """Centred taskbar (floating dock or full-width bar) with animated
    running/active pills. Buttons are kept between updates and only their state
    changes, so pills glide, hovers never flicker, and apps slide in and out."""

    def __init__(self, shell, monitor=None):
        self.shell = shell
        self.monitor = monitor
        self.items = {}            # key → {"btn", "pill", "rev", "entry", "icon"}
        self.buttons = []          # (entry, button) for the genie icon map
        self._icons_src = None
        self._first = True
        self.preview = WindowPreview(shell, monitor)
        self.tasks = box(Gtk.Orientation.HORIZONTAL, 0)
        start = self._task_button(icon("lumen-logo"), None, lambda: shell.toggle("start"), "Start")
        start.add_css_class("start")
        self.start_btn = start
        self.search_text = lbl("Search", "search-text", xalign=0, ellipsize=3, max_width_chars=20)
        self.caret = Gtk.Box(css_classes=["search-caret"], valign=Gtk.Align.CENTER, visible=False)
        search = box(Gtk.Orientation.HORIZONTAL, 10, "search-pill", icon("system-search-symbolic"),
                     box(Gtk.Orientation.HORIZONTAL, 1, None, self.search_text, self.caret),
                     valign=Gtk.Align.CENTER)
        clickable(search, shell.open_search)
        self.search = search
        self.sep = Gtk.Box(css_classes=["task-sep"])
        # One pane for both shapes: the dock hugs its icons, the bar is the same pane
        # stretched to the screen's width with square corners. Its contents stay
        # centred inside, so switching shape morphs one into the other (style.css).
        inner = box(Gtk.Orientation.HORIZONTAL, 0, None, start, search, self.sep, self.tasks,
                    halign=Gtk.Align.CENTER, hexpand=True, valign=Gtk.Align.CENTER)
        self.center = box(Gtk.Orientation.HORIZONTAL, 0, "taskbar", inner,
                          valign=Gtk.Align.END, halign=Gtk.Align.CENTER)

        cb = Gtk.CenterBox()
        cb.add_css_class("taskbar-wrap")
        cb.set_center_widget(self.center)
        self.widget = cb
        self.pane = self.center    # the widget that is the glass
        self.glass_ns = glass_ns("lumen-taskbar", monitor)
        self._style = None
        self._heights = {}
        self.apply_style()
        cb.connect("map", lambda *_: (self.report_glass(), self.report_icons()))
        follow_frames(cb, self.glass_now)
        shell.taskbars.append(self)
        shell.track("taskbar", self)
        shell.track("comp", shell.comp.connect("changed", lambda *_: self.sync()))
        if self.preview.win is not None:
            shell.track("window", self.preview.win)
        self.sync()

    MORPH_MS = 420

    def screen_width(self):
        if self.monitor is not None:
            return self.monitor.get_geometry().width
        root = self.widget.get_root()
        return root.get_width() if root is not None and root.get_width() > 100 else 1920

    def apply_style(self):
        style = taskbar_style(self.shell.cfg)
        liquid = glass_style() == "liquid"
        W = self.screen_width()
        # the bar's width: the screen's (a capsule just inside it on Liquid Glass),
        # less the pane's own padding and border
        _bar_width_css(W, (W - 58) if liquid else (W - 18))
        self._input_rect = None
        old = self._style
        self._style = style
        for c in self.center.get_css_classes():
            if c.startswith("barw"):
                self.center.remove_css_class(c)
        (self.center.add_css_class if style == "dock" else self.center.remove_css_class)("dock")
        (self.center.add_css_class if style == "bar" else self.center.remove_css_class)("bar")
        self.center.add_css_class(f"barw{W}")
        if old is not None and old != style:
            self.morph(old)
        elif old is not None and pouring():
            self.morph(old, POUR_MS)       # same shape, other glass: the bar ⇄ capsule flows too

    def morph(self, old, base_ms=None):
        """the shape changed: while the pane flows into its new shape (a CSS
        transition) the surface keeps one height, the glass follows the pane frame
        by frame, and the click area is set again at the end"""
        ms = motion_ms(base_ms or self.MORPH_MS)
        cb = self.widget
        h0 = cb.get_height()
        if h0 > 8 and base_ms is None:
            self._heights[old] = h0
        if ms <= 0 or h0 <= 8:
            GLib.timeout_add(120, lambda: (self.report_glass(), False)[1])
            return
        cb.set_size_request(-1, max(h0, self._heights.get(self._style, 78 if self._style == "dock" else 0),
                                    70 if base_ms else 0))
        if self._style == "dock" and base_ms is None:
            W = self.screen_width()
            nat = self.center.get_first_child().measure(Gtk.Orientation.HORIZONTAL, -1)[1]
            _bar_width_css(W, _bar_widths.get(W, W), dock=nat)
            self.center.add_css_class("settling")
        gen = self._morph_gen = getattr(self, "_morph_gen", 0) + 1
        t_end = GLib.get_monotonic_time() + (ms + 160) * 1000

        def tick(_w, _clock):
            if gen != self._morph_gen:
                return False
            root = cb.get_root()
            if GLASS.enabled and root is not None:
                panes = [pane_shape(self.pane, root, shadow=1.0, frost=0.5),
                         pane_shape(self.search, root, shadow=0.0, frost=0.3)]
                GLASS.send(self.glass_ns, [p for p in panes if p])
            if GLib.get_monotonic_time() < t_end:
                return True
            cb.set_size_request(-1, -1)
            self.center.remove_css_class("settling")
            self._input_rect = None
            self.report_glass()
            self.report_icons()
            return False
        cb.add_tick_callback(tick)

    def _task_button(self, img, pill, on_click, tooltip):
        img.add_css_class("task-icon")
        img.set_halign(Gtk.Align.CENTER)
        inner = box(Gtk.Orientation.VERTICAL, 0, None, img, valign=Gtk.Align.CENTER)
        if pill is not None:
            inner.append(pill)
        b = button(inner, "task", on_click, tooltip)
        b.set_valign(Gtk.Align.CENTER)
        return b

    def _next_ws(self):
        st = self.shell.comp.state
        ipc.send(f"workspace {st['workspace'] % st['workspaces'] + 1}")

    def entries(self):
        st = self.shell.comp.state
        out, by_key = [], {}
        for did in self.shell.cfg["pinned"]:
            ai = app_info(did)
            if ai is None and not self.shell.preview:
                continue
            key = desktop_key(did)
            if key in by_key:
                continue
            e = {"key": key, "app": ai, "icon": icon_for(ai, did.removesuffix(".desktop") if not ai else None),
                 "name": ai.get_name() if ai else key, "windows": [], "pinned": True, "desktop_id": did}
            out.append(e)
            by_key[key] = e
        for w in st.get("windows", []):
            ai = app_for_window(w.get("app_id"), w.get("title"))
            key = desktop_key(ai.get_id()) if ai else (w.get("app_id") or "").lower()
            e = by_key.get(key) or by_key.get((w.get("app_id") or "").lower())
            if not e:
                e = {"key": key, "app": ai, "icon": icon_for(ai, w.get("app_id")),
                     "name": ai.get_name() if ai else w.get("title", ""), "windows": [],
                     "pinned": False, "desktop_id": ai.get_id() if ai else None}
                out.append(e)
                by_key[key] = e
            e["windows"].append(w)
        return out

    def glass_now(self):
        """after every frame: the glass goes where the pane is now. The click
        area follows once the pane has stopped moving."""
        root = self.widget.get_root()
        if root is None or not GLASS.enabled or GLASS.hold or not self.widget.get_mapped():
            return
        before = GLASS.last.get(self.glass_ns)
        panes = [pane_shape(self.pane, root, shadow=1.0, frost=0.5),
                 pane_shape(self.search, root, shadow=0.0, frost=0.3)]
        GLASS.send(self.glass_ns, [p for p in panes if p])
        if GLASS.last.get(self.glass_ns) != before:
            if getattr(self, "_input_src", 0):
                GLib.source_remove(self._input_src)

            def settle():
                self._input_src = 0
                self.update_input_region()
                return False
            self._input_src = GLib.timeout_add(200, settle)

    def report_glass(self):
        """the dock (or bar) is one pane; the Search pill is its own little lens"""
        def go():
            root = self.widget.get_root()
            if root is None:
                return False
            panes = [pane_shape(self.pane, root, shadow=1.0, frost=0.5),
                     pane_shape(self.search, root, shadow=0.0, frost=0.3)]
            GLASS.send(self.glass_ns, [p for p in panes if p])
            self.update_input_region()
            return False
        GLib.timeout_add(80, go)

    def update_input_region(self):
        """the dock floats: clicks beside it go to whatever is behind (a window
        that reaches down there), not to the invisible rest of our surface"""
        root = self.widget.get_root()
        surf = root.get_surface() if isinstance(root, Gtk.Native) else None
        if surf is None or self.shell.preview:
            return
        try:
            import cairo
            r = widget_rect(self.pane, root)
            if not r or r[2] < 8:
                return
            r = (int(r[0]) - 2, int(r[1]) - 2, int(r[2]) + 4, int(r[3]) + 4 + 12)   # down to the screen edge
            if getattr(self, "_input_rect", None) != r:
                self._input_rect = r
                surf.set_input_region(cairo.Region(cairo.RectangleInt(*r)))
        except Exception as e:   # noqa: BLE001 — never worth breaking the bar over
            if not getattr(self, "_input_warned", False):
                self._input_warned = True
                print("lumen-shell: taskbar input region:", e, file=sys.stderr)

    def report_icons(self):
        """tell the compositor where each app's button is, so windows can flow
        out of (and back into) their icon — the genie effect"""
        if self._icons_src:
            return

        def go():
            self._icons_src = None
            root = self.widget.get_root()
            if root is None or self.shell.preview:
                return False
            mon = self.monitor
            if mon is None:
                mons = Gdk.Display.get_default().get_monitors()
                mon = mons.get_item(0) if mons.get_n_items() else None
            conn = mon.get_connector() if mon is not None else None
            if not conn:
                return False

            def clean(k):
                return "".join(c for c in (k or "").lower() if c.isalnum() or c in ".-_@")
            parts = []
            for e, b in [(None, self.start_btn)] + self.buttons:
                r = widget_rect(b, root)
                if not r or r[2] <= 0:
                    continue
                if e is None:
                    keys = ["@start"]
                else:
                    keys = [e["key"], e["key"].split(".")[-1]]
                    ai = e.get("app")
                    if ai is not None:
                        wm = ai.get_startup_wm_class() if hasattr(ai, "get_startup_wm_class") else None
                        keys += [wm or "", (ai.get_id() or "").removesuffix(".desktop")]
                        keys += [(ai.get_executable() or "").split("/")[-1]]
                    keys += [w.get("app_id") or "" for w in e["windows"]]
                keys = ",".join(dict.fromkeys(k for k in map(clean, keys) if k))
                if keys:
                    parts.append(f"{keys} {int(r[0])} {int(r[1])} {int(r[2])} {int(r[3])}")
            GLASS._write(f"icons {conn} " + "|".join(parts))
            return False
        self._icons_src = GLib.timeout_add(160, go)

    # ------------------------------------------------------ keeping in sync
    def rebuild(self):
        """settings changed (pins, icon theme, style): start from scratch"""
        self.apply_style()
        for key in list(self.items):
            self._drop(key, animate=False)
        self._first = True
        self.sync()

    def _add(self, e):
        key = e["key"]
        pill = Gtk.Box(halign=Gtk.Align.CENTER)
        pill.add_css_class("pill")
        pill.add_css_class("hidden")
        cur = lambda: self.items[key]["entry"] if key in self.items else e  # noqa: E731
        b = self._task_button(app_icon(e["icon"]), pill, lambda: self.activate(cur()), e["name"])
        g = Gtk.GestureClick(button=0)
        g.connect("pressed", lambda g, n, x, y: (self.preview.hide(), self.on_press(g, cur(), b)))
        b.add_controller(g)
        mc = Gtk.EventControllerMotion()   # hover → window previews
        mc.connect("enter", lambda *_a: cur()["windows"] and self.hover(cur(), b))
        mc.connect("leave", lambda *_a: self.preview.hide_soon())
        b.add_controller(mc)
        rev = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_RIGHT, child=b)
        animate = not self._first and not self.shell.preview
        rev.set_transition_duration(motion_ms(280) if animate else 0)
        self.tasks.append(rev)
        if animate:
            b.add_css_class("task-in")
            GLib.idle_add(lambda: (rev.set_reveal_child(True), False)[1])
            GLib.timeout_add(700, lambda: (b.remove_css_class("task-in"), False)[1])
        else:
            rev.set_reveal_child(True)
        # a Revealer clips its child; once it's fully open the icon may lift and bounce freely
        rev.connect("notify::child-revealed", lambda r, _p: r.set_overflow(
            Gtk.Overflow.VISIBLE if r.get_child_revealed() else Gtk.Overflow.HIDDEN))
        if not animate:
            rev.set_overflow(Gtk.Overflow.VISIBLE)
        it = {"btn": b, "pill": pill, "rev": rev, "entry": e, "icon": _icon_id(e["icon"])}
        self.items[key] = it
        return it

    def _drop(self, key, animate=True):
        it = self.items.pop(key, None)
        if not it:
            return
        rev = it["rev"]
        ms = motion_ms(220) if animate and not self.shell.preview else 0
        if ms <= 0:
            self.tasks.remove(rev)
            return
        it["btn"].add_css_class("task-out")
        it["btn"].set_sensitive(False)
        rev.set_overflow(Gtk.Overflow.HIDDEN)
        rev.set_transition_duration(ms)
        rev.set_reveal_child(False)
        GLib.timeout_add(ms + 40, lambda: (rev.get_parent() is self.tasks and self.tasks.remove(rev), False)[1])

    def sync(self):
        """bring the buttons in line with the pinned apps and open windows"""
        entries = self.entries()
        keys = {e["key"] for e in entries}
        changed = False
        for key in list(self.items):
            if key not in keys:
                self._drop(key)
                changed = True
        prev = None
        for e in entries:
            it = self.items.get(e["key"])
            if it is not None and it["icon"] != _icon_id(e["icon"]):
                self._drop(e["key"], animate=False)       # its icon changed: a fresh button
                it = None
            if it is None:
                it = self._add(e)
                changed = True
            it["entry"] = e
            # keep the order: pinned apps first, then by first window
            sib = it["rev"].get_prev_sibling()
            while sib is not None and sib.get_child() is not None and sib.get_child().has_css_class("task-out"):
                sib = sib.get_prev_sibling()
            if sib is not prev:
                self.tasks.reorder_child_after(it["rev"], prev)
                changed = True
            prev = it["rev"]
            wins = e["windows"]
            active = any(w.get("focused") for w in wins)
            for cls, on in (("hidden", not wins), ("active", active), ("multi", len(wins) > 1 and not active)):
                (it["pill"].add_css_class if on else it["pill"].remove_css_class)(cls)
            (it["btn"].add_css_class if active else it["btn"].remove_css_class)("active")
            if wins:
                it["btn"].remove_css_class("launching")
            it["btn"].set_tooltip_text(e["name"])
        self.sep.set_visible(bool(entries))
        self.buttons = [(e, self.items[e["key"]]["btn"]) for e in entries]
        self._first = False
        self.report_icons()
        if changed:           # the dock changes width as buttons slide in or out
            self.report_glass()
            for ms in (200, 420):
                GLib.timeout_add(motion_ms(ms) + 30, lambda: (self.report_glass(), self.report_icons(), False)[2])

    def show_query(self, q):
        """mirror what's typed in Start search, so typing 'happens' in the bar"""
        self.search_text.set_label(q or "Search")
        self.caret.set_visible(bool(q))
        for c in ("typing", "has-text"):
            (self.search.add_css_class if q else self.search.remove_css_class)(c)

    def set_start_open(self, on):
        (self.start_btn.add_css_class if on else self.start_btn.remove_css_class)("open")

    def hover(self, e, b):
        root = b.get_root()
        if root is None:
            return
        ok, pt = b.compute_point(root, Graphene.Point().init(b.get_width() / 2, 0))
        self.preview.show_soon(e, pt.x if ok else 0, self.widget.get_height() + 10)

    def on_press(self, gesture, e, b):
        btn = gesture.get_current_button()
        if btn == 3:      # right click: Windows 11-style jump list
            gesture.set_state(Gtk.EventSequenceState.CLAIMED)
            ok, pt = b.compute_point(b.get_root(), Graphene.Point().init(b.get_width() / 2, 0))
            self.shell.task_menu(e, pt.x if ok else 0)
        elif btn == 2 and is_file_manager(e):   # middle click on Files: its folders fan out
            gesture.set_state(Gtk.EventSequenceState.CLAIMED)
            ok, pt = b.compute_point(b.get_root(), Graphene.Point().init(b.get_width() / 2, 0))
            self.shell.popups["stack"].show_for(e, pt.x if ok else 0)
        elif btn == 2 and e["app"]:   # middle click: new window
            gesture.set_state(Gtk.EventSequenceState.CLAIMED)
            self.launch(e)

    def launch(self, e):
        """start the app; its icon bounces until a window shows up"""
        system.launch_app(e["app"], self.shell.cfg.get("terminal", "kitty"))
        it = self.items.get(e["key"])
        if it and not e["windows"]:
            b = it["btn"]
            b.add_css_class("launching")
            GLib.timeout_add(motion_ms(4500) + 50, lambda: (b.remove_css_class("launching"), False)[1])

    def activate(self, e):
        wins = e["windows"]
        if not wins:
            if e["app"]:
                self.launch(e)
            return
        if len(wins) == 1:
            ipc.send(f"toggle {wins[0]['id']}")
            return
        # several windows: cycle through them, starting after the focused one
        ids = [w["id"] for w in wins]
        foc = next((i for i, w in enumerate(wins) if w.get("focused")), -1)
        ipc.send(f"focus {ids[(foc + 1) % len(ids)]}")

# ----------------------------------------------------------------- popups
class Popup:
    """A full-output transparent overlay holding one glass card. Clicking the
    empty area or pressing Escape closes it. The card grows out of the thing
    that opened it with a soft spring (CSS, see `.pop` in style.css) while the
    Revealer fades it; closing tucks it back, a touch quicker."""

    IN_MS, OUT_MS = 300, 150

    def __init__(self, shell, name, card, halign, valign, margins, transition=None):
        self.shell, self.name, self.card = shell, name, card
        self.rev = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.CROSSFADE, transition_duration=220,
                                halign=halign, valign=valign)
        self.rev.set_overflow(Gtk.Overflow.VISIBLE)     # the card may spring past its box
        for side, m in margins.items():
            getattr(self.rev, f"set_margin_{side}")(m)
        self.origin = ("b" if valign == Gtk.Align.END else "t") + \
            ("l" if halign == Gtk.Align.START else "r" if halign == Gtk.Align.END else "")
        self.rev.set_child(card)
        self.adopt(card)
        self.win = None
        self._hide_src = None
        self._open = False

    def adopt(self, card):
        """mark a (new) card as this popup's animated pane"""
        card.add_css_class("pop")
        card.add_css_class({"tl": "from-tl", "tr": "from-tr", "t": "from-t", "b": "from-b",
                            "bl": "from-bl", "br": "from-b"}[self.origin])

    def build_window(self):
        win = LayerWin(self.shell.app, f"lumen-{self.name}", "overlay", "tblr", -1, "exclusive")
        overlay = Gtk.Overlay()
        catcher = Gtk.Box(hexpand=True, vexpand=True)
        g = Gtk.GestureClick(button=0)
        g.connect("pressed", lambda *_: self.close())
        catcher.add_controller(g)
        overlay.set_child(catcher)
        overlay.add_overlay(self.rev)
        win.set_child(overlay)
        k = Gtk.EventControllerKey()
        k.connect("key-pressed", lambda c, kv, *a: (self.close(), True)[1] if kv == Gdk.KEY_Escape else False)
        win.add_controller(k)
        self.win = win
        follow_frames(win, self.glass_frame)

    def glass_frame(self):
        """after every frame this menu draws: its lens goes where its card is now
        (the card springs in and out; a lens placed by a timer trails it)"""
        if not GLASS.enabled or self.win is None or not self.win.get_mapped():
            return
        GLASS.send(f"lumen-{self.name}", self.glass_rects() if self.rev.get_reveal_child() or
                   self.rev.get_child_revealed() else [])

    def set_keyboard(self, on):
        """Only the menu that is opening may hold the keyboard: a menu still
        sliding shut must not steal the first keystrokes of the next one."""
        if LS and self.win is not None:
            LS.set_keyboard_mode(self.win, LS.KeyboardMode.EXCLUSIVE if on else LS.KeyboardMode.NONE)

    def is_open(self):
        return bool(self._open and self.win and self.win.get_visible())

    def open(self):
        if self.win is None:
            self.build_window()
        if self._hide_src:                 # reopened while it was still closing
            GLib.source_remove(self._hide_src)
            self._hide_src = None
        self._open = True
        if self.origin.startswith("b"):    # sits just above the taskbar, whatever its shape
            self.rev.set_margin_bottom(bar_clearance(self.shell.cfg))
        self.rev.set_transition_duration(motion_ms(200))
        self.set_keyboard(True)
        self.on_open()
        card = self.rev.get_child()
        self.win.present()
        if card is not None:
            card.remove_css_class("pop-out")
            card.add_css_class("pop-in")
        GLib.timeout_add(16, lambda: (self._open and self.rev.set_reveal_child(True), False)[1])
        self.track_glass()
        self.opened()

    def close(self):
        if not self._open or not self.win or not self.win.get_visible():
            return
        self._open = False
        ms = motion_ms(self.OUT_MS)   # closing is a touch quicker
        card = self.rev.get_child()
        if card is not None:
            card.remove_css_class("pop-in")
            card.add_css_class("pop-out")
        self.rev.set_transition_duration(ms)
        self.rev.set_reveal_child(False)
        self.set_keyboard(False)
        self.track_glass()
        self.closed()

        def hide():
            self._hide_src = None
            self.win.set_visible(False)
            GLASS.send(f"lumen-{self.name}", [])
            return False
        if self._hide_src:
            GLib.source_remove(self._hide_src)
        self._hide_src = GLib.timeout_add(ms + 30, hide)

    def opened(self):
        pass

    def closed(self):
        pass

    def glass_rects(self):
        card = self.rev.get_child()
        if card is None or not self.win:
            return []
        p = pane_shape(card, self.win)
        return [p] if p else []

    def track_glass(self):
        if not GLASS.enabled or getattr(self, "_glass_tick", None):
            return
        self._settled = 0

        def tick(widget, clock):
            GLASS.send(f"lumen-{self.name}", self.glass_rects() if self.rev.get_reveal_child() or
                       self.rev.get_child_revealed() else [])
            moving = self.rev.get_child_revealed() != self.rev.get_reveal_child()
            self._settled = 0 if moving else self._settled + 1
            if self._settled > 14:        # the spring settles a little after the fade
                self._glass_tick = None
                return False
            return True
        self._glass_tick = self.rev.add_tick_callback(tick)

    def toggle(self):
        if self.is_open():
            self.close()
        else:
            self.shell.close_all(except_=self.name)
            self.open()

    def on_open(self):
        pass


def menu_card(items, after=None):
    """items: (label, accel, callback) tuples or None for a separator.
    `after` runs once an item is chosen (closes the menu so the app opened by the
    item isn't hidden under it)."""
    m = box(Gtk.Orientation.VERTICAL, 0, "glass menu")
    for it in items:
        if it is None:
            sep = Gtk.Box()
            sep.add_css_class("menu-sep")
            m.append(sep)
            continue
        text, accel, cb = it
        row = box(Gtk.Orientation.HORIZONTAL, 18, None, lbl(text, xalign=0, hexpand=True))
        if accel:
            row.append(lbl(accel, "accel"))
        m.append(button(row, "menu-item", (lambda cb=cb: (after and after(), cb())) if after else cb))
    return m


def menu_row(text, icon_name=None, cb=None, cls="menu-item", accel=None):
    row = box(Gtk.Orientation.HORIZONTAL, 12)
    if icon_name:
        row.append(icon(icon_name, 16))
    row.append(lbl(text, xalign=0, hexpand=True, ellipsize=3, max_width_chars=30))
    if accel:
        row.append(lbl(accel, "accel"))
    return button(row, cls, cb)


class TaskMenu(Popup):
    """Right-click menu for a taskbar app (rebuilt for every open)."""

    def __init__(self, shell):
        super().__init__(shell, "task", Gtk.Box(), Gtk.Align.START, Gtk.Align.END, {"bottom": 60})
        self.origin = "b"       # it opens centred over the icon that was clicked

    def show_for(self, e, x):
        sh = self.shell
        done = lambda f: (lambda: (f(), self.close()))  # noqa: E731
        wins = e["windows"]
        focused = next((w for w in wins if w.get("focused")), wins[0] if wins else None)
        m = box(Gtk.Orientation.VERTICAL, 0, "glass menu taskmenu")
        head = box(Gtk.Orientation.HORIZONTAL, 10, "menu-head", icon(e["icon"], 22),
                   lbl(e["name"], "menu-title", xalign=0, hexpand=True, ellipsize=3, max_width_chars=26))
        m.append(head)
        # music / video playing in this app (Spotify, a YouTube tab…): controls right here
        player = None
        if wins or e["pinned"]:
            if sh.preview:
                np_ = sh.sys.get("media")
                player = np_ if np_ and np_.get("app", "") in e["key"] else None
            else:
                player = system.player_for_app(e["key"])
                if player:
                    player["art"] = system.art_path(player["art_url"])
        if player:
            np = NowPlaying(sh, art=44, title_cls="menu-np-title", artist_cls="menu-np-sub")
            np.update(player)
            m.append(box(Gtk.Orientation.VERTICAL, 8, "menu-media",
                         box(Gtk.Orientation.HORIZONTAL, 10, None, np.art, np.text), np.controls))
        if len(wins) > 1:
            m.append(lbl("Windows", "menu-section", xalign=0))
            for w in wins:
                m.append(menu_row(w.get("title") or e["name"], "window-new-symbolic" if w.get("focused") else None,
                                  done(lambda w=w: ipc.send(f"focus {w['id']}"))))
        # separators are only drawn between two non-empty groups
        pending = [False]
        real_append = m.append

        def add(w):
            if pending[0] and m.get_last_child() is not head:
                real_append(Gtk.Box(css_classes=["menu-sep"]))
            pending[0] = False
            real_append(w)
        m.append = add

        def sep():
            pending[0] = True
        sep()
        if e["app"]:
            m.append(menu_row("New window", "window-new-symbolic", done(lambda: system.launch_app(e["app"], sh.cfg.get("terminal", "kitty")))))
            if e["desktop_id"]:
                if e["pinned"]:
                    m.append(menu_row("Unpin from taskbar", "view-pin-symbolic",
                                      done(lambda: sh.set_pinned(e["desktop_id"], False))))
                else:
                    m.append(menu_row("Pin to taskbar", "view-pin-symbolic",
                                      done(lambda: sh.set_pinned(e["desktop_id"], True))))
        if focused:
            sep()
            if focused.get("minimized"):
                m.append(menu_row("Restore", "view-restore-symbolic", done(lambda: ipc.send(f"focus {focused['id']}"))))
            else:
                m.append(menu_row("Minimize", "window-minimize-symbolic",
                                  done(lambda: ipc.send(f"minimize {focused['id']}"))))
            m.append(menu_row("Restore size" if focused.get("maximized") else "Maximize",
                              "window-maximize-symbolic", done(lambda: ipc.send(f"maximize {focused['id']}"))))
            m.append(menu_row("Keep on Top", "object-select-symbolic" if focused.get("on_top") else "go-top-symbolic",
                              done(lambda: ipc.send(f"ontop {focused['id']}"))))
            grid = Gtk.Grid(column_spacing=4, row_spacing=4, column_homogeneous=True, hexpand=True)
            cur = focused.get("workspace", 1)
            for n in range(1, sh.comp.state.get("workspaces", 10) + 1):
                chip = button(lbl(str(n)), "ws-chip" + (" current" if n == cur else ""),
                              done(lambda n=n: ipc.send(f"move {focused['id']} {n}")))
                grid.attach(chip, (n - 1) % 5, (n - 1) // 5, 1, 1)
            m.append(box(Gtk.Orientation.VERTICAL, 4, "move-row",
                         lbl("Move to desktop", "menu-label", xalign=0), grid))
            if conf_value("tiling", "false").lower() in ("true", "yes", "1", "on"):
                m.append(menu_row("Float window" if not focused.get("floating") else "Tile window",
                                  "view-dual-symbolic", done(lambda: ipc.send(f"float {focused['id']}"))))
            sep()
            if len(wins) > 1:
                m.append(menu_row("Close all windows", "window-close-symbolic",
                                  done(lambda: [ipc.send(f"close {w['id']}") for w in wins]), "menu-item danger"))
            else:
                m.append(menu_row("Close window", "window-close-symbolic",
                                  done(lambda: ipc.send(f"close {focused['id']}")), "menu-item danger"))
        m.set_size_request(260, -1)
        self.card = m
        self.rev.set_child(m)
        self.adopt(m)
        self.rev.set_margin_start(int(max(8, x - 130)))
        if self.shell.preview:
            return
        self.shell.close_all(except_=self.name)
        self.open()


FILE_MANAGERS = ("files", "nautilus", "thunar", "dolphin", "nemo", "pcmanfm", "caja")


def is_file_manager(e):
    """a taskbar entry that is a file manager (Lumen Files, or whichever is pinned)"""
    did = (e.get("desktop_id") or e.get("key") or "").lower()
    return any(n in did for n in FILE_MANAGERS)


class FolderFan(Popup):
    """Middle-click the Files icon: your folders spring out of the dock in a fan,
    like a stack on macOS. Nearest the dock is Home, then Downloads, Documents and
    the rest, then your sidebar bookmarks; the arrow at the top opens Files itself.
    Each one flies out of the icon to its place along a curve that leans right,
    one after another, and they fall back the same way."""

    STEP, ICON, WIDTH, MAX = 70, 56, 380, 9

    def __init__(self, shell):
        self.shell = shell
        self.fixed = Gtk.Fixed()
        self.fixed.add_css_class("fan")
        self.items = []
        self._css = None
        super().__init__(shell, "stack", self.fixed, Gtk.Align.START, Gtk.Align.END, {"bottom": 60})
        for c in ("pop", "from-b"):          # the items do the moving, not the box they sit in
            self.fixed.remove_css_class(c)

    def folders(self):
        home = os.path.expanduser("~")
        out, seen = [("Home", home, "user-home")], {home}
        if self.shell.preview:
            return out + [(n, os.path.join(home, n), ic) for n, ic in (
                ("Downloads", "folder-download"), ("Documents", "folder-documents"), ("Desktop", "user-desktop"),
                ("Pictures", "folder-pictures"), ("Music", "folder-music"), ("Videos", "folder-videos"),
                ("Projects", "folder-projects"))]
        D = GLib.UserDirectory
        for d, usual, ic in ((D.DIRECTORY_DOWNLOAD, "Downloads", "folder-download"),
                             (D.DIRECTORY_DOCUMENTS, "Documents", "folder-documents"),
                             (D.DIRECTORY_DESKTOP, "Desktop", "user-desktop"),
                             (D.DIRECTORY_PICTURES, "Pictures", "folder-pictures"),
                             (D.DIRECTORY_MUSIC, "Music", "folder-music"),
                             (D.DIRECTORY_VIDEOS, "Videos", "folder-videos")):
            p = GLib.get_user_special_dir(d) or os.path.join(home, usual)   # (no user-dirs file: the usual names)
            if p and p not in seen and os.path.isdir(p):
                seen.add(p)
                out.append((os.path.basename(p) or p, p, ic))
        # the sidebar bookmarks of Files (shared with every GTK app)
        for bm in (os.path.join(os.path.dirname(CONFIG_DIR), "gtk-3.0", "bookmarks"),
                   os.path.expanduser("~/.gtk-bookmarks")):
            try:
                with open(bm) as f:
                    for line in f:
                        uri, _sp, label = line.strip().partition(" ")
                        p = Gio.File.new_for_uri(uri).get_path() if uri.startswith("file://") else None
                        if p and p not in seen and os.path.isdir(p):
                            seen.add(p)
                            out.append((label or os.path.basename(p), p, "folder"))
            except OSError:
                pass
        return out[:self.MAX]

    def place(self, i):
        """where item i (0 = nearest the dock) sits: how far right its icon leans, and its tilt"""
        return 0.95 * i * i, 1.25 * i

    def show_for(self, e, x):
        if self.is_open():
            self.close()
            return
        for child in list(_children(self.fixed)):
            self.fixed.remove(child)
        entries = [(name, ic, lambda p=path: self.open_folder(p)) for name, path, ic in self.folders()]
        app = e["app"].get_name() if e.get("app") else "Files"
        entries.append((f"Open in {app}", None, lambda: self.open_app(e)))
        n = len(entries)
        lean = self.place(n - 1)[0]
        H = n * self.STEP + 16
        self.fixed.set_size_request(int(self.WIDTH + lean + 30), H)
        k = max(0.4, _motion_scale()) if _motion_scale() > 0 else 0
        css = [".fan-item, .fan-tilt { transform-origin: 100% 50%; }"]
        self.items = []
        for i, (name, ic, run) in enumerate(entries):
            dx, rot = self.place(i)
            label = lbl(name, "fan-label", valign=Gtk.Align.CENTER, ellipsize=3, max_width_chars=28)
            if ic is None:
                pic = Gtk.Box(css_classes=["fan-go"], valign=Gtk.Align.CENTER)
                arrow = icon("go-jump-symbolic", 26)
                arrow.set_hexpand(True)
                pic.append(arrow)
                pic.set_size_request(self.ICON, self.ICON)
            else:
                pic = icon(ic, self.ICON, "fan-icon")
            b = button(box(Gtk.Orientation.HORIZONTAL, 12, None, label, pic), "fan-btn",
                       lambda run=run: (self.close(), run()), None)
            b.set_halign(Gtk.Align.END)
            b.set_can_focus(False)
            # two layers: the inner one carries the tilt and never animates, the outer
            # one flies. (Animating a rotate() with a springy curve trips an assertion
            # in GTK 4.14's transform code, which would take the whole shell down.)
            tilt = box(Gtk.Orientation.HORIZONTAL, 0, f"fan-tilt ft{i}", b)
            b.set_hexpand(True)
            tilt.set_hexpand(True)
            item = box(Gtk.Orientation.HORIZONTAL, 0, f"fan-item fi{i}", tilt)
            item.set_size_request(self.WIDTH, self.STEP)
            y = H - (i + 1) * self.STEP - 8
            self.fixed.put(item, dx, y)
            self.items.append(item)
            # out of the dock icon, to its place: same list of transforms at both ends
            down = (i + 1) * self.STEP + 6
            rest = "translate(0px, 0px) scale(1)"
            away = f"translate({-dx:.1f}px, {down}px) scale(0.2)"
            if rot:
                css.append(f".fan-tilt.ft{i} {{ transform: rotate({rot:.2f}deg); }}")
            css.append(f"@keyframes fan-in-{i} {{ from {{ opacity: 0; transform: {away}; }} "
                       f"35% {{ opacity: 1; }} to {{ opacity: 1; transform: {rest}; }} }}")
            css.append(f"@keyframes fan-out-{i} {{ from {{ opacity: 1; transform: {rest}; }} "
                       f"to {{ opacity: 0; transform: {away}; }} }}")
            css.append(f".fan-item.fi{i}.fan-in {{ animation: fan-in-{i} {int(360 * k)}ms "
                       f"cubic-bezier(.2, 1.12, .3, 1) {int(26 * i * k)}ms both; }}")
            css.append(f".fan-item.fi{i}.fan-out {{ animation: fan-out-{i} {int(170 * k)}ms "
                       f"cubic-bezier(.5, 0, .9, .5) {int(12 * (n - 1 - i) * k)}ms both; }}")
        if self._css is None:
            self._css = Gtk.CssProvider()
            Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), self._css,
                                                      Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 6)
        text = "\n".join(css)
        self._css.load_from_string(text) if hasattr(self._css, "load_from_string") \
            else self._css.load_from_data(text.encode(), -1)
        self.OUT_MS = 170 + 12 * n                 # the last one home before the window goes
        # item 0's icon sits right over the dock icon that was clicked
        self.rev.set_margin_start(int(max(4, x - (self.WIDTH - 9 - self.ICON / 2))))
        if self.shell.preview:
            for it in self.items:
                it.add_css_class("fan-in")
            return
        self.shell.close_all(except_=self.name)
        self.open()

    def opened(self):
        for it in self.items:
            it.remove_css_class("fan-out")
            it.add_css_class("fan-in")

    def closed(self):
        for it in self.items:
            it.remove_css_class("fan-in")
            it.add_css_class("fan-out")

    def glass_rects(self):
        return []                                  # labels are their own little pills, no lens

    def open_folder(self, path):
        fm = "lumen-files" if shutil.which("lumen-files") else "gio open"
        system.run(f"{fm} {shlex.quote(path)}")

    def open_app(self, e):
        if e.get("windows"):
            ipc.send(f"focus {e['windows'][0]['id']}")
        elif e.get("app"):
            system.launch_app(e["app"], self.shell.cfg.get("terminal", "kitty"))
        else:
            self.open_folder(os.path.expanduser("~"))


class StartMenu(Popup):
    def __init__(self, shell):
        self.shell = shell
        self.entry = Gtk.SearchEntry(placeholder_text="Search for apps, settings, and documents")
        self.entry.connect("search-changed", lambda *_: self.on_search())
        self.entry.connect("activate", lambda *_: None if self.sel else self.launch_first())
        self.grid = Gtk.FlowBox(max_children_per_line=6, min_children_per_line=6,
                                selection_mode=Gtk.SelectionMode.NONE, homogeneous=True,
                                row_spacing=2, column_spacing=2)
        self.section = lbl("Pinned", "section", xalign=0, hexpand=True)
        self.all_btn = button(lbl("All apps  ›"), "chip", self.toggle_all)
        self.all_btn.set_valign(Gtk.Align.CENTER)
        self.show_all = False
        self.recent = Gtk.Grid(column_spacing=8, row_spacing=2, column_homogeneous=True)
        head = box(Gtk.Orientation.HORIZONTAL, 0, None, self.section, self.all_btn)
        self.scroller = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER,
                                           min_content_height=318, max_content_height=318,
                                           propagate_natural_height=True)
        self.scroller.set_child(self.grid)
        self.entry.connect("stop-search", lambda *_: self.close())
        # "Search the web" row (Firefox), revealed while searching
        self.web_title = lbl("Search the web", "web-title", xalign=0, ellipsize=3, max_width_chars=48)
        self.web_sub = lbl("Firefox", "sub", xalign=0)
        web_inner = box(Gtk.Orientation.HORIZONTAL, 14, None, icon(browser_icon(), 30),
                        box(Gtk.Orientation.VERTICAL, 0, None, self.web_title, self.web_sub,
                            valign=Gtk.Align.CENTER, hexpand=True),
                        icon("go-next-symbolic", 14, "dim"))
        self.web_row = button(web_inner, "web-row", self.web_search)
        self.web_rev = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN,
                                    transition_duration=200, child=self.web_row)
        self.search_mode = False
        self.sel, self.tiles, self.rec_buttons = None, [], []
        self.rec_head = lbl("Recommended", "section", xalign=0)
        body = box(Gtk.Orientation.VERTICAL, 0, "body", self.entry, self.web_rev, head, self.scroller,
                   self.rec_head, self.recent)

        uname = "You" if shell.preview else system.user_name()
        initials = "".join(p[0] for p in uname.split()[:2]).upper() or "U"
        avatar = lbl(initials, "avatar", valign=Gtk.Align.CENTER)
        power_menu = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_LEFT,
                                  transition_duration=220)
        pm = box(Gtk.Orientation.HORIZONTAL, 2)
        for ic, tip, cmd in (("system-lock-screen-symbolic", "Lock", "lumen-lock"),
                             ("system-log-out-symbolic", "Sign out", "logout"),
                             ("system-reboot-symbolic", "Restart", "restart"),
                             ("system-shutdown-symbolic", "Shut down", "shutdown")):
            pm.append(button(icon(ic), "icon-btn", lambda c=cmd: (
                shell.end_session(c) if c in Shell.ENDINGS else system.spawn(c)), tip))
        power_menu.set_child(pm)
        power = button(icon("system-shutdown-symbolic"), "icon-btn",
                       lambda: power_menu.set_reveal_child(not power_menu.get_reveal_child()), "Power")
        footer = box(Gtk.Orientation.HORIZONTAL, 12, "footer", avatar,
                     lbl(uname, "user", hexpand=True, xalign=0), power_menu, power)
        card = box(Gtk.Orientation.VERTICAL, 0, "glass startmenu", body, footer)
        keys = Gtk.EventControllerKey()
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect("key-pressed", self.on_key)
        card.add_controller(keys)
        super().__init__(shell, "start", card, Gtk.Align.CENTER, Gtk.Align.END, {"bottom": 62})
        self.refresh()

    # the Start button turns while the menu is open; tiles rise in one after another
    def opened(self):
        for t in self.shell.taskbars:
            t.set_start_open(True)
        if motion_ms(100) <= 0 or self.shell.preview:
            return
        for i, w in enumerate(self.tiles[:18]):
            w.add_css_class("rise")
            w.add_css_class(f"d{min(9, i // 6 + i % 6)}")

    def closed(self):
        for t in self.shell.taskbars:
            t.set_start_open(False)

        def settle():
            # drop the entrance classes (once hidden) so the next open plays them again
            if not self._open:
                for w in self.tiles + self.rec_buttons:
                    for c in [c for c in w.get_css_classes()
                              if c == "rise" or (len(c) == 2 and c[0] == "d" and c[1].isdigit())]:
                        w.remove_css_class(c)
            return False
        GLib.timeout_add(motion_ms(self.OUT_MS) + 60, settle)

    def apps(self):
        if self.shell.preview:
            return [(None, n, i) for n, i in (
                ("Firefox", "firefox"), ("Files", "org.gnome.Nautilus"), ("Terminal", "kitty"),
                ("Code", "visual-studio-code"), ("Spotify", "spotify"), ("Settings", "preferences-system"),
                ("Mail", "thunderbird"), ("Calendar", "org.gnome.Calendar"), ("Photos", "shotwell"),
                ("Music", "rhythmbox"), ("Calculator", "org.gnome.Calculator"), ("GIMP", "gimp"),
                ("Discord", "discord"), ("Steam", "steam"), ("Obsidian", "obsidian"),
                ("Blender", "blender"), ("Inkscape", "inkscape"), ("VLC", "vlc"))]
        q = self.entry.get_text().strip().lower()
        if q or self.show_all:
            infos = [a for a in Gio.AppInfo.get_all() if a.should_show()]
            if q:
                infos = [a for a in infos if q in (a.get_name() or "").lower()
                         or q in (a.get_description() or "").lower()
                         or q in (a.get_executable() or "").lower()]
            infos.sort(key=lambda a: a.get_name().lower())
        else:
            infos = [ai for ai in map(app_info, self.shell.cfg["pinned"]) if ai]
            seen = {a.get_id() for a in infos}
            extra = sorted((a for a in Gio.AppInfo.get_all() if a.should_show() and a.get_id() not in seen),
                           key=lambda a: a.get_name().lower())
            infos += extra[: max(0, 18 - len(infos))]
        return [(a, a.get_name(), icon_for(a)) for a in infos]

    def refresh(self):
        self.refresh_grid()
        self.refresh_recent()

    # ------------------------------------------------ keyboard navigation
    # sections (top → bottom): web-search row, app grid (6 wide), recommended (2 wide)
    def nav_sections(self):
        secs = []
        if self.web_rev.get_reveal_child():
            secs.append(([self.web_row], 1))
        if self.tiles:
            secs.append((self.tiles, 6))
        if self.recent.get_visible() and self.rec_buttons:
            secs.append((self.rec_buttons, 2))
        return secs

    def nav_flat(self):
        return [w for ws, _c in self.nav_sections() for w in ws]

    def set_sel(self, w):
        if self.sel is not None and self.sel is not w:
            self.sel.remove_css_class("kb-sel")
        self.sel = w
        if w is None:
            return
        w.add_css_class("kb-sel")
        if w in self.tiles:   # keep it in view inside the scrolling grid
            ok, b = w.compute_bounds(self.grid)
            adj = self.scroller.get_vadjustment()
            if ok:
                top, bot = b.origin.y, b.origin.y + b.size.height
                if top < adj.get_value():
                    adj.set_value(top - 6)
                elif bot > adj.get_value() + adj.get_page_size():
                    adj.set_value(bot - adj.get_page_size() + 6)

    def nav_move(self, key):
        secs = self.nav_sections()
        if not secs:
            return
        flat = [w for ws, _c in secs for w in ws]
        if self.sel not in flat:   # nothing selected yet: start at the top
            self.set_sel(flat[0] if key in ("down", "right", "next") else flat[-1] if key == "up" else flat[0])
            return
        si = next(i for i, (ws, _c) in enumerate(secs) if self.sel in ws)
        ws, cols = secs[si]
        i = ws.index(self.sel)
        if key in ("right", "next"):
            nxt = flat.index(self.sel) + 1
            self.set_sel(flat[min(nxt, len(flat) - 1)])
        elif key == "left":
            self.set_sel(flat[max(flat.index(self.sel) - 1, 0)])
        elif key == "down":
            if i + cols < len(ws):
                self.set_sel(ws[i + cols])
            elif si + 1 < len(secs):            # into the next section, same column
                nws, ncols = secs[si + 1]
                self.set_sel(nws[min(i % cols, ncols - 1, len(nws) - 1)])
            elif i // cols < (len(ws) - 1) // cols:   # partial last row
                self.set_sel(ws[-1])
        elif key == "up":
            if i - cols >= 0:
                self.set_sel(ws[i - cols])
            elif si > 0:                        # last row of the section above
                pws, pcols = secs[si - 1]
                last_row = (len(pws) - 1) // pcols
                self.set_sel(pws[min(last_row * pcols + min(i % cols, pcols - 1), len(pws) - 1)])
            else:
                self.set_sel(None)              # back up into the search box

    def on_key(self, _ctl, keyval, _code, state):
        K = Gdk
        if keyval in (K.KEY_Down, K.KEY_KP_Down):
            self.nav_move("down")
        elif keyval in (K.KEY_Up, K.KEY_KP_Up):
            self.nav_move("up")
        elif keyval in (K.KEY_Tab,):
            self.nav_move("next")
        elif keyval in (K.KEY_ISO_Left_Tab,):
            self.nav_move("left")
        elif keyval in (K.KEY_Right, K.KEY_KP_Right, K.KEY_Left, K.KEY_KP_Left):
            # with something selected the arrows move the selection; otherwise they edit the text
            if self.sel is None:
                return False
            self.nav_move("right" if keyval in (K.KEY_Right, K.KEY_KP_Right) else "left")
        elif keyval in (K.KEY_Return, K.KEY_KP_Enter):
            if self.sel is not None:
                self.sel.emit("clicked")
            else:
                self.launch_first()
        else:
            return False
        return True

    def on_search(self):
        self.refresh_grid()
        q0 = self.entry.get_text()
        (self.entry.add_css_class if q0 else self.entry.remove_css_class)("typing")
        for t in self.shell.taskbars:
            t.show_query(q0)
        # while typing, the best match is highlighted (Enter opens it), like Windows
        q = self.entry.get_text().strip()
        self.set_sel((self.tiles[0] if self.tiles else (self.web_row if q else None)) if q else None)

    def refresh_web(self):
        q = self.entry.get_text().strip()
        name = browser_name()
        self.web_title.set_label(f"Search the web for “{q}”" if q else f"Search the web with {name}")
        self.web_sub.set_label(f"{name} · press Enter" if q and not self._first else name)
        self.web_rev.set_reveal_child(bool(q) or self.search_mode)
        self.rec_head.set_visible(not q)
        self.recent.set_visible(not q)

    def web_search(self):
        system.run(browser_search_cmd(self.entry.get_text().strip()))
        self.close()

    def refresh_grid(self):
        q = self.entry.get_text().strip()
        self.section.set_label("Best match" if q else ("All apps" if self.show_all else "Pinned"))
        self.all_btn.get_child().set_label("‹  Back" if self.show_all else "All apps  ›")
        self.grid.remove_all()
        self._first = None
        if getattr(self, "sel", None) is not None and self.sel in getattr(self, "tiles", []):
            self.sel = None
        self.tiles = []
        for ai, name, ic in self.apps():
            ico = app_icon(ic)
            ico.add_css_class("tile-icon")
            ico.set_halign(Gtk.Align.CENTER)
            tile = box(Gtk.Orientation.VERTICAL, 0, None, ico,
                       lbl(name, max_width_chars=11, ellipsize=3, justify=Gtk.Justification.CENTER))
            b = button(tile, "app-tile", lambda a=ai: self.launch(a))
            b.set_focus_on_click(False)
            self.grid.append(b)
            self.tiles.append(b)
            self._first = self._first or ai
        if hasattr(self, "web_rev"):
            self.refresh_web()

    def refresh_recent(self, rise=False):
        if getattr(self, "sel", None) in getattr(self, "rec_buttons", []):
            self.set_sel(None)
        self.rec_buttons = []
        child = self.recent.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.recent.remove(child)
            child = nxt
        items = self.recent_items()
        for i, (name, sub, ic, uri) in enumerate(items[:6]):
            row = box(Gtk.Orientation.HORIZONTAL, 12, None, icon(ic, 30),
                      box(Gtk.Orientation.VERTICAL, 0, None, lbl(name, xalign=0, ellipsize=3, max_width_chars=24),
                          lbl(sub, "sub", xalign=0)))
            rb = button(row, "rec-row", lambda u=uri: (system.open_uri(u), self.close()))
            rb.set_focus_on_click(False)
            if rise and motion_ms(100) > 0 and not self.shell.preview:
                rb.add_css_class("rise")
                rb.add_css_class(f"d{min(9, 3 + i // 2 + i % 2)}")
            self.recent.attach(rb, i % 2, i // 2, 1, 1)
            self.rec_buttons.append(rb)

    def recent_items(self):
        if self.shell.preview:
            return [("lumen-flow.jpg", "Recently added", "image-x-generic", None),
                    ("compositor.c", "17m ago", "text-x-csrc", None),
                    ("Q4 roadmap.odt", "Yesterday at 6:12 PM", "x-office-document", None),
                    ("dotfiles", "Nov 4", "folder", None),
                    ("budget.ods", "Nov 2", "x-office-spreadsheet", None),
                    ("arch-install.md", "Oct 30", "text-x-markdown", None)]
        out = []
        for it in Gtk.RecentManager.get_default().get_items()[:6]:
            age = time.time() - it.get_modified().to_unix()
            sub = "Just now" if age < 120 else f"{int(age // 60)}m ago" if age < 3600 else \
                f"{int(age // 3600)}h ago" if age < 86400 else it.get_modified().format("%b %-d")
            out.append((it.get_display_name(), sub, it.get_gicon() or "text-x-generic", it.get_uri()))
        return out

    def toggle_all(self):
        self.show_all = not self.show_all
        self.refresh()

    def launch(self, ai):
        if ai:
            system.launch_app(ai, self.shell.cfg.get("terminal", "kitty"))
        self.close()

    def launch_first(self):
        if self._first and self.entry.get_text().strip():
            self.launch(self._first)
        elif self.entry.get_text().strip():
            self.web_search()          # no app matches → search the web instead
        elif self._first:
            self.launch(self._first)

    def on_open(self):
        # the pinned grid is already built: only reset if a search / All apps was left open
        if self.entry.get_text() or self.show_all:
            self.show_all = False
            self.entry.set_text("")
            self.refresh_grid()
        self.set_sel(None)
        GLib.idle_add(self.entry.grab_focus)
        self.set_search_mode(self.search_mode)
        self.refresh_recent(rise=True)

    def set_search_mode(self, on):
        """opened from the taskbar's Search pill: the search box glows"""
        self.search_mode = on
        if on:
            self.entry.add_css_class("highlight")
        else:
            self.entry.remove_css_class("highlight")
        self.refresh_web()

    def close(self):
        super().close()
        self.search_mode = False
        for t in self.shell.taskbars:
            t.show_query("")
        GLib.timeout_add(300, lambda: (self.entry.remove_css_class("highlight"), False)[1])


def _calc(q):
    """`q` as plain arithmetic → its value as text, or None (never eval(): only
    numbers and + - * / % ** ( ) are walked)"""
    import ast
    import operator as op
    q = q.strip().replace("×", "*").replace("÷", "/").replace("^", "**").replace(",", "")
    if not q or len(q) > 80 or not any(c.isdigit() for c in q) or not any(c in "+-*/%" for c in q[1:]):
        return None
    ops = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv,
           ast.Mod: op.mod, ast.Pow: op.pow, ast.FloorDiv: op.floordiv}

    def ev(n):
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)) and not isinstance(n.value, bool):
            return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in ops:
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Pow) and (abs(b) > 64 or abs(a) > 1e6):
                raise ValueError
            return ops[type(n.op)](a, b)
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.USub, ast.UAdd)):
            return -ev(n.operand) if isinstance(n.op, ast.USub) else ev(n.operand)
        raise ValueError
    try:
        v = ev(ast.parse(q, mode="eval").body)
    except Exception:   # noqa: BLE001 — not arithmetic after all
        return None
    if isinstance(v, float):
        if v != v or v in (float("inf"), float("-inf")):
            return None
        v = round(v, 10)
        if v == int(v) and abs(v) < 1e15:
            v = int(v)
    return f"{v:,}" if isinstance(v, int) else f"{v:,.10f}".rstrip("0").rstrip(".")


class Spotlight(Popup):
    """Super+Space: a search bar in the middle of the screen. Type, and results
    grow out underneath it. Five categories, as the rofi launcher had (plus All):
    All (apps, open windows, recent files, sums, the web), Apps, Run (commands),
    Windows (switch to one) and Files (browse folders). Ctrl+Tab or Shift+←/→
    changes category. Matching is fuzzy: "fx" finds Firefox.
    Everything moves: the list opens and closes row by row, a row whose result
    changes settles in, and the highlights glide from row to row and tab to tab."""

    ROWS, ROW_H, TAB_W = 7, 54, 104
    MODES = (("all", "All"), ("apps", "Apps"), ("run", "Run"), ("windows", "Windows"), ("files", "Files"))

    def __init__(self, shell):
        self.shell = shell
        self.entry = Gtk.Entry(placeholder_text="Spotlight Search", hexpand=True, has_frame=False)
        self.entry.add_css_class("spot-entry")
        self.entry.connect("changed", lambda *_: self.refresh())
        self.entry.connect("activate", lambda *_: self.activate())
        head = box(Gtk.Orientation.HORIZONTAL, 14, "spot-head", icon("system-search-symbolic", 22), self.entry)
        self.slots = []
        rows = box(Gtk.Orientation.VERTICAL, 0)
        for i in range(self.ROWS):
            img = Gtk.Image(pixel_size=34)
            title = lbl("", "spot-title", xalign=0, ellipsize=3)
            sub = lbl("", "spot-sub", xalign=0, ellipsize=3)
            hint = lbl("", "spot-hint", valign=Gtk.Align.CENTER)
            body = box(Gtk.Orientation.HORIZONTAL, 14, "spot-row", img,
                       box(Gtk.Orientation.VERTICAL, 1, None, title, sub, valign=Gtk.Align.CENTER, hexpand=True), hint)
            body.set_size_request(-1, self.ROW_H)
            rev = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN, child=body)
            g = Gtk.GestureClick()
            g.connect("released", lambda *_a, i=i: (self.set_sel(self.top + i), self.activate()))
            body.add_controller(g)
            m = Gtk.EventControllerMotion()
            m.connect("motion", lambda *_a, i=i: self.top + i < len(self.results) and self.set_sel(self.top + i))
            body.add_controller(m)
            rows.append(rev)
            self.slots.append({"rev": rev, "body": body, "img": img, "title": title, "sub": sub, "hint": hint,
                               "key": None})
        # the highlight is one bar behind the rows that slides to the selected one
        # (its size comes from CSS min-height: a size request would count the margin
        # that moves it as part of the bar, and squash it)
        self.hl = Gtk.Box(css_classes=["spot-hl", "none"], valign=Gtk.Align.START)
        under = Gtk.Box()
        self.hl.set_hexpand(True)
        under.append(self.hl)
        stack = Gtk.Overlay(child=under)
        stack.add_overlay(rows)
        stack.set_measure_overlay(rows, True)
        self.list_rev = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN,
                                     child=box(Gtk.Orientation.VERTICAL, 0, "spot-list", stack))
        wheel = Gtk.EventControllerScroll(flags=Gtk.EventControllerScrollFlags.VERTICAL)
        wheel.connect("scroll", lambda _c, _dx, dy: (self.scroll_by(1 if dy > 0 else -1), True)[1])
        stack.add_controller(wheel)
        # categories: one pill behind the names slides to the chosen one
        self.mode = "all"
        self.tab_hl = Gtk.Box(css_classes=["spot-tab-hl", "t0"], halign=Gtk.Align.START)
        tabs = box(Gtk.Orientation.HORIZONTAL, 0)
        self.tabs = {}
        for key, name in self.MODES:
            b = button(lbl(name), "spot-tab", lambda k=key: self.set_mode(k))
            b.set_size_request(self.TAB_W, -1)
            b.set_focus_on_click(False)
            b.set_can_focus(False)
            tabs.append(b)
            self.tabs[key] = b
        self.tabs["all"].add_css_class("on")
        tab_stack = Gtk.Overlay(child=self.tab_hl)
        tab_stack.add_overlay(tabs)
        tab_stack.set_measure_overlay(tabs, True)
        tab_row = box(Gtk.Orientation.HORIZONTAL, 0, "spot-tabs", tab_stack, halign=Gtk.Align.CENTER)
        card = box(Gtk.Orientation.VERTICAL, 0, "glass card spotlight", head, self.list_rev,
                   box(Gtk.Orientation.HORIZONTAL, 0, "spot-foot", tab_row, halign=Gtk.Align.FILL))
        tab_row.set_hexpand(True)
        card.set_size_request(660, -1)
        keys = Gtk.EventControllerKey()
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect("key-pressed", self.on_key)
        card.add_controller(keys)
        self.results, self.sel, self.top, self._apps, self._cmds, self._follow = [], -1, 0, None, None, 0
        super().__init__(shell, "spotlight", card, Gtk.Align.CENTER, Gtk.Align.START, {"top": 200})

    # ------------------------------------------------------------ results
    def all_apps(self):
        if self._apps is None:
            if self.shell.preview:
                self._apps = [(None, n, i, "") for _a, n, i in StartMenu.apps(self.shell.popups["start"])] \
                    if "start" in self.shell.popups else []
            else:
                self._apps = [(a, a.get_name() or "", icon_for(a),
                               " ".join(filter(None, (a.get_description(), a.get_executable(),
                                                      " ".join(a.get_keywords() if hasattr(a, "get_keywords") else []))))
                               .lower())
                              for a in Gio.AppInfo.get_all() if a.should_show()]
        return self._apps

    @staticmethod
    def match(q, name):
        """how well q matches name: None, or a sort key (lower is better).
        prefix < start of a word < anywhere < the letters in order (fuzzy)"""
        n = name.lower()
        if not q:
            return (0, 0)
        if n.startswith(q):
            return (0, len(n))
        if any(w.startswith(q) for w in n.replace("-", " ").replace("_", " ").replace(".", " ").split()):
            return (1, len(n))
        at = n.find(q)
        if at >= 0:
            return (2, at)
        i, first, last = 0, -1, -1
        for k, ch in enumerate(n):
            if i < len(q) and ch == q[i]:
                first = k if first < 0 else first
                last = k
                i += 1
        return (3, last - first) if i == len(q) and len(q) >= 2 else None

    def find_apps(self, ql, limit):
        ranked = []
        for ai, name, ic, extra in self.all_apps():
            m = self.match(ql, name)
            if m is None and ql and ql in extra:
                m = (4, 0)
            if m is not None:
                ranked.append((m, name.lower(), ai, name, ic))
        ranked.sort(key=lambda r: r[:2])
        return [{"key": "app:" + name, "title": name, "sub": "Application", "icon": ic, "hint": "Open",
                 "run": lambda ai=ai: system.launch_app(ai, self.shell.cfg.get("terminal", "kitty"))}
                for _m, _n, ai, name, ic in ranked[:limit]]

    def find_windows(self, ql, limit):
        out = []
        for w in self.shell.comp.state.get("windows", []):
            ai = None if self.shell.preview else app_for_window(w.get("app_id"), w.get("title"))
            app = ai.get_name() if ai else (w.get("app_id") or "App").split(".")[-1].capitalize()
            title = w.get("title") or app
            m = self.match(ql, title) or self.match(ql, app)
            if m is None:
                continue
            where = f"Desktop {w.get('workspace', 0) + 1}" + (" · minimised" if w.get("minimized") else "")
            out.append((m, {"key": f"win:{w.get('id')}", "title": title, "sub": f"{app} · {where}",
                            "icon": icon_for(ai, w.get("app_id")), "hint": "Switch",
                            "run": lambda wid=w.get("id"): ipc.send(f"focus {wid}")}))
        out.sort(key=lambda r: r[0])
        return [r for _m, r in out[:limit]]

    def find_commands(self, q, limit):
        ql = q.strip().lower()
        if not ql:
            return []
        if self._cmds is None:
            names = set()
            for d in os.environ.get("PATH", "").split(":"):
                try:
                    names.update(os.listdir(d))
                except OSError:
                    pass
            self._cmds = sorted(names)
        word = ql.split()[0]
        ranked = sorted((m, c) for c in self._cmds for m in [self.match(word, c)] if m is not None and m[0] < 3)
        out = [{"key": "cmd:" + c, "title": c, "sub": "Command", "icon": "utilities-terminal", "hint": "Run",
                "run": lambda c=c: system.run(c)} for _m, c in ranked[:limit - 1] if c != ql]
        # whatever was typed can always be run as it stands (with its arguments)
        return [{"key": "cmdline", "title": q.strip(), "sub": "Run this command", "icon": "utilities-terminal",
                 "hint": "Run", "run": lambda: system.run(q.strip())}] + out

    def find_actions(self, ql, limit):
        """Lock, Sleep, Log Out, Light Mode… by name (or a word for it: "reboot")"""
        if len(ql) < 2:
            return []
        hits = []
        for key, title, ic, words, run in self.shell.system_actions():
            best = self.match(ql, title.lower().rstrip("…"))
            for w in words.split():
                m = self.match(ql, w)
                if m is not None and m[0] < 2 and (best is None or m < best):
                    best = m
            if best is not None and best[0] < 3:
                hits.append((best, {"key": "act:" + key, "title": title, "sub": "System", "icon": ic,
                                    "hint": "Do it", "run": run}))
        hits.sort(key=lambda h: h[0])
        return [h for _m, h in hits[:limit]]

    def find_files(self, q, limit):
        """a small file browser: a path ("~/Doc", "/etc/") lists that folder,
        anything else searches your home folder and recent files"""
        q = q.strip()
        home = os.path.expanduser("~")
        if q.startswith(("/", "~")):
            path = os.path.expanduser(q)
            folder, part = (path, "") if q.endswith("/") else os.path.split(path)
        else:
            folder, part = home, q
        pl = part.lower()
        found = []
        try:
            with os.scandir(folder or "/") as it:
                for n, e in enumerate(it):
                    if n > 4000:
                        break
                    if e.name.startswith(".") and not pl.startswith("."):
                        continue
                    m = self.match(pl, e.name)
                    if m is not None:
                        try:
                            is_dir = e.is_dir()
                        except OSError:
                            is_dir = False
                        found.append((m, not is_dir, e.name.lower(), e.name, e.path, is_dir))
        except OSError:
            pass
        found.sort(key=lambda f: f[:3])
        out = []
        for _m, _f, _l, name, path, is_dir in found[:limit]:
            shown = path.replace(home, "~", 1) if path.startswith(home) else path
            if is_dir:
                # Enter on a folder goes into it: the list becomes its contents
                out.append({"key": "dir:" + path, "title": name, "sub": os.path.dirname(shown) or "/",
                            "icon": "folder", "hint": "Open", "stay": True,
                            "run": lambda shown=shown: (self.entry.set_text(shown + "/"), self.entry.set_position(-1))})
            else:
                gf = Gio.File.new_for_path(path)
                ctype, _unsure = Gio.content_type_guess(name, None)
                out.append({"key": "file:" + path, "title": name, "sub": os.path.dirname(shown) or "/",
                            "icon": Gio.content_type_get_icon(ctype) if ctype else "text-x-generic", "hint": "Open",
                            "run": lambda gf=gf: system.run(f"gio open {shlex.quote(gf.get_uri())}")})
        if folder == home and pl and len(out) < limit and not self.shell.preview:
            have = {r["key"] for r in out}
            for it in Gtk.RecentManager.get_default().get_items():
                if len(out) >= limit:
                    break
                uri = it.get_uri()
                p = Gio.File.new_for_uri(uri).get_path() or uri
                if "file:" + p not in have and self.match(pl, it.get_display_name() or "") is not None:
                    out.append({"key": "file:" + p, "title": it.get_display_name(), "sub": "Recent file",
                                "icon": it.get_gicon() or "text-x-generic", "hint": "Open",
                                "run": lambda uri=uri: system.run(f"gio open {shlex.quote(uri)}")})
        return out

    def search(self, q):
        ql = q.strip().lower()
        if self.mode == "apps":
            return self.find_apps(ql, 200)
        if self.mode == "run":
            return self.find_commands(q, 60)
        if self.mode == "windows":
            return self.find_windows(ql, 60)
        if self.mode == "files":
            return self.find_files(q, 200)
        if not ql:
            return []                       # All, nothing typed: just the bar
        out = []
        val = _calc(q)
        if val is not None:
            out.append({"key": "calc:" + val, "title": val, "sub": f"{q.strip()} =", "icon": "accessories-calculator",
                        "hint": "Copy", "run": lambda: Gdk.Display.get_default().get_clipboard().set(val.replace(",", ""))})
        out += self.find_apps(ql, 4)
        out += self.find_actions(ql, 2)
        out += self.find_windows(ql, 2) if len(ql) >= 2 else []
        if len(ql) >= 2 and not self.shell.preview:
            n = 0
            for it in Gtk.RecentManager.get_default().get_items():
                if n >= 2:
                    break
                if ql in (it.get_display_name() or "").lower():
                    uri = it.get_uri()
                    out.append({"key": "file:" + uri, "title": it.get_display_name(), "sub": "Recent file",
                                "icon": it.get_gicon() or "text-x-generic", "hint": "Open",
                                "run": lambda uri=uri: system.run(f"gio open {shlex.quote(uri)}")})
                    n += 1
        out.append({"key": "web", "title": f"Search the web for “{q.strip()}”", "sub": browser_name(),
                    "icon": browser_icon(), "hint": "Search",
                    "run": lambda: system.run(browser_search_cmd(q.strip()))})
        return out

    def refresh(self):
        self.results = self.search(self.entry.get_text())
        self.top = 0
        self.sel = None                      # (so set_sel always applies)
        self.show(settle=True)
        self.set_sel(0 if self.results else -1)
        self.list_rev.set_transition_duration(motion_ms(180))
        self.list_rev.set_reveal_child(bool(self.results))
        self.follow_glass()

    def show(self, settle):
        """the ROWS results from `top` on. settle: a row that changes what it shows
        while it is up settles in (not while scrolling, where every row changes)"""
        ms = motion_ms(150)
        for i, slot in enumerate(self.slots):
            k = self.top + i
            r = self.results[k] if k < len(self.results) else None
            slot["rev"].set_transition_duration(ms)
            if r is None:
                slot["rev"].set_reveal_child(False)
                continue
            slot["title"].set_label(r["title"])        # (the web row's text follows the typing)
            slot["sub"].set_label(r["sub"])
            slot["hint"].set_label(r["hint"])
            if slot["key"] != r["key"]:
                ic = r["icon"]
                if isinstance(ic, Gio.Icon):
                    slot["img"].set_from_gicon(ic)
                else:
                    slot["img"].set_from_icon_name(ic or "application-x-executable")
                if settle and slot["rev"].get_reveal_child() and ms > 0:
                    nxt = "swap-b" if slot["body"].has_css_class("swap-a") else "swap-a"
                    slot["body"].remove_css_class("swap-a")
                    slot["body"].remove_css_class("swap-b")
                    slot["body"].add_css_class(nxt)
                slot["key"] = r["key"]
            slot["rev"].set_reveal_child(True)

    def set_sel(self, i):
        if i == self.sel:
            return
        self.sel = i
        if i >= 0 and not self.top <= i < self.top + self.ROWS:      # keep it in view
            self.top = i if i < self.top else i - self.ROWS + 1
            self.show(settle=False)
        row = i - self.top if i >= 0 else -1
        for c in self.hl.get_css_classes():
            if c == "none" or (c.startswith("i") and c[1:].isdigit()):
                self.hl.remove_css_class(c)
        self.hl.add_css_class("none" if row < 0 else f"i{row}")
        for k, slot in enumerate(self.slots):
            (slot["body"].add_css_class if k == row else slot["body"].remove_css_class)("selected")

    def scroll_by(self, d):
        n = len(self.results)
        if n <= self.ROWS:
            return
        top = max(0, min(n - self.ROWS, self.top + d))
        if top != self.top:
            self.top = top
            self.show(settle=False)
            sel = max(top, min(top + self.ROWS - 1, self.sel))
            self.sel = None
            self.set_sel(sel)

    def set_mode(self, mode):
        if mode == self.mode or mode not in self.tabs:
            return
        self.mode = mode
        idx = [k for k, _n in self.MODES].index(mode)
        for c in self.tab_hl.get_css_classes():
            if c.startswith("t") and c[1:].isdigit():
                self.tab_hl.remove_css_class(c)
        self.tab_hl.add_css_class(f"t{idx}")
        for k, b in self.tabs.items():
            (b.add_css_class if k == mode else b.remove_css_class)("on")
        self.entry.set_placeholder_text({"all": "Spotlight Search", "apps": "Search apps", "run": "Run a command",
                                         "windows": "Switch to a window", "files": "Find a file, or type a path"}[mode])
        self.refresh()

    def follow_glass(self, ms=420):
        """liquid mode: the lens keeps to the card while the list grows and shrinks"""
        if not GLASS.enabled:
            return
        going = self._follow > GLib.get_monotonic_time()
        self._follow = GLib.get_monotonic_time() + ms * 1000
        if going:
            return

        def tick(_w, _c):
            if self.is_open():
                GLASS.send(f"lumen-{self.name}", self.glass_rects())
            return self._follow > GLib.get_monotonic_time()
        self.card.add_tick_callback(tick)

    # --------------------------------------------------------------- keys
    def on_key(self, _ctl, keyval, _code, state):
        n = len(self.results)
        ctrl, shift = state & Gdk.ModifierType.CONTROL_MASK, state & Gdk.ModifierType.SHIFT_MASK
        step = 0
        if ctrl and keyval in (Gdk.KEY_Tab, Gdk.KEY_ISO_Left_Tab):
            step = -1 if keyval == Gdk.KEY_ISO_Left_Tab or shift else 1
        elif shift and keyval in (Gdk.KEY_Right, Gdk.KEY_Left):
            step = 1 if keyval == Gdk.KEY_Right else -1
        if step:                                  # next / previous category
            keys = [k for k, _n in self.MODES]
            self.set_mode(keys[(keys.index(self.mode) + step) % len(keys)])
            return True
        if keyval in (Gdk.KEY_Page_Down, Gdk.KEY_Page_Up) and n:
            self.set_sel(max(0, min(n - 1, self.sel + (self.ROWS if keyval == Gdk.KEY_Page_Down else -self.ROWS))))
            return True
        if keyval in (Gdk.KEY_Down, Gdk.KEY_Tab) and n:
            self.set_sel((self.sel + 1) % n)
            return True
        if keyval in (Gdk.KEY_Up, Gdk.KEY_ISO_Left_Tab) and n:
            self.set_sel((self.sel - 1) % n)
            return True
        if keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            self.activate()
            return True
        return False

    def activate(self):
        if self.sel is not None and 0 <= self.sel < len(self.results):
            r = self.results[self.sel]
            if not r.get("stay"):                # (a folder: we go into it instead)
                self.close()
            r["run"]()

    def on_open(self):
        self._apps = self._cmds = None     # apps installed since last time show up
        if self.mode != "all":
            self.mode = None
            self.set_mode("all")
        self.entry.set_text("")
        self.refresh()
        GLib.idle_add(lambda: (self.entry.grab_focus(), False)[1])


class ControlCenter(Popup):
    """Quick settings: a grid of toggles, brightness and volume, power mode and
    whatever is playing."""

    TILES = (("wifi", "network-wireless-signal-excellent-symbolic", "Wi-Fi"),
             ("bt", "bluetooth-active-symbolic", "Bluetooth"),
             ("dnd", "lumen-bell-off-symbolic", "Do Not Disturb"),
             ("night", "weather-clear-night-symbolic", "Night Shift"),
             ("perf", "lumen-performance-symbolic", "Performance"),
             ("shot", "camera-photo-symbolic", "Screenshot"),
             ("light", "weather-clear-symbolic", "Light Mode"),
             ("lock", "system-lock-screen-symbolic", "Lock Screen"))

    def __init__(self, shell):
        self.shell = shell
        self.tiles = {}
        self.night = False
        grid = Gtk.Grid(column_spacing=10, row_spacing=10, column_homogeneous=True)
        for i, (key, ic, title) in enumerate(self.TILES):
            img = icon(ic, 16)
            img.set_hexpand(True)
            badge = box(Gtk.Orientation.HORIZONTAL, 0, "toggle-icon", img,
                        valign=Gtk.Align.CENTER, halign=Gtk.Align.START, hexpand=False)
            badge.set_size_request(34, 34)
            sub = lbl("", "sub", xalign=0, ellipsize=3, max_width_chars=13)
            text = box(Gtk.Orientation.VERTICAL, 1, None,
                       lbl(title, "title", xalign=0, ellipsize=3, max_width_chars=13), sub,
                       valign=Gtk.Align.CENTER, hexpand=True)
            tile = button(box(Gtk.Orientation.HORIZONTAL, 10, None, badge, text), "cc-tile",
                          lambda k=key: self.flip(k))
            tile.set_hexpand(True)
            grid.attach(tile, i % 2, i // 2, 1, 1)
            self.tiles[key] = (tile, badge, sub, img)

        self._sync = False
        self.bright, self.bright_val, disp = self._slider(
            "display-brightness-symbolic", system.set_brightness, None, "Brightness")
        self.vol, self.vol_val, snd = self._slider(
            "audio-volume-high-symbolic", system.set_volume, self.toggle_mute, "Mute")
        self.vol_icon = snd.get_first_child().get_child()

        self.np = NowPlaying(shell, art=46, title_cls="title", artist_cls="sub")
        self.modes = PowerModes(shell)
        power = box(Gtk.Orientation.VERTICAL, 0, "module", lbl("Power mode", "heading", xalign=0), self.modes.widget)
        media = box(Gtk.Orientation.HORIZONTAL, 12, "module media-module", self.np.art, self.np.text,
                    self.np.controls)
        card = box(Gtk.Orientation.VERTICAL, 10, "glass card control", grid, disp, snd, power, media)
        card.set_size_request(356, -1)
        super().__init__(shell, "control", card, Gtk.Align.END, Gtk.Align.START, {"top": 38, "end": 10})

    def _slider(self, ic, setter, on_icon, tip):
        sc = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 1, 0.01)
        sc.set_draw_value(False)
        sc.set_hexpand(True)
        val = lbl("", "cc-val", xalign=1, width_chars=4)

        def changed(s):
            val.set_label(f"{round(s.get_value() * 100)}%")
            if not self._sync:
                setter(s.get_value())
        sc.connect("value-changed", changed)
        ib = button(icon(ic, 16), "cc-mute", on_icon, tip)
        ib.set_valign(Gtk.Align.CENTER)
        if on_icon is None:
            ib.set_can_target(False)
        return sc, val, box(Gtk.Orientation.HORIZONTAL, 8, "module cc-slider", ib, sc, val)

    def toggle_mute(self):
        v = self.shell.sys["volume"]
        v["muted"] = not v.get("muted")
        system.spawn("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle")
        self.sync()

    def toggle_performance(self):
        on = not performance_mode()
        set_conf_value("performance_mode", "true" if on else "false")
        ipc.send("reload")
        self.shell.reload()

    def flip(self, key):
        s = self.shell.sys
        if key == "wifi":
            system.spawn(f"nmcli radio wifi {'off' if s['wifi']['on'] else 'on'}")
            s["wifi"]["on"] = not s["wifi"]["on"]
        elif key == "bt":
            s["bt"] = not s["bt"]
            system.spawn(f"bluetoothctl power {'on' if s['bt'] else 'off'}")
        elif key == "dnd":
            self.shell.notify.set_dnd(not self.shell.notify.dnd)
        elif key == "night":
            self.night = not self.night
            system.spawn("wlsunset -t 4000" if self.night else "pkill -x wlsunset")
        elif key == "perf":
            self.toggle_performance()
        elif key == "light":
            self.shell.set_light_mode(not light_mode())
        elif key == "lock":
            self.close()
            GLib.timeout_add(motion_ms(self.OUT_MS) + 60, lambda: (system.spawn("lumen-lock"), False)[1])
            return
        elif key == "shot":
            self.close()      # never in the picture
            GLib.timeout_add(motion_ms(self.OUT_MS) + 120, lambda: (system.spawn("lumen-screenshot"), False)[1])
            return
        self.sync()

    def sync(self):
        s = self.shell.sys
        nf = self.shell.notify
        state = {"wifi": (s["wifi"]["on"], s["wifi"]["ssid"] or ("On" if s["wifi"]["on"] else "Off")),
                 "bt": (s["bt"], "On" if s["bt"] else "Off"),
                 "dnd": (nf.silenced(), "On" if nf.dnd else ("Quiet hours" if nf.quiet_hours() else "Off")),
                 "night": (self.night, "Warmer colours" if self.night else "Off"),
                 "perf": (performance_mode(), "Effects off" if performance_mode() else "Off"),
                 "shot": (False, "Capture screen"),
                 "light": (light_mode(), "On" if light_mode() else "Off"),
                 "lock": (False, "⌘ L")}
        for k, (on, sub) in state.items():
            tile, badge, sl, _img = self.tiles[k]
            (badge.add_css_class if on else badge.remove_css_class)("on")
            (tile.add_css_class if on else tile.remove_css_class)("on")
            sl.set_label(sub)
        self.tiles["wifi"][3].set_from_icon_name(system.wifi_icon(s["wifi"]))
        self._sync = True
        b = s["brightness"]
        self.bright.set_value(b if b is not None else 0.8)
        self.bright.get_parent().set_visible(b is not None or self.shell.preview)
        self.vol.set_value(s["volume"]["level"])
        self.vol_icon.set_from_icon_name(system.volume_icon(s["volume"]))
        self._sync = False
        self.np.update(s["media"], "Not Playing", "")
        self.modes.refresh()

    def on_open(self):
        self.sync()                                     # show last-known state instantly
        self.shell.poll(full=True, then=self.sync)      # refresh in the background

        def probe():
            on = bool(system._run("pgrep", "-x", "wlsunset"))
            GLib.idle_add(lambda: (setattr(self, "night", on), self.sync(), False)[2])
        if not self.shell.preview:
            threading.Thread(target=probe, daemon=True).start()


# ------------------------------------------------------------ media pieces
class Marquee(Gtk.ScrolledWindow):
    """A one-line label that, when it doesn't fit, glides to the end, rests,
    and glides back — like the iOS now-playing title."""

    SPEED, PAUSE = 32.0, 1.8   # px/s, seconds at each end

    def __init__(self, cls=None, xalign=0.0):
        super().__init__(hscrollbar_policy=Gtk.PolicyType.EXTERNAL, vscrollbar_policy=Gtk.PolicyType.NEVER,
                         propagate_natural_height=True, hexpand=True)
        self.add_css_class("marquee")
        self.label = lbl("", cls, xalign=xalign, single_line_mode=True)
        self.set_child(self.label)
        self._t0 = None
        self._timer = None
        self.connect("map", lambda *_: self._ensure())
        self.connect("unmap", lambda *_: self._stop())

    def set_label(self, text):
        if text == self.label.get_label():
            return
        self.label.set_label(text)
        self._t0 = None
        self.get_hadjustment().set_value(0)
        GLib.idle_add(lambda: (self._ensure(), False)[1])

    def get_label(self):
        return self.label.get_label()

    def _span(self):
        adj = self.get_hadjustment()
        return adj.get_upper() - adj.get_page_size()

    def _ensure(self):
        if self.get_mapped() and self._span() > 2 and self._timer is None:
            self._timer = GLib.timeout_add(33, self._step)
        return False

    def _stop(self):
        if self._timer:
            GLib.source_remove(self._timer)
        self._timer = None

    def _step(self):
        span = self._span()
        if not self.get_mapped() or span <= 2:
            self.get_hadjustment().set_value(0)
            self._timer = None
            return False
        now = time.monotonic()
        if self._t0 is None:
            self._t0 = now
        travel = span / self.SPEED
        cycle = 2 * (self.PAUSE + travel)
        t = (now - self._t0) % cycle

        def ease(x):
            return x * x * (3 - 2 * x)
        if t < self.PAUSE:
            x = 0
        elif t < self.PAUSE + travel:
            x = ease((t - self.PAUSE) / travel) * span
        elif t < 2 * self.PAUSE + travel:
            x = span
        else:
            x = (1 - ease((t - 2 * self.PAUSE - travel) / travel)) * span
        self.get_hadjustment().set_value(x)
        return True


_tex_cache = {}


def load_texture(path):
    if not path:
        return None
    if path in _tex_cache:
        return _tex_cache[path]
    try:
        tex = Gdk.Texture.new_from_filename(path)
    except GLib.Error:
        tex = None
    if len(_tex_cache) > 24:
        _tex_cache.clear()
    _tex_cache[path] = tex
    return tex


class Artwork(Gtk.Overlay):
    """Song cover / video thumbnail, cropped to a rounded square (fills it)."""

    def __init__(self, size, cls="w-art"):
        super().__init__()
        self.add_css_class(cls)
        self.add_css_class("artwork")
        self.set_overflow(Gtk.Overflow.HIDDEN)
        self.set_size_request(size, size)
        self.set_halign(Gtk.Align.START)
        self.set_valign(Gtk.Align.CENTER)
        self.fallback = icon("audio-x-generic-symbolic", max(16, size // 2))
        self.fallback.set_halign(Gtk.Align.CENTER)
        self.fallback.set_valign(Gtk.Align.CENTER)
        self.pic = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True)
        self.set_child(WidgetCell(Gtk.Box(), size, size))
        self.add_overlay(self.fallback)
        self.add_overlay(self.pic)
        self.size = size
        self.path = None

    def set_art(self, path):
        if path == self.path:
            return
        self.path = path
        tex = load_texture(path)
        self.pic.set_paintable(tex)
        self.pic.set_visible(tex is not None)
        self.fallback.set_visible(tex is None)


class NowPlaying:
    """Artwork + scrolling title/artist + prev/play/next for whatever is playing
    (Spotify, a YouTube tab, mpv…); controls go to that exact player."""

    def __init__(self, shell, art=46, layout="row", title_cls="w-head", artist_cls="w-sub", player_app=None):
        self.shell, self.player_app = shell, player_app
        self.np = None
        self.art = Artwork(art)
        self.title = Marquee(title_cls)
        self.artist = Marquee(artist_cls)
        self.play = button(icon("media-playback-start-symbolic"), "w-btn play", lambda: self.cmd("play-pause"))
        self.prev = button(icon("media-skip-backward-symbolic"), "w-btn", lambda: self.cmd("previous"))
        self.next = button(icon("media-skip-forward-symbolic"), "w-btn", lambda: self.cmd("next"))
        self.controls = box(Gtk.Orientation.HORIZONTAL, 8, "np-controls", self.prev, self.play, self.next,
                            valign=Gtk.Align.CENTER)
        self.text = box(Gtk.Orientation.VERTICAL, 1, None, self.title, self.artist,
                        valign=Gtk.Align.CENTER, hexpand=True)

    def cmd(self, action):
        if self.shell.preview:
            return
        system.media_cmd(action, self.np["player"] if self.np else None)
        GLib.timeout_add(350, lambda: (self.shell.poll(full=False, then=self.shell._media_changed), False)[1])

    def update(self, np, empty_title="Nothing playing", empty_sub="Start some music"):
        self.np = np
        self.title.set_label(np["title"] if np else empty_title)
        self.artist.set_label((np["artist"] or np.get("app", "").capitalize()) if np else empty_sub)
        self.art.set_art(np.get("art") if np else None)
        self.play.get_child().set_from_icon_name(
            "media-playback-pause-symbolic" if np and np["playing"] else "media-playback-start-symbolic")
        for b in (self.prev, self.play, self.next):
            b.set_sensitive(np is not None or self.shell.preview)


# ------------------------------------------------------------ desktop widgets
WIDGET_KINDS = ("clock", "weather", "calendar", "system", "media")
WIDGET_SIZES = {"small": (1, 1), "wide": (2, 1), "tall": (1, 2), "large": (2, 2)}
WIDGET_CELL, WIDGET_GAP = 150, 14
DEFAULT_WIDGETS = [{"kind": "clock", "size": "wide"}, {"kind": "weather", "size": "small"},
                   {"kind": "calendar", "size": "small"}, {"kind": "system", "size": "wide"},
                   {"kind": "media", "size": "wide"}]


def widget_list(cfg):
    """shell.json "widgets": [{"kind", "size"}] (old plain-name lists still work)"""
    out = []
    for w in cfg.get("widgets", DEFAULT_WIDGETS):
        if isinstance(w, str):
            w = next((d for d in DEFAULT_WIDGETS if d["kind"] == w), {"kind": w, "size": "small"})
        if w.get("kind") in WIDGET_KINDS:
            out.append({"kind": w["kind"], "size": w.get("size") if w.get("size") in WIDGET_SIZES else "small"})
    return out


def pack_widgets(items, cols):
    """iOS-style packing: each widget takes the first free spot (row-major) it fits.
    Returns [(col, row, w, h)] in cells."""
    taken, out = set(), []
    for it in items:
        w, h = WIDGET_SIZES[it["size"]]
        w = min(w, cols)
        r = 0
        while True:
            spot = next((c for c in range(cols - w + 1)
                         if all((c + dx, r + dy) not in taken for dx in range(w) for dy in range(h))), None)
            if spot is not None:
                break
            r += 1
        for dx in range(w):
            for dy in range(h):
                taken.add((spot + dx, r + dy))
        out.append((spot, r, w, h))
    return out


class WidgetCell(Gtk.Widget):
    """A card that is exactly its size (small / wide / tall / large): the
    content is laid out inside and clipped, it can never stretch the card."""

    def __init__(self, child, w, h):
        super().__init__()
        self.w, self.h, self.child = w, h, child
        child.set_parent(self)
        self.set_overflow(Gtk.Overflow.HIDDEN)

    def do_measure(self, orientation, for_size):
        v = self.w if orientation == Gtk.Orientation.HORIZONTAL else self.h
        return v, v, -1, -1

    def do_size_allocate(self, width, height, baseline):
        if self.child is None:
            return
        mw = self.child.measure(Gtk.Orientation.HORIZONTAL, -1)[0]
        mh = self.child.measure(Gtk.Orientation.VERTICAL, max(width, mw))[0]
        self.child.allocate(max(width, mw), max(height, mh), -1, None)

    def do_dispose(self):
        if self.child is not None:
            self.child.unparent()
            self.child = None


class Ring(Gtk.DrawingArea):
    """a progress ring in the accent colour (system widget)"""

    def __init__(self, size, width=7):
        super().__init__(content_width=size, content_height=size)
        self.value, self.width = 0.0, width
        self.add_css_class("w-ring")
        self.set_draw_func(self.draw)

    def set_value(self, v):
        self.value = max(0.0, min(1.0, v))
        self.queue_draw()

    def draw(self, _a, cr, w, h):
        import math
        c = self.get_color()
        r = min(w, h) / 2 - self.width / 2 - 1
        cr.set_line_width(self.width)
        cr.set_line_cap(1)   # round
        cr.set_source_rgba(*ink(), 0.14)
        cr.arc(w / 2, h / 2, r, 0, 2 * math.pi)
        cr.stroke()
        if self.value > 0.005:
            cr.set_source_rgba(c.red, c.green, c.blue, 1)
            cr.arc(w / 2, h / 2, r, -math.pi / 2, -math.pi / 2 + 2 * math.pi * self.value)
            cr.stroke()


class AnalogClock(Gtk.DrawingArea):
    def __init__(self, size):
        super().__init__(content_width=size, content_height=size)
        self.add_css_class("w-analog")
        self.set_draw_func(self.draw)

    def draw(self, _a, cr, w, h):
        import math
        acc = self.get_color()
        t = time.localtime()
        cx, cy, r = w / 2, h / 2, min(w, h) / 2 - 2
        cr.set_source_rgba(*ink(), 0.06)
        cr.arc(cx, cy, r, 0, 2 * math.pi)
        cr.fill()
        for i in range(60):   # ticks
            a = i / 60 * 2 * math.pi
            big = i % 5 == 0
            cr.set_source_rgba(*ink(), 0.85 if big else 0.25)
            cr.set_line_width(2.2 if big else 1)
            r0 = r - (9 if big else 5)
            cr.move_to(cx + math.sin(a) * r0, cy - math.cos(a) * r0)
            cr.line_to(cx + math.sin(a) * (r - 2), cy - math.cos(a) * (r - 2))
            cr.stroke()
        cr.set_line_cap(1)

        def hand(frac, length, width, rgba):
            a = frac * 2 * math.pi
            cr.set_source_rgba(*rgba)
            cr.set_line_width(width)
            cr.move_to(cx - math.sin(a) * 6, cy + math.cos(a) * 6)
            cr.line_to(cx + math.sin(a) * length, cy - math.cos(a) * length)
            cr.stroke()
        hand((t.tm_hour % 12 + t.tm_min / 60) / 12, r * 0.52, 4.5, (*ink(), 0.95))
        hand((t.tm_min + t.tm_sec / 60) / 60, r * 0.78, 3, (*ink(), 0.95))
        hand(t.tm_sec / 60, r * 0.84, 1.4, (acc.red, acc.green, acc.blue, 1))
        cr.set_source_rgba(acc.red, acc.green, acc.blue, 1)
        cr.arc(cx, cy, 3.5, 0, 2 * math.pi)
        cr.fill()


class DesktopWidgets:
    """Glass cards on the desktop (above the wallpaper, below windows), sized like
    Apple's widgets — small (square), wide, tall, large — each size showing more.
    Every card is a .glass pane, so it is frosted or Liquid Glass exactly like the
    rest of the shell and switches with Settings → Glass style."""

    def __init__(self, shell, win=None):
        self.shell, self.win = shell, win
        self.box = Gtk.Fixed()
        self.box.add_css_class("widgets")
        self.cards, self.updaters = [], []
        self.weather, self.weather_at = None, 0
        self.rebuild()
        shell.on_tick(self.tick)
        GLib.timeout_add_seconds(2, self._sys_tick)

    # --------------------------------------------------------- layout
    def place_window(self):
        """anchor the layer surface to the chosen corner of the screen"""
        if not LS or self.win is None:
            return
        pos = self.shell.cfg.get("widgets_position", "top-right")
        v, h = pos.split("-") if "-" in pos else ("top", "right")
        m = self.shell.cfg.get("widgets_margin", 22)
        for edge, on in (("t", v == "top"), ("b", v == "bottom"), ("l", h == "left"), ("r", h == "right")):
            e = {"t": LS.Edge.TOP, "b": LS.Edge.BOTTOM, "l": LS.Edge.LEFT, "r": LS.Edge.RIGHT}[edge]
            LS.set_anchor(self.win, e, on)
            LS.set_margin(self.win, e, (14 if edge in "tb" else m) if on else 0)

    def rebuild(self):
        child = self.box.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.box.remove(child)
            # (a card lets go of its content here: left to the garbage collector,
            # GTK warned "finalizing WidgetCell, but it still has children left"
            # in the session log for every card, at every restyle)
            if isinstance(child, WidgetCell) and child.child is not None:
                child.child.unparent()
                child.child = None
            child = nxt
        self.cards, self.updaters, self._wx_uis, self.sys_updaters = [], [], [], []
        items = widget_list(self.shell.cfg)
        cols = max(1, int(self.shell.cfg.get("widgets_columns", 2)))
        right = self.shell.cfg.get("widgets_position", "top-right").endswith("right")
        places = pack_widgets(items, cols)
        full_w = cols * WIDGET_CELL + (cols - 1) * WIDGET_GAP
        rows = max([r + h for _c, r, _w, h in places], default=0)
        for it, (c, r, w, h) in zip(items, places):
            pw, ph = w * WIDGET_CELL + (w - 1) * WIDGET_GAP, h * WIDGET_CELL + (h - 1) * WIDGET_GAP
            body = getattr(self, f"w_{it['kind']}")(it["size"], pw, ph)
            body.add_css_class("widget-body")
            card = WidgetCell(body, pw, ph)
            for cls in ("glass", "widget", f"size-{it['size']}", f"kind-{it['kind']}"):
                card.add_css_class(cls)
            x = c * (WIDGET_CELL + WIDGET_GAP)
            if right:   # right-anchored grids fill from the right edge
                x = full_w - x - pw
            self.box.put(card, x, r * (WIDGET_CELL + WIDGET_GAP))
            self.cards.append(card)
        # a changed set or layout (Settings → Widgets) arrives card by card
        sig = json.dumps([items, cols, right], sort_keys=True, default=str)
        if getattr(self, "_sig", None) not in (None, sig) and not self.shell.preview and motion_ms(100) > 0:
            for i, card in enumerate(self.cards):
                card.add_css_class("rise")
                card.add_css_class(f"d{min(i + 1, 9)}")
        self._sig = sig
        self.box.set_size_request(full_w if items else 1, rows * (WIDGET_CELL + WIDGET_GAP) - WIDGET_GAP if rows else 1)
        self.place_window()
        if self.win is not None and self.win.get_realized():
            self.win.set_visible(bool(self.cards))
        if not self.cards:
            GLASS.send(glass_ns("lumen-widgets", win=self.win), [])
        self.tick(True)
        self.report_glass()

    def glass_now(self):
        """after every frame the widgets draw: each lens goes where its card is now"""
        win = self.box.get_root()
        if not GLASS.enabled or GLASS.hold or self.shell.preview or not self.cards:
            return
        if isinstance(win, Gtk.Native) and win.get_mapped():
            panes = [pane_shape(c, win, 24, shadow=0.8, frost=0.7) for c in self.cards]
            GLASS.send(glass_ns("lumen-widgets", win=self.win), [p for p in panes if p])

    def report_glass(self):
        """liquid mode: one lens per card (re-sent when cards change)"""
        def go():
            win = self.box.get_root()
            if isinstance(win, Gtk.Native) and not self.shell.preview:
                panes = [pane_shape(c, win, 24, shadow=0.8, frost=0.7) for c in self.cards]
                GLASS.send(glass_ns("lumen-widgets", win=self.win), [p for p in panes if p])
            return False
        GLib.timeout_add(150, go)

    @staticmethod
    def _v(*kids, sp=0, cls=None, **kw):
        return box(Gtk.Orientation.VERTICAL, sp, cls, *kids, **kw)

    @staticmethod
    def _h(*kids, sp=0, cls=None, **kw):
        return box(Gtk.Orientation.HORIZONTAL, sp, cls, *kids, **kw)

    # ----------------------------------------------------------- clock
    def w_clock(self, size, pw, ph):
        time_lbl = lbl("", "w-time", xalign=0)
        date_lbl = lbl("", "w-date", xalign=0)
        day_lbl = lbl("", "w-kicker", xalign=0)
        fmt24 = lambda: self.shell.cfg["clock_24h"]  # noqa: E731
        analog = None
        if size == "small":
            time_lbl.add_css_class("w-time-s")
            card = self._v(day_lbl, Gtk.Box(vexpand=True), time_lbl, date_lbl, cls="w-clock")
        elif size == "wide":
            card = self._v(day_lbl, Gtk.Box(vexpand=True), time_lbl, date_lbl, cls="w-clock")
        else:
            analog = AnalogClock(int(min(pw - 40, ph - 124)))
            analog.set_halign(Gtk.Align.CENTER)
            time_lbl.add_css_class("w-time-s")
            time_lbl.set_xalign(0.5)
            date_lbl.set_xalign(0.5)
            card = self._v(analog, Gtk.Box(vexpand=True), time_lbl, date_lbl, cls="w-clock")

        def upd(full):
            t = time.localtime()
            time_lbl.set_label(time.strftime("%H:%M" if fmt24() else "%-I:%M", t))
            day_lbl.set_label(time.strftime("%A", t).upper())
            date_lbl.set_label(time.strftime("%a %-d %b" if size == "small" else "%B %-d, %Y", t))
            if analog:
                analog.queue_draw()
        self.updaters.append(upd)
        return card

    # --------------------------------------------------------- weather
    def w_weather(self, size, pw, ph):
        ui = {"icon": icon("weather-few-clouds-symbolic", 36 if size == "small" else 46, "w-wx-icon"),
              "temp": lbl("--°", "w-temp", xalign=0), "desc": lbl("Loading weather…", "w-sub", xalign=0,
                                                                  ellipsize=3, max_width_chars=20),
              "place": lbl("", "w-head", xalign=0, ellipsize=3, max_width_chars=18),
              "hilo": lbl("", "w-sub", xalign=0), "hours": None, "days": None}
        if size == "small":
            card = self._v(ui["place"], self._h(ui["temp"], Gtk.Box(hexpand=True), ui["icon"]),
                           Gtk.Box(vexpand=True), ui["desc"], ui["hilo"], cls="w-weather")
        elif size == "tall":   # narrow: stacked, then the next days
            ui["desc"].set_max_width_chars(14)
            ui["days"] = self._v(sp=6, cls="w-days", vexpand=True, valign=Gtk.Align.END)
            card = self._v(ui["place"], self._h(ui["temp"], Gtk.Box(hexpand=True), ui["icon"]),
                           ui["desc"], ui["hilo"], ui["days"], sp=2, cls="w-weather")
        else:
            if size == "wide":
                ui["temp"].add_css_class("w-temp-m")
                ui["icon"].set_pixel_size(34)
            top = self._h(self._v(ui["place"], ui["temp"], sp=0), Gtk.Box(hexpand=True),
                          self._v(ui["icon"], ui["desc"], ui["hilo"], sp=2, halign=Gtk.Align.END))
            ui["desc"].set_xalign(1)
            ui["hilo"].set_xalign(1)
            kids = [top]
            if size in ("wide", "large"):
                ui["hours"] = self._h(sp=0, cls="w-hours", homogeneous=True, vexpand=True, valign=Gtk.Align.END)
                kids.append(ui["hours"])
            if size in ("tall", "large"):
                ui["days"] = self._v(sp=4, cls="w-days", vexpand=True, valign=Gtk.Align.END)
                kids.append(ui["days"])
            card = self._v(*kids, sp=4 if size == "wide" else 10, cls="w-weather")

        def upd(full):
            if self.shell.preview and not self.weather:
                self.weather = {"temp_c": 4, "temp_f": 39, "desc": "Partly cloudy",
                                "icon": "weather-few-clouds-symbolic", "hi_c": 7, "lo_c": -1, "hi_f": 45,
                                "lo_f": 30, "place": "Toronto",
                                "hours": [{"hour": h, "temp_c": t, "temp_f": t * 9 // 5 + 32, "icon": i}
                                          for h, t, i in ((9, 2, "weather-overcast-symbolic"),
                                                          (12, 5, "weather-few-clouds-symbolic"),
                                                          (15, 7, "weather-clear-symbolic"),
                                                          (18, 4, "weather-few-clouds-symbolic"),
                                                          (21, 1, "weather-overcast-symbolic"),
                                                          (0, -1, "weather-clear-night-symbolic"))],
                                "days": [{"date": "2026-11-07", "hi_c": 7, "lo_c": -1, "hi_f": 45, "lo_f": 30,
                                          "icon": "weather-few-clouds-symbolic"},
                                         {"date": "2026-11-08", "hi_c": 9, "lo_c": 2, "hi_f": 48, "lo_f": 36,
                                          "icon": "weather-showers-symbolic"},
                                         {"date": "2026-11-09", "hi_c": 5, "lo_c": -2, "hi_f": 41, "lo_f": 28,
                                          "icon": "weather-clear-symbolic"}]}
            if not self.shell.preview and time.time() - self.weather_at > 1800:
                self.weather_at = time.time()

                def fetch():
                    w = system.weather(self.shell.cfg.get("weather_location", ""))
                    GLib.idle_add(lambda: (self._weather_arrived(w), False)[1])
                threading.Thread(target=fetch, daemon=True).start()
            self._show_weather(ui, size)
        self.updaters.append(upd)
        ui["upd"] = upd
        self._wx_uis = getattr(self, "_wx_uis", []) + [(ui, size)]
        return card

    def _weather_arrived(self, w):
        if w is not None:
            self.weather = w
        for ui, size in getattr(self, "_wx_uis", []):
            self._show_weather(ui, size)

    def _show_weather(self, ui, size):
        w = self.weather
        if w is None:
            ui["desc"].set_label("Weather unavailable" if self.weather_at else "Loading weather…")
            return
        u = "f" if self.shell.cfg.get("weather_units", "c") == "f" else "c"
        ui["icon"].set_from_icon_name(w["icon"])
        ui["temp"].set_label(f"{w['temp_' + u]}°")
        ui["desc"].set_label(w["desc"])
        ui["place"].set_label(w["place"] or "Weather")
        ui["hilo"].set_label(f"H {w['hi_' + u]}°  L {w['lo_' + u]}°")
        if ui["hours"] is not None:
            for ch in list(_children(ui["hours"])):
                ui["hours"].remove(ch)
            for i, h in enumerate(w.get("hours", [])[:6]):
                name = "Now" if i == 0 else time.strftime("%-I %p" if not self.shell.cfg["clock_24h"] else "%H:00",
                                                          time.struct_time((2000, 1, 1, h["hour"], 0, 0, 0, 1, -1)))
                ui["hours"].append(self._v(lbl(name, "w-tiny"), icon(h["icon"], 18, "w-wx-icon"),
                                           lbl(f"{h['temp_' + u]}°", "w-small"), sp=2))
        if ui["days"] is not None:
            for ch in list(_children(ui["days"])):
                ui["days"].remove(ch)
            narrow = size == "tall"
            for i, d in enumerate(w.get("days", [])[:3]):
                try:
                    name = "Today" if i == 0 else time.strftime("%a" if narrow else "%A",
                                                                time.strptime(d["date"], "%Y-%m-%d"))
                except ValueError:
                    name = d["date"]
                if narrow:
                    ui["days"].append(self._h(lbl(name, "w-small", xalign=0, hexpand=True),
                                              icon(d["icon"], 16, "w-wx-icon"),
                                              lbl(f"{d['hi_' + u]}°", "w-small", width_chars=3, xalign=1), sp=6))
                else:
                    ui["days"].append(self._h(lbl(name, "w-small", xalign=0, hexpand=True),
                                              icon(d["icon"], 18, "w-wx-icon"),
                                              lbl(f"{d['lo_' + u]}°", "w-sub", width_chars=4, xalign=1),
                                              lbl(f"{d['hi_' + u]}°", "w-small", width_chars=4, xalign=1), sp=8))

    # -------------------------------------------------------- calendar
    def w_calendar(self, size, pw, ph):
        import calendar as _cal
        head = lbl("", "w-kicker", xalign=0)
        big = lbl("", "w-bigday", xalign=0)
        sub = lbl("", "w-date", xalign=0, ellipsize=3, max_width_chars=14)
        grid = None
        if size == "small":
            card = self._v(head, big, Gtk.Box(vexpand=True), sub, cls="w-calendar")
        elif size == "wide":
            grid = Gtk.Grid(column_homogeneous=True, row_spacing=4, column_spacing=2, hexpand=True,
                            valign=Gtk.Align.CENTER)
            card = self._h(self._v(head, big, Gtk.Box(vexpand=True), sub, sp=0), grid, sp=18, cls="w-calendar")
        else:
            grid = Gtk.Grid(column_homogeneous=True, row_homogeneous=True, row_spacing=2, column_spacing=2,
                            vexpand=True)
            card = self._v(head, grid, sp=8, cls="w-calendar")
        state = {"day": None}

        def upd(full):
            t = time.localtime()
            key = (t.tm_year, t.tm_mon, t.tm_mday)
            if state["day"] == key:
                return
            state["day"] = key
            head.set_label(time.strftime("%A" if size in ("small", "wide") else "%B %Y", t).upper())
            big.set_label(str(t.tm_mday))
            sub.set_label(time.strftime("%b %Y" if size == "wide" else "%B %Y", t))
            if grid is None:
                return
            for ch in list(_children(grid)):
                grid.remove(ch)
            for c, d in enumerate("SMTWTFS"):
                grid.attach(lbl(d, "w-dow"), c, 0, 1, 1)
            weeks = _cal.Calendar(firstweekday=6).monthdayscalendar(t.tm_year, t.tm_mon)
            if size == "wide":   # just this week
                weeks = [next(wk for wk in weeks if t.tm_mday in wk)]
            for r, week in enumerate(weeks):
                for c, d in enumerate(week):
                    cell = lbl(str(d) if d else "", "w-day")
                    if d == t.tm_mday:
                        cell.add_css_class("today")
                    grid.attach(cell, c, r + 1, 1, 1)
        self.updaters.append(upd)
        return card

    # ---------------------------------------------------------- system
    def w_system(self, size, pw, ph):
        keys = (("cpu", "CPU"), ("mem", "Memory"), ("disk", "Disk"), ("bat", "Battery"))
        parts = {}
        extra = None
        if size in ("small", "large"):
            ring_sz = 84 if size == "small" else 104
            shown = keys[:1] if size == "small" else keys
            grid = Gtk.Grid(column_homogeneous=True, row_homogeneous=True, column_spacing=10, row_spacing=10,
                            vexpand=True)
            for i, (k, name) in enumerate(shown):
                ring = Ring(ring_sz, 8)
                pct = lbl("", "w-ring-val")
                ov = Gtk.Overlay(halign=Gtk.Align.CENTER)
                ov.set_child(ring)
                ov.add_overlay(pct)
                cell = self._v(ov, lbl(name, "w-tiny"), sp=4, valign=Gtk.Align.CENTER)
                parts[k] = (ring, pct, cell)
                grid.attach(cell, i % 2, i // 2, 1, 1)
            if size == "small":
                extra = lbl("", "w-sub")
                card = self._v(grid, extra, sp=4, cls="w-system")
            else:
                card = self._v(lbl("System", "w-head", xalign=0), grid, sp=8, cls="w-system")
        else:
            rows = []
            for k, name in keys:
                bar = Gtk.LevelBar(min_value=0, max_value=1, hexpand=True, valign=Gtk.Align.CENTER)
                bar.add_css_class("w-bar")
                val = lbl("", "w-val", xalign=1, width_chars=7)
                r = self._h(lbl(name, "w-name", xalign=0, width_chars=7), bar, val, sp=10, cls="w-row")
                parts[k] = (bar, val, r)
                rows.append(r)
            kids = [lbl("System", "w-head", xalign=0), *rows]
            if size == "tall":
                extra = lbl("", "w-sub", xalign=0)
                kids += [Gtk.Box(vexpand=True), extra]
            card = self._v(*kids, sp=8 if size == "wide" else 12, cls="w-system")

        def upd(full=False):
            if self.shell.preview:
                vals = {"cpu": (0.23, "23%"), "mem": (0.41, "6.5 GB"), "disk": (0.58, "290 GB"), "bat": (0.82, "82%")}
                up, la = "3h 12m", 0.42
            else:
                m, d, b = system.memory(), system.disk(), self.shell.sys.get("battery")
                c = system.cpu_percent()
                vals = {"cpu": (c, f"{c * 100:.0f}%"), "mem": (m[0], f"{m[1]:.1f} GB"),
                        "disk": (d[0], f"{d[1]:.0f} GB"),
                        "bat": ((b["percent"] / 100, f"{b['percent']}%{' ⚡' if b['charging'] else ''}")
                                if b else None)}
                up, la = system.uptime(), system.loadavg()
            for k, (w, val, row) in parts.items():
                v = vals.get(k)
                row.set_visible(v is not None)
                if v:
                    w.set_value(v[0])
                    val.set_label(v[1] if isinstance(w, Gtk.LevelBar) else f"{v[0] * 100:.0f}%")
            if extra is not None:
                extra.set_label(f"Memory {vals['mem'][1]}" if size == "small" else f"Up {up}  ·  load {la:.2f}")
        self.sys_updaters = getattr(self, "sys_updaters", []) + [upd]
        self.updaters.append(lambda full: upd() if full else None)
        return card

    def _sys_tick(self):
        for u in getattr(self, "sys_updaters", []):
            u()
        return True

    # ----------------------------------------------------------- media
    def w_media(self, size, pw, ph):
        art_px = {"small": 64, "wide": 56, "tall": 112, "large": 170}[size]
        np = NowPlaying(self.shell, art=art_px)
        if size == "small":
            card = self._v(self._h(np.art, Gtk.Box(hexpand=True), np.play, valign=Gtk.Align.START),
                           Gtk.Box(vexpand=True), np.text, cls="w-media")
        elif size == "wide":
            np.controls.set_halign(Gtk.Align.START)
            card = self._v(self._h(np.art, np.text, sp=12), Gtk.Box(vexpand=True), np.controls, cls="w-media")
        else:
            np.art.set_halign(Gtk.Align.CENTER)
            np.title.label.set_xalign(0.5)
            np.artist.label.set_xalign(0.5)
            np.controls.set_halign(Gtk.Align.CENTER)
            card = self._v(np.art, Gtk.Box(vexpand=True), np.text, np.controls, sp=6, cls="w-media")

        def upd(full):
            np.update(self.shell.sys.get("media"), "Nothing playing", "" if size == "small" else "Start some music")
        self.updaters.append(upd)
        return card

    def tick(self, full):
        for u in self.updaters:
            u(full)


def _children(w):
    c = w.get_first_child()
    while c:
        nxt = c.get_next_sibling()
        yield c
        c = nxt


class BatteryPopup(Popup):
    """Battery level, time left and power mode (power-profiles-daemon)."""

    def __init__(self, shell):
        self.shell = shell
        self.pct = lbl("", "bat-big", xalign=0)
        self.state = lbl("", "sub", xalign=0)
        self.bar = Gtk.LevelBar(min_value=0, max_value=1, hexpand=True)
        self.bar.add_css_class("bat-bar")
        self.modes = PowerModes(shell)
        card = box(Gtk.Orientation.VERTICAL, 10, "glass card battery-card",
                   box(Gtk.Orientation.HORIZONTAL, 12, None, icon("battery-good-symbolic", 30, "bat-ic"),
                       box(Gtk.Orientation.VERTICAL, 0, None, self.pct, self.state, valign=Gtk.Align.CENTER)),
                   self.bar, lbl("Power Mode", "section", xalign=0), self.modes.widget)
        card.set_size_request(330, -1)
        super().__init__(shell, "battery", card, Gtk.Align.END, Gtk.Align.START,
                         {"top": 38, "end": 160}, Gtk.RevealerTransitionType.SLIDE_DOWN)

    def on_open(self):
        b = self.shell.sys.get("battery")
        if b:
            self.pct.set_label(f"{b['percent']}%")
            self.bar.set_value(b["percent"] / 100)
            m = b.get("minutes")
            hm = (f"{m // 60} h {m % 60} min" if m >= 60 else f"{m} min") if m else None
            if b.get("full"):
                self.state.set_label("Fully charged")
            elif b["charging"]:
                self.state.set_label(f"Charging · full in {hm}" if hm else "Charging")
            else:
                self.state.set_label(f"{hm} remaining" if hm else "On battery")
        else:
            self.pct.set_label("Plugged in")
            self.state.set_label("No battery")
        self.modes.refresh()


class PowerModes:
    """Power Saver / Balanced / Performance segmented control."""

    def __init__(self, shell):
        self.shell = shell
        self.btns = {}
        self.note = lbl("Install power-profiles-daemon to switch power modes.", "sub", xalign=0, wrap=True)
        row = box(Gtk.Orientation.HORIZONTAL, 6, "power-modes", homogeneous=True)
        for key, name, ic in system.POWER_PROFILES:
            b = Gtk.ToggleButton()
            b.set_child(box(Gtk.Orientation.VERTICAL, 4, None, icon(ic, 20), lbl(name, "pm-name")))
            b.add_css_class("pm")
            b.connect("toggled", lambda w, k=key: w.get_active() and self.pick(k))
            self.btns[key] = b
            row.append(b)
        self.widget = box(Gtk.Orientation.VERTICAL, 6, None, row, self.note)
        self._busy = False

    def refresh(self):
        def work():
            cur, avail = system.power_profile(), system.power_profiles_available()
            GLib.idle_add(lambda: (self.show(cur, avail), False)[1])
        if self.shell.preview:
            self.show("balanced", ["power-saver", "balanced", "performance"])
        else:
            threading.Thread(target=work, daemon=True).start()

    def show(self, cur, avail):
        self._busy = True
        for k, b in self.btns.items():
            b.set_active(k == cur)
            b.set_sensitive(k in avail)
        self.note.set_visible(not avail)
        self._busy = False

    def pick(self, key):
        if self._busy:
            return
        self._busy = True
        for k, b in self.btns.items():
            if k != key:
                b.set_active(False)
        self._busy = False
        if not self.shell.preview:
            system.set_power_profile(key)


class CalendarPopup(Popup):
    """Today at a glance, and a month you can page through."""

    def __init__(self, shell):
        self.kicker = lbl("", "cal-kicker", xalign=0)
        self.big = lbl("", "cal-big", xalign=0)
        self.time = lbl("", "cal-time", xalign=0)
        self.month_lbl = lbl("", "cal-month", xalign=0, hexpand=True)
        self.today_btn = button(lbl("Today"), "cal-today", lambda: self.show_month(None))
        self.today_btn.set_valign(Gtk.Align.CENTER)
        prev = button(icon("go-previous-symbolic", 14), "cal-nav", lambda: self.step(-1), "Previous month")
        nxt = button(icon("go-next-symbolic", 14), "cal-nav", lambda: self.step(1), "Next month")
        nav = box(Gtk.Orientation.HORIZONTAL, 2, None, self.month_lbl, self.today_btn, prev, nxt)
        nav.set_margin_top(10)
        self.stack = Gtk.Stack(transition_duration=260, hhomogeneous=True, vhomogeneous=False,
                               interpolate_size=True)
        self.shown = None          # (year, month)
        self._n = 0
        card = box(Gtk.Orientation.VERTICAL, 2, "glass card calendar-card", self.kicker, self.big, self.time,
                   nav, self.stack)
        sc = Gtk.EventControllerScroll(flags=Gtk.EventControllerScrollFlags.VERTICAL |
                                       Gtk.EventControllerScrollFlags.DISCRETE)
        sc.connect("scroll", lambda _c, _dx, dy: (self.step(1 if dy > 0 else -1), True)[1])
        card.add_controller(sc)
        super().__init__(shell, "calendar", card, Gtk.Align.END, Gtk.Align.START, {"top": 38, "end": 10})
        shell.on_tick(self.tick)

    def tick(self, _slow):
        if self._open:
            fmt = "%H:%M" if self.shell.cfg["clock_24h"] else "%-I:%M %p"
            self.time.set_label(time.strftime(fmt + "  ·  %Z"))

    def month_grid(self, year, month):
        import calendar as _cal
        t = time.localtime()
        grid = Gtk.Grid(column_homogeneous=True, row_spacing=2, column_spacing=2, margin_top=6)
        for c, d in enumerate(("S", "M", "T", "W", "T", "F", "S")):
            grid.attach(lbl(d, "cal-dow"), c, 0, 1, 1)
        for r, week in enumerate(_cal.Calendar(firstweekday=6).monthdatescalendar(year, month)):
            for c, day in enumerate(week):
                cell = lbl(str(day.day), "cal-day", halign=Gtk.Align.CENTER)
                if day.month != month:
                    cell.add_css_class("other")
                if c in (0, 6):
                    cell.add_css_class("weekend")
                if (day.year, day.month, day.day) == (t.tm_year, t.tm_mon, t.tm_mday):
                    cell.add_css_class("today")
                grid.attach(cell, c, r + 1, 1, 1)
        return grid

    def show_month(self, ym, direction=0):
        t = time.localtime()
        ym = ym or (t.tm_year, t.tm_mon)
        if self.shown and not direction:
            direction = (ym > self.shown) - (ym < self.shown)
        self.shown = ym
        self._n += 1
        page = self.month_grid(*ym)
        name = f"m{self._n}"
        old = self.stack.get_visible_child()
        self.stack.add_named(page, name)
        self.stack.set_transition_duration(motion_ms(260))
        self.stack.set_visible_child_full(name, {1: Gtk.StackTransitionType.SLIDE_LEFT,
                                                 -1: Gtk.StackTransitionType.SLIDE_RIGHT}.get(
                                                     direction, Gtk.StackTransitionType.NONE))
        if old is not None:
            GLib.timeout_add(motion_ms(260) + 80, lambda: (old.get_parent() is self.stack and
                                                          self.stack.remove(old), False)[1])
        self.month_lbl.set_label(time.strftime("%B %Y", (ym[0], ym[1], 1, 0, 0, 0, 0, 1, -1)))
        self.today_btn.set_visible(ym != (t.tm_year, t.tm_mon))

    def step(self, d):
        y, m = self.shown or time.localtime()[:2]
        y, m0 = divmod(y * 12 + (m - 1) + d, 12)
        self.show_month((y, m0 + 1), 1 if d > 0 else -1)

    def on_open(self):
        t = time.localtime()
        self.kicker.set_label(time.strftime("%A", t).upper())
        self.big.set_label(time.strftime("%B %-d", t))
        self._open = True
        self.tick(True)
        self.shown = None
        self.show_month(None)


class WallpaperView(Gtk.Stack):
    """The desktop picture. A new wallpaper fades in over the old one instead of
    cutting to it. Looks like a Gtk.Picture to the rest of the shell."""

    def __init__(self):
        super().__init__(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=700)
        self.lumen_media = None
        self.source = None       # what is showing (path), so reloads don't restart it
        self._n = 0

    def _show(self, pic):
        self._n += 1
        old = self.get_visible_child()
        name = f"w{self._n}"
        self.add_named(pic, name)
        ms = motion_ms(700) if old is not None else 0
        self.set_transition_duration(ms)
        self.set_visible_child_name(name)
        if old is not None:
            GLib.timeout_add(ms + 250, lambda: (old.get_parent() is self and self.remove(old), False)[1])

    def set_filename(self, path):
        pic = Gtk.Picture(content_fit=Gtk.ContentFit.COVER)
        pic.set_filename(path)
        self._show(pic)

    def set_paintable(self, paintable):
        pic = Gtk.Picture(content_fit=Gtk.ContentFit.COVER)
        pic.set_paintable(paintable)
        self._show(pic)


# ------------------------------------------------------------------ startup
class Startup:
    """The first second of a session. The Lumen mark comes up on black; then the
    wallpaper fades in underneath while it settles from slightly zoomed in, the
    mark blooms away, and the bars and widgets arrive (the compositor slides them
    in, the dock's icons rise one after another).

    It plays once per session: not when the shell restarts or reloads, and not
    when a screen is plugged in. It follows the animation speed slider and never
    plays with animations off or in Performance mode. It lives on the wallpaper
    surface, under everything, so it can never cover a window or take input."""

    MARK_IN, HOLD, REVEAL, BLOOM, SETTLE, BARS = 200, 40, 560, 360, 900, 0   # ms at normal speed

    CSS = """
.boot-cover { background-color: #000; }
.boot-mark { opacity: 0; }
.boot-halo { background-image: radial-gradient(circle closest-side, rgba(167,123,255,.34),
    rgba(127,156,255,.13) 52%%, rgba(127,156,255,0)); }
.boot-wall { transform: scale(1.07); }
.boot-go .boot-mark { animation: boot-mark %(mark)dms cubic-bezier(.2,.8,.2,1) both; }
.boot-go .boot-bloom { animation: boot-bloom %(bloom)dms cubic-bezier(.45,0,.9,.6) %(at)dms both; }
.boot-cover.boot-go { animation: boot-cover %(reveal)dms cubic-bezier(.4,0,.2,1) %(at)dms both; }
.boot-wall.boot-go { animation: boot-wall %(settle)dms cubic-bezier(.16,1,.3,1) %(at)dms both; }
.boot-item { animation: rise %(item)dms cubic-bezier(.2,1.1,.3,1) both; }
.boot-hide { opacity: 0; }
.boot-show { animation: boot-show %(item)dms cubic-bezier(.2,.9,.3,1) both; }
@keyframes boot-show { from { opacity: 0; } to { opacity: 1; } }
@keyframes boot-mark { from { opacity: 0; transform: scale(.8); } to { opacity: 1; transform: none; } }
@keyframes boot-bloom { from { opacity: 1; transform: none; } to { opacity: 0; transform: scale(1.5); } }
@keyframes boot-cover { from { opacity: 1; } to { opacity: 0; } }
@keyframes boot-wall { from { transform: scale(1.07); } to { transform: none; } }
"""

    @staticmethod
    def wanted(cfg):
        """only at login: once per compositor instance, with animations on"""
        if not cfg.get("startup_animation", True) or _motion_scale() <= 0:
            return False
        try:
            st = os.stat(ipc.socket_path())      # a new compositor makes a new socket
        except OSError:
            return False
        ident = f"{st.st_ino}:{st.st_ctime_ns}"
        marker = os.path.join(os.environ.get("XDG_RUNTIME_DIR") or "/tmp", "lumen-startup")
        try:
            with open(marker) as f:
                if f.read().strip() == ident:
                    return False                  # the shell restarted mid-session
        except OSError:
            pass
        try:
            with open(marker, "w") as f:
                f.write(ident)
        except OSError:
            return False                          # can't remember: don't replay on every reload
        return True

    def __init__(self, k=1.0):
        self.k = max(0.5, min(1.6, k))
        self.open = True          # still taking screens (the first build only)
        self.done = False
        self.parts = []           # (overlay, cover, wallpaper) per screen
        self.shown = []           # bar / widget contents that faded in
        GLASS.hold = True
        self.waiting = []         # what shows once the desktop is revealed
        self.items = []
        self._going = self._released = False
        ms = lambda v: int(v * self.k)   # noqa: E731
        self.at = ms(self.MARK_IN + self.HOLD)
        self.total = self.at + ms(self.SETTLE) + 150
        css = self.CSS % {"mark": ms(self.MARK_IN), "bloom": ms(self.BLOOM), "reveal": ms(self.REVEAL),
                          "settle": ms(self.SETTLE), "at": self.at, "item": ms(260)}
        css += "".join(f".boot-item.bi{i} {{ animation-delay: {ms(14 * i)}ms; }}\n" for i in range(16))
        self.provider = Gtk.CssProvider()
        self.provider.load_from_string(css) if hasattr(self.provider, "load_from_string") \
            else self.provider.load_from_data(css.encode(), -1)
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), self.provider,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 4)
        # whatever happens, the bars are never held back for long (normally go()
        # releases them a third of a second after the wallpaper's first frame)
        GLib.timeout_add(3000, self.release)
        GLib.timeout_add(3000 + self.total, self.finish)

    def attach(self, win, pic):
        """put the cover over this screen's wallpaper; returns what the window shows"""
        halo = Gtk.Box(css_classes=["boot-halo"])
        halo.set_size_request(440, 440)
        logo = Gtk.Image.new_from_gicon(logo_gicon("lumen-logo"))
        logo.set_pixel_size(116)
        logo.set_halign(Gtk.Align.CENTER)
        logo.set_valign(Gtk.Align.CENTER)
        bloom = Gtk.Overlay(css_classes=["boot-bloom"], child=halo)
        bloom.add_overlay(logo)
        mark = Gtk.Box(css_classes=["boot-mark"], halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER,
                       hexpand=True, vexpand=True)
        mark.append(bloom)
        cover = Gtk.Box(css_classes=["boot-cover"], can_target=False)
        cover.append(mark)
        pic.add_css_class("boot-wall")
        ov = Gtk.Overlay(child=pic)
        ov.add_overlay(cover)
        self.parts.append((ov, cover, pic))
        # start once the black frame is really on screen and the shell has settled
        win.connect("map", lambda *_: GLib.timeout_add(40, self.go))
        return ov

    def later(self, fn):
        """run fn when the desktop is revealed (now, if that already happened)"""
        if self._released:
            fn()
        else:
            self.waiting.append(fn)

    def go(self):
        if self._going or self.done:
            return False
        self._going = True
        for _ov, cover, pic in self.parts:
            cover.add_css_class("boot-go")
            pic.add_css_class("boot-go")
        GLib.timeout_add(self.at + int(self.BARS * self.k), self.release)
        GLib.timeout_add(self.total, self.finish)
        return False

    def stagger(self, widgets):
        """these rise one after another as their bar arrives"""
        for i, w in enumerate(widgets):
            w.add_css_class("boot-item")
            w.add_css_class(f"bi{min(i, 15)}")
            self.items.append(w)

    def release(self):
        if self._released:
            return False
        self._released = True
        GLASS.hold = False
        waiting, self.waiting = self.waiting, []
        for fn in waiting:
            try:
                fn()
            except Exception as e:   # noqa: BLE001 — one screen's trouble never hides another's bars
                print("lumen-shell: startup:", e, file=sys.stderr)
        return False

    def finish(self):
        if self.done:
            return False
        self.release()
        self.done = True
        self.open = False
        for ov, cover, pic in self.parts:
            try:
                ov.remove_overlay(cover)
                pic.remove_css_class("boot-wall")
                pic.remove_css_class("boot-go")
            except Exception:   # noqa: BLE001 — the screen went away meanwhile
                pass
        for w in self.shown:
            w.remove_css_class("boot-hide")
            w.remove_css_class("boot-show")
        self.shown = []
        GLASS.hold = False
        for w in self.items:
            w.remove_css_class("boot-item")
            for i in range(16):
                w.remove_css_class(f"bi{i}")
        self.parts, self.items = [], []
        Gtk.StyleContext.remove_provider_for_display(Gdk.Display.get_default(), self.provider)
        return False


class Farewell:
    """Logging out, restarting or shutting down: the desktop sinks to black while the
    Lumen mark gathers in the middle, rests a moment and dims; then the session
    ends. The mirror image of Startup, at the same speed setting. If the session
    turns out not to end (a shutdown that something blocked), the desktop comes
    back after a few seconds."""

    COVER, MARK_AT, MARK_IN, HOLD, MARK_OUT = 420, 90, 340, 120, 180   # ms at normal speed

    CSS = """
.bye-cover { background-color: #000; animation: bye-cover %(cover)dms cubic-bezier(.4,0,.2,1) both; }
.bye-halo { background-image: radial-gradient(circle closest-side, rgba(167,123,255,.34),
    rgba(127,156,255,.13) 52%%, rgba(127,156,255,0)); }
.bye-mark { animation: bye-mark %(mark)dms cubic-bezier(.2,.8,.2,1) %(at)dms both; }
.bye-dim { animation: bye-dim %(out)dms cubic-bezier(.4,0,1,1) %(dim)dms both; }
@keyframes bye-cover { from { opacity: 0; } to { opacity: 1; } }
@keyframes bye-mark { from { opacity: 0; transform: scale(1.4); } to { opacity: 1; transform: none; } }
@keyframes bye-dim { from { opacity: 1; transform: none; } to { opacity: 0; transform: scale(.92); } }
"""

    def __init__(self, shell, action, k=1.0):
        self.shell, self.action = shell, action
        k = max(0.5, min(1.6, k))
        ms = lambda v: int(v * k)   # noqa: E731
        dim = ms(self.MARK_AT + self.MARK_IN + self.HOLD)
        self.total = dim + ms(self.MARK_OUT) + 40
        css = self.CSS % {"cover": ms(self.COVER), "mark": ms(self.MARK_IN), "at": ms(self.MARK_AT),
                          "out": ms(self.MARK_OUT), "dim": dim}
        self.provider = Gtk.CssProvider()
        self.provider.load_from_string(css) if hasattr(self.provider, "load_from_string") \
            else self.provider.load_from_data(css.encode(), -1)
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), self.provider,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 4)
        self.wins = []
        self._left = False
        mons = Gdk.Display.get_default().get_monitors()
        for i in range(max(1, mons.get_n_items())):
            mon = mons.get_item(i) if mons.get_n_items() else None
            # (not a "lumen-" surface: this one is no glass panel, nothing is frosted behind it)
            win = LayerWin(shell.app, "farewell", "overlay", "tblr", -1, monitor=mon)
            win.set_child(self.cover())
            self.wins.append(win)
            # the clock starts when the cover is really up, so the mark has dimmed before we go
            win.connect("map", lambda *_: GLib.timeout_add(self.total + 60, self.leave))
            win.present()
        GLib.timeout_add(self.total + 2000, self.leave)    # whatever happens, we do leave

    def cover(self):
        halo = Gtk.Box(css_classes=["bye-halo"])
        halo.set_size_request(440, 440)
        logo = Gtk.Image.new_from_gicon(logo_gicon("lumen-logo"))
        logo.set_pixel_size(116)
        logo.set_halign(Gtk.Align.CENTER)
        logo.set_valign(Gtk.Align.CENTER)
        dim = Gtk.Overlay(css_classes=["bye-dim"], child=halo)
        dim.add_overlay(logo)
        mark = Gtk.Box(css_classes=["bye-mark"], halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER,
                       hexpand=True, vexpand=True)
        mark.append(dim)
        cover = Gtk.Box(css_classes=["bye-cover"])
        cover.append(mark)
        return cover

    def leave(self):
        if self._left:
            return False
        self._left = True
        try:
            ok = self.action()
        except Exception as e:   # noqa: BLE001
            print("lumen-shell: ending the session:", e, file=sys.stderr)
            ok = False
        # still here in a while? then it didn't happen: give the desktop back
        GLib.timeout_add(600 if ok is False else 6000, self.back)
        return False

    def back(self):
        for w in self.wins:
            w.destroy()
        self.wins = []
        Gtk.StyleContext.remove_provider_for_display(Gdk.Display.get_default(), self.provider)
        self.shell.farewell = None
        return False


# ---------------------------------------------------------------- the shell
class Shell:
    def __init__(self, app, preview=False, fake_state=None):
        self.app = app
        self.preview = preview
        self.cfg = load_config()
        self.comp = ipc.Compositor(fake_state)
        self._tickers = []
        self.sys = {"battery": None, "wifi": {"on": True, "ssid": None, "signal": 0},
                    "volume": {"level": 0.5, "muted": False}, "bt": False, "brightness": None, "media": None}
        if preview:
            self.sys.update(battery={"percent": 82, "charging": False},
                            wifi={"on": True, "ssid": "Lumen-5G", "signal": 90},
                            volume={"level": 0.62, "muted": False}, bt=True, brightness=0.74,
                            media={"playing": True, "title": "Midnight City — M83 (Official Video, Remastered 4K)",
                                   "artist": "Synthwave Radio", "player": "firefox", "app": "firefox",
                                   "art": os.environ.get("LUMEN_PREVIEW_ART")})
        else:
            self.poll(full=True)
        self.popups = {}
        self.osd = extras.Osd(self)
        self.notify = notifications.Notifications(self)
        self.taskbars = []
        self.wallpapers = []
        self.desktop_widgets = []
        self.monitor_parts = {}     # Gdk.Monitor → what its bars/widgets registered
        self._building = None
        self.boot = None            # the startup animation, while it plays
        self.farewell = None        # the log out animation, while it plays

    def launcher(self):
        """Spotlight, unless another launcher was chosen in lumen.conf / shell.json"""
        cmd = self.cfg.get("launcher", "lumen-launcher")
        if cmd == "lumen-launcher" and conf_value("launcher", "lumen-launcher") == "lumen-launcher":
            self.toggle("spotlight")
        else:
            system.run(cmd)

    ENDINGS = {"logout": lambda: ipc.send("quit") or (system.spawn("lumenctl quit"), None)[1],
               "restart": lambda: system.spawn("systemctl reboot"),
               "shutdown": lambda: system.spawn("systemctl poweroff")}

    def end_session(self, how):
        """log out / restart / shut down, after the farewell animation (if animations are on)"""
        action = self.ENDINGS.get(how)
        if action is None or self.farewell is not None:
            return
        self.close_all()
        if self.preview or _motion_scale() <= 0 or not self.cfg.get("startup_animation", True):
            action()
            return
        self.farewell = Farewell(self, action, _motion_scale())

    def set_light_mode(self, on):
        """dark ⇄ light from the shell (Control Centre, Spotlight): the same as
        Settings → Appearance. The compositor, we, Files and Settings follow
        lumen.conf; lumen-theme tells the other apps."""
        if light_mode() == bool(on):
            return
        set_conf_value("color_scheme", "light" if on else "dark")
        other = extras.wallpaper_for(self.cfg.get("wallpaper", ""), on)
        if other:                       # Lumen's own wallpapers have a version for each mode
            save_config({"wallpaper": other})
        ipc.send("reload")
        self.reload()
        system.spawn("lumen-theme >/dev/null 2>&1")

    def system_actions(self):
        """things Spotlight can do by name"""
        nf = self.notify
        light = light_mode()
        return [
            ("lock", "Lock Screen", "system-lock-screen-symbolic", "lock screen", lambda: system.spawn("lumen-lock")),
            ("sleep", "Sleep", "weather-clear-night-symbolic", "sleep suspend", lambda: system.spawn("systemctl suspend")),
            ("logout", "Log Out…", "system-log-out-symbolic", "log out sign out exit", lambda: self.end_session("logout")),
            ("restart", "Restart…", "system-reboot-symbolic", "restart reboot", lambda: self.end_session("restart")),
            ("shutdown", "Shut Down…", "system-shutdown-symbolic", "shut down power off", lambda: self.end_session("shutdown")),
            ("scheme", "Dark Mode" if light else "Light Mode", "weather-clear-symbolic",
             "light mode dark mode appearance theme", lambda: self.set_light_mode(not light)),
            ("shot", "Screenshot", "camera-photo-symbolic", "screenshot capture screen",
             lambda: GLib.timeout_add(350, lambda: (system.spawn("lumen-screenshot"), False)[1])),
            ("dnd", "Turn Do Not Disturb " + ("Off" if nf.dnd else "On"), "lumen-bell-off-symbolic",
             "do not disturb dnd quiet silence notifications", lambda: nf.set_dnd(not nf.dnd)),
            ("desktop", "Show Desktop", "user-desktop-symbolic", "show desktop hide windows minimise all",
             lambda: ipc.send("desktop")),
            ("emoji", "Emoji", "face-smile-symbolic", "emoji smiley symbols",
             lambda: GLib.timeout_add(250, lambda: (self.toggle("emoji"), False)[1])),
            ("trash", "Empty Trash", "user-trash-symbolic", "empty trash bin", lambda: system.spawn("gio trash --empty")),
            ("settings", "System Settings", "preferences-system", "settings preferences", lambda: system.run(self.cfg["settings"])),
        ]

    def task_menu(self, entry, x):
        self.popups["task"].show_for(entry, x)

    def set_pinned(self, desktop_id, pinned):
        pins = [p for p in self.cfg["pinned"] if p != desktop_id]
        if pinned:
            pins.append(desktop_id)
        self.cfg["pinned"] = pins
        save_config({"pinned": pins})
        for t in self.taskbars:
            t.rebuild()

    def reload(self):
        """Settings changed shell.json / shell.css: apply without restarting."""
        self.cfg = load_config()
        # whatever changes colour (accent, tint, glass style) flows to its new value
        wins = list(Gtk.Window.list_toplevels())
        for w in wins:
            w.add_css_class("restyle")
        GLib.timeout_add(520, lambda: ([w.remove_css_class("restyle") for w in wins], False)[1])
        load_css(self.cfg.get("icon_theme"))
        for pic in self.wallpapers:
            self.set_wallpaper(pic)
        self.update_videos()
        for t in self.taskbars:
            t.rebuild()
        for dw in self.desktop_widgets:
            dw.rebuild()
        GLASS.last.clear()
        for w in self.app.get_windows() if self.app else []:
            if getattr(w, "is_topbar", False):
                self.report_topbar(w)
        for fn in self._tickers:
            fn(True)
        self.notify.changed()

    def build_popups(self):
        logo_items = [
            ("About Lumen", None, lambda: system.spawn("lumen-about || notify-send 'Lumen' 'Liquid glass desktop'")),
            None,
            ("System Settings…", None, lambda: system.run(self.cfg["settings"])),
            ("Spotlight…", "⌘ Space", self.launcher),
            ("Overview", "⌘ Tab", lambda: ipc.send("overview")),
            None,
            ("Force Quit…", None, lambda: self._focused_cmd("close")),
            None,
            ("Sleep", None, lambda: system.spawn("systemctl suspend")),
            ("Restart…", None, lambda: self.end_session("restart")),
            ("Shut Down…", None, lambda: self.end_session("shutdown")),
            None,
            ("Lock Screen", "⌘ L", lambda: system.spawn("lumen-lock")),
            ("Log Out…", "⇧⌘ E", lambda: self.end_session("logout")),
        ]
        logo = Popup(self, "logo", menu_card(logo_items, self.close_all), Gtk.Align.START, Gtk.Align.START, {"top": 34, "start": 8},
            Gtk.RevealerTransitionType.SLIDE_DOWN)
        win = Popup(self, "window", menu_card(after=self.close_all, items=[
            ("Minimize", "⌘ M", lambda: self._focused_cmd("minimize")),
            ("Zoom", "⌘ F", lambda: self._focused_cmd("maximize")),
            None,
            ("Move to Desktop 1", None, lambda: self._move(1)),
            ("Move to Desktop 2", None, lambda: self._move(2)),
            ("Move to Desktop 3", None, lambda: self._move(3)),
            ("Move to Desktop 4", None, lambda: self._move(4)),
            None,
            ("Close Window", "⌘ Esc", lambda: self._focused_cmd("close")),
        ]), Gtk.Align.START, Gtk.Align.START, {"top": 34, "start": 120},
            Gtk.RevealerTransitionType.SLIDE_DOWN)
        logo_right = Popup(self, "logo-right", menu_card(logo_items, self.close_all), Gtk.Align.END, Gtk.Align.START,
                           {"top": 34, "end": 8}, Gtk.RevealerTransitionType.SLIDE_DOWN)
        for p in (logo, logo_right, win, StartMenu(self), Spotlight(self), ControlCenter(self), CalendarPopup(self),
                  TaskMenu(self), FolderFan(self),
                  BatteryPopup(self), notifications.NotificationCentre.make(self),
                  clipboard.ClipboardPanel.make(self), extras.make_desktop_menu(self),
                  extras.make_emoji_panel(self)):
            self.popups[p.name] = p
        self.comp.connect("event", lambda _c, ev: ev.get("event") == "shell" and self.toggle(ev.get("what", "")))
        if not self.preview:
            # (after the startup animation: building ten windows would make it stutter)
            GLib.timeout_add(600 + (self.boot.total + 400 if self.boot else 0), self.prebuild)

    def prebuild(self):
        """create popup windows ahead of time so the first open is instant"""
        for p in self.popups.values():
            if p.win is None:
                p.build_window()
        return False

    def _focused_cmd(self, cmd):
        f = self.comp.focused
        if f:
            ipc.send(f"{cmd} {f['id']}")
        self.close_all()

    def _move(self, ws):
        f = self.comp.focused
        if f:
            ipc.send(f"move {f['id']} {ws}")
        self.close_all()

    def toggle(self, name):
        if name in self.ENDINGS:        # the compositor's log out shortcut
            self.end_session(name)
            return
        if name.startswith("osd-"):     # the volume / brightness keys
            if not self.preview:
                self.osd.show(name[4:])
            return
        if name in ("light", "dark"):   # `lumenctl shell light` / `lumenctl shell dark`
            self.set_light_mode(name == "light")
            return
        if name in self.popups:
            if name == "start":
                self.popups[name].search_mode = False
            self.popups[name].toggle()

    def open_search(self):
        """taskbar Search pill: Start menu with the search box highlighted"""
        sm = self.popups.get("start")
        if not sm:
            return system.run(self.cfg["launcher"])
        self.close_all(except_="start")
        if sm.is_open():
            sm.set_search_mode(True)
            sm.entry.grab_focus()
            return
        sm.search_mode = True
        sm.open()

    def close_all(self, except_=None):
        for n, p in self.popups.items():
            if n != except_:
                p.close()

    def on_tick(self, fn):
        self._tickers.append(fn)
        self.track("tick", fn)
        fn(True)

    # ------------------------------------------------ monitors come and go
    def track(self, kind, obj):
        """remember what a monitor's bars/widgets registered, to undo it later"""
        rec = getattr(self, "_building", None)
        if rec is not None:
            rec.append((kind, obj))

    def watch_monitors(self):
        mons = Gdk.Display.get_default().get_monitors()
        self._mon_src = None

        def changed(*_a):
            if self._mon_src:
                GLib.source_remove(self._mon_src)
            # monitors arrive in steps (connector, then geometry): settle first
            self._mon_src = GLib.timeout_add(400, self.sync_monitors)
        mons.connect("items-changed", changed)

    def sync_monitors(self):
        self._mon_src = None
        mons = Gdk.Display.get_default().get_monitors()
        current = [mons.get_item(i) for i in range(mons.get_n_items())]
        for mon in list(self.monitor_parts):
            if mon not in current:
                self.teardown_monitor(mon)
        for mon in current:
            if mon not in self.monitor_parts:
                self.build_monitor(mon)
        return False

    def teardown_monitor(self, mon):
        for kind, obj in self.monitor_parts.pop(mon, []):
            try:
                if kind == "comp":
                    self.comp.disconnect(obj)
                elif kind == "tick" and obj in self._tickers:
                    self._tickers.remove(obj)
                elif kind == "notify" and obj in self.notify.listeners:
                    self.notify.listeners.remove(obj)
                elif kind == "taskbar" and obj in self.taskbars:
                    self.taskbars.remove(obj)
                elif kind == "widgets" and obj in self.desktop_widgets:
                    self.desktop_widgets.remove(obj)
                elif kind == "wallpaper" and obj in self.wallpapers:
                    self.wallpapers.remove(obj)
                elif kind == "window":
                    obj.destroy()
            except Exception:   # noqa: BLE001 — one stale piece never blocks the rest
                pass

    def _media_changed(self):
        for fn in self._tickers:
            fn(True)

    def poll(self, full=False, then=None):
        """Read battery/audio/network/… in a worker thread; the UI never waits on
        nmcli/wpctl/playerctl. `then` runs on the main loop once fresh data is in."""
        if self.preview:
            if then:
                then()
            return
        if getattr(self, "_polling", False):
            return
        self._polling = True

        def work():
            fresh = {"battery": system.battery(), "volume": system.volume(), "media": system.now_playing()}
            if full:
                fresh.update(wifi=system.wifi(), bt=system.bluetooth_on(), brightness=system.brightness())

            def apply():
                self._polling = False
                self.sys.update(fresh)
                for fn in self._tickers:
                    fn(True)
                if then:
                    then()
                return False
            GLib.idle_add(apply)
        threading.Thread(target=work, daemon=True).start()

    def start_ticking(self):
        self._n = 0

        def tick():
            self._n += 1
            if self._n % 2 == 0:
                self.poll(full=self._n % 30 == 0)   # tickers refresh when data arrives
            for fn in self._tickers:
                fn(False)
            return True
        GLib.timeout_add(1000, tick)

    def report_topbar(self, win):
        win.is_topbar = True
        p = pane_shape(win.get_child(), win, 0, open_edges="trl", shadow=0.0, frost=0.0)
        GLASS.send(glass_ns("lumen-topbar", win=win), [p] if p else [])

    def build_monitor(self, monitor):
        self._building = []
        try:
            self._build_monitor(monitor)
        finally:
            self.monitor_parts[monitor] = self._building
            self._building = None

    # ------------------------------------------------------- wallpapers
    VIDEO_EXTS = (".mp4", ".webm", ".mkv", ".mov", ".m4v", ".gif")

    def set_wallpaper(self, pic):
        """a picture, or a looping silent video (paused under fullscreen apps)"""
        path = self.cfg["wallpaper"]
        if getattr(pic, "source", None) == path:
            return                      # already showing it (settings reloads call this a lot)
        pic.source = path
        old = getattr(pic, "lumen_media", None)
        if old is not None:
            old.pause()
            pic.lumen_media = None
        if path.lower().endswith(self.VIDEO_EXTS):
            media = Gtk.MediaFile.new_for_filename(path)
            media.set_loop(True)
            media.set_muted(True)
            pic.set_paintable(media)
            pic.lumen_media = media

            def failed(m, _p, pic=pic):
                # no GStreamer module / codec: never a blank desktop
                if m.get_error() is not None and getattr(pic, "lumen_media", None) is m:
                    print("lumen-shell: video wallpaper:", m.get_error().message, file=sys.stderr)
                    pic.lumen_media = None      # (source stays: no retry until the wallpaper changes)
                    fallback = "/usr/share/backgrounds/lumen/lumen-flow.jpg"
                    if not os.path.exists(fallback):
                        fallback = os.path.abspath(os.path.join(HERE, "..", "..", "data", "wallpapers",
                                                                "lumen-flow.jpg"))
                    pic.set_filename(fallback)
            media.connect("notify::error", failed)
            if media.get_error() is not None:
                failed(media, None)
            GLib.idle_add(lambda: (self.update_videos(), False)[1])
        else:
            pic.set_filename(path)

    def update_videos(self):
        """video wallpapers play only when you can see them: paused while a
        fullscreen app (a game, a film) is up on that screen, and in Performance mode"""
        perf = performance_mode() or self.preview
        st = self.comp.state
        outs = {o.get("name"): o.get("ws") for o in st.get("outputs", [])}
        for mon, parts in self.monitor_parts.items():
            for kind, obj in parts:
                if kind != "wallpaper" or getattr(obj, "lumen_media", None) is None:
                    continue
                conn = mon.get_connector() if hasattr(mon, "get_connector") else None
                ws = outs.get(conn)
                covered = any(w.get("fullscreen") and not w.get("minimized") and
                              (ws is None or w.get("workspace") == ws) for w in st.get("windows", []))
                (obj.lumen_media.pause if covered or perf else obj.lumen_media.play)()

    def _build_monitor(self, monitor):
        wall = LayerWin(self.app, "lumen-wallpaper", "background", "tblr", -1, monitor=monitor)
        pic = WallpaperView()
        extras.desktop_clicks(self, pic)
        self.set_wallpaper(pic)
        self.wallpapers.append(pic)
        self.track("wallpaper", pic)
        boot = self.boot if self.boot is not None and self.boot.open else None
        wall.set_child(boot.attach(wall, pic) if boot else pic)
        # The wallpaper goes up before the bars are even built: showing the first
        # window is what sets up drawing (GL, shaders), and that takes as long as
        # reading the icon theme does on its thread — the two now overlap.
        self.track("window", wall)
        wall.present()
        top = LayerWin(self.app, "lumen-topbar", "top", "tlr", "auto", monitor=monitor)
        top.set_child(TopBar(self, monitor).widget)
        top.connect("map", lambda w: GLib.timeout_add(80, lambda: (self.report_topbar(w), False)[1]))
        bar = LayerWin(self.app, "lumen-taskbar", "top", "blr", "auto", monitor=monitor)
        dock = Taskbar(self, monitor)
        bar.set_child(dock.widget)
        # desktop widgets: under the top bar on the right; the surface hugs the cards
        wl = LayerWin(self.app, "lumen-widgets", "bottom", "tr", None, monitor=monitor)
        dw = DesktopWidgets(self, wl)
        self.desktop_widgets.append(dw)
        self.track("widgets", dw)
        wl.set_child(dw.box)
        wl.connect("map", lambda *_: dw.report_glass())
        follow_frames(wl, dw.glass_now)
        follow_frames(top, lambda: top.get_mapped() and not GLASS.hold and self.report_topbar(top))
        # Every surface goes up at once, as it always did. (An earlier version held
        # the bars back until the startup animation revealed the desktop; on a real
        # session they then stayed missing until some window opened.) At login the
        # bars and widgets are merely invisible until the desktop is revealed: their
        # contents are transparent and their glass isn't reported yet.
        held = [top.get_child(), bar.get_child(), dw.box] if boot else []
        for h in held:
            h.add_css_class("boot-hide")
        for w in (top, bar, wl):
            self.track("window", w)
            w.present()
        wl.set_visible(bool(dw.cards))

        def arrive():
            for h in held:
                h.remove_css_class("boot-hide")
                h.add_css_class("boot-show")
            boot.stagger([dock.start_btn, dock.search] + [it["btn"] for it in dock.items.values()])
            boot.shown += held
            dock.report_glass()
            dw.report_glass()
            if top.get_mapped():
                self.report_topbar(top)
        if boot:
            boot.later(arrive)


_providers = {}
POUR_MS = 722                       # the compositor's pour: anim_ms × 1.9 (liquid.c)
_glass = {"liquid": None, "until": 0}


def pouring():
    """a glass-style change is flowing across right now"""
    return GLib.get_monotonic_time() < _glass["until"]


def _pour_css(ms):
    """for the length of the pour, everything that differs between the two styles
    (fills, borders, shadows, the bar's capsule) moves instead of jumping"""
    css = (".pouring, .pouring * { transition-property: background-color, background-image, border-color, "
           "box-shadow, text-shadow, -gtk-icon-shadow, margin, padding, border-radius, min-width, min-height; "
           f"transition-duration: {ms}ms; transition-timing-function: cubic-bezier(.4, 0, .2, 1); }}\n")
    if "pour" not in _providers:
        _providers["pour"] = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), _providers["pour"],
                                                  Gtk.STYLE_PROVIDER_PRIORITY_USER + 1)
    p = _providers["pour"]
    p.load_from_string(css) if hasattr(p, "load_from_string") else p.load_from_data(css.encode(), -1)
    wins = list(Gtk.Window.list_toplevels())
    for w in wins:
        w.add_css_class("pouring")

    def done():
        if pouring():
            return True                      # another change arrived meanwhile
        for w in wins:
            w.remove_css_class("pouring")
        p.load_from_string("") if hasattr(p, "load_from_string") else p.load_from_data(b"", -1)
        return False
    GLib.timeout_add(ms + 150, done)


def load_css(icon_theme="Papirus-Dark"):
    display = Gdk.Display.get_default()
    light = light_mode()

    def sheet(name):
        """the light sheet in light mode (tools/make-light-css.py writes them)"""
        alt = os.path.join(HERE, name[:-4] + "-light.css")
        return alt if light and os.path.exists(alt) else os.path.join(HERE, name)
    for key, path, prio in (("base", sheet("style.css"), Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION),
                            ("user", os.path.join(CONFIG_DIR, "shell.css"), Gtk.STYLE_PROVIDER_PRIORITY_USER)):
        if key not in _providers:
            _providers[key] = Gtk.CssProvider()
            Gtk.StyleContext.add_provider_for_display(display, _providers[key], prio)
        if os.path.exists(path):
            _providers[key].load_from_path(path)
        else:
            _providers[key].load_from_string("") if hasattr(_providers[key], "load_from_string") \
                else _providers[key].load_from_data(b"", -1)
    # liquid glass: clear panes on top of the base style (the compositor draws the rims)
    liquid = glass_style() == "liquid"
    # The style changed while we're up: the compositor pours one glass into the
    # other (it draws both for most of a second), and our fills, borders and the
    # capsule shape of the bar flow across in the same time instead of snapping.
    _motion["t"] = 0
    pour = motion_ms(POUR_MS) if _glass["liquid"] is not None and _glass["liquid"] != liquid else 0
    _glass["liquid"] = liquid
    if pour > 0:
        _glass["until"] = GLib.get_monotonic_time() + pour * 1000
        _pour_css(pour)
    if "liquid" not in _providers:
        _providers["liquid"] = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(display, _providers["liquid"],
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)
    if liquid:
        _providers["liquid"].load_from_path(sheet("liquid.css"))
    else:
        p = _providers["liquid"]
        p.load_from_string("") if hasattr(p, "load_from_string") else p.load_from_data(b"", -1)
    if liquid or pour <= 0:
        GLASS.set_enabled(liquid)
    else:
        # draining to frosted: the compositor still needs to know where the panes
        # are until the last of the liquid is gone
        GLib.timeout_add(pour + 100, lambda: (_glass["liquid"] or GLASS.set_enabled(False), False)[1])
    # Window tint (Settings → Glass & Motion) colours Lumen's own glass too: the
    # bars, menus and cards. Default tint #1c1f2a at 55% = the built-in look.
    if "tint" not in _providers:
        _providers["tint"] = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(display, _providers["tint"],
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 2)
    css = ""
    t = conf_value("glass_tint", "#1c1f2a8c").lstrip("#")
    try:
        r, g, b = int(t[0:2], 16), int(t[2:4], 16), int(t[4:6], 16)
        a = int(t[6:8], 16) / 255 if len(t) >= 8 else 0.55
        k = a / 0.55                                    # relative to the default strength
        # (light mode has its own glass; a tint only counts there once it has been changed
        # from the dark default, which the compositor swaps for a pale one itself)
        stock = (r, g, b) == (0x1c, 0x1f, 0x2a)
        if not liquid and not (light and stock) and (abs(k - 1) > 0.02 or not stock):
            def bg(base):
                return f"background-color: rgba({r}, {g}, {b}, {min(0.97, base * k):.3f});"
            css = (f".glass {{ {bg(0.42)} }}\n.topbar {{ {bg(0.30)} }}\n.taskbar {{ {bg(0.50)} }}\n"
                   f".notif.card, .nc.card {{ {bg(0.48)} }}\n")
    except (ValueError, IndexError):
        css = ""
    tp = _providers["tint"]
    tp.load_from_string(css) if hasattr(tp, "load_from_string") else tp.load_from_data(css.encode(), -1)
    # keyframe animations follow the speed slider too (transitions are short enough as they are)
    if "motion" not in _providers:
        _providers["motion"] = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(display, _providers["motion"],
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 3)
    _motion["t"] = 0
    k = _motion_scale()
    mcss = ""
    if k > 0 and abs(k - 1) > 0.04:
        def d(ms):
            return f"{max(60, int(ms * k))}ms"
        mcss = (f".pop.pop-in {{ animation-duration: {d(300)}; }}\n.pop.pop-out {{ animation-duration: {d(150)}; }}\n"
                f".rise {{ animation-duration: {d(320)}; }}\n.task.task-in {{ animation-duration: {d(360)}; }}\n"
                f".toast > .notif {{ animation-duration: {d(420)}; }}\n"
                f".toast.leaving > .notif {{ animation-duration: {d(200)}; }}\n"
                f".preview-card {{ animation-duration: {d(220)}; }}\n"
                f".taskbar {{ transition-duration: {d(420)}; }}\n")
    mp = _providers["motion"]
    mp.load_from_string(mcss) if hasattr(mp, "load_from_string") else mp.load_from_data(mcss.encode(), -1)
    try:
        note_for_greeter(load_config())
    except Exception:   # noqa: BLE001 — never worth breaking the shell over
        pass
    theme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default())
    # (Every change to the icon theme's name or folders makes GTK read the whole
    # theme again, a quarter of a second for Papirus, with the shell waiting. So
    # only real changes are made: the extra folder exists only when running from
    # the source tree, and the name is usually already right — it used to be read
    # twice at every login.)
    dev_icons = os.path.abspath(os.path.join(HERE, "..", "..", "data", "icons"))
    if os.path.isdir(dev_icons) and dev_icons not in [os.path.abspath(p) for p in (theme.get_search_path() or [])]:
        theme.add_search_path(dev_icons)
    settings = Gtk.Settings.get_default()
    if settings.get_property("gtk-application-prefer-dark-theme") != (not light):
        settings.set_property("gtk-application-prefer-dark-theme", not light)
    _motion["t"] = 0
    settings.set_property("gtk-enable-animations", motion_ms(100) > 0)
    roots = [os.path.expanduser("~/.local/share/icons"), "/usr/share/icons", "/usr/local/share/icons",
             os.path.join(HERE, "..", "..", "data", "icons")]
    # light mode: the same icons on light tiles (Lumen-Light), Papirus's light set
    lit = {"Lumen": "Lumen-Light", "Papirus-Dark": "Papirus-Light"}.get(icon_theme or "Lumen") if light_mode() else None
    for t in filter(None, (lit, icon_theme, "Lumen", "Papirus-Dark")):
        if any(os.path.isdir(os.path.join(d, t)) for d in roots):
            if settings.get_property("gtk-icon-theme-name") != t:
                settings.set_property("gtk-icon-theme-name", t)
            sync_system_icon_theme(t)
            break
    sync_system_scheme()


_synced_theme = [None]
_synced_scheme = [None]


def sync_system_scheme():
    """dark or light, as the desktop setting other apps follow (GTK, Firefox,
    Chromium, Electron): written when it differs from Settings → Appearance"""
    light = light_mode()
    if _synced_scheme[0] == light or not shutil.which("gsettings"):
        return
    _synced_scheme[0] = light
    want = "prefer-light" if light else "prefer-dark"
    theme = "Adwaita" if light else "Adwaita-dark"
    script = (f"gsettings set org.gnome.desktop.interface color-scheme {want}; "
              "case \"$(gsettings get org.gnome.desktop.interface gtk-theme)\" in "
              "\"'Adwaita'\"|\"'Adwaita-dark'\"|\"'Default'\"|\"\") "
              f"gsettings set org.gnome.desktop.interface gtk-theme {theme};; esac")
    try:
        subprocess.Popen(["sh", "-c", script], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        pass


def note_for_greeter(cfg):
    """the login screen wears this account's look (glass style, accents, wallpaper),
    but it can't read our home folder: leave it a small note where it can"""
    try:
        note = {"glass_style": glass_style(), "wallpaper": cfg.get("wallpaper", ""),
                "color_scheme": "light" if light_mode() else "dark"}
        for k in ("accent", "accent2"):
            if cfg.get(k):
                note[k] = cfg[k]
        path = f"/var/tmp/lumen-greeter-{os.getuid()}.json"
        text = json.dumps(note)
        try:
            if open(path).read() == text:
                return
        except OSError:
            pass
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o644)
        with os.fdopen(fd, "w") as f:
            f.write(text)
    except OSError:
        pass


def sync_system_icon_theme(theme):
    """make every GTK app (not just the shell) use the chosen icon theme"""
    if _synced_theme[0] == theme or not shutil.which("gsettings"):
        return
    _synced_theme[0] = theme
    try:
        subprocess.Popen(["gsettings", "set", "org.gnome.desktop.interface", "icon-theme", theme],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        pass


class App(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="dev.lumen.Shell",
                         flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        # No bundled resources: with a resource path set, GTK adds an icon folder
        # for it at startup — which waits for the icon theme to finish loading and
        # then throws the result away, so the theme is read a second time.
        self.set_resource_base_path(None)
        self.shell = None

    def do_command_line(self, cmdline):
        args = cmdline.get_arguments()[1:]
        if self.shell is None and args[:1] == ["--reload"]:
            return 0      # nothing running to reload: don't start a second shell
        if self.shell is None:
            self.hold()
            if LS is None or not LS.is_supported():
                print("lumen-shell: gtk4-layer-shell missing or compositor lacks wlr-layer-shell",
                      file=sys.stderr)
                return 1
            self.shell = Shell(self)
            load_css(self.shell.cfg.get("icon_theme"))
            if Startup.wanted(self.shell.cfg):
                self.shell.boot = Startup(_motion_scale())
            # the desktop first (wallpaper, bars, widgets), then the menus nobody
            # can have asked for yet
            display = Gdk.Display.get_default()
            mons = display.get_monitors()
            for i in range(mons.get_n_items()):
                self.shell.build_monitor(mons.get_item(i))
            self.shell.build_popups()
            if self.shell.boot:
                self.shell.boot.open = False   # screens plugged in later just appear
            self.shell.watch_monitors()   # unplug / re-plug: bars follow the screens
            self.shell.comp.connect("changed", lambda *_: self.shell.update_videos())
            clipboard.start_watcher()      # Super+V history
            try:                           # USB drives: mounted and announced when plugged in
                from . import drives
                self.shell.drives = drives.Drives(self.shell)
            except Exception as e:         # noqa: BLE001 — never keep the desktop from starting
                print("lumen-shell: drives:", e, file=sys.stderr)
            self.shell.start_ticking()
        if len(args) >= 2 and args[0] == "--toggle":
            self.shell.toggle(args[1])
        elif args and args[0] == "--reload":
            self.shell.reload()
        return 0


def warm_icons():
    """Start reading the icon theme right away. GTK does it on a thread of its
    own, so it runs while the shell sets itself up, instead of the first icon on
    the dock waiting a quarter of a second for it."""
    try:
        display = Gdk.Display.get_default()
        if display is not None:
            Gtk.IconTheme.get_for_display(display)
    except Exception:   # noqa: BLE001 — only a head start
        pass


def main():
    if "--preview" in sys.argv:
        from .preview import run_preview
        return run_preview(sys.argv)
    if not any(a in sys.argv for a in ("--reload", "--toggle")):
        warm_icons()
    return App().run(sys.argv)
