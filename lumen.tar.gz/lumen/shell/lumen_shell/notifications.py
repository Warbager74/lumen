"""Lumen notifications: the desktop's own notification service.

* Implements org.freedesktop.Notifications on the session bus (replaces mako), so
  every app's notify-send / libnotify / portal notification lands here.
* Glass pop-ups slide in under the top bar, stack, pause while hovered and go
  away on their own. They have action buttons, inline reply (for apps that
  support it) and image previews.
* Everything that popped up lands in the Notification Centre (bell in the top
  bar, Super+N), grouped by app, kept across restarts.
* Do Not Disturb (with an optional quiet-hours schedule) and per-app rules:
  allow / pop-ups / sound, set from Settings → Notifications.
"""
import html
import json
import os
import re
import shutil
import subprocess
import time

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("GdkPixbuf", "2.0")
gi.require_version("Pango", "1.0")
from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk, Pango  # noqa: E402

from . import system  # noqa: E402

BUS_NAME = "org.freedesktop.Notifications"
OBJ_PATH = "/org/freedesktop/Notifications"
IFACE_XML = """
<node>
  <interface name="org.freedesktop.Notifications">
    <method name="GetCapabilities"><arg direction="out" type="as"/></method>
    <method name="Notify">
      <arg direction="in" type="s"/><arg direction="in" type="u"/><arg direction="in" type="s"/>
      <arg direction="in" type="s"/><arg direction="in" type="s"/><arg direction="in" type="as"/>
      <arg direction="in" type="a{sv}"/><arg direction="in" type="i"/>
      <arg direction="out" type="u"/>
    </method>
    <method name="CloseNotification"><arg direction="in" type="u"/></method>
    <method name="GetServerInformation">
      <arg direction="out" type="s"/><arg direction="out" type="s"/>
      <arg direction="out" type="s"/><arg direction="out" type="s"/>
    </method>
    <signal name="NotificationClosed"><arg type="u"/><arg type="u"/></signal>
    <signal name="ActionInvoked"><arg type="u"/><arg type="s"/></signal>
    <signal name="ActivationToken"><arg type="u"/><arg type="s"/></signal>
    <signal name="NotificationReplied"><arg type="u"/><arg type="s"/></signal>
  </interface>
</node>"""
CAPS = ["actions", "body", "body-markup", "body-hyperlinks", "body-images", "icon-static",
        "persistence", "inline-reply", "x-kde-display-appname", "sound"]

# NotificationClosed reasons
EXPIRED, DISMISSED, CLOSED_BY_APP = 1, 2, 3

CACHE = os.path.join(GLib.get_user_cache_dir(), "lumen")
HISTORY = os.path.join(CACHE, "notifications.json")
IMAGES = os.path.join(CACHE, "notify-images")
MAX_HISTORY = 120
MAX_TOASTS = 4
WIDTH = 380


def A():
    """the shell module (imported lazily: it imports us)"""
    from . import app
    return app


# --------------------------------------------------------------- helpers
_ALLOWED = re.compile(r"&lt;(/?)(b|i|u|a)(\s+href=(?:&quot;|&#x27;)(.*?)(?:&quot;|&#x27;))?&gt;", re.I)


def clean_markup(text):
    """Notification bodies are a tiny HTML subset. Escape everything, then
    restore <b> <i> <u> <a href>; anything Pango still rejects falls back to text."""
    if not text:
        return ""
    text = re.sub(r"<img[^>]*>", "", text, flags=re.I)
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.I)
    esc = html.escape(text, quote=True)
    esc = esc.replace("&amp;amp;", "&amp;").replace("&amp;lt;", "&lt;").replace("&amp;gt;", "&gt;")

    def back(m):
        slash, tag, _attr, href = m.group(1), m.group(2).lower(), m.group(3), m.group(4)
        if tag == "a" and not slash:
            return f'<a href="{html.escape(html.unescape(href or ""), quote=True)}">'
        return f"<{slash}{tag}>"
    out = _ALLOWED.sub(back, esc)
    try:
        # Pango doesn't know <a> (GtkLabel handles links): check the rest
        Pango.parse_markup(re.sub(r"</?a[^>]*>", "", out), -1, "\0")
        return out
    except GLib.Error:
        return GLib.markup_escape_text(re.sub(r"<[^>]+>", "", text))


def ago(ts):
    d = max(0, time.time() - ts)
    if d < 60:
        return "now"
    if d < 3600:
        return f"{int(d // 60)}m ago"
    if d < 86400:
        return f"{int(d // 3600)}h ago"
    if d < 7 * 86400:
        return time.strftime("%a", time.localtime(ts))
    return time.strftime("%b %-d", time.localtime(ts))


def _hint(hints, *names):
    for n in names:
        v = hints.lookup_value(n, None) if hints is not None else None
        if v is not None:
            return v
    return None


def image_from_data(v, nid):
    """image-data (iiibiiay) → a PNG in the cache (so history keeps it)"""
    try:
        w, h, stride = v.get_child_value(0).get_int32(), v.get_child_value(1).get_int32(), \
            v.get_child_value(2).get_int32()
        alpha, bps = v.get_child_value(3).get_boolean(), v.get_child_value(4).get_int32()
        data = v.get_child_value(6).get_data_as_bytes()
        pb = GdkPixbuf.Pixbuf.new_from_bytes(data, GdkPixbuf.Colorspace.RGB, alpha, bps, w, h, stride)
        if max(w, h) > 256:
            k = 256 / max(w, h)
            pb = pb.scale_simple(max(1, int(w * k)), max(1, int(h * k)), GdkPixbuf.InterpType.BILINEAR)
        os.makedirs(IMAGES, exist_ok=True)
        path = os.path.join(IMAGES, f"{int(time.time() * 1000)}-{nid}.png")
        pb.savev(path, "png", [], [])
        return path
    except Exception:   # noqa: BLE001 — a broken image never costs the notification
        return None


def _is_image_path(s):
    if not s:
        return None
    if s.startswith("file://"):
        s = GLib.filename_from_uri(s)[0]
    return s if s.startswith("/") and os.path.exists(s) else None


def app_icon_for(n):
    """an icon (Gio.Icon or name) for the app that sent `n`"""
    ic = n.get("app_icon") or ""
    if ic and not ic.startswith("/") and not ic.startswith("file://"):
        return ic
    if ic:
        p = _is_image_path(ic)
        if p:
            return Gio.FileIcon.new(Gio.File.new_for_path(p))
    for did in filter(None, [n.get("desktop_entry"), (n.get("app_name") or "").lower()]):
        ai = A().app_info(did if did.endswith(".desktop") else did + ".desktop")
        if ai and ai.get_icon():
            return ai.get_icon()
    theme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default())
    name = (n.get("app_name") or "").lower().replace(" ", "-")
    if name and theme.has_icon(name):
        return name
    return "lumen-bell-symbolic"


def set_image(img, icon_):
    if isinstance(icon_, str):
        img.set_from_icon_name(icon_)
    else:
        img.set_from_gicon(icon_)


def find_sound():
    for p in ("/usr/share/sounds/freedesktop/stereo/message-new-instant.oga",
              "/usr/share/sounds/freedesktop/stereo/message.oga"):
        if os.path.exists(p):
            return p
    return None


_thumbs = {}


def thumb_texture(path, size):
    """a square, centre-cropped thumbnail texture (2× for HiDPI); its natural
    size is what we ask for, never the photo's own (that would stretch the card)"""
    if not path or not os.path.exists(path):
        return None
    key = (path, size)
    if key in _thumbs:
        return _thumbs[key]
    try:
        px = size * 2
        pb = GdkPixbuf.Pixbuf.new_from_file(path)
        w, h = pb.get_width(), pb.get_height()
        k = px / min(w, h)
        pb = pb.scale_simple(max(px, round(w * k)), max(px, round(h * k)), GdkPixbuf.InterpType.BILINEAR)
        x, y = (pb.get_width() - px) // 2, (pb.get_height() - px) // 2
        pb = pb.new_subpixbuf(x, y, px, px)
        tex = Gdk.Texture.new_for_pixbuf(pb)
    except Exception:   # noqa: BLE001 — unreadable image: just no thumbnail
        tex = None
    if len(_thumbs) > 200:
        _thumbs.clear()
    _thumbs[key] = tex
    return tex


# ----------------------------------------------------------------- card UI
def build_card(mgr, n, compact=False):
    """One notification as a glass card. Toasts and the centre share it."""
    L = A()
    live = n.get("live", False)
    head_icon = Gtk.Image()
    head_icon.set_pixel_size(16)
    set_image(head_icon, app_icon_for(n))
    name = L.lbl(n.get("app_name") or "Notification", "n-app", xalign=0, hexpand=True,
                 ellipsize=Pango.EllipsizeMode.END)
    when = L.lbl(ago(n["time"]), "n-time")
    close = L.button(L.icon("window-close-symbolic", 12), "n-close",
                     lambda: mgr.dismiss(n["id"], DISMISSED), "Clear")
    title = L.lbl(n.get("summary") or "", "n-title", xalign=0, wrap=True, wrap_mode=Pango.WrapMode.WORD_CHAR,
                  max_width_chars=34, lines=2, ellipsize=Pango.EllipsizeMode.END)
    if compact:      # in the centre the group heading already names the app: title · time · ×
        title.set_hexpand(True)
        title.set_lines(1)
        title.set_wrap(False)
        when.set_valign(Gtk.Align.CENTER)
        head = L.box(Gtk.Orientation.HORIZONTAL, 7, "n-head", title, when, close)
    else:
        head = L.box(Gtk.Orientation.HORIZONTAL, 7, "n-head", head_icon, name, when, close)
    body = Gtk.Label(xalign=0, wrap=True, wrap_mode=Pango.WrapMode.WORD_CHAR, max_width_chars=40,
                     lines=2 if compact else 5, ellipsize=Pango.EllipsizeMode.END, selectable=False)
    body.add_css_class("n-body")
    body.set_markup(clean_markup(n.get("body") or ""))
    body.set_visible(bool(n.get("body")))
    body.connect("activate-link", lambda _l, uri: (system.open_uri(uri), mgr.dismiss(n["id"], DISMISSED), True)[2])
    text = L.box(Gtk.Orientation.VERTICAL, 2, None, hexpand=True, valign=Gtk.Align.CENTER)
    if not compact:
        text.append(title)
    text.append(body)
    main = L.box(Gtk.Orientation.HORIZONTAL, 12, "n-main", text)
    main.set_visible(bool(n.get("body")) or not compact)
    tex = thumb_texture(n.get("image"), 46 if compact else 54)
    if tex:
        pic = Gtk.Image.new_from_paintable(tex)
        pic.set_pixel_size(46 if compact else 54)
        pic.set_valign(Gtk.Align.START)
        frame = L.box(Gtk.Orientation.HORIZONTAL, 0, "n-image", pic, overflow=Gtk.Overflow.HIDDEN,
                      valign=Gtk.Align.START)
        main.append(frame)
        main.set_visible(True)

    card = L.box(Gtk.Orientation.VERTICAL, 6, "glass card notif", head, main)
    if n.get("urgency") == 2:
        card.add_css_class("critical")
    card.set_size_request(WIDTH, -1)

    actions = [(k, lbl) for k, lbl in n.get("actions", []) if k not in ("default", "inline-reply")]
    if live and actions:
        row = L.box(Gtk.Orientation.HORIZONTAL, 6, "n-actions", homogeneous=True)
        for k, label in actions[:3]:
            row.append(L.button(L.lbl(label, ellipsize=Pango.EllipsizeMode.END), "n-action",
                                lambda k=k: mgr.invoke(n["id"], k)))
        card.append(row)
    if live and n.get("reply"):
        entry = Gtk.Entry(placeholder_text=n.get("reply_placeholder") or "Reply…", hexpand=True)
        entry.add_css_class("n-reply")
        send = L.button(L.icon("mail-send-symbolic", 14), "n-send", lambda: mgr.reply(n["id"], entry.get_text()))
        entry.connect("activate", lambda e: mgr.reply(n["id"], e.get_text()))
        rrow = L.box(Gtk.Orientation.HORIZONTAL, 6, "n-reply-row", entry, send)
        rev = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN, transition_duration=180)
        rev.set_child(rrow)
        btn = L.button(L.lbl("Reply"), "n-action",
                       lambda: (rev.set_reveal_child(True), entry.grab_focus(), mgr.hold(n["id"])))
        card.append(L.box(Gtk.Orientation.HORIZONTAL, 6, "n-actions", btn, homogeneous=True))
        card.append(rev)

    # click the card: the app's default action (or just clear it)
    g = Gtk.GestureClick()
    g.set_button(1)

    def clicked(gesture, _n, x, y):
        picked = card.pick(x, y, Gtk.PickFlags.DEFAULT)
        w = picked
        while w is not None and w is not card:          # a button / entry handles itself
            if isinstance(w, (Gtk.Button, Gtk.Entry)) or (isinstance(w, Gtk.Label) and w.get_current_uri()):
                return
            w = w.get_parent()
        gesture.set_state(Gtk.EventSequenceState.CLAIMED)
        mgr.activate(n["id"])
    g.connect("released", clicked)
    card.add_controller(g)
    card.n_time_label = when
    return card


# ---------------------------------------------------------------- manager
class Notifications:
    def __init__(self, shell):
        self.shell = shell
        self.items = []             # newest first: dicts
        self.next_id = 1
        self.unread = 0
        self.conn = None
        self.listeners = []         # called when the list or unread/dnd change
        self.toasts = {}            # id -> (revealer, card, timer info)
        self.toast_win = None
        self.toast_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.toast_box.add_css_class("toasts")
        self._glass_tick = None
        self._save_src = None
        self.sound = find_sound()
        self.load()
        if not shell.preview:
            self.own_name()
            # quiet hours begin and end on their own: keep the bell / Control Centre honest
            GLib.timeout_add_seconds(60, lambda: (self.changed(), True)[1])

    # ------------------------------------------------------------ settings
    @property
    def cfg(self):
        return self.shell.cfg

    @property
    def dnd(self):
        return bool(self.cfg.get("dnd", False))

    def set_dnd(self, on):
        self.cfg["dnd"] = bool(on)
        A().save_config({"dnd": bool(on)})
        self.changed()

    def quiet_hours(self):
        sch = self.cfg.get("dnd_schedule") or {}
        if not sch.get("on"):
            return False
        try:
            f = [int(x) for x in sch.get("from", "22:00").split(":")]
            t = [int(x) for x in sch.get("to", "07:00").split(":")]
        except ValueError:
            return False
        now = time.localtime()
        m, a, b = now.tm_hour * 60 + now.tm_min, f[0] * 60 + f[1], t[0] * 60 + t[1]
        return a <= m < b if a <= b else (m >= a or m < b)

    def silenced(self):
        return self.dnd or self.quiet_hours()

    def app_rule(self, app):
        r = {"enabled": True, "popups": True, "sound": True}
        r.update((self.cfg.get("notify_apps") or {}).get(app, {}))
        return r

    # --------------------------------------------------------------- D-Bus
    def own_name(self):
        # mako (or another daemon) from an older session would keep the name
        subprocess.run(["pkill", "-x", "mako"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.node = Gio.DBusNodeInfo.new_for_xml(IFACE_XML)
        flags = Gio.BusNameOwnerFlags.ALLOW_REPLACEMENT | Gio.BusNameOwnerFlags.REPLACE
        self._tries = 0

        def acquired_bus(conn, _name):
            self.conn = conn
            try:
                conn.register_object(OBJ_PATH, self.node.interfaces[0], self.on_call, None, None)
            except TypeError:   # older PyGObject
                conn.register_object_with_closures(OBJ_PATH, self.node.interfaces[0], self.on_call, None, None)

        def lost(_conn, _name):
            # someone else holds it: ask them to go and try again a few times
            self._tries += 1
            if self._tries <= 5:
                subprocess.run(["pkill", "-x", "mako"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                subprocess.run(["pkill", "-x", "dunst"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                GLib.timeout_add(700, lambda: (self._own(flags, acquired_bus, lost), False)[1])
        self._own(flags, acquired_bus, lost)

    def _own(self, flags, acquired_bus, lost):
        if getattr(self, "_owner", None):
            Gio.bus_unown_name(self._owner)
        self._owner = Gio.bus_own_name(Gio.BusType.SESSION, BUS_NAME, flags, acquired_bus, None, lost)

    def on_call(self, _conn, _sender, _path, _iface, method, params, inv):
        try:
            if method == "GetCapabilities":
                inv.return_value(GLib.Variant("(as)", (CAPS,)))
            elif method == "GetServerInformation":
                inv.return_value(GLib.Variant("(ssss)", ("Lumen", "Lumen", "0.1", "1.2")))
            elif method == "CloseNotification":
                self.dismiss(params.get_child_value(0).get_uint32(), CLOSED_BY_APP)
                inv.return_value(None)
            elif method == "Notify":
                nid = self.notify(params)
                inv.return_value(GLib.Variant("(u)", (nid,)))
            else:
                inv.return_dbus_error("org.freedesktop.DBus.Error.UnknownMethod", method)
        except Exception as e:   # noqa: BLE001 — never wedge the caller
            inv.return_dbus_error("org.freedesktop.DBus.Error.Failed", str(e))

    def emit(self, signal, fmt, args):
        if self.conn:
            try:
                self.conn.emit_signal(None, OBJ_PATH, BUS_NAME, signal, GLib.Variant(fmt, args))
            except GLib.Error:
                pass

    # ------------------------------------------------------------- intake
    def notify(self, params):
        g = params.get_child_value
        app_name, replaces, app_icon = g(0).get_string(), g(1).get_uint32(), g(2).get_string()
        summary, body = g(3).get_string(), g(4).get_string()
        flat = g(5).unpack()
        hints = g(6)
        timeout = g(7).get_int32()

        def hs(*names):
            v = _hint(hints, *names)
            if v is None:
                return None
            try:
                return v.unpack()
            except Exception:   # noqa: BLE001
                return None
        nid = replaces if replaces and self.find(replaces) else self.next_id
        if nid == self.next_id:
            self.next_id += 1
        desktop = hs("desktop-entry") or ""
        display_app = app_name
        if not display_app and desktop:
            ai = A().app_info(desktop + ".desktop")
            display_app = ai.get_name() if ai else desktop
        image = None
        v = _hint(hints, "image-data", "image_data", "icon_data")
        if v is not None:
            image = image_from_data(v, nid)
        if not image:
            image = _is_image_path(hs("image-path", "image_path") or "")
        if not image and _is_image_path(app_icon) and not app_icon.endswith(".svg"):
            image = _is_image_path(app_icon)
        actions = [(flat[i], flat[i + 1]) for i in range(0, len(flat) - 1, 2)]
        urgency = hs("urgency")
        n = {
            "id": nid, "app_name": display_app or "Notification", "app_icon": app_icon,
            "desktop_entry": desktop, "summary": summary, "body": body, "actions": actions,
            "image": image, "urgency": int(urgency) if urgency is not None else 1,
            "time": time.time(), "live": True, "resident": bool(hs("resident")),
            "transient": bool(hs("transient")),
            "reply": any(k == "inline-reply" for k, _ in actions),
            "reply_placeholder": hs("x-kde-reply-placeholder-text") or "",
            "timeout": timeout, "suppress_sound": bool(hs("suppress-sound")),
            "sound_file": hs("sound-file") or "",
        }
        rule = self.app_rule(n["app_name"])
        if not rule["enabled"]:
            return nid       # muted app: accepted and dropped
        self.add(n, rule)
        return nid

    def add(self, n, rule=None):
        rule = rule or self.app_rule(n["app_name"])
        old = self.find(n["id"])
        if old:
            self.items.remove(old)
        if not n.get("transient"):
            self.items.insert(0, n)
            del self.items[MAX_HISTORY:]
        quiet = self.silenced() and n["urgency"] != 2
        centre = self.shell.popups.get("notifications")
        centre_open = bool(centre and centre.is_open())
        if not centre_open and not n.get("transient"):
            self.unread += 1 if not old else 0
        if rule["popups"] and not quiet and not centre_open:
            self.show_toast(n, replace=bool(old))
            if rule.get("sound", True) and self.cfg.get("notify_sound", True) and not n["suppress_sound"]:
                self.play(n)
        self.changed()
        self.save_soon()

    def play(self, n):
        f = n.get("sound_file") if n.get("sound_file") and os.path.exists(n["sound_file"]) else self.sound
        if not f:
            return
        for player in ("pw-play", "paplay"):
            if shutil.which(player):
                system.spawn(f"{player} {GLib.shell_quote(f)}")
                return

    def find(self, nid):
        return next((x for x in self.items if x["id"] == nid), None) or \
            (self.toasts[nid]["n"] if nid in self.toasts else None)

    # ------------------------------------------------------------ actions
    def invoke(self, nid, key):
        n = self.find(nid)
        if n and n.get("live"):
            self.emit("ActivationToken", "(us)", (nid, ""))
            self.emit("ActionInvoked", "(us)", (nid, key))
        if not (n and n.get("resident")):
            self.dismiss(nid, DISMISSED)
        self.shell.close_all()

    def activate(self, nid):
        n = self.find(nid)
        if n and n.get("live") and any(k == "default" for k, _ in n.get("actions", [])):
            self.invoke(nid, "default")
            return
        # no default action: bring the app forward if it has a window, then clear
        if n:
            self.focus_app(n)
        self.dismiss(nid, DISMISSED)

    def focus_app(self, n):
        keys = {k.lower() for k in (n.get("desktop_entry"), n.get("app_name")) if k}
        for w in self.shell.comp.state.get("windows", []):
            aid = (w.get("app_id") or "").lower()
            if aid and (aid in keys or aid.split(".")[-1] in keys):
                A().ipc.send(f"focus {w['id']}")
                self.shell.close_all()
                return

    def reply(self, nid, text):
        text = (text or "").strip()
        if not text:
            return
        self.emit("NotificationReplied", "(us)", (nid, text))
        self.dismiss(nid, DISMISSED)

    def dismiss(self, nid, reason=DISMISSED, keep=False):
        """remove from screen (and from the centre unless `keep`)"""
        n = self.find(nid)
        self.hide_toast(nid)
        if n and not keep:
            if n in self.items:
                self.items.remove(n)
            self.changed()
            self.save_soon()
        if n and n.get("live"):
            n["live"] = False
            self.emit("NotificationClosed", "(uu)", (nid, reason))

    def clear(self, app=None):
        for n in list(self.items):
            if app is None or n["app_name"] == app:
                self.dismiss(n["id"], DISMISSED)

    def seen(self):
        if self.unread:
            self.unread = 0
            self.changed()

    def changed(self):
        for fn in list(self.listeners):
            fn()

    # ------------------------------------------------------------- toasts
    def ensure_toast_win(self):
        if self.toast_win is not None or self.shell.preview:
            return
        L = A()
        win = L.LayerWin(self.shell.app, "lumen-notifications", "overlay", "tr", None, "on_demand",
                         margins={"t": 44, "r": 12})
        win.set_child(self.toast_box)
        self.toast_win = win

    def show_toast(self, n, replace=False):
        if n["id"] in self.toasts:
            t = self.toasts[n["id"]]
            new = build_card(self, n)
            self._wrap(t["rev"], new)
            t.update(card=new, n=n)
            self.arm(n["id"])
            return
        # too many on screen: the oldest steps aside (it's in the centre)
        while len(self.toasts) >= MAX_TOASTS:
            oldest = min(self.toasts, key=lambda k: self.toasts[k]["since"])
            self.hide_toast(oldest)
        card = build_card(self, n)
        rev = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN,
                           transition_duration=A().motion_ms(260))
        self._wrap(rev, card)
        motion = Gtk.EventControllerMotion()
        motion.connect("enter", lambda *_: self.hold(n["id"]))
        motion.connect("leave", lambda *_: self.arm(n["id"], resume=True))
        rev.add_controller(motion)
        self.toast_box.prepend(rev)          # newest on top
        self.toasts[n["id"]] = {"rev": rev, "card": card, "n": n, "since": time.time(), "timer": None}
        self.ensure_toast_win()
        if self.toast_win is not None and not self.toast_win.get_visible():
            self.toast_win.set_default_size(1, 1)
            self.toast_win.present()
        GLib.timeout_add(20, lambda: (rev.set_reveal_child(True), False)[1])
        self.arm(n["id"])
        self.track_glass()

    def _wrap(self, rev, card):
        holder = Gtk.Box()
        holder.add_css_class("toast")
        holder.append(card)
        rev.set_child(holder)

    def toast_ms(self, n):
        if n["urgency"] == 2 or n.get("resident") and n.get("timeout", -1) == 0:
            return 0
        t = n.get("timeout", -1)
        if t == 0:
            return 0
        if t is None or t < 0:
            return int(float(self.cfg.get("notify_timeout", 6)) * 1000)
        return max(1500, min(t, 60000))

    def arm(self, nid, resume=False):
        t = self.toasts.get(nid)
        if not t:
            return
        if t["timer"]:
            GLib.source_remove(t["timer"])
            t["timer"] = None
        ms = self.toast_ms(t["n"])
        if ms <= 0 or self.shell.preview:
            return
        if resume:
            ms = max(ms // 2, 2500)
        t["timer"] = GLib.timeout_add(ms, lambda: (self.expire(nid), False)[1])

    def hold(self, nid):
        t = self.toasts.get(nid)
        if t and t["timer"]:
            GLib.source_remove(t["timer"])
            t["timer"] = None

    def expire(self, nid):
        t = self.toasts.get(nid)
        if t:
            t["timer"] = None
        self.hide_toast(nid)          # it stays in the centre
        n = self.find(nid)
        if n and n.get("transient") and n.get("live"):
            n["live"] = False
            self.emit("NotificationClosed", "(uu)", (nid, EXPIRED))

    def hide_toast(self, nid):
        t = self.toasts.pop(nid, None)
        if not t:
            return
        if t["timer"]:
            GLib.source_remove(t["timer"])
        rev = t["rev"]
        child = rev.get_child()
        if child:
            child.add_css_class("leaving")
        rev.set_reveal_child(False)
        self.track_glass()

        def gone():
            if rev.get_parent() is self.toast_box:
                self.toast_box.remove(rev)
            if not self.toasts and self.toast_win is not None:
                self.toast_win.set_visible(False)
                A().GLASS.send("lumen-notifications", [])
            return False
        GLib.timeout_add(300, gone)

    def hide_all_toasts(self):
        for nid in list(self.toasts):
            self.hide_toast(nid)

    def track_glass(self):
        """liquid glass: stream the cards' shapes while they slide"""
        L = A()
        if not L.GLASS.enabled or self._glass_tick or self.toast_win is None:
            return
        self._settle = 0

        def tick(_w, _clock):
            panes = []
            for t in self.toasts.values():
                clip = L.widget_rect(t["rev"], self.toast_win)
                p = L.pane_shape(t["card"], self.toast_win, clip=clip) if clip else None
                if p:
                    panes.append(p)
            L.GLASS.send("lumen-notifications", panes)
            moving = any(t["rev"].get_child_revealed() != t["rev"].get_reveal_child() for t in self.toasts.values())
            self._settle = 0 if moving else self._settle + 1
            if self._settle > 20:
                self._glass_tick = None
                return False
            return True
        self._glass_tick = self.toast_box.add_tick_callback(tick)

    # ------------------------------------------------------------ storage
    def load(self):
        try:
            with open(HISTORY) as f:
                data = json.load(f)
            self.items = [dict(x, live=False) for x in data.get("items", [])][:MAX_HISTORY]
            self.next_id = max([x["id"] for x in self.items] + [0]) + 1
        except (OSError, ValueError, KeyError, TypeError):
            self.items = []

    def save_soon(self):
        if self.shell.preview or self._save_src:
            return

        def save():
            self._save_src = None
            try:
                os.makedirs(CACHE, exist_ok=True)
                keep = [{k: v for k, v in x.items() if k != "live"} for x in self.items]
                tmp = HISTORY + ".tmp"
                with open(tmp, "w") as f:
                    json.dump({"items": keep}, f)
                os.replace(tmp, HISTORY)
                # images nobody refers to any more
                used = {x.get("image") for x in self.items}
                if os.path.isdir(IMAGES):
                    for fn in os.listdir(IMAGES):
                        p = os.path.join(IMAGES, fn)
                        if p not in used and time.time() - os.path.getmtime(p) > 60:
                            os.remove(p)
            except OSError:
                pass
            return False
        self._save_src = GLib.timeout_add(800, save)

    def apps(self):
        """apps seen in the history (for Settings)"""
        seen = []
        for n in self.items:
            if n["app_name"] not in seen:
                seen.append(n["app_name"])
        return seen


# ------------------------------------------------------------ the centre
class NotificationCentre:
    """Popup: every notification, grouped by app, newest first."""

    @staticmethod
    def make(shell):
        L = A()

        class Centre(L.Popup):
            def __init__(self):
                self.shell = shell
                self.mgr = shell.notify
                self.expanded = set()
                self.dnd_btn = L.button(L.icon("lumen-bell-off-symbolic", 16), "n-dnd",
                                        lambda: self.mgr.set_dnd(not self.mgr.dnd), "Do Not Disturb")
                clear = L.button(L.lbl("Clear all"), "n-clear-all", lambda: self.mgr.clear())
                self.clear_btn = clear
                head = L.box(Gtk.Orientation.HORIZONTAL, 8, "nc-head",
                             L.lbl("Notifications", "nc-title", xalign=0, hexpand=True), self.dnd_btn, clear)
                self.list = L.box(Gtk.Orientation.VERTICAL, 14, "nc-list")
                self.scroller = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER,
                                                   propagate_natural_height=True, max_content_height=640)
                self.scroller.set_child(self.list)
                self.dnd_note = L.lbl("", "nc-dnd-note", xalign=0, wrap=True)
                card = L.box(Gtk.Orientation.VERTICAL, 10, "glass card nc", head, self.dnd_note, self.scroller)
                card.set_size_request(WIDTH + 24, -1)
                super().__init__(shell, "notifications", card, Gtk.Align.END, Gtk.Align.START,
                                 {"top": 38, "end": 10}, Gtk.RevealerTransitionType.SLIDE_DOWN)
                self.mgr.listeners.append(self.refresh_if_open)

            def refresh_if_open(self):
                self.sync_head()
                if self.win and self.win.get_visible():
                    self.refresh()

            def sync_head(self):
                (self.dnd_btn.add_css_class if self.mgr.dnd else self.dnd_btn.remove_css_class)("on")
                note = ""
                if self.mgr.dnd:
                    note = "Do Not Disturb is on — notifications arrive quietly."
                elif self.mgr.quiet_hours():
                    sch = self.shell.cfg.get("dnd_schedule") or {}
                    note = f"Quiet hours until {sch.get('to', '07:00')}."
                self.dnd_note.set_label(note)
                self.dnd_note.set_visible(bool(note))
                self.clear_btn.set_visible(bool(self.mgr.items))

            def refresh(self):
                child = self.list.get_first_child()
                while child:
                    nxt = child.get_next_sibling()
                    self.list.remove(child)
                    child = nxt
                self.sync_head()
                if not self.mgr.items:
                    empty = L.box(Gtk.Orientation.VERTICAL, 8, "nc-empty",
                                  L.icon("lumen-bell-symbolic", 34), L.lbl("No notifications", "nc-empty-title"),
                                  L.lbl("You're all caught up.", "nc-empty-sub"))
                    self.list.append(empty)
                    return
                groups = {}
                order = []
                for n in self.mgr.items:
                    if n["app_name"] not in groups:
                        groups[n["app_name"]] = []
                        order.append(n["app_name"])
                    groups[n["app_name"]].append(n)
                for app in order:
                    items = groups[app]
                    gi_ = Gtk.Image()
                    gi_.set_pixel_size(18)
                    set_image(gi_, app_icon_for(items[0]))
                    count = L.lbl(str(len(items)), "nc-count")
                    count.set_visible(len(items) > 1)
                    x = L.button(L.icon("window-close-symbolic", 12), "n-close", lambda a=app: self.mgr.clear(a),
                                 f"Clear {app}")
                    ghead = L.box(Gtk.Orientation.HORIZONTAL, 8, "nc-group-head", gi_,
                                  L.lbl(app, "nc-group-title", xalign=0, hexpand=True,
                                        ellipsize=Pango.EllipsizeMode.END), count, x)
                    group = L.box(Gtk.Orientation.VERTICAL, 8, "nc-group", ghead)
                    open_ = app in self.expanded
                    shown = items if open_ else items[:2]
                    stack = L.box(Gtk.Orientation.VERTICAL, 8, "nc-stack" + ("" if open_ or len(items) < 3 else " stacked"))
                    for n in shown:
                        stack.append(build_card(self.mgr, n, compact=True))
                    group.append(stack)
                    if len(items) > 2:
                        more = L.button(L.lbl("Show less" if open_ else f"Show {len(items) - 2} more"), "nc-more",
                                        lambda a=app: self.toggle_group(a))
                        group.append(more)
                    self.list.append(group)

            def toggle_group(self, app):
                (self.expanded.discard if app in self.expanded else self.expanded.add)(app)
                self.refresh()

            def on_open(self):
                self.mgr.hide_all_toasts()
                self.refresh()
                self.mgr.seen()

        return Centre()
