"""Small, dependency-free readers for battery / audio / network / brightness / media."""
import glob
import os
import time
import shutil
import subprocess


def _run(*cmd, timeout=1.0):
    if not shutil.which(cmd[0]):
        return ""
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def spawn(cmd: str):
    subprocess.Popen(["/bin/sh", "-c", cmd], start_new_session=True,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def battery():
    """percent, charging, and time left (minutes, None if unknown)"""
    for d in glob.glob("/sys/class/power_supply/BAT*"):
        try:
            cap = int(open(f"{d}/capacity").read())
            status = open(f"{d}/status").read().strip()
        except (OSError, ValueError):
            continue

        def rd(name):
            try:
                return int(open(f"{d}/{name}").read())
            except (OSError, ValueError):
                return None
        now, full = rd("energy_now") or rd("charge_now"), rd("energy_full") or rd("charge_full")
        rate = rd("power_now") or rd("current_now")
        mins = None
        if rate and rate > 0 and now is not None:
            if status == "Discharging":
                mins = int(now / rate * 60)
            elif status == "Charging" and full:
                mins = int((full - now) / rate * 60)
        return {"percent": cap, "charging": status in ("Charging", "Full"), "full": status == "Full",
                "minutes": mins if mins is not None and 0 < mins < 48 * 60 else None}
    return None


# ------------------------------------------------------------ power modes
POWER_PROFILES = (("power-saver", "Power Saver", "power-profile-power-saver-symbolic"),
                  ("balanced", "Balanced", "power-profile-balanced-symbolic"),
                  ("performance", "Performance", "power-profile-performance-symbolic"))


def power_profile():
    """current power-profiles-daemon profile, or None if it isn't installed"""
    out = _run("powerprofilesctl", "get")
    return out if out in {p for p, _n, _i in POWER_PROFILES} else None


def power_profiles_available():
    out = _run("powerprofilesctl", "list")
    return [p for p, _n, _i in POWER_PROFILES if f"{p}:" in out] if out else []


def set_power_profile(p):
    spawn(f"powerprofilesctl set {p}")


def battery_icon(b):
    if not b:
        return "ac-adapter-symbolic"
    level = min(100, (b["percent"] + 5) // 10 * 10)
    return f"battery-level-{level}{'-charging' if b['charging'] else ''}-symbolic"


def volume():
    out = _run("wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@")   # "Volume: 0.45 [MUTED]"
    try:
        return {"level": float(out.split()[1]), "muted": "MUTED" in out}
    except (IndexError, ValueError):
        return {"level": 0.5, "muted": False}


def set_volume(frac):
    spawn(f"wpctl set-volume @DEFAULT_AUDIO_SINK@ {max(0, min(1, frac)):.2f}")


def volume_icon(v):
    if v["muted"] or v["level"] <= 0.001:
        return "audio-volume-muted-symbolic"
    return "audio-volume-" + ("low" if v["level"] < .34 else "medium" if v["level"] < .67 else "high") + "-symbolic"


def wifi():
    out = _run("nmcli", "-t", "-f", "ACTIVE,SSID,SIGNAL", "dev", "wifi")
    for line in out.splitlines():
        parts = line.split(":")
        if parts and parts[0] == "yes":
            return {"ssid": parts[1], "signal": int(parts[2] or 0), "on": True}
    radio = _run("nmcli", "radio", "wifi")
    return {"ssid": None, "signal": 0, "on": radio != "disabled"}


def wifi_icon(w):
    if not w["on"]:
        return "network-wireless-disabled-symbolic"
    if not w["ssid"]:
        return "network-wireless-offline-symbolic"
    s = w["signal"]
    q = "excellent" if s > 75 else "good" if s > 50 else "ok" if s > 25 else "weak"
    return f"network-wireless-signal-{q}-symbolic"


def bluetooth_on():
    return "Powered: yes" in _run("bluetoothctl", "show")


def brightness():
    out = _run("brightnessctl", "-m")      # name,class,cur,pct%,max
    try:
        return int(out.split(",")[3].rstrip("%")) / 100
    except (IndexError, ValueError):
        return None


def set_brightness(frac):
    spawn(f"brightnessctl set {int(max(0.02, frac) * 100)}%")


# ------------------------------------------------------------------- media
_ART_DIR = os.path.join(os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache")), "lumen", "art")


def players():
    """Every MPRIS player (Spotify, Firefox/YouTube, Chromium, mpv…), with
    status, title, artist and artwork URL."""
    fmt = "{{playerName}}\x1f{{playerInstance}}\x1f{{status}}\x1f{{title}}\x1f{{artist}}\x1f{{mpris:artUrl}}"
    out = _run("playerctl", "-a", "metadata", "--format", fmt)
    res = []
    for line in out.splitlines():
        p = line.split("\x1f")
        if len(p) != 6 or not p[3].strip():
            continue
        res.append({"app": p[0], "player": p[1], "status": p[2], "playing": p[2] == "Playing",
                    "title": p[3].strip(), "artist": p[4].strip(), "art_url": p[5].strip()})
    return res


_last_player = None


def now_playing():
    """What the media controls should show: whatever is playing right now (a
    YouTube tab counts), else the player that played last, else any paused one."""
    global _last_player
    ps = players()
    if not ps:
        return None
    pick = next((p for p in ps if p["playing"]), None) \
        or next((p for p in ps if p["player"] == _last_player), None) \
        or next((p for p in ps if p["status"] == "Paused"), None) or ps[0]
    if pick["playing"]:
        _last_player = pick["player"]
    pick["art"] = art_path(pick["art_url"])
    return pick


def art_path(url):
    """Local file for an artwork URL. file:// as-is; http(s) is fetched in the
    background into ~/.cache/lumen/art (None until it's there)."""
    import hashlib
    import threading
    import urllib.parse
    if not url:
        return None
    if url.startswith("file://"):
        p = urllib.parse.unquote(url[7:])
        return p if os.path.exists(p) else None
    if not url.startswith(("http://", "https://")):
        return None
    os.makedirs(_ART_DIR, exist_ok=True)
    path = os.path.join(_ART_DIR, hashlib.sha1(url.encode()).hexdigest()[:16])
    if os.path.exists(path):
        return path

    def fetch():
        import urllib.request
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "lumen-shell"})
            with urllib.request.urlopen(req, timeout=8) as r:
                data = r.read(4_000_000)
            tmp = path + ".part"
            with open(tmp, "wb") as f:
                f.write(data)
            os.replace(tmp, path)
        except Exception:
            pass
    threading.Thread(target=fetch, daemon=True).start()
    return None


def media_cmd(action, player=None):
    """play-pause / next / previous for one specific player"""
    import shlex as _sh
    spawn(f"playerctl -p {_sh.quote(player)} {action}" if player else f"playerctl {action}")


def player_for_app(app_key, ps=None):
    """the MPRIS player belonging to a taskbar app (firefox, spotify, chromium…)"""
    key = (app_key or "").lower()
    for p in (ps if ps is not None else players()):
        name = p["app"].lower()
        if name and (name in key or key.split(".")[-1] in name):
            return p
    return None


def user_name():
    import pwd
    pw = pwd.getpwuid(os.getuid())
    return (pw.pw_gecos.split(",")[0] or pw.pw_name).strip()


# ------------------------------------------------------------- desktop widgets
_cpu = {"prev": None, "at": 0.0, "value": 0.0}


def cpu_percent():
    """CPU busy share (0..1) over the last ~second. Every caller shares one
    measurement, so several System widgets don't reset each other to 0%."""
    now = time.monotonic()
    if now - _cpu["at"] < 0.9 and _cpu["prev"] is not None:
        return _cpu["value"]
    try:
        with open("/proc/stat") as f:
            v = [int(x) for x in f.readline().split()[1:]]
    except (OSError, ValueError):
        return _cpu["value"]
    idle, total = v[3] + (v[4] if len(v) > 4 else 0), sum(v[:8])
    prev = _cpu["prev"]
    _cpu["prev"], _cpu["at"] = (idle, total), now
    if prev and total > prev[1]:
        _cpu["value"] = max(0.0, min(1.0, 1 - (idle - prev[0]) / (total - prev[1])))
    return _cpu["value"]


def memory():
    """(used fraction, used GiB, total GiB)"""
    info = {}
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":", 1)
                info[k] = int(v.split()[0])
    except (OSError, ValueError):
        return 0.0, 0.0, 0.0
    total, avail = info.get("MemTotal", 1), info.get("MemAvailable", 0)
    return (total - avail) / total, (total - avail) / 1048576, total / 1048576


def disk(path="/"):
    import shutil
    try:
        u = shutil.disk_usage(path)
        return u.used / u.total, u.used / 1e9, u.total / 1e9
    except OSError:
        return 0.0, 0.0, 0.0


WEATHER_ICONS = [  # wttr.in condition codes → symbolic icons
    ((113,), "weather-clear-symbolic"), ((116,), "weather-few-clouds-symbolic"),
    ((119, 122), "weather-overcast-symbolic"), ((143, 248, 260), "weather-fog-symbolic"),
    ((200, 386, 389, 392, 395), "weather-storm-symbolic"),
    ((179, 182, 185, 227, 230, 317, 320, 323, 326, 329, 332, 335, 338, 350, 362, 365, 368, 371, 374, 377),
     "weather-snow-symbolic"),
]


def _wx_icon(code):
    return next((i for codes, i in WEATHER_ICONS if code in codes), "weather-showers-symbolic")


def weather(location=""):
    """Current conditions + today's hours + 3 days from wttr.in (no API key).
    None when offline."""
    import json
    import urllib.parse
    import urllib.request
    url = f"https://wttr.in/{urllib.parse.quote(location)}?format=j1"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "lumen-shell"})
        with urllib.request.urlopen(req, timeout=6) as r:
            d = json.load(r)
        cur, day = d["current_condition"][0], d["weather"][0]
        area = d.get("nearest_area", [{}])[0]
        hours = []
        now_h = time.localtime().tm_hour
        for dd in d["weather"][:2]:
            for h in dd.get("hourly", []):
                hh = int(h["time"]) // 100
                if dd is day and hh < now_h:
                    continue
                hours.append({"hour": hh, "temp_c": int(h["tempC"]), "temp_f": int(h["tempF"]),
                              "icon": _wx_icon(int(h.get("weatherCode", 113)))})
        days = []
        for dd in d["weather"][:3]:
            mid = dd.get("hourly", [{}] * 5)[min(4, len(dd.get("hourly", [])) - 1)] if dd.get("hourly") else {}
            days.append({"date": dd["date"], "hi_c": int(dd["maxtempC"]), "lo_c": int(dd["mintempC"]),
                         "hi_f": int(dd["maxtempF"]), "lo_f": int(dd["mintempF"]),
                         "icon": _wx_icon(int(mid.get("weatherCode", 113)))})
        return {"temp_c": int(cur["temp_C"]), "temp_f": int(cur["temp_F"]),
                "desc": cur["weatherDesc"][0]["value"], "icon": _wx_icon(int(cur.get("weatherCode", 113))),
                "hi_c": int(day["maxtempC"]), "lo_c": int(day["mintempC"]),
                "hi_f": int(day["maxtempF"]), "lo_f": int(day["mintempF"]),
                "place": (area.get("areaName", [{}])[0].get("value") or location or "").strip(),
                "hours": hours[:6], "days": days}
    except Exception:
        return None


def uptime():
    try:
        with open("/proc/uptime") as f:
            s = int(float(f.read().split()[0]))
    except (OSError, ValueError):
        return ""
    d, h, m = s // 86400, s % 86400 // 3600, s % 3600 // 60
    return (f"{d}d " if d else "") + f"{h}h {m}m"


def loadavg():
    try:
        return os.getloadavg()[0]
    except OSError:
        return 0.0


# --------------------------------------------------------------- launching
LAUNCH_LOG = os.path.join(os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache")), "lumen", "launch.log")


def _log_path():
    try:
        os.makedirs(os.path.dirname(LAUNCH_LOG), exist_ok=True)
        if os.path.exists(LAUNCH_LOG) and os.path.getsize(LAUNCH_LOG) > 1_000_000:
            os.replace(LAUNCH_LOG, LAUNCH_LOG + ".old")
        return LAUNCH_LOG
    except OSError:
        return "/dev/null"


def run(cmd: str):
    """Start a program the reliable way: the compositor launches it (clean
    environment, own session, survives shell restarts), output goes to
    ~/.cache/lumen/launch.log. Falls back to starting it ourselves."""
    import shlex as _sh
    from . import ipc
    log = _log_path()
    try:
        with open(log, "a") as f:
            f.write(time.strftime("[%H:%M:%S] ") + cmd + "\n")
    except OSError:
        pass
    full = f"( {cmd} ) >>{_sh.quote(log)} 2>&1"
    if "\n" in full or not ipc.send("exec " + full):
        spawn(full)


def launch_app(ai, terminal="kitty"):
    """Open a desktop app (Gio.DesktopAppInfo)."""
    import shlex as _sh
    if ai is None:
        return
    fn = ai.get_filename() if hasattr(ai, "get_filename") else None
    exe = (ai.get_commandline() or "").strip()
    # strip %u %F … field codes
    exe_clean = " ".join(t for t in exe.split() if not (len(t) == 2 and t.startswith("%")))
    needs_term = hasattr(ai, "get_boolean") and ai.get_boolean("Terminal")
    if needs_term and exe_clean:
        run(f"{terminal} -e {exe_clean}")
    elif fn and shutil.which("gio"):
        run(f"gio launch {_sh.quote(fn)}")      # handles Exec field codes, D-Bus activation, …
    elif exe_clean:
        run(exe_clean)


def open_uri(uri):
    import shlex as _sh
    if uri:
        run(f"gio open {_sh.quote(uri)}" if shutil.which("gio") else f"xdg-open {_sh.quote(uri)}")
