"""The small things every desktop has: the level display for the volume and
brightness keys, the menu on the desktop's right click, and the emoji picker
(Super+.)."""
import os
import re
import shlex
import shutil
import unicodedata

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

from . import ipc, system  # noqa: E402


def A():
    from . import app
    return app


# ------------------------------------------------- light / dark wallpapers
PAIRED = re.compile(r"^(lumen-(?:flow|dawn|ocean))(-light)?\.jpg$")


def wallpaper_for(path, light):
    """Lumen's own wallpapers come in a dark and a light version: the one that
    goes with the mode, or None when `path` is somebody's own picture (or is
    already the right one)."""
    m = PAIRED.match(os.path.basename(path or ""))
    if not m or bool(m.group(2)) == bool(light):
        return None
    other = os.path.join(os.path.dirname(path), m.group(1) + ("-light" if light else "") + ".jpg")
    return other if os.path.exists(other) else None


# ------------------------------------------------------- level display
class Osd:
    """Volume, mute and brightness keys: a small glass pill above the taskbar
    with the new level. It takes no clicks and no keyboard."""

    def __init__(self, shell):
        self.shell = shell
        self.win = None
        self._hide = None
        self._seq = 0

    def build(self):
        L = A()
        self.win = L.LayerWin(self.shell.app, "lumen-osd", "overlay", "b", None, "none",
                              margins={"b": L.bar_clearance(self.shell.cfg) + 34})
        self.icon = Gtk.Image(pixel_size=22)
        self.bar = Gtk.ProgressBar(hexpand=True, valign=Gtk.Align.CENTER, width_request=150)
        self.bar.add_css_class("osd-bar")
        self.text = L.lbl("", "osd-text", xalign=1, width_chars=4)
        self.card = L.box(Gtk.Orientation.HORIZONTAL, 14, "glass osd", self.icon, self.bar, self.text)
        self.card.set_size_request(280, -1)
        self.rev = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.CROSSFADE, child=self.card)
        self.win.set_child(self.rev)
        self.win.set_can_target(False)
        L.follow_frames(self.win, self.glass)

    def glass(self):
        L = A()
        if not L.GLASS.enabled or self.win is None or not self.win.get_mapped():
            return
        on = self.rev.get_reveal_child() or self.rev.get_child_revealed()
        p = L.pane_shape(self.card, self.win) if on else None
        L.GLASS.send("lumen-osd", [p] if p else [])

    def show(self, kind):
        """the key's command has only just been started: read the level a
        moment later (and once more, for a slow mixer)"""
        self._seq += 1
        seq = self._seq
        for ms in (70, 260):
            GLib.timeout_add(ms, lambda: (seq == self._seq and self.update(kind), False)[1])

    def level(self, kind):
        if kind == "brightness":
            b = system.brightness()
            return (None if b is None else ("display-brightness-symbolic", b, f"{round(b * 100)}%"))
        if kind == "mic":
            out = system._run("wpctl", "get-volume", "@DEFAULT_AUDIO_SOURCE@")
            off = "MUTED" in out
            return ("microphone-sensitivity-muted-symbolic" if off else "audio-input-microphone-symbolic",
                    0.0 if off else 1.0, "Off" if off else "On")
        v = system.volume()
        return (system.volume_icon(v), 0.0 if v["muted"] else min(1.0, v["level"]),
                "Mute" if v["muted"] else f"{round(v['level'] * 100)}%")

    def update(self, kind, fake=None):
        got = fake or self.level(kind)
        if got is None:
            return
        if self.win is None:
            self.build()
        name, frac, text = got
        self.icon.set_from_icon_name(name)
        self.bar.set_fraction(max(0.0, min(1.0, frac)))
        self.text.set_label(text)
        L = A()
        self.rev.set_transition_duration(L.motion_ms(140))
        self.win.present()
        self.rev.set_reveal_child(True)
        if self._hide:
            GLib.source_remove(self._hide)
        self._hide = GLib.timeout_add(1500, self.hide)

    def hide(self):
        self._hide = None
        self.rev.set_reveal_child(False)

        def gone():
            if not self.rev.get_reveal_child() and self.win is not None:
                self.win.set_visible(False)
                A().GLASS.send("lumen-osd", [])
            return False
        GLib.timeout_add(A().motion_ms(140) + 60, gone)
        return False


# ---------------------------------------------------------- desktop menu
def make_desktop_menu(shell):
    L = A()

    class DesktopMenu(L.Popup):
        """Right click on the desktop."""

        def __init__(self):
            super().__init__(shell, "desktop", Gtk.Box(), Gtk.Align.START, Gtk.Align.START, {})
            self.at = (200, 200, 1920, 1080)

        def show_at(self, x, y, w, h):
            self.at = (x, y, w, h)
            self.shell.close_all(except_=self.name)
            self.open()

        def on_open(self):
            sh = self.shell
            light = L.light_mode()
            run = system.spawn
            term = L.conf_value("terminal", "kitty")
            files = L.conf_value("file_manager", "lumen-files")
            items = [
                ("Open Files", "Super E", lambda: run(files)),
                ("Open Terminal", "Super Q", lambda: run(term)),
                None,
                ("Change Wallpaper…", None, lambda: run("lumen-settings --page=appearance")),
                ("Edit Widgets…", None, lambda: run("lumen-settings --page=widgets")),
                ("Dark Mode" if light else "Light Mode", None, lambda: sh.set_light_mode(not light)),
                None,
                ("Show All Windows", "Super Tab", lambda: ipc.send("overview")),
                ("Take a Screenshot", "Print", lambda: GLib.timeout_add(
                    350, lambda: (run("lumen-screenshot region"), False)[1])),
                None,
                ("System Settings", None, lambda: system.run(sh.cfg["settings"])),
            ]
            m = L.menu_card(items, after=self.close)
            self.card = m
            self.rev.set_child(m)
            self.adopt(m)
            x, y, w, h = self.at
            mw, mh = 250, 36 * 8 + 3 * 11 + 12          # near enough to keep it on the screen
            self.rev.set_margin_start(int(max(6, min(x, w - mw - 6))))
            self.rev.set_margin_top(int(max(36, min(y, h - mh - 6))))

    return DesktopMenu()


def desktop_clicks(shell, widget):
    """the wallpaper: right click opens the desktop menu"""
    g = Gtk.GestureClick(button=3)

    def pressed(_g, _n, x, y):
        menu = shell.popups.get("desktop")
        if menu is not None and not shell.preview:
            menu.show_at(x, y, widget.get_width(), widget.get_height())
    g.connect("pressed", pressed)
    widget.add_controller(g)


# ----------------------------------------------------------------- emoji
EMOJI = (
    ("Smileys", "😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 🤨 😐 😑 😶 😏 😒 "
                "🙄 😬 😌 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🥵 🥶 🥴 😵 🤯 🤠 🥳 😎 🤓 🧐 😕 😟 🙁 😮 😯 😲 😳 🥺 😦 😧 😨 😰 "
                "😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 👿 💀 💩 🤡 👻 👽 🤖 😺 😸 😹 😻 😼 🙀 😿"),
    ("People", "👋 🤚 ✋ 🖖 👌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 💪 🦾 👀 👁️ 👅 👄 🧠 "
               "👶 🧒 👦 👧 🧑 👨 👩 🧓 👴 👵 🙅 🙆 💁 🙋 🙇 🤦 🤷 💃 🕺 🏃 🚶 🧘 🛀 👪"),
    ("Hearts", "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 💯 💢 💥 💫 💦 💨 💤 ✨ ⭐ 🌟 🔥 🎉 🎊"),
    ("Nature", "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 "
               "🐢 🐍 🦎 🐙 🦑 🦀 🐠 🐟 🐬 🐳 🦈 🐊 🐘 🦒 🐕 🐈 🌵 🎄 🌲 🌳 🌴 🌱 🌿 ☘️ 🍀 🍁 🍂 🍃 🌺 🌻 🌹 🌷 🌼 🌸 "
               "💐 🌍 🌙 ☀️ ⛅ ☁️ 🌧️ ⛈️ ❄️ ☃️ 🌈 🌊 ⚡"),
    ("Food", "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🥦 🥒 🌶️ 🌽 🥕 🧄 🧅 🥔 🍞 🥐 🥖 🧀 🥚 🍳 🥞 🥓 🍗 🍖 🌭 🍔 "
             "🍟 🍕 🥪 🌮 🌯 🥗 🍝 🍜 🍲 🍣 🍱 🍤 🍙 🍚 🍦 🍩 🍪 🎂 🍰 🧁 🍫 🍬 🍭 🍿 ☕ 🍵 🥤 🍺 🍻 🥂 🍷 🍸 🍹"),
    ("Activity", "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🥊 🥋 ⛳ 🎣 🎿 🏂 🏋️ 🚴 🏆 🥇 🥈 🥉 🏅 🎮 🕹️ 🎲 🧩 🎯 🎳 🎨 🎬 🎤 🎧 🎼 🎹 "
                 "🥁 🎷 🎺 🎸 🎻"),
    ("Travel", "🚗 🚕 🚌 🚓 🚑 🚒 🚚 🚜 🏍️ 🚲 🛴 ✈️ 🚀 🛸 🚁 ⛵ 🚢 🚂 🚇 🗺️ 🗽 🗼 🏰 🏠 🏡 🏢 🏥 🏦 🏨 🏫 ⛺ 🏖️ 🏝️ ⛰️ 🌋 🌅 "
               "🌃 🌉"),
    ("Objects", "⌚ 📱 💻 ⌨️ 🖥️ 🖨️ 🖱️ 💾 💿 📷 📹 🎥 📞 ☎️ 📺 📻 ⏰ ⏳ 💡 🔦 🔋 🔌 💸 💵 💳 💎 🔧 🔨 🛠️ ⚙️ 🔫 💣 🔪 🛡️ 🔮 "
                "💊 💉 🧬 🔬 🔭 🧹 🧻 🚽 🛁 🔑 🚪 🛏️ 🎁 🎈 ✉️ 📦 📝 📁 📂 📅 📈 📉 📊 📌 📎 ✂️ 🔒 🔓 🔍 📚 📖 🔗 🗑️"),
    ("Symbols", "✅ ❌ ❓ ❗ ⚠️ 🚫 ⛔ ♻️ ➕ ➖ ➗ ✖️ ♾️ ™️ ©️ ®️ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🟥 🟧 🟨 🟩 🟦 🟪 ⬛ ⬜ ▶️ ⏸️ ⏹️ ⏺️ "
                "⏭️ ⏮️ 🔀 🔁 🔊 🔇 🔔 🔕 ⬆️ ⬇️ ⬅️ ➡️ ↩️ 🔄 🏁 🚩 🏳️ 🏴"),
)
ALIASES = {"😂": "lol laugh crying", "🤣": "rofl lol", "😭": "cry sob", "👍": "ok yes like", "👎": "no dislike",
           "🙏": "please thanks pray", "🔥": "fire lit", "🎉": "party tada celebrate", "❤️": "love heart red",
           "✨": "sparkles", "💀": "skull dead", "😅": "sweat phew", "🥺": "pleading puppy", "🤔": "thinking hmm",
           "👀": "eyes look", "💯": "hundred", "✅": "check done yes", "❌": "cross no wrong", "😎": "cool sunglasses",
           "🙂": "smile", "😀": "smile grin happy", "😊": "smile blush happy", "😢": "sad tear", "😡": "angry mad",
           "🤷": "shrug", "🤦": "facepalm", "👏": "clap", "💪": "strong muscle", "🚀": "rocket ship launch"}
RECENT = os.path.join(GLib.get_user_cache_dir(), "lumen", "emoji-recent")


def emoji_words(e):
    try:
        name = unicodedata.name(e[0], "").lower()
    except (TypeError, ValueError):
        name = ""
    return (name + " " + ALIASES.get(e, "")).strip()


def recent_emoji():
    try:
        with open(RECENT, encoding="utf-8") as f:
            return [x for x in f.read().split() if x][:24]
    except OSError:
        return []


def make_emoji_panel(shell):
    L = A()

    class EmojiPanel(L.Popup):
        """Super+. — pick an emoji (or type to find one): it goes into the
        window you were typing in, and onto the clipboard."""

        def __init__(self):
            self.shell = shell
            self.first = None
            self.search = Gtk.SearchEntry(placeholder_text="Search emoji", hexpand=True)
            self.search.add_css_class("clip-search")
            self.search.connect("search-changed", lambda *_: self.refresh())
            self.search.connect("activate", lambda *_: self.first and self.pick(self.first))
            self.body = L.box(Gtk.Orientation.VERTICAL, 4, "emoji-body")
            self.scroller = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, min_content_height=300,
                                               max_content_height=300)
            self.scroller.set_child(self.body)
            card = L.box(Gtk.Orientation.VERTICAL, 10, "glass card nc clip emoji",
                         L.box(Gtk.Orientation.HORIZONTAL, 8, "nc-head", L.lbl("Emoji", "nc-title", xalign=0)),
                         self.search, self.scroller,
                         L.lbl("Enter picks the first · Esc closes", "clip-hint", xalign=0))
            card.set_size_request(400, -1)
            super().__init__(shell, "emoji", card, Gtk.Align.CENTER, Gtk.Align.END, {"bottom": 70},
                             Gtk.RevealerTransitionType.SLIDE_UP)
            self._built_for = None

        def on_open(self):
            self.search.set_text("")
            self._built_for = None
            self.refresh()
            GLib.timeout_add(60, lambda: (self.search.grab_focus(), False)[1])

        def section(self, title, emoji):
            flow = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=9,
                               min_children_per_line=9, homogeneous=True, row_spacing=2, column_spacing=2)
            for e in emoji:
                b = L.button(L.lbl(e, "emoji-glyph"), "emoji-btn", lambda e=e: self.pick(e), emoji_words(e).title())
                flow.append(b)
            self.body.append(L.lbl(title, "emoji-title", xalign=0))
            self.body.append(flow)

        def refresh(self):
            q = self.search.get_text().strip().lower()
            if self._built_for == q:
                return
            self._built_for = q
            child = self.body.get_first_child()
            while child:
                nxt = child.get_next_sibling()
                self.body.remove(child)
                child = nxt
            self.first = None
            if q:
                words = q.split()
                hits = [e for _t, s in EMOJI for e in s.split() if all(w in emoji_words(e) for w in words)]
                if hits:
                    self.first = hits[0]
                    self.section("Results", hits[:90])
                else:
                    self.body.append(L.lbl("No emoji by that name", "nc-empty-title"))
                return
            rec = recent_emoji()
            if rec:
                self.section("Recently used", rec[:18])
            for title, s in EMOJI:
                self.section(title, s.split())
            self.scroller.get_vadjustment().set_value(0)

        def pick(self, e):
            rec = [e] + [x for x in recent_emoji() if x != e]
            try:
                os.makedirs(os.path.dirname(RECENT), exist_ok=True)
                with open(RECENT, "w", encoding="utf-8") as f:
                    f.write(" ".join(rec[:24]))
            except OSError:
                pass
            self.close()
            if self.shell.preview:
                return
            if shutil.which("wl-copy"):
                system.spawn("printf %s " + shlex.quote(e) + " | wl-copy")
                # once the window under us has the keyboard back: paste
                GLib.timeout_add(240, lambda: (ipc.send("paste"), False)[1])
            else:
                Gdk.Display.get_default().get_clipboard().set(e)

    return EmojiPanel()
