#ifndef LUMEN_LIQUID_GL_H
#define LUMEN_LIQUID_GL_H
#include <stdbool.h>

#define LIQUID_MAX_SHAPES 32

/* a glass pane in framebuffer pixels (y down) */
struct liquid_shape {
	float x, y, w, h;
	float radius[4];   /* tl, tr, br, bl */
	float band[4];     /* bevel per edge (top, right, bottom, left); 0 = flat (screen/clip edge) */
	float shadow;      /* 0..1 floating drop shadow */
	float frost;       /* 0..1 of the configured frost */
	float alpha;
	float tint[4];     /* premultiplied colour laid over the glass (window tint) */
	unsigned mask_tex, mask_target;   /* optional app texture: glass only under its pixels */
	int mask_w, mask_h;               /* its size in texels (for converting external textures) */
	float mask_lo, mask_hi;           /* alpha ramp that counts as "drawn" (0,0 = defaults for windows) */
	float mask_rect[4], mask_src[4];
	/* a see-through window with our titlebar (a terminal): the titlebar takes the
	 * app's own background colour, so titlebar + content read as ONE pane of
	 * glass instead of a light cap on a dark box with square corners */
	unsigned bg_tex, bg_target;       /* the app's texture, to read that colour from (0: none) */
	float bg_u0, bg_u1, bg_v;         /* the row of texels to look at */
	const void *bg_key;               /* whose colour it is (cached between frames) */
	float cap_h;                      /* fb px from the pane's top that get cap_tint */
	float cap_tint[4];                /* premultiplied */
	float min_radius;                 /* the lens is never squarer than this (see liquid.c) */
	bool measure_only;                /* the mask is read for the corner radius, but doesn't trim the lens */
	bool rim_over;                    /* rim light goes on after the content (liquid_gl_draw_rim) */
	bool measure;                     /* compositor bookkeeping: measure corner radius */
	int measure_x, measure_y;
	float measure_scale;
};

/* something to redraw on top of the glass (fb pixels) */
struct liquid_paint {
	float x, y, w, h;
	float radius[4];        /* tl tr br bl */
	float hole[4];          /* clipped region (SceneFX): x y w h, w = 0 → none */
	float hole_radius[4];
};
struct liquid_clip { int x, y, w, h; };

struct liquid_params {
	float band;       /* max bevel width, logical px */
	float strength;   /* refraction */
	float zoom;       /* magnification of the flat top (0.03 = 3%) */
	float frost;      /* max blur radius, logical px */
	float specular;   /* rim highlight */
	float tint;       /* white lift of the glass body */
};

/* on the backdrop frame (glass panes invisible): remember what is behind each pane */
bool liquid_gl_capture(int fb_w, int fb_h, float scale, const struct liquid_shape *shapes, int first, int n,
	const struct liquid_params *prm);

/* on the final frame: shadow + lens for shapes[first .. first+n) */
bool liquid_gl_draw(int fb_w, int fb_h, float scale, const struct liquid_shape *shapes, int first, int n,
	const struct liquid_params *prm);

/* after the pane's own content is back on top: the light on the rim of panes
 * with rim_over, so the glass edge wraps what the app draws */
bool liquid_gl_draw_rim(int fb_w, int fb_h, float scale, const struct liquid_shape *shapes, int first, int n,
	const struct liquid_params *prm);

/* the colour an app paints its background with: the most common of a few texels
 * along one row of its texture (premultiplied RGBA). false: couldn't tell */
bool liquid_gl_sample_row(unsigned tex, unsigned target, float u0, float u1, float v, float out[4]);
/* switching glass style: keep a frame (0 = frosted, 1 = liquid), then pour the two together */
bool liquid_gl_pour_grab(int which, int fb_w, int fb_h);
bool liquid_gl_pour_mix(int fb_w, int fb_h, float scale, float level, float t);

/* an app's corner radius in texels, measured from its pixels (-1: unknown) */
float liquid_gl_corner_radius(unsigned key, unsigned tex, int x, int y, int max_r);

/* copy any app texture (2D or external OES) into a plain 2D texture we can
 * sample as a mask and read back; slot = shape index. 0 on failure */
unsigned liquid_gl_to_2d(int slot, unsigned tex, unsigned target, int w, int h);

bool liquid_gl_paint_begin(int fb_w, int fb_h);
void liquid_gl_paint_rect(const struct liquid_paint *pt, const float color[4], const struct liquid_clip *clip);
bool liquid_gl_paint_texture(const struct liquid_paint *pt, unsigned tex, unsigned target, bool has_alpha,
	const float src[4], float opacity, const struct liquid_clip *clip);
bool liquid_gl_paint_end(void);

#endif
