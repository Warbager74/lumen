/* Windows: glass frames, mac traffic lights, workspaces and their animations. */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <wlr/types/wlr_subcompositor.h>
#include <wlr/util/edges.h>
#include <wlr/util/log.h>
#include "lumen.h"

#define EDGE_GRAB 7
enum { A_OPEN = 1, A_CLOSE, A_MIN, A_GEOM, A_RESTORE, A_LIGHTS, A_CLOSEWAIT, A_HANDOVER, A_FOCUS };

static const float LIGHT_COLORS[3][4] = {
	{ 1.000f, 0.373f, 0.341f, 1 },   /* #ff5f57 close */
	{ 0.996f, 0.737f, 0.180f, 1 },   /* #febc2e minimize */
	{ 0.157f, 0.784f, 0.251f, 1 },   /* #28c840 zoom */
};
static const float LIGHT_IDLE[4] = { 1, 1, 1, 0.22f };

/* the rim and resize-edge rects live beside the frame; keep them as children
 * found by fixed indices stored in node->data tags */
struct view_extra { struct wlr_scene_rect *rim, *edge; bool animating_geom;
	struct wlr_scene_tree *popups;   /* the app's menus and popovers: above everything, never clipped */
	bool on_top;                     /* kept above the other windows (Super+T) */
	int title_tone;                  /* 0: the configured colour · 1: white (dark titlebar) · 2: dark (pale one) */
	struct wlr_box anim_box; int title_w;
	struct wlr_buffer *last_buf; struct wlr_fbox last_src;   /* for the close fade */
	double closing_since;
	double focus_k, focus_to; };  /* 0 = in the background … 1 = focused (eased, see focus_sync) */
static struct view_extra *X(struct lumen_view *v) { return (struct view_extra *)(v + 1); }

/* SceneFX aborts on an opacity outside 0..1: springy animations overshoot */
static float alpha01(struct lumen_view *v) {
	double a = v->alpha;
	return (float)(a < 0 ? 0 : (a > 1 ? 1 : a));
}

static void premul(const float in[4], float a, float out[4]) {
	out[0] = in[0] * a; out[1] = in[1] * a; out[2] = in[2] * a; out[3] = in[3] * a;
}

/* windows kept on top go back above whichever window was just raised */
static void restack_on_top(struct lumen_server *s, struct lumen_view *raised) {
	if (raised && (raised->fullscreen || X(raised)->on_top)) return;
	struct lumen_view *v;
	wl_list_for_each_reverse(v, &s->views, link)
		if (X(v)->on_top && v->mapped && !v->fullscreen && v->tree->node.parent == s->ws_tree[v->workspace])
			wlr_scene_node_raise_to_top(&v->tree->node);
}

bool view_on_top(struct lumen_view *v) { return v && X(v)->on_top; }

void view_toggle_on_top(struct lumen_view *v) {
	if (!v) return;
	X(v)->on_top = !X(v)->on_top;
	if (X(v)->on_top && v->mapped && !v->fullscreen) wlr_scene_node_raise_to_top(&v->tree->node);
	restack_on_top(v->server, NULL);
	ipc_state_changed(v->server);
}

struct lumen_view *view_by_id(struct lumen_server *s, uint32_t id) {
	struct lumen_view *v;
	wl_list_for_each(v, &s->views, link) if (v->id == id) return v;
	return NULL;
}

/* ------------------------------------------------- client abstraction
 * Everything that differs between xdg-shell and X11 windows lives here. */
struct wlr_surface *view_surface(struct lumen_view *v) {
#if WLR_HAS_XWAYLAND
	if (v->type == VIEW_X11) return v->xsurf ? v->xsurf->surface : NULL;
#endif
	return v->xdg->base->surface;
}

const char *view_title(struct lumen_view *v) {
	const char *t = NULL;
#if WLR_HAS_XWAYLAND
	if (v->type == VIEW_X11) t = v->xsurf ? v->xsurf->title : NULL;
	else
#endif
	t = v->xdg->title;
	return t ? t : "";
}

const char *view_app_id(struct lumen_view *v) {
	const char *a = NULL;
#if WLR_HAS_XWAYLAND
	if (v->type == VIEW_X11) a = v->xsurf ? v->xsurf->class : NULL;
	else
#endif
	a = v->xdg->app_id;
	return a ? a : "";
}

static int title_h(struct lumen_view *v) {
	return v->ssd && !v->fullscreen ? TITLEBAR_H : 0;
}

static void client_activate(struct lumen_view *v, bool on) {
#if WLR_HAS_XWAYLAND
	if (v->type == VIEW_X11) {
		if (!v->xsurf) return;
		wlr_xwayland_surface_activate(v->xsurf, on);
		if (on) wlr_xwayland_surface_restack(v->xsurf, NULL, XCB_STACK_MODE_ABOVE);
		return;
	}
#endif
	wlr_xdg_toplevel_set_activated(v->xdg, on);
}

static void client_close(struct lumen_view *v) {
#if WLR_HAS_XWAYLAND
	if (v->type == VIEW_X11) { if (v->xsurf) wlr_xwayland_surface_close(v->xsurf); return; }
#endif
	wlr_xdg_toplevel_send_close(v->xdg);
}

/* tell the client its new frame box (X11 also needs the absolute position) */
static void client_set_box(struct lumen_view *v, struct wlr_box frame) {
	int th = title_h(v);
	int w = frame.width > 1 ? frame.width : 1;
	int h = frame.height - th > 1 ? frame.height - th : 1;
#if WLR_HAS_XWAYLAND
	if (v->type == VIEW_X11) {
		if (v->xsurf) wlr_xwayland_surface_configure(v->xsurf, frame.x, frame.y + th, w, h);
		return;
	}
#endif
	wlr_xdg_toplevel_set_size(v->xdg, w, h);
}

static void client_set_maximized(struct lumen_view *v, bool on) {
#if WLR_HAS_XWAYLAND
	if (v->type == VIEW_X11) { if (v->xsurf) wlr_xwayland_surface_set_maximized(v->xsurf, on, on); return; }
#endif
	wlr_xdg_toplevel_set_maximized(v->xdg, on);
}

static void client_set_fullscreen(struct lumen_view *v, bool on) {
#if WLR_HAS_XWAYLAND
	if (v->type == VIEW_X11) { if (v->xsurf) wlr_xwayland_surface_set_fullscreen(v->xsurf, on); return; }
#endif
	wlr_xdg_toplevel_set_fullscreen(v->xdg, on);
}

static void client_set_minimized(struct lumen_view *v, bool on) {
#if WLR_HAS_XWAYLAND
	if (v->type == VIEW_X11) { if (v->xsurf) wlr_xwayland_surface_set_minimized(v->xsurf, on); return; }
#endif
	wlr_xdg_toplevel_set_suspended(v->xdg, on);
}

static struct wlr_box client_geometry(struct lumen_view *v) {
#if WLR_HAS_XWAYLAND
	if (v->type == VIEW_X11) {
		struct wlr_surface *sf = view_surface(v);
		return (struct wlr_box){ 0, 0, sf ? sf->current.width : 0, sf ? sf->current.height : 0 };
	}
#endif
	/* the part of its surface the app calls its window: without the margins it
	 * keeps around it for its own shadow and resize grips (GTK: 12px or more) */
	return v->xdg->base->geometry;
}

struct lumen_view *focused_view(struct lumen_server *s) {
	struct wlr_surface *f = s->seat->keyboard_state.focused_surface;
	if (!f) return NULL;
	struct lumen_view *v;
	wl_list_for_each(v, &s->views, link)
		if (v->mapped && view_surface(v) == f) return v;
	return NULL;
}

/* -------------------------------------------------------- decoration paint */
struct body_find { struct wlr_surface *sf; struct wlr_scene_buffer *b; };
static void body_find_cb(struct wlr_scene_buffer *b, int sx, int sy, void *data) {
	(void)sx; (void)sy;
	struct body_find *f = data;
	struct wlr_scene_surface *ss = wlr_scene_surface_try_from_buffer(b);
	if (!f->b && ss && ss->surface == f->sf) f->b = b;
}

/* The box the app actually paints its main surface into, relative to the
 * window's tree (after the geometry clip). Apps like Firefox report an xdg
 * geometry larger than the buffer they draw, so sizing glass from the geometry
 * left blur and shadow sticking out past the window. */
bool view_body_box(struct lumen_view *v, struct wlr_box *out) {
	if (!v->surface_tree) return false;
	struct body_find f = { view_surface(v), NULL };
	if (!f.sf) return false;
	wlr_scene_node_for_each_buffer(&v->surface_tree->node, body_find_cb, &f);
	if (!f.b) return false;
	int bx, by, tx, ty;
	wlr_scene_node_coords(&f.b->node, &bx, &by);
	wlr_scene_node_coords(&v->tree->node, &tx, &ty);
	int w = f.b->dst_width > 0 ? f.b->dst_width : f.sf->current.width;
	int h = f.b->dst_height > 0 ? f.b->dst_height : f.sf->current.height;
	if (w <= 0 || h <= 0) return false;
	*out = (struct wlr_box){ bx - tx, by - ty, w, h };
	return true;
}

static void set_buffer_alpha(struct wlr_scene_buffer *b, int sx, int sy, void *data) {
	struct lumen_view *v = data;
	wlr_scene_buffer_set_opacity(b, alpha01(v));
	if (b == v->title) return;
	struct wlr_scene_surface *ss = wlr_scene_surface_try_from_buffer(b);
	if (!ss) return;
	/* round the window's main surface; subsurfaces/popups stay square */
	if (ss->surface == view_surface(v) && !v->ssd) {
		/* client-side decorated (GTK, Chrome…): the app draws its own frame,
		 * rounded corners and soft drop shadow. Frost exactly the window body:
		 * the blur covers the window geometry only (never the shadow around
		 * it, which used to leak out below and to the side), and where this
		 * SceneFX can, the app's own alpha trims the rounded corners. */
		/* blur box + corners are laid out from the drawn body in layout_decor */
#ifdef LUMEN_HAVE_BLUR_THRESHOLD
		if (wlr_scene_blur_get_transparency_mask_source(v->blur) != b)
			wlr_scene_blur_set_transparency_mask_source(v->blur, b);
#endif
		(void)sx; (void)sy;
	}
	if (ss->surface == view_surface(v)) {
		int r = v->server->cfg.corner_radius;
		bool full = v->maximized || v->fullscreen;
		wlr_scene_buffer_set_corner_radii(b, full ? corner_radii_none()
			: v->ssd ? corner_radii_bottom(r) : corner_radii_all(r));
	}
}

/* Window controls: macOS traffic-light colours, Windows 11 manners. Hovering
 * the titlebar's controls reveals thin glyphs; the one under the pointer grows
 * from a dot into a rounded Windows-style button. Default: on the left, close,
 * minimise, zoom (like macOS and Lumen Files); controls_side = right gives the
 * Windows order minimise, maximise, close. */
#define LIGHT 14
#define LIGHT_SP 24
static void light_rect(struct lumen_view *v, int i, int *x, int *y, int *w, int *h) {
	bool right = strcmp(v->server->cfg.controls_side, "left") != 0;
	struct wlr_box b = X(v)->animating_geom ? X(v)->anim_box : v->geom;
	/* slot: right side → min(0) max(1) close(2) from the left of the group */
	int slot = right ? (i == 0 ? 2 : i == 1 ? 0 : 1) : i;
	int cx = right ? b.width - 18 - (2 - slot) * LIGHT_SP - LIGHT / 2 : 14 + slot * LIGHT_SP + LIGHT / 2;
	int cy = TITLEBAR_H / 2;
	bool big = v->hover_part == i;
	*w = big ? 30 : LIGHT;
	*h = big ? 22 : LIGHT;
	*x = cx - *w / 2;
	*y = cy - *h / 2;
}

/* a control's colour: grey in the background, its traffic-light colour when the
 * window has focus (or the pointer is on the controls), eased in between */
static void light_color(struct lumen_view *v, int i, float out[4]) {
	double k = v->hover_lights ? 1.0 : X(v)->focus_k;
	if (k < 0) k = 0;
	if (k > 1) k = 1;
	float mix[4];
	/* (resting controls: a faint dot — pale on dark glass, dark on light) */
	const float idle_light[4] = { 0.10f, 0.11f, 0.16f, 0.20f };
	const float *idle = v->server->cfg.light ? idle_light : LIGHT_IDLE;
	for (int j = 0; j < 4; j++) mix[j] = (float)lerp(idle[j], LIGHT_COLORS[i][j], k);
	/* the idle colour is translucent white: premultiply by its own alpha too */
	float a = mix[3] * alpha01(v);
	out[0] = mix[0] * a; out[1] = mix[1] * a; out[2] = mix[2] * a; out[3] = a;
}

static void paint_lights(struct lumen_view *v) {
	float scale = 1;
	struct lumen_output *o = output_at(v->server, v->geom.x + 1, v->geom.y + 1);
	if (o) scale = o->wlr_output->scale;
	for (int i = 0; i < 3; i++) {
		float c[4];
		bool big = v->hover_part == i;
		light_color(v, i, c);
		if (big) { c[0] = fminf(c[3], c[0] * 1.06f); c[1] = fminf(c[3], c[1] * 1.06f); c[2] = fminf(c[3], c[2] * 1.06f); }
		wlr_scene_rect_set_color(v->lights[i], c);
		int x, y, w, h;
		light_rect(v, i, &x, &y, &w, &h);
		wlr_scene_rect_set_size(v->lights[i], w, h);
		wlr_scene_rect_set_corner_radius(v->lights[i], big ? 7 : LIGHT / 2);
		wlr_scene_node_set_position(&v->lights[i]->node, x, y);
		/* glyphs appear when the pointer is over the controls */
		bool show = v->hover_lights;
		if (show) {
			const float dark[4] = { 0.08f, 0.06f, 0.06f, 0.75f }, white[4] = { 1, 1, 1, 0.95f };
			struct wlr_buffer *gb = glyph_buffer_create(i, i == 2 && v->maximized,
				big && i == 0 ? white : dark, 12, scale);
			if (!v->glyphs[i]) v->glyphs[i] = wlr_scene_buffer_create(v->titlebar, NULL);
			wlr_scene_buffer_set_buffer(v->glyphs[i], gb);
			wlr_scene_buffer_set_dest_size(v->glyphs[i], 12, 12);
			wlr_buffer_drop(gb);
			wlr_scene_node_set_position(&v->glyphs[i]->node, x + w / 2 - 6, y + h / 2 - 6);
			wlr_scene_buffer_set_opacity(v->glyphs[i], alpha01(v));
			wlr_scene_node_raise_to_top(&v->glyphs[i]->node);
		}
		if (v->glyphs[i]) wlr_scene_node_set_enabled(&v->glyphs[i]->node, show);
	}
}

void view_hover_part(struct lumen_view *v, int part) {
	if (!v) return;
	int i = part == PART_CLOSE ? 0 : part == PART_MIN ? 1 : part == PART_ZOOM ? 2 : -1;
	bool on = i >= 0;
	if (v->hover_part == i && v->hover_lights == on) return;
	v->hover_part = i;
	v->hover_lights = on;
	paint_lights(v);
	snap_flyout_hover(v, i == 2);   /* Windows 11: hover maximise for snap layouts */
}

/* what changes with focus: the shadow deepens and the controls take their
 * colours. Both follow focus_k, which eases (see focus_sync) instead of jumping */
static void paint_focus(struct lumen_view *v) {
	float c[4];
	double k = X(v)->focus_k < 0 ? 0 : (X(v)->focus_k > 1 ? 1 : X(v)->focus_k);
	premul(v->server->cfg.shadow_color, (float)(alpha01(v) * lerp(0.55, 1.0, k)), c);
	wlr_scene_shadow_set_color(v->shadow, c);
	for (int i = 0; i < 3; i++) {
		light_color(v, i, c);
		if (v->hover_part == i) {
			c[0] = fminf(c[3], c[0] * 1.06f); c[1] = fminf(c[3], c[1] * 1.06f); c[2] = fminf(c[3], c[2] * 1.06f);
		}
		wlr_scene_rect_set_color(v->lights[i], c);
	}
}

static void focus_step(struct anim *a, double t) {
	struct lumen_view *v = a->owner;
	X(v)->focus_k = lerp(a->from[0], a->to[0], t);
	if (v->mapped) paint_focus(v);
}

/* keep focus_k heading for the window's real focus state */
static void focus_sync(struct lumen_view *v) {
	struct view_extra *x = X(v);
	double to = focused_view(v->server) == v ? 1 : 0;
	if (x->focus_to == to) return;
	x->focus_to = to;
	if (!v->server->cfg.animations || !v->mapped) {
		anim_cancel(v, A_FOCUS);
		x->focus_k = to;
		return;
	}
	struct anim *a = anim_start(v, A_FOCUS, anim_scaled(to > 0.5 ? 150 : 220), EASE_OUT_CUBIC, focus_step, NULL);
	a->from[0] = x->focus_k;
	a->to[0] = to;
}

static void paint(struct lumen_view *v) {
	struct lumen_config *cfg = &v->server->cfg;
	float c[4];
	focus_sync(v);
	premul(cfg->glass_tint, (float)v->alpha, c);
	wlr_scene_rect_set_color(v->frame, c);
	wlr_scene_blur_set_alpha(v->blur, alpha01(v));
	wlr_scene_blur_set_strength(v->blur, alpha01(v));
	/* a hairline of light around the frame (premultiplied, like every scene colour) */
	float rim[4] = { 0.24f, 0.24f, 0.24f, 0.24f };
	premul(rim, alpha01(v), c);
	wlr_scene_rect_set_color(X(v)->rim, c);
	paint_lights(v);
	paint_focus(v);
	wlr_scene_node_for_each_buffer(&v->tree->node, set_buffer_alpha, v);
}

static void update_title(struct lumen_view *v, int width) {
	if (!v->ssd) return;
	const char *t = view_title(v);
	int w = width - 180;
	if (w < 10) w = 10;
	float scale = 1;
	struct lumen_output *o = output_at(v->server, v->geom.x + 1, v->geom.y + 1);
	if (o) scale = o->wlr_output->scale;
	/* a see-through app wears its own colour on our titlebar (Liquid Glass): the
	 * title is then whichever of white and dark reads on that colour */
	static const float on_dark[4] = { 1, 1, 1, 0.90f }, on_pale[4] = { 0.10f, 0.11f, 0.16f, 0.88f };
	int tone = liquid_enabled(v->server) ? X(v)->title_tone : 0;
	const float *col = tone == 1 ? on_dark : tone == 2 ? on_pale : v->server->cfg.title_color;
	struct wlr_buffer *buf = text_buffer_create(t, "Inter Semi-Bold 10.5",
		col, w, TITLEBAR_H, scale);
	wlr_scene_buffer_set_buffer(v->title, buf);
	wlr_scene_buffer_set_dest_size(v->title, w, TITLEBAR_H);
	wlr_buffer_drop(buf);
	wlr_scene_node_set_position(&v->title->node, 90, 0);   /* centred in width-180 */
	snprintf(v->last_title, sizeof(v->last_title), "%s", t);
	X(v)->title_w = width;
}

/* lay out every decoration node for a frame box of size w×h */
static void layout_decor(struct lumen_view *v, int w, int h) {
	if (w < 1) w = 1;
	if (h < 1) h = 1;
	struct lumen_config *cfg = &v->server->cfg;
	bool flat = v->maximized || v->fullscreen;
	int r = flat ? 0 : cfg->corner_radius;
	float sig = flat || cfg->performance_mode ? 0 : cfg->shadow_sigma;   /* no shadows in performance mode */

	/* self-decorated apps: shadow and frost follow what the app really draws */
	struct wlr_box body = { 0, 0, w, h };
	if (!v->ssd) {
		struct wlr_box bb;
		if (view_body_box(v, &bb)) {
			struct wlr_box frame = { 0, 0, w, h };
			if (!wlr_box_intersection(&body, &bb, &frame)) body = (struct wlr_box){ 0, 0, 0, 0 };
		}
	}
	/* no shadow wanted (size 0, a maximised window, Performance mode): no node */
	wlr_scene_node_set_enabled(&v->shadow->node, !v->fullscreen && body.width > 0 && sig >= 1);
	wlr_scene_shadow_set_blur_sigma(v->shadow, sig);
	wlr_scene_shadow_set_corner_radius(v->shadow, r);
	wlr_scene_shadow_set_size(v->shadow, body.width + sig * 2, body.height + sig * 2);
	wlr_scene_node_set_position(&v->shadow->node, body.x - sig, body.y - sig + sig * 0.25);
	wlr_scene_shadow_set_clipped_region(v->shadow, (struct clipped_region){
		.corners = corner_radii_all(r),
		.area = { (int)sig, (int)(sig - sig * 0.25), body.width, body.height } });

	/* glass body: our frame for server-decorated windows, the app's body otherwise */
	wlr_scene_node_set_enabled(&v->frame->node, v->ssd);
	struct wlr_box fb = body;
	bool blur_on = body.width > 0;
	if (!v->ssd && blur_on) {
		/* self-drawn apps: frost only what can show through. An app that says it's
		 * opaque gets none, and the frost stays 2px inside the app's edge, or it
		 * glows through the anti-aliased border as a light outline (Electron apps) */
		struct wlr_surface *sf = view_surface(v);
		if (sf && pixman_region32_contains_rectangle(&sf->opaque_region,
				&(pixman_box32_t){ 24, 24, sf->current.width - 24, sf->current.height - 24 }) == PIXMAN_REGION_IN)
			blur_on = false;
		fb.x += 2; fb.y += 2; fb.width -= 4; fb.height -= 4;
		if (fb.width < 1 || fb.height < 1) blur_on = false;
	}
	wlr_scene_node_set_enabled(&v->blur->node, blur_on);
	if (blur_on) {
		wlr_scene_node_set_position(&v->blur->node, fb.x, fb.y);
		wlr_scene_blur_set_size(v->blur, fb.width, fb.height);
		wlr_scene_blur_set_corner_radius(v->blur, r > 2 ? r - 2 : 0);
	}
	wlr_scene_rect_set_size(v->frame, w, h);
	wlr_scene_rect_set_corner_radius(v->frame, r);

	struct wlr_scene_rect *rim = X(v)->rim;
	wlr_scene_node_set_enabled(&rim->node, !flat && v->ssd);
	wlr_scene_rect_set_size(rim, w, h);
	wlr_scene_rect_set_corner_radius(rim, r);
	wlr_scene_rect_set_clipped_region(rim, (struct clipped_region){
		.corners = corner_radii_all(r > 1 ? r - 1 : 0),
		.area = { 1, 1, w - 2, h - 2 } });

	struct wlr_scene_rect *edge = X(v)->edge;
	wlr_scene_node_set_enabled(&edge->node, !flat);
	wlr_scene_rect_set_size(edge, w + EDGE_GRAB * 2, h + EDGE_GRAB * 2);
	wlr_scene_node_set_position(&edge->node, -EDGE_GRAB, -EDGE_GRAB);
	wlr_scene_rect_set_clipped_region(edge, (struct clipped_region){
		.corners = corner_radii_all(r),
		.area = { EDGE_GRAB, EDGE_GRAB, w, h } });

	wlr_scene_node_set_enabled(&v->titlebar->node, v->ssd && !v->fullscreen);
	/* re-render the title when it changes or the window is resized (not mid-animation) */
	if (v->ssd && (strcmp(v->last_title, view_title(v)) != 0 ||
			(X(v)->title_w != w && !X(v)->animating_geom)))
		update_title(v, w);
}

static void place(struct lumen_view *v) {
	struct wlr_box b = X(v)->animating_geom ? X(v)->anim_box : v->geom;
	wlr_scene_node_set_position(&v->tree->node, b.x, b.y + (int)v->scale_y_off);
}

static void update_decor(struct lumen_view *v) {
	struct wlr_box b = X(v)->animating_geom ? X(v)->anim_box : v->geom;
	layout_decor(v, b.width, b.height);
	place(v);
	paint(v);
}

/* ------------------------------------------------------------------ focus */
void focus_view(struct lumen_view *v) {
	if (!v || !v->mapped) return;
	struct lumen_server *s = v->server;
	if (s->exclusive_layer || session_locked()) return;  /* launcher / lock screen owns the keyboard */
	struct lumen_view *prev = focused_view(s);
	if (v->workspace != s->ws_current) {
		if (output_showing(s, v->workspace)) s->ws_current = v->workspace;   /* other monitor */
		else workspace_switch(s, v->workspace);
	}
	if (v->minimized) view_set_minimized(v, false);
	wlr_scene_node_raise_to_top(&v->tree->node);
	wl_list_remove(&v->link);
	wl_list_insert(&s->views, &v->link);
	restack_on_top(s, v);
	if (prev == v) return;
	if (prev) {
		client_activate(prev, false);
		if (prev->ftl) wlr_foreign_toplevel_handle_v1_set_activated(prev->ftl, false);
	}
	client_activate(v, true);
	if (v->ftl) wlr_foreign_toplevel_handle_v1_set_activated(v->ftl, true);
	seat_focus(s, view_surface(v));
	if (prev) paint(prev);
	paint(v);
	ipc_state_changed(s);
}

/* focus follows the mouse: keyboard focus moves to the window under the
 * pointer, without raising it or reordering Alt+Tab */
void focus_view_noraise(struct lumen_view *v) {
	if (!v || !v->mapped || v->minimized || v->closing) return;
	struct lumen_server *s = v->server;
	if (s->exclusive_layer || session_locked()) return;
	struct lumen_view *prev = focused_view(s);
	if (prev == v) return;
	if (prev) {
		client_activate(prev, false);
		if (prev->ftl) wlr_foreign_toplevel_handle_v1_set_activated(prev->ftl, false);
	}
	client_activate(v, true);
	if (v->ftl) wlr_foreign_toplevel_handle_v1_set_activated(v->ftl, true);
	seat_focus(s, view_surface(v));
	if (prev) paint(prev);
	paint(v);
	ipc_state_changed(s);
}

/* show the desktop (four fingers down, pinch out): minimise this desktop's
 * windows and remember them; show = false (four fingers up) brings them back */
static uint32_t shown_away[64];
static int n_shown_away;

bool views_desktop_shown(void) { return n_shown_away > 0; }

void views_show_desktop(struct lumen_server *s, bool show) {
	if (show && n_shown_away == 0) {
		struct lumen_view *v, *tmp;
		wl_list_for_each_safe(v, tmp, &s->views, link)
			if (v->mapped && !v->minimized && v->workspace == s->ws_current && n_shown_away < 64) {
				shown_away[n_shown_away++] = v->id;
				view_set_minimized(v, true);
			}
	} else if (!show || n_shown_away) {
		/* bring them back in their old stacking order (last focused on top) */
		for (int i = n_shown_away - 1; i >= 0; i--) {
			struct lumen_view *v = view_by_id(s, shown_away[i]);
			if (v && v->mapped && v->minimized) focus_view(v);
		}
		n_shown_away = 0;
	}
}

void focus_next_view(struct lumen_server *s) {
	/* Alt-Tab: bring the least-recently-focused window on this workspace forward */
	struct lumen_view *v, *pick = NULL;
	wl_list_for_each_reverse(v, &s->views, link) {
		if (v->mapped && !v->minimized && v->workspace == s->ws_current) { pick = v; break; }
	}
	if (pick && pick != focused_view(s)) focus_view(pick);
}

static void focus_topmost(struct lumen_server *s) {
	struct lumen_view *v;
	wl_list_for_each(v, &s->views, link) {
		if (v->mapped && !v->minimized && !v->closing && v->workspace == s->ws_current) {
			focus_view(v);
			return;
		}
	}
	wlr_seat_keyboard_notify_clear_focus(s->seat);
	ipc_state_changed(s);
}

/* ---------------------------------------------------------------- hit test */
static bool peek_untouchable(struct lumen_view *v);

struct lumen_view *view_at(struct lumen_server *s, double lx, double ly,
		struct wlr_surface **surface, double *sx, double *sy, int *part) {
	*surface = NULL; *part = PART_NONE;
	struct wlr_scene_node *node = wlr_scene_node_at(&s->layer[L_WS]->node, lx, ly, sx, sy);
	if (!node) return NULL;
	struct wlr_scene_tree *t = node->parent;
	while (t && !t->node.data) t = t->node.parent;
	if (!t) return NULL;
	struct lumen_view *v = t->node.data;
	/* a neighbouring desktop is showing at this edge because one of its windows
	 * hangs over; its other windows (their resize borders reach a little past
	 * the edge too) are not here */
	if (peek_untouchable(v)) return NULL;

	if (node->type == WLR_SCENE_NODE_BUFFER) {
		struct wlr_scene_buffer *b = wlr_scene_buffer_from_node(node);
		struct wlr_scene_surface *ss = wlr_scene_surface_try_from_buffer(b);
		if (ss) { *surface = ss->surface; *part = PART_CONTENT; return v; }
	}
	if (node->type == WLR_SCENE_NODE_RECT && node == &X(v)->edge->node) {
		*part = PART_EDGE;
		return v;
	}
	/* titlebar: test the controls by their shape, not by node, so the hover
	 * glyphs drawn on top of them (and the grown hover button) still count */
	*part = PART_TITLE;
	if (v->ssd && !v->fullscreen) {
		int tx, ty;
		wlr_scene_node_coords(&v->tree->node, &tx, &ty);
		double px = lx - tx, py = ly - ty;
		for (int i = 0; i < 3; i++) {
			int x, y, w, h;
			light_rect(v, i, &x, &y, &w, &h);
			if (px >= x - 3 && px < x + w + 3 && py >= y - 4 && py < y + h + 4) {
				*part = PART_CLOSE + i;
				break;
			}
		}
	}
	return v;
}

void view_hover_lights(struct lumen_view *v, bool hover) {
	if (!v || (v->hover_lights == hover && (hover || v->hover_part < 0))) return;
	if (!hover) { v->hover_part = -1; snap_flyout_hover(v, false); }
	v->hover_lights = hover;
	paint_lights(v);
}

/* -------------------------------------------------------------- animations */
static void open_step(struct anim *a, double t) {
	struct lumen_view *v = a->owner;
	v->alpha = t < 0 ? 0 : (t > 1 ? 1 : t);
	v->scale_y_off = lerp(a->from[0], 0, t);
	place(v); paint(v);
}

static void alpha_y_step(struct anim *a, double t) {
	struct lumen_view *v = a->owner;
	v->alpha = lerp(a->from[0], a->to[0], t);
	v->scale_y_off = lerp(a->from[1], a->to[1], t);
	place(v); paint(v);
}

static void restore_if_alive(struct anim *a) {
	/* the client ignored the close (e.g. "save changes?" dialog): fade back */
	struct lumen_view *v = a->owner;
	if (!v->mapped || !v->closing) return;
	v->closing = false;
	struct anim *b = anim_start(v, A_OPEN, anim_scaled(220), EASE_OUT_CUBIC, alpha_y_step, NULL);
	b->from[0] = v->alpha; b->to[0] = 1; b->from[1] = v->scale_y_off; b->to[1] = 0;
}

static void close_done(struct anim *a) {
	struct lumen_view *v = a->owner;
	client_close(v);
	/* its own tag: nothing else may cancel this, or `closing` would stick and
	 * the close button would stop working for this window */
	struct anim *w = anim_start(v, A_CLOSEWAIT, 900, EASE_OUT_CUBIC, NULL, restore_if_alive);
	(void)w;
}

void view_close(struct lumen_view *v) {
	if (!v) return;
	/* already closing: ignore double clicks, but a close that's been pending a
	 * while (busy app) can always be asked again */
	if (v->closing && now_ms() - X(v)->closing_since < 1500) return;
	struct lumen_server *s = v->server;
	if (!s->cfg.animations) { client_close(v); return; }
	v->closing = true;
	X(v)->closing_since = now_ms();
	struct anim *a = anim_start(v, A_CLOSE, s->cfg.anim_ms * 0.55, EASE_OUT_CUBIC,
		alpha_y_step, close_done);
	a->from[0] = v->alpha; a->to[0] = 0;
	a->from[1] = 0; a->to[1] = 18;
	if (focused_view(s) == v) {
		wlr_seat_keyboard_notify_clear_focus(s->seat);
		/* hand focus to the next window while this one fades */
		struct lumen_view *n;
		wl_list_for_each(n, &s->views, link)
			if (n != v && n->mapped && !n->minimized && n->workspace == s->ws_current) {
				focus_view(n); break;
			}
	}
}

static void min_done(struct anim *a) {
	struct lumen_view *v = a->owner;
	wlr_scene_node_set_enabled(&v->tree->node, false);
}

/* the genie hands over to the real window gradually (no pop at the end) */
void view_set_alpha(struct lumen_view *v, double a) {
	if (!v->mapped) return;
	v->alpha = a < 0 ? 0 : (a > 1 ? 1 : a);
	wlr_scene_node_set_enabled(&v->tree->node, v->alpha > 0.003);
	if (v->alpha > 0.003) paint(v);
}

/* genie finished bringing the window out: the real one takes over */
static void genie_shown(struct lumen_view *v) {
	if (!v->mapped || v->minimized) return;
	v->alpha = 1;
	wlr_scene_node_set_enabled(&v->tree->node, true);
	update_decor(v);
}

static void genie_gone(struct lumen_view *v) {
	if (v->minimized) wlr_scene_node_set_enabled(&v->tree->node, false);
}

void view_set_minimized(struct lumen_view *v, bool min) {
	if (!v || v->minimized == min) return;
	struct lumen_server *s = v->server;
	v->minimized = min;
	client_set_minimized(v, min);
	if (v->ftl) wlr_foreign_toplevel_handle_v1_set_minimized(v->ftl, min);
	struct lumen_output *o = output_focused(s);
	double drop = o ? (o->full.y + o->full.height) - v->geom.y : 600;  /* toward the taskbar */
	struct anim *a;
	if (min && !v->fullscreen) {
		/* pour into the taskbar icon (the real window fades into the effect) */
		anim_cancel(v, A_MIN);
		v->alpha = 1;
		if (genie_run(v, false, genie_gone)) {
			if (focused_view(s) == v) {
				client_activate(v, false);
				wlr_seat_keyboard_notify_clear_focus(s->seat);
				focus_topmost(s);
			}
			tile_workspace(s, v->workspace);
			ipc_state_changed(s);
			return;
		}
	} else if (!min && !v->fullscreen) {
		/* flow back out of it */
		anim_cancel(v, A_MIN);
		v->alpha = 1;
		v->scale_y_off = 0;
		update_decor(v);
		wlr_scene_node_set_enabled(&v->tree->node, false);
		if (genie_run(v, true, genie_shown)) {
			tile_workspace(s, v->workspace);
			ipc_state_changed(s);
			return;
		}
	}
	if (min) {
		a = anim_start(v, A_MIN, s->cfg.anim_ms, EASE_IN_OUT_CUBIC, alpha_y_step, min_done);
		a->from[0] = v->alpha; a->to[0] = 0; a->from[1] = 0; a->to[1] = drop * 0.6;
		if (focused_view(s) == v) {
			client_activate(v, false);
			wlr_seat_keyboard_notify_clear_focus(s->seat);
			focus_topmost(s);
		}
	} else {
		wlr_scene_node_set_enabled(&v->tree->node, true);
		a = anim_start(v, A_MIN, s->cfg.anim_ms, EASE_OUT_EXPO, alpha_y_step, NULL);
		a->from[0] = 0; a->to[0] = 1; a->from[1] = drop * 0.6; a->to[1] = 0;
	}
	if (!s->cfg.animations) { a->dur_ms = 1; }
	tile_workspace(s, v->workspace);
	ipc_state_changed(s);
}

static void geom_step(struct anim *a, double t) {
	struct lumen_view *v = a->owner;
	struct wlr_box *b = &X(v)->anim_box;
	b->x = (int)lerp(a->from[0], a->to[0], t);
	b->y = (int)lerp(a->from[1], a->to[1], t);
	b->width = (int)lerp(a->from[2], a->to[2], t);
	b->height = (int)lerp(a->from[3], a->to[3], t);
	/* the spring overshoots: never let a shrinking window go to (or past) zero */
	int minw = (int)fmin(a->to[2], a->from[2]) * 0.6, minh = (int)fmin(a->to[3], a->from[3]) * 0.6;
	if (b->width < (minw > 40 ? minw : 40)) b->width = minw > 40 ? minw : 40;
	if (b->height < (minh > 40 ? minh : 40)) b->height = minh > 40 ? minh : 40;
	update_decor(v);
}

static void geom_done(struct anim *a) {
	struct lumen_view *v = a->owner;
	X(v)->animating_geom = false;
	if (v->type == VIEW_X11) client_set_box(v, v->geom);
	update_decor(v);
}

/* animate the frame to `to` and ask the client for the matching size */
void view_animate_to(struct lumen_view *v, struct wlr_box to);
static void animate_to(struct lumen_view *v, struct wlr_box to) {
	if (to.width < 60 || to.height < 60) {
		/* e.g. un-maximising a window that was born maximised: no saved size */
		struct lumen_output *o = output_at(v->server, v->geom.x + v->geom.width / 2.0, v->geom.y + 10);
		if (!o) o = output_focused(v->server);
		if (!o || o->usable.width < 100) return;
		int w = (int)(o->usable.width * 0.62), h = (int)(o->usable.height * 0.72);
		to = (struct wlr_box){ to.width < 60 ? o->usable.x + (o->usable.width - w) / 2 : to.x,
			to.height < 60 ? o->usable.y + (o->usable.height - h) / 2 : to.y, w, h };
	}
	struct wlr_box from = X(v)->animating_geom ? X(v)->anim_box : v->geom;
	client_set_box(v, to);
	v->geom.x = to.x; v->geom.y = to.y;
	if (!v->server->cfg.animations) { v->geom = to; update_decor(v); return; }
	X(v)->animating_geom = true;
	X(v)->anim_box = from;
	/* maximise, restore, snap, tile: glide there and settle, no wobble */
	struct anim *a = anim_start(v, A_GEOM, v->server->cfg.anim_ms, EASE_SPRING_SOFT,
		geom_step, geom_done);
	a->from[0] = from.x; a->from[1] = from.y; a->from[2] = from.width; a->from[3] = from.height;
	a->to[0] = to.x; a->to[1] = to.y; a->to[2] = to.width; a->to[3] = to.height;
}

void view_toggle_maximize(struct lumen_view *v) {
	if (!v || v->fullscreen) return;
	struct lumen_output *o = output_at(v->server, v->geom.x + v->geom.width / 2.0,
		v->geom.y + v->geom.height / 2.0);
	if (!o) o = output_focused(v->server);
	if (!o) return;
	v->maximized = !v->maximized;
	client_set_maximized(v, v->maximized);
	if (v->ftl) wlr_foreign_toplevel_handle_v1_set_maximized(v->ftl, v->maximized);
	if (v->maximized) {
		v->saved = v->geom;
		animate_to(v, o->usable);
	} else {
		animate_to(v, v->saved);
	}
	if (!v->maximized) tile_workspace(v->server, v->workspace);
	ipc_state_changed(v->server);
}

/* work area changed (bar appeared/resized): keep maximised windows filling it */
void views_reflow_maximized(struct lumen_output *o) {
	struct lumen_view *v;
	wl_list_for_each(v, &o->server->views, link)
		if (v->mapped && v->maximized && !v->fullscreen &&
				output_at(o->server, v->geom.x + 1, v->geom.y + 1) == o)
			animate_to(v, o->usable);
}

void view_set_fullscreen(struct lumen_view *v, bool fs) {
	if (!v || v->fullscreen == fs) return;
	struct lumen_output *o = output_at(v->server, v->geom.x + v->geom.width / 2.0,
		v->geom.y + v->geom.height / 2.0);
	if (!o) o = output_focused(v->server);
	if (!o) return;
	if (fs && !v->maximized) v->saved = v->geom;
	v->fullscreen = fs;
	client_set_fullscreen(v, fs);
	if (v->ftl) wlr_foreign_toplevel_handle_v1_set_fullscreen(v->ftl, fs);
	/* fullscreen windows sit above the bars */
	wlr_scene_node_reparent(&v->tree->node, fs ? v->server->layer[L_OVERLAY]
		: v->server->ws_tree[v->workspace]);
	animate_to(v, fs ? o->full : (v->maximized ? o->usable : v->saved));
}

void view_move_to(struct lumen_view *v, int x, int y) {
	v->geom.x = x; v->geom.y = y;
	place(v);
	if (v->type == VIEW_X11) client_set_box(v, v->geom);  /* X needs absolute coords */
}

void view_resize_to(struct lumen_view *v, struct wlr_box box) {
	v->geom.x = box.x; v->geom.y = box.y;
	client_set_box(v, box);
	place(v);
}

/* -------------------------------------------------------------- workspaces
 * Ten workspaces, each monitor shows its own one (like Hyprland). A workspace
 * remembers the monitor box its windows live on (ws_home); when it appears on
 * a different monitor its windows move along. Switching slides just that
 * monitor; swipes drag it 1:1. s->ws_current = workspace of the focused
 * monitor (the one under the pointer). */
struct lumen_output *output_showing(struct lumen_server *s, int ws) {
	struct lumen_output *o;
	wl_list_for_each(o, &s->outputs, link) if (o->ws == ws) return o;
	return NULL;
}

/* ------------------------------------------------------------ one long line
 * A monitor's desktops sit side by side as one continuous strip. A window left
 * hanging over the edge of the screen is therefore on the next desktop as well:
 * the part that hangs over shows there, at the opposite edge, and slides along
 * with the strip when you switch. Touch that part and the window belongs to the
 * desktop you touched it on (view_adopt_peek).
 *
 * Only where the strip has room to exist: a monitor with another monitor to its
 * left or right keeps separate desktops (a window hanging over that edge is
 * simply on the other screen). */
#define PEEK_MIN 8      /* px a window must hang over before it counts */

/* per-monitor slide: `from` leaves, `to` arrives (dir: +1 = to the right) */
struct ws_slide { bool active; int from, to, dir; double W, off; };
static struct ws_slide slides[16];
static int slide_slot(struct lumen_output *o) {
	int i = 0;
	struct lumen_output *it;
	wl_list_for_each(it, &o->server->outputs, link) { if (it == o) break; i++; }
	return i % 16;
}

/* what each desktop's tree is doing right now */
static struct {
	struct lumen_output *out;        /* the monitor it is drawn for (NULL: not shown) */
	int peek;                        /* 0, or the edge its windows hang over: -1 left, +1 right */
	struct wlr_scene_node *under;    /* the tree it was last tucked beneath */
} strip[LUMEN_WORKSPACES];

static bool strip_room(struct lumen_output *o) {
	struct lumen_output *it;
	wl_list_for_each(it, &o->server->outputs, link) {
		if (it == o) continue;
		for (int d = -1; d <= 1; d += 2) {
			struct wlr_box b = o->full, x;
			b.x += d * b.width;
			if (wlr_box_intersection(&x, &b, &it->full)) return false;
		}
	}
	return !wlr_box_empty(&o->full);
}

/* the distance between two desktops on this monitor's strip */
static double strip_pitch(struct lumen_output *o) {
	return o->full.width + (strip_room(o) ? 0 : 60);
}

static bool view_hangs_over(struct lumen_view *v, const struct wlr_box *b, int d) {
	if (!v->mapped || v->minimized || v->fullscreen || v->maximized || v->closing) return false;
	if (v->tree->node.parent != v->server->ws_tree[v->workspace]) return false;   /* being carried */
	if (v->geom.y >= b->y + b->height || v->geom.y + v->geom.height <= b->y) return false;
	return d > 0 ? v->geom.x + v->geom.width > b->x + b->width + PEEK_MIN : v->geom.x < b->x - PEEK_MIN;
}

/* desktop `ws` lives on monitor o's box, isn't up anywhere, and has a window
 * hanging over o's edge on side d */
static bool ws_hangs_over(struct lumen_server *s, int ws, struct lumen_output *o, int d) {
	if (ws < 0 || ws >= LUMEN_WORKSPACES || output_showing(s, ws)) return false;
	struct wlr_box h = s->ws_home[ws];
	if (h.x != o->full.x || h.y != o->full.y || h.width != o->full.width || h.height != o->full.height)
		return false;
	struct lumen_view *v;
	wl_list_for_each(v, &s->views, link)
		if (v->workspace == ws && view_hangs_over(v, &o->full, d)) return true;
	return false;
}

/* put every desktop's tree where it belongs: the one each monitor shows (or the
 * two mid-slide), and at each end the neighbour that hangs over, if any */
static void strip_layout(struct lumen_server *s) {
	bool hidden = overview_active();
	struct lumen_output *out[LUMEN_WORKSPACES] = { NULL };
	int px[LUMEN_WORKSPACES] = { 0 }, peek[LUMEN_WORKSPACES] = { 0 };
	struct wlr_scene_node *under[LUMEN_WORKSPACES] = { NULL };
	struct lumen_output *o;
	wl_list_for_each(o, &s->outputs, link) {
		struct ws_slide *sl = &slides[slide_slot(o)];
		if (sl->active && sl->from >= 0 && sl->from < LUMEN_WORKSPACES) {
			out[sl->from] = o;
			px[sl->from] = (int)lround(-sl->off);
			if (sl->to >= 0 && sl->to < LUMEN_WORKSPACES && sl->to != sl->from) {
				out[sl->to] = o;
				px[sl->to] = (int)lround(sl->dir * sl->W - sl->off);
				/* what arrives is in front of what leaves (and of what hangs over from it) */
				under[sl->from] = &s->ws_tree[sl->to]->node;
			}
		} else if (o->ws >= 0 && o->ws < LUMEN_WORKSPACES) {
			out[o->ws] = o;
		}
	}
	wl_list_for_each(o, &s->outputs, link) {
		if (!strip_room(o)) continue;
		struct ws_slide *sl = &slides[slide_slot(o)];
		int W = o->full.width;
		int left = o->ws, right = o->ws;      /* the desktops at each end of what's showing */
		if (sl->active && sl->from >= 0 && sl->from < LUMEN_WORKSPACES) {
			left = right = sl->from;
			if (sl->to >= 0 && sl->to < LUMEN_WORKSPACES && sl->to != sl->from) {
				left = sl->dir > 0 ? sl->from : sl->to;
				right = sl->dir > 0 ? sl->to : sl->from;
			}
		}
		if (left < 0 || left >= LUMEN_WORKSPACES || right < 0 || right >= LUMEN_WORKSPACES) continue;
		int a = left - 1, b = right + 1;
		if (ws_hangs_over(s, a, o, 1) && !out[a]) {
			out[a] = o; peek[a] = 1; px[a] = px[left] - W;
			under[a] = &s->ws_tree[left]->node;
		}
		if (ws_hangs_over(s, b, o, -1) && !out[b]) {
			out[b] = o; peek[b] = -1; px[b] = px[right] + W;
			under[b] = &s->ws_tree[right]->node;
		}
	}
	for (int i = 0; i < LUMEN_WORKSPACES; i++) {
		struct wlr_scene_node *n = &s->ws_tree[i]->node;
		bool on = !hidden && out[i];
		/* windows of the desktop you're on stay in front of what hangs over from next door */
		if (on && under[i] && (strip[i].under != under[i] || !n->enabled))
			wlr_scene_node_place_below(n, under[i]);
		strip[i].under = on ? under[i] : NULL;
		strip[i].out = on ? out[i] : NULL;
		strip[i].peek = on ? peek[i] : 0;
		wlr_scene_node_set_position(n, on ? px[i] : 0, 0);
		wlr_scene_node_set_enabled(n, on);
	}
}

/* show every monitor's workspace (and what hangs over into it), all at rest */
void workspace_strip_sync(struct lumen_server *s) {
	struct lumen_output *o;
	wl_list_for_each(o, &s->outputs, link) {
		anim_cancel(o, 99);
		slides[slide_slot(o)].active = false;
	}
	strip_layout(s);
}

/* windows moved, appeared or went: does anything hang over an edge now? (every frame; cheap) */
void workspace_strip_refresh(struct lumen_server *s) {
	strip_layout(s);
}

/* v is drawn on monitor o: on its desktop, sliding off it, or hanging over into it */
bool view_visible_on(struct lumen_view *v, struct lumen_output *o) {
	if (v->workspace < 0 || v->workspace >= LUMEN_WORKSPACES) return false;
	if (v->workspace == o->ws) return true;
	return strip[v->workspace].out == o && v->tree->node.parent == v->server->ws_tree[v->workspace];
}

/* v shows here only because its desktop hangs over into this one */
bool view_peeking(struct lumen_view *v) {
	return v && v->workspace >= 0 && v->workspace < LUMEN_WORKSPACES && strip[v->workspace].peek &&
		strip[v->workspace].out && v->tree->node.parent == v->server->ws_tree[v->workspace];
}

static bool peek_untouchable(struct lumen_view *v) {
	if (!view_peeking(v)) return false;
	return !view_hangs_over(v, &strip[v->workspace].out->full, strip[v->workspace].peek);
}

static void translate_view(struct lumen_view *v, struct wlr_box from, struct wlr_box to) {
	if (to.width < 100 || to.height < 100) return;   /* a monitor mid-change: leave it be */
	if (v->maximized) {
		v->geom.x += to.x - from.x; v->geom.y += to.y - from.y;
		v->saved.x += to.x - from.x; v->saved.y += to.y - from.y;
		struct lumen_output *o = output_at(v->server, to.x + to.width / 2.0, to.y + to.height / 2.0);
		if (o) { client_set_box(v, o->usable); v->geom = o->usable; }
	} else {
		/* keep the window's place relative to the monitor, and inside it */
		double fx = from.width > 0 ? (v->geom.x - from.x) / (double)from.width : 0.1;
		double fy = from.height > 0 ? (v->geom.y - from.y) / (double)from.height : 0.1;
		int w = v->geom.width < to.width ? v->geom.width : to.width - 40;
		int h = v->geom.height < to.height ? v->geom.height : to.height - 60;
		v->geom.x = to.x + (int)(fx * to.width);
		v->geom.y = to.y + (int)(fy * to.height);
		if (v->geom.x + w > to.x + to.width) v->geom.x = to.x + to.width - w;
		if (v->geom.y + h > to.y + to.height) v->geom.y = to.y + to.height - h;
		if (w != v->geom.width || h != v->geom.height || v->type == VIEW_X11)
			client_set_box(v, (struct wlr_box){ v->geom.x, v->geom.y, w, h });
	}
	place(v);
}

/* the windows of `ws` now belong on monitor `o` */
static void ws_relocate(struct lumen_server *s, int ws, struct lumen_output *o) {
	struct wlr_box from = s->ws_home[ws], to = o->full;
	if (from.width > 0 && from.x == to.x && from.y == to.y && from.width == to.width && from.height == to.height)
		return;
	if (from.width > 0) {
		struct lumen_view *v;
		wl_list_for_each(v, &s->views, link)
			if (v->workspace == ws && v->mapped && !v->fullscreen) translate_view(v, from, to);
	}
	s->ws_home[ws] = to;
}

/* a monitor moved, rotated or changed resolution: its windows follow */
void workspace_output_moved(struct lumen_output *o) {
	struct lumen_server *s = o->server;
	if (o->ws < 0 || o->ws >= LUMEN_WORKSPACES || wlr_box_empty(&o->full)) return;
	if (s->ws_home[o->ws].width > 0) ws_relocate(s, o->ws, o);
	tile_workspace(s, o->ws);
}

static void slide_place(struct lumen_output *o, double off) {
	struct ws_slide *sl = &slides[slide_slot(o)];
	sl->active = true;
	sl->off = off;
	strip_layout(o->server);
}

static void slide_step(struct anim *a, double e) {
	slide_place(a->owner, lerp(a->from[0], a->to[0], e));
}

static void slide_done(struct anim *a) {
	struct lumen_output *o = a->owner;
	struct ws_slide *sl = &slides[slide_slot(o)];
	sl->active = false;
	sl->from = sl->to = -1;
	workspace_strip_sync(o->server);
}

static void animate_switch(struct lumen_output *o, int from, int to, double from_off, double speed) {
	struct lumen_server *s = o->server;
	struct ws_slide *sl = &slides[slide_slot(o)];
	sl->from = from;
	sl->to = to;
	sl->dir = to > from ? 1 : -1;
	sl->W = strip_pitch(o);
	double target = sl->dir * sl->W;
	/* quick off the mark, then a long soft landing (a touch longer than a plain
	 * ease-out, but most of the distance is covered in the first third) */
	double dur = s->cfg.animations ? s->cfg.anim_ms * speed * 1.2 : 1;
	struct anim *a = anim_start(o, 99, dur, EASE_OUT_QUINT, slide_step, slide_done);
	a->from[0] = from_off;
	a->to[0] = target;
	slide_place(o, from_off);
}

static void ws_changed(struct lumen_server *s) {
	wlr_seat_keyboard_notify_clear_focus(s->seat);
	focus_topmost(s);
	ipc_state_changed(s);
}

/* show `ws` on monitor `o` (no animation); used by the overview */
void workspace_assign(struct lumen_server *s, struct lumen_output *o, int ws) {
	if (!o || ws < 0 || ws >= LUMEN_WORKSPACES) return;
	struct lumen_output *other = output_showing(s, ws);
	if (other && other != o) other->ws = o->ws;   /* swap */
	if (other && other != o) ws_relocate(s, other->ws, other);
	o->ws = ws;
	ws_relocate(s, ws, o);
	s->ws_current = ws;
	workspace_strip_sync(s);
	tile_workspace(s, ws);
}

void workspace_switch(struct lumen_server *s, int ws) {
	if (ws < 0 || ws >= LUMEN_WORKSPACES) return;
	if (overview_active()) { overview_set_ws(ws); return; }
	struct lumen_output *o = output_focused(s);
	if (!o) return;
	if (o->ws == ws) { s->ws_current = ws; return; }
	struct lumen_output *other = output_showing(s, ws);
	if (other) {
		/* already up on another monitor: go there */
		wlr_cursor_warp(s->cursor, NULL, other->full.x + other->full.width / 2.0,
			other->full.y + other->full.height / 2.0);
		s->ws_current = ws;
		ws_changed(s);
		return;
	}
	int old = o->ws;
	ws_relocate(s, ws, o);
	o->ws = ws;
	s->ws_current = ws;
	tile_workspace(s, ws);
	animate_switch(o, old, ws, 0, 1.0);
	ws_changed(s);
}

/* ------------------------------------------- finger-tracked desktop switch */
static struct { bool active; struct lumen_output *o; int nb, dir; double off, W; } wd;

void workspace_drag_update(struct lumen_server *s, double total_dx) {
	struct lumen_output *o = wd.active ? wd.o : output_focused(s);
	if (!o) return;
	if (!wd.active) {
		anim_cancel(o, 99);
		workspace_strip_sync(s);
		wd.o = o;
		wd.W = strip_pitch(o);
		wd.active = true;
	}
	double off = -total_dx * 1.3;          /* fingers left → desktop on the right */
	int dir = off >= 0 ? 1 : -1;
	int nb = o->ws + dir;
	if (nb < 0 || nb >= LUMEN_WORKSPACES || (output_showing(s, nb) && output_showing(s, nb) != o)) {
		off *= 0.25;                        /* rubber band */
		nb = -1;
	}
	if (nb >= 0 && nb != wd.nb) ws_relocate(s, nb, o);
	wd.off = off; wd.dir = dir; wd.nb = nb;
	struct ws_slide *sl = &slides[slide_slot(o)];
	sl->from = o->ws; sl->to = nb; sl->dir = dir; sl->W = wd.W;
	slide_place(o, off);
}

void workspace_drag_end(struct lumen_server *s, double vx, bool cancelled) {
	if (!wd.active) return;
	wd.active = false;
	struct lumen_output *o = wd.o;
	bool flick = fabs(vx) > 0.6 && (-vx * wd.off) > 0;
	bool commit = !cancelled && wd.nb >= 0 && (fabs(wd.off) > wd.W * 0.2 || flick);
	struct ws_slide *sl = &slides[slide_slot(o)];
	if (commit) {
		int old = o->ws;
		o->ws = wd.nb;
		s->ws_current = wd.nb;
		tile_workspace(s, wd.nb);
		animate_switch(o, old, wd.nb, wd.off * (wd.dir > 0 ? 1 : 1), 0.6);
		ws_changed(s);
	} else {
		sl->from = o->ws; sl->to = wd.nb;
		sl->active = true;
		struct anim *a = anim_start(o, 99, s->cfg.animations ? s->cfg.anim_ms * 0.7 : 1,
			EASE_OUT_QUINT, slide_step, slide_done);
		a->from[0] = wd.off;
		a->to[0] = 0;
	}
}

/* a monitor is going away (unplugged, switched off): nothing may keep pointing
 * at it — a desktop slide or swipe in flight used to run on freed memory */
void workspace_output_gone(struct lumen_output *o) {
	anim_cancel(o, -1);
	struct ws_slide *sl = &slides[slide_slot(o)];
	sl->active = false;
	sl->from = sl->to = -1;
	if (wd.o == o) { wd.active = false; wd.o = NULL; }
	for (int i = 0; i < LUMEN_WORKSPACES; i++)
		if (strip[i].out == o) { strip[i].out = NULL; strip[i].peek = 0; }
}

/* The part of a window that hangs over from the desktop next door was touched:
 * it is this desktop's window now, exactly where it is on screen (the rest of it
 * hangs over the other way). false = it couldn't be taken over right now. */
bool view_adopt_peek(struct lumen_view *v) {
	if (!view_peeking(v) || X(v)->animating_geom) return false;
	struct lumen_server *s = v->server;
	int old = v->workspace;
	struct lumen_output *o = strip[old].out;
	if (slides[slide_slot(o)].active || o->ws < 0 || o->ws >= LUMEN_WORKSPACES || o->ws == old) return false;
	int dx = s->ws_tree[old]->node.x;
	v->geom.x += dx;
	v->workspace = o->ws;
	wlr_scene_node_reparent(&v->tree->node, s->ws_tree[o->ws]);
	if (v->type == VIEW_X11) client_set_box(v, v->geom);   /* X11 apps place their menus by it */
	place(v);
	tile_workspace(s, old);
	tile_workspace(s, o->ws);
	strip_layout(s);
	overview_views_changed();
	ipc_state_changed(s);
	return true;
}

void view_move_to_workspace(struct lumen_view *v, int ws) {
	if (!v || ws < 0 || ws >= LUMEN_WORKSPACES || ws == v->workspace) return;
	struct lumen_server *s = v->server;
	int old = v->workspace;
	if (s->ws_home[ws].width == 0) s->ws_home[ws] = s->ws_home[old];
	if (!v->fullscreen) translate_view(v, s->ws_home[old], s->ws_home[ws]);
	v->workspace = ws;
	if (!v->fullscreen) wlr_scene_node_reparent(&v->tree->node, s->ws_tree[ws]);
	tile_workspace(s, old);
	tile_workspace(s, ws);
	focus_topmost(s);
	ipc_state_changed(s);
}


/* ------------------------------------------ dragging windows between desktops
 * While a window is being moved it lives directly in the workspace layer (not
 * in any desktop's tree), so it stays under the pointer whatever the desktops
 * do. It belongs to the desktop of the monitor under the pointer: carry it onto
 * the other screen and it joins whatever desktop is up there (desktop 1 on the
 * left, 8 on the right: it becomes an 8 window). Hold it against a screen edge
 * with no monitor beyond and it flies off to the previous / next desktop; the
 * desktop you're looking at stays put. A quick drop at the edge still snaps. */
#define EDGE_DWELL_MS 650
static struct {
	struct wl_event_source *timer;
	struct lumen_view *v;
	int dir;            /* edge being held: -1 left, +1 right, 0 none */
	bool switched;      /* an edge switch happened: no half-screen snap until it leaves */
} ED;

static void drag_set_workspace(struct lumen_view *v, int ws) {
	if (ws == v->workspace || ws < 0 || ws >= LUMEN_WORKSPACES) return;
	int old = v->workspace;
	v->workspace = ws;   /* no translation: it's exactly where the pointer put it */
	tile_workspace(v->server, old);
	ipc_state_changed(v->server);
}

/* the window flew off the edge: it lands on the neighbouring desktop, at the
 * same spot but fully on-screen, without switching what you're looking at */
struct send_off { struct lumen_view *v; int ws; struct wlr_box land; };
static struct send_off SO;

static void send_off_step(struct anim *a, double t) {
	struct lumen_view *v = a->owner;
	v->alpha = 1 - (t < 0 ? 0 : (t > 1 ? 1 : t));
	v->geom.x = (int)lerp(a->from[0], a->to[0], t);
	place(v);
	paint(v);
}

static void send_off_done(struct anim *a) {
	struct lumen_view *v = a->owner;
	if (SO.v != v || !v->mapped) return;
	struct lumen_server *s = v->server;
	int old = v->workspace;
	v->geom.x = SO.land.x;
	v->geom.y = SO.land.y;
	v->workspace = SO.ws;
	wlr_scene_node_reparent(&v->tree->node, s->ws_tree[SO.ws]);
	v->alpha = 1;
	place(v);
	update_decor(v);
	tile_workspace(s, old);
	tile_workspace(s, SO.ws);
	SO.v = NULL;
	focus_topmost(s);
	ipc_state_changed(s);
	char cmd[160];
	snprintf(cmd, sizeof(cmd), "notify-send -a Lumen -i lumen-logo -t 1600 -h int:transient:1 "
		"-h string:x-canonical-private-synchronous:lumen-move 'Moved to Desktop %d'", SO.ws + 1);
	spawn(cmd);
}

static int edge_fire(void *data) {
	(void)data;
	struct lumen_view *v = ED.v;
	struct lumen_server *s = g_server;
	if (!v || s->grabbed != v || s->cursor_mode != CURSOR_MOVE || !ED.dir || overview_active()) return 0;
	struct lumen_output *o = output_at(s, s->cursor->x, s->cursor->y);
	if (!o) return 0;
	int nb = o->ws + ED.dir;
	if (nb < 0 || nb >= LUMEN_WORKSPACES) return 0;
	/* let go of the window: it's on its way */
	snap_cancel(s);
	view_drag_end(v);
	s->grabbed = NULL;
	s->cursor_mode = CURSOR_PASSTHROUGH;
	/* where it lands: same place on that desktop's screen, pulled fully on-screen */
	struct wlr_box home = s->ws_home[nb].width ? s->ws_home[nb] : o->full;
	struct lumen_output *there = output_showing(s, nb);
	struct wlr_box u = there ? there->usable : o->usable;
	if (!there) {   /* that desktop isn't on screen: it lives on this monitor's box */
		u = o->usable;
		u.x += home.x - o->full.x;
		u.y += home.y - o->full.y;
	}
	struct wlr_box land = { v->geom.x - o->full.x + u.x, v->geom.y - o->full.y + u.y, v->geom.width, v->geom.height };
	if (land.x + land.width > u.x + u.width) land.x = u.x + u.width - land.width;
	if (land.x < u.x) land.x = u.x;
	if (land.y + land.height > u.y + u.height) land.y = u.y + u.height - land.height;
	if (land.y < u.y) land.y = u.y;
	SO = (struct send_off){ v, nb, (struct wlr_box){ land.x, land.y, 0, 0 } };
	/* fly off past the edge and fade */
	double to_x = ED.dir < 0 ? o->full.x - v->geom.width - 40 : o->full.x + o->full.width + 40;
	struct anim *a = anim_start(v, A_RESTORE, anim_scaled(260), EASE_IN_OUT_CUBIC,
		send_off_step, send_off_done);
	a->from[0] = v->geom.x;
	a->to[0] = to_x;
	ED.dir = 0;
	return 0;
}

void view_drag_begin(struct lumen_view *v) {
	struct lumen_server *s = v->server;
	if (!ED.timer) ED.timer = wl_event_loop_add_timer(s->loop, edge_fire, NULL);
	ED.v = v;
	ED.dir = 0;
	ED.switched = false;
	if (v->fullscreen) return;
	wlr_scene_node_reparent(&v->tree->node, s->layer[L_WS]);
	wlr_scene_node_raise_to_top(&v->tree->node);
}

/* pointer moved while dragging. true = allow half-screen snapping now */
bool view_drag_motion(struct lumen_view *v) {
	struct lumen_server *s = v->server;
	double x = s->cursor->x, y = s->cursor->y;
	struct lumen_output *o = output_at(s, x, y);
	if (!o) return !ED.switched;
	if (o->ws != v->workspace) drag_set_workspace(v, o->ws);   /* onto another screen */

	int dir = 0;
	if (x <= o->full.x + 1) dir = -1;
	else if (x >= o->full.x + o->full.width - 2) dir = 1;
	/* another monitor beyond that edge: the window just carries over */
	if (dir && wlr_output_layout_output_at(s->output_layout, x + dir * 6, y)) dir = 0;
	if (dir != ED.dir) {
		ED.dir = dir;
		if (ED.timer) wl_event_source_timer_update(ED.timer, dir ? EDGE_DWELL_MS : 0);
	}
	/* after a desktop switch, half-snapping waits until the pointer leaves the edge */
	if (ED.switched && !dir && x > o->full.x + 60 && x < o->full.x + o->full.width - 60)
		ED.switched = false;
	return !ED.switched;
}

/* dropped (or the grab ended): back into its desktop's tree */
void view_drag_end(struct lumen_view *v) {
	struct lumen_server *s = v->server;
	if (ED.timer) wl_event_source_timer_update(ED.timer, 0);
	ED.v = NULL;
	ED.dir = 0;
	ED.switched = false;
	if (!v->mapped || v->fullscreen) return;
	struct lumen_output *o = output_at(s, s->cursor->x, s->cursor->y);
	if (o) drag_set_workspace(v, o->ws);
	wlr_scene_node_reparent(&v->tree->node, s->ws_tree[v->workspace]);
	wlr_scene_node_raise_to_top(&v->tree->node);
	restack_on_top(s, v);
	tile_workspace(s, v->workspace);
	overview_views_changed();
}

/* --------------------------------------------------------- xdg toplevels */
static void place_new(struct lumen_view *v) {
	struct lumen_output *o = output_focused(v->server);
	if (!o) return;
	struct wlr_box u = o->usable;
	/* apps that open (nearly) screen-sized get a normal window instead:
	 * maximising is the user's choice, not the default */
	if (!v->maximized && !v->fullscreen &&
			(v->geom.width > u.width * 0.94 || v->geom.height > u.height * 0.94)) {
		int w = (int)(u.width * 0.72), h = (int)(u.height * 0.80);
		v->geom.width = w;
		v->geom.height = h;
		client_set_box(v, (struct wlr_box){ u.x + (u.width - w) / 2, u.y + (u.height - h) / 2, w, h });
	}
	/* cascade new windows from the centre, like a fresh Finder window */
	static int cascade = 0;
	int x = u.x + (u.width - v->geom.width) / 2 + cascade * 28;
	int y = u.y + (u.height - v->geom.height) / 2 + cascade * 28;
	cascade = (cascade + 1) % 6;
	if (x < u.x) x = u.x;
	if (y < u.y) y = u.y;
	v->geom.x = x; v->geom.y = y;
}

/* client committed a new size: re-lay out content + decorations */
void view_update_content(struct lumen_view *v, struct wlr_box g) {
	if (v->surface_tree) wlr_scene_subsurface_tree_set_clip(&v->surface_tree->node, &g);
	int th = title_h(v);
	/* The window's top-left corner goes at the content origin. wlroots already
	 * moves an xdg surface up and left by its geometry offset
	 * (wlr_scene_xdg_surface_create), so nothing is added for it here. Doing it
	 * a second time put every app with margins around its window (GTK apps:
	 * 12px on each side; Electron: its shadow) that far up and left of its own
	 * frame, glass, shadow and resize edges: Files and Settings lost 11px of
	 * their top and left under square-cornered glass, and Claude sat outside
	 * its titlebar. */
	wlr_scene_node_set_position(&v->content->node, 0, th);
	wlr_scene_node_set_position(&X(v)->popups->node, 0, th);
	v->content_w = g.width; v->content_h = g.height;
	/* hold on to the latest picture: if the app closes itself, it fades from this */
	struct wlr_buffer *b;
	struct wlr_fbox src;
	if (genie_source(v, &b, &src)) {
		if (b != X(v)->last_buf) {
			if (X(v)->last_buf) wlr_buffer_unlock(X(v)->last_buf);
			X(v)->last_buf = wlr_buffer_lock(b);
		}
		X(v)->last_src = src;
	}
	v->geom.width = g.width;
	v->geom.height = g.height + th;
	if (!X(v)->animating_geom) update_decor(v);
	else wlr_scene_node_for_each_buffer(&v->tree->node, set_buffer_alpha, v);
	overview_view_updated(v);
	switcher_view_updated(v);
}

static void deco_apply(struct lumen_view *v);

static void handle_commit(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_view *v = wl_container_of(l, v, commit);
	struct wlr_xdg_surface *base = v->xdg->base;
	if (base->initial_commit) {
		if (v->decoration) {
			wlr_xdg_toplevel_decoration_v1_set_mode(v->decoration,
				WLR_XDG_TOPLEVEL_DECORATION_V1_MODE_SERVER_SIDE);
			deco_apply(v);
		}
		wlr_xdg_toplevel_set_wm_capabilities(v->xdg,
			WLR_XDG_TOPLEVEL_WM_CAPABILITIES_MAXIMIZE |
			WLR_XDG_TOPLEVEL_WM_CAPABILITIES_MINIMIZE |
			WLR_XDG_TOPLEVEL_WM_CAPABILITIES_FULLSCREEN);
		/* let the app pick its size, within the monitor's free area */
		struct lumen_output *o = output_focused(v->server);
		if (o && wl_resource_get_version(v->xdg->resource) >= 4)
			wlr_xdg_toplevel_set_bounds(v->xdg, o->usable.width, o->usable.height - TITLEBAR_H);
		wlr_xdg_toplevel_set_size(v->xdg, 0, 0);
		return;
	}
	view_update_content(v, client_geometry(v));
}

void view_handle_map(struct lumen_view *v) {
	struct lumen_server *s = v->server;
	v->mapped = true;
	v->workspace = s->ws_current;
	wlr_scene_node_reparent(&v->tree->node, s->ws_tree[v->workspace]);
	struct wlr_box g = client_geometry(v);
	int th = title_h(v);
	v->geom.width = g.width; v->geom.height = g.height + th;
	bool placed = false;
#if WLR_HAS_XWAYLAND
	/* X11 dialogs usually position themselves relative to their parent */
	if (v->type == VIEW_X11 && v->xsurf && (v->xsurf->x || v->xsurf->y)) {
		v->geom.x = v->xsurf->x;
		v->geom.y = v->xsurf->y - th;
		placed = true;
	}
#endif
	if (!placed) place_new(v);
	v->tile_order = ++s->next_view_id;
	if (v->type == VIEW_X11) client_set_box(v, v->geom);
	view_update_content(v, g);
	wlr_scene_node_set_enabled(&v->tree->node, true);

	v->ftl = wlr_foreign_toplevel_handle_v1_create(s->ftl_mgr);
	if (v->ftl) {
		wlr_foreign_toplevel_handle_v1_set_title(v->ftl, view_title(v));
		wlr_foreign_toplevel_handle_v1_set_app_id(v->ftl, view_app_id(v));
		struct lumen_output *o = output_focused(s);
		if (o) wlr_foreign_toplevel_handle_v1_output_enter(v->ftl, o->wlr_output);
		wl_signal_add(&v->ftl->events.request_activate, &v->ftl_activate);
		wl_signal_add(&v->ftl->events.request_close, &v->ftl_close);
		wl_signal_add(&v->ftl->events.request_minimize, &v->ftl_minimize);
		wl_signal_add(&v->ftl->events.request_maximize, &v->ftl_maximize);
	}

	/* genie out of the taskbar icon (plain fade-and-rise when tiling moves it
	 * around right away, or there's nothing to show yet) */
	bool genie = false;
	if (!s->cfg.tiling && !v->fullscreen) {
		v->alpha = 1;
		update_decor(v);
		wlr_scene_node_set_enabled(&v->tree->node, false);
		genie = genie_run(v, true, genie_shown);
		if (!genie) wlr_scene_node_set_enabled(&v->tree->node, true);
	}
	if (!genie) {
		v->alpha = 0;
		update_decor(v);
		struct anim *a = anim_start(v, A_OPEN, s->cfg.animations ? s->cfg.anim_ms * 1.2 : 1,
			EASE_SPRING, open_step, NULL);
		a->from[0] = 34;
	}
	focus_view(v);
	tile_workspace(s, v->workspace);
	overview_views_changed();
	switcher_views_changed();
	ipc_state_changed(s);
}

static void handle_map(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_view *v = wl_container_of(l, v, map);
	view_handle_map(v);
}

void view_handle_unmap(struct lumen_view *v) {
	struct lumen_server *s = v->server;
	struct wlr_surface *surf = view_surface(v);
	/* fade out what was last on screen (apps closing themselves vanish otherwise) */
	if (!genie_active(v)) genie_close_ghost(v, X(v)->last_buf, X(v)->last_src);
	if (X(v)->last_buf) { wlr_buffer_unlock(X(v)->last_buf); X(v)->last_buf = NULL; }
	v->mapped = false;
	v->closing = false;
	anim_cancel(v, -1);
	X(v)->focus_k = X(v)->focus_to = 0;
	genie_cancel(v);
	wlr_scene_node_set_enabled(&v->tree->node, false);
	if (s->grabbed == v) {
		if (s->cursor_mode == CURSOR_MOVE) view_drag_end(v);
		s->grabbed = NULL; s->cursor_mode = CURSOR_PASSTHROUGH;
	}
	if (s->last_click_view == v) s->last_click_view = NULL;
	pointer_forget_view(v);
	if (v->ftl) {
		wl_list_remove(&v->ftl_activate.link);
		wl_list_remove(&v->ftl_close.link);
		wl_list_remove(&v->ftl_minimize.link);
		wl_list_remove(&v->ftl_maximize.link);
		wlr_foreign_toplevel_handle_v1_destroy(v->ftl);
		v->ftl = NULL;
	}
	if (s->seat->keyboard_state.focused_surface == surf ||
			!s->seat->keyboard_state.focused_surface)
		focus_topmost(s);
	tile_workspace(s, v->workspace);
	overview_views_changed();
	switcher_views_changed();
	ipc_state_changed(s);
}

static void handle_unmap(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_view *v = wl_container_of(l, v, unmap);
	view_handle_unmap(v);
}

void view_destroy(struct lumen_view *v) {
	anim_cancel(v, -1);
	genie_cancel(v);
	if (X(v)->last_buf) { wlr_buffer_unlock(X(v)->last_buf); X(v)->last_buf = NULL; }
	pointer_forget_view(v);
	wl_list_remove(&v->link);
	wlr_scene_node_destroy(&v->tree->node);
	free(v);
	ipc_state_changed(g_server);
}

static void handle_destroy(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_view *v = wl_container_of(l, v, destroy);
	wl_list_remove(&v->map.link);
	wl_list_remove(&v->unmap.link);
	wl_list_remove(&v->commit.link);
	wl_list_remove(&v->destroy.link);
	wl_list_remove(&v->request_move.link);
	wl_list_remove(&v->request_resize.link);
	wl_list_remove(&v->request_maximize.link);
	wl_list_remove(&v->request_fullscreen.link);
	wl_list_remove(&v->request_minimize.link);
	wl_list_remove(&v->set_title.link);
	wl_list_remove(&v->set_app_id.link);
	view_destroy(v);
}

static void begin_grab(struct lumen_view *v, enum cursor_mode mode, uint32_t edges) {
	struct lumen_server *s = v->server;
	if (v->maximized && mode == CURSOR_MOVE) {
		/* dragging a maximised window "tears" it off at the cursor, like macOS */
		double rel = (s->cursor->x - v->geom.x) / (double)v->geom.width;
		v->maximized = false;
		client_set_maximized(v, false);
		struct wlr_box to = v->saved;
		to.x = (int)(s->cursor->x - rel * to.width);
		to.y = (int)s->cursor->y - TITLEBAR_H / 2;
		animate_to(v, to);
	}
	if (v->maximized || v->fullscreen) return;
	s->grabbed = v;
	s->cursor_mode = mode;
	if (mode == CURSOR_MOVE) {
		s->grab_x = s->cursor->x - v->geom.x;
		s->grab_y = s->cursor->y - v->geom.y;
		view_drag_begin(v);
	} else {
		s->grab_box = v->geom;
		s->grab_x = s->cursor->x;
		s->grab_y = s->cursor->y;
		s->resize_edges = edges;
	}
}

static void handle_request_move(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_view *v = wl_container_of(l, v, request_move);
	begin_grab(v, CURSOR_MOVE, 0);
}

static void handle_request_resize(struct wl_listener *l, void *data) {
	struct wlr_xdg_toplevel_resize_event *e = data;
	struct lumen_view *v = wl_container_of(l, v, request_resize);
	begin_grab(v, CURSOR_RESIZE, e->edges);
}

void view_begin_grab(struct lumen_view *v, enum cursor_mode mode, uint32_t edges) {
	begin_grab(v, mode, edges);
}

static void handle_request_maximize(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_view *v = wl_container_of(l, v, request_maximize);
	if (!v->xdg->base->initialized) return;
	if (v->xdg->requested.maximized != v->maximized) view_toggle_maximize(v);
	else wlr_xdg_surface_schedule_configure(v->xdg->base);
}

static void handle_request_fullscreen(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_view *v = wl_container_of(l, v, request_fullscreen);
	if (!v->xdg->base->initialized) return;
	if (v->mapped) view_set_fullscreen(v, v->xdg->requested.fullscreen);
	else wlr_xdg_surface_schedule_configure(v->xdg->base);
}

static void handle_request_minimize(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_view *v = wl_container_of(l, v, request_minimize);
	/* a fullscreen app minimising itself right after losing focus (games'
	 * auto-iconify): ignore, so Alt+Tab to another monitor leaves it be */
	if (v->fullscreen && focused_view(v->server) != v) return;
	if (v->mapped) view_set_minimized(v, true);
}

void view_title_changed(struct lumen_view *v) {
	if (v->ftl) wlr_foreign_toplevel_handle_v1_set_title(v->ftl, view_title(v));
	if (v->mapped) update_decor(v);
	ipc_state_changed(v->server);
}

void view_app_id_changed(struct lumen_view *v) {
	if (v->ftl) wlr_foreign_toplevel_handle_v1_set_app_id(v->ftl, view_app_id(v));
	ipc_state_changed(v->server);
}

/* X11 can toggle its decorations (Motif hints) at any time */
void view_set_ssd(struct lumen_view *v, bool ssd) {
	if (v->ssd == ssd) return;
	v->ssd = ssd;
	if (ssd && wlr_scene_blur_get_transparency_mask_source(v->blur)) {
		/* drop the CSD alpha mask: recreate the blur node in the same slot
		 * (scenefx can't clear a mask source by passing NULL) */
		struct wlr_scene_blur *nb = wlr_scene_blur_create(v->tree, 0, 0);
		wlr_scene_node_place_above(&nb->node, &v->blur->node);
		wlr_scene_node_destroy(&v->blur->node);
		v->blur = nb;
	}
	v->last_title[0] = 0;
	if (v->mapped) view_update_content(v, client_geometry(v));
}

static void handle_set_title(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_view *v = wl_container_of(l, v, set_title);
	view_title_changed(v);
}

static void handle_set_app_id(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_view *v = wl_container_of(l, v, set_app_id);
	view_app_id_changed(v);
}

/* foreign-toplevel requests (external taskbars / docks) */
static void ftl_activate(struct wl_listener *l, void *d) { (void)d;
	struct lumen_view *v = wl_container_of(l, v, ftl_activate); focus_view(v); }
static void ftl_close(struct wl_listener *l, void *d) { (void)d;
	struct lumen_view *v = wl_container_of(l, v, ftl_close); view_close(v); }
static void ftl_minimize(struct wl_listener *l, void *d) {
	struct wlr_foreign_toplevel_handle_v1_minimized_event *e = d;
	struct lumen_view *v = wl_container_of(l, v, ftl_minimize);
	view_set_minimized(v, e->minimized); }
static void ftl_maximize(struct wl_listener *l, void *d) {
	struct wlr_foreign_toplevel_handle_v1_maximized_event *e = d;
	struct lumen_view *v = wl_container_of(l, v, ftl_maximize);
	if (e->maximized != v->maximized) view_toggle_maximize(v); }

/* build the glass frame shared by Wayland and X11 windows */
struct lumen_view *view_create(struct lumen_server *s, enum view_type type) {
	struct lumen_view *v = calloc(1, sizeof(*v) + sizeof(struct view_extra));
	struct lumen_config *cfg = &s->cfg;
	v->server = s;
	v->type = type;
	v->id = ++s->next_view_id;
	v->alpha = 1;
	v->ssd = false;    /* becomes true once the client agrees to server-side deco */

	v->tree = wlr_scene_tree_create(s->ws_tree[s->ws_current]);
	v->tree->node.data = v;
	wlr_scene_node_set_enabled(&v->tree->node, false);

	v->shadow = wlr_scene_shadow_create(v->tree, 0, 0, cfg->corner_radius,
		cfg->shadow_sigma, cfg->shadow_color);
	X(v)->edge = wlr_scene_rect_create(v->tree, 0, 0, (float[4]){ 0, 0, 0, 0 });
	v->blur = wlr_scene_blur_create(v->tree, 0, 0);
#ifdef LUMEN_HAVE_BLUR_THRESHOLD
	wlr_scene_blur_set_ignore_alpha_threshold(v->blur, 0.2f);  /* CSD shadows stay crisp */
#endif
	v->frame = wlr_scene_rect_create(v->tree, 0, 0, cfg->glass_tint);
	v->frame->accepts_input = true;

	v->content = wlr_scene_tree_create(v->tree);   /* client surfaces go in here */

	v->titlebar = wlr_scene_tree_create(v->tree);
	v->hover_part = -1;
	for (int i = 0; i < 3; i++) {
		v->lights[i] = wlr_scene_rect_create(v->titlebar, LIGHT, LIGHT, LIGHT_COLORS[i]);
		wlr_scene_rect_set_corner_radius(v->lights[i], LIGHT / 2);
	}
	v->title = wlr_scene_buffer_create(v->titlebar, NULL);
	wlr_scene_node_set_enabled(&v->titlebar->node, false);

	X(v)->rim = wlr_scene_rect_create(v->tree, 0, 0, (float[4]){ 0.16f, 0.16f, 0.16f, 0.16f });
	X(v)->rim->accepts_input = false;
	X(v)->popups = wlr_scene_tree_create(v->tree);

	v->ftl_activate.notify = ftl_activate;
	v->ftl_close.notify = ftl_close;
	v->ftl_minimize.notify = ftl_minimize;
	v->ftl_maximize.notify = ftl_maximize;
	wl_list_insert(&s->views, &v->link);
	return v;
}

static void new_toplevel(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, new_xdg_toplevel);
	struct wlr_xdg_toplevel *xdg = data;
	struct lumen_view *v = view_create(s, VIEW_XDG);
	v->xdg = xdg;
	v->surface_tree = wlr_scene_xdg_surface_create(v->content, xdg->base);
	xdg->base->data = v->surface_tree;

	v->map.notify = handle_map;
	wl_signal_add(&xdg->base->surface->events.map, &v->map);
	v->unmap.notify = handle_unmap;
	wl_signal_add(&xdg->base->surface->events.unmap, &v->unmap);
	v->commit.notify = handle_commit;
	wl_signal_add(&xdg->base->surface->events.commit, &v->commit);
	v->destroy.notify = handle_destroy;
	wl_signal_add(&xdg->events.destroy, &v->destroy);
	v->request_move.notify = handle_request_move;
	wl_signal_add(&xdg->events.request_move, &v->request_move);
	v->request_resize.notify = handle_request_resize;
	wl_signal_add(&xdg->events.request_resize, &v->request_resize);
	v->request_maximize.notify = handle_request_maximize;
	wl_signal_add(&xdg->events.request_maximize, &v->request_maximize);
	v->request_fullscreen.notify = handle_request_fullscreen;
	wl_signal_add(&xdg->events.request_fullscreen, &v->request_fullscreen);
	v->request_minimize.notify = handle_request_minimize;
	wl_signal_add(&xdg->events.request_minimize, &v->request_minimize);
	v->set_title.notify = handle_set_title;
	wl_signal_add(&xdg->events.set_title, &v->set_title);
	v->set_app_id.notify = handle_set_app_id;
	wl_signal_add(&xdg->events.set_app_id, &v->set_app_id);
}

/* ------------------------------------------------------------ decorations */
static void deco_apply(struct lumen_view *v) {
	/* Lumen always answers "server side", so any window that negotiates
	 * decorations gets our titlebar. (Reading the mode back here was a race:
	 * kitty asks before its first commit, when nothing has been sent yet, and
	 * ended up with no titlebar from either side.) */
	bool ssd = v->decoration != NULL;
	if (ssd == v->ssd) return;
	v->ssd = ssd;
	v->last_title[0] = 0;
	if (v->mapped) update_decor(v);
}

static void deco_request_mode(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_view *v = wl_container_of(l, v, deco_request_mode);
	if (v->xdg->base->initialized)
		wlr_xdg_toplevel_decoration_v1_set_mode(v->decoration,
			WLR_XDG_TOPLEVEL_DECORATION_V1_MODE_SERVER_SIDE);
	deco_apply(v);
}

static void deco_destroy(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_view *v = wl_container_of(l, v, deco_destroy);
	wl_list_remove(&v->deco_request_mode.link);
	wl_list_remove(&v->deco_destroy.link);
	v->decoration = NULL;
	v->ssd = false;
}

static void new_decoration(struct wl_listener *l, void *data) {
	(void)l;
	struct wlr_xdg_toplevel_decoration_v1 *d = data;
	struct lumen_view *v;
	wl_list_for_each(v, &g_server->views, link) {
		if (v->type != VIEW_XDG || v->xdg != d->toplevel) continue;
		v->decoration = d;
		v->deco_request_mode.notify = deco_request_mode;
		wl_signal_add(&d->events.request_mode, &v->deco_request_mode);
		v->deco_destroy.notify = deco_destroy;
		wl_signal_add(&d->events.destroy, &v->deco_destroy);
		v->ssd = true;
		if (v->xdg->base->initialized)
			wlr_xdg_toplevel_decoration_v1_set_mode(d,
				WLR_XDG_TOPLEVEL_DECORATION_V1_MODE_SERVER_SIDE);
		return;
	}
}

/* ------------------------------------------------------------------ popups */
struct popup { struct wlr_xdg_popup *p; struct wl_listener commit, destroy, reposition; };

/* keep menus on-screen: unconstrain against the output under the parent.
 * An app's menus also stay clear of the bar and the dock (they open under
 * those, where their last rows couldn't be reached); the shell's own menus
 * may use the whole screen. */
static void popup_unconstrain(struct wlr_xdg_popup *xp) {
	struct lumen_output *o = output_focused(g_server);
	struct wlr_scene_tree *t = xp->base->data;
	if (!o || !t) return;
	int lx, ly;
	wlr_scene_node_coords(&t->node.parent->node, &lx, &ly);
	struct wlr_box box = o->full;
	struct wlr_xdg_popup *top = xp;
	struct wlr_xdg_surface *ps;
	while (top->parent && (ps = wlr_xdg_surface_try_from_wlr_surface(top->parent))) {
		if (ps->role == WLR_XDG_SURFACE_ROLE_TOPLEVEL) {
			if (o->usable.width > 0 && o->usable.height > 0) box = o->usable;
			break;
		}
		if (ps->role != WLR_XDG_SURFACE_ROLE_POPUP || !ps->popup) break;
		top = ps->popup;
	}
	box.x -= lx; box.y -= ly;
	wlr_xdg_popup_unconstrain_from_box(xp, &box);
}

static void popup_commit(struct wl_listener *l, void *data) {
	(void)data;
	struct popup *p = wl_container_of(l, p, commit);
	if (!p->p->base->initial_commit) return;
	popup_unconstrain(p->p);
	wlr_xdg_surface_schedule_configure(p->p->base);
}

/* the app asked for another size or place (a menu that grew): fit it again */
static void popup_reposition(struct wl_listener *l, void *data) {
	(void)data;
	struct popup *p = wl_container_of(l, p, reposition);
	popup_unconstrain(p->p);
}

static void popup_destroy(struct wl_listener *l, void *data) {
	(void)data;
	struct popup *p = wl_container_of(l, p, destroy);
	wl_list_remove(&p->commit.link);
	wl_list_remove(&p->destroy.link);
	wl_list_remove(&p->reposition.link);
	free(p);
}

/* add an xdg_popup to the scene under parent_tree and keep it configured */
void popup_attach(struct wlr_xdg_popup *xp, struct wlr_scene_tree *parent_tree) {
	if (!parent_tree || xp->base->data) return;
	struct popup *p = calloc(1, sizeof(*p));
	p->p = xp;
	xp->base->data = wlr_scene_xdg_surface_create(parent_tree, xp->base);
	p->commit.notify = popup_commit;
	wl_signal_add(&xp->base->surface->events.commit, &p->commit);
	p->destroy.notify = popup_destroy;
	wl_signal_add(&xp->events.destroy, &p->destroy);
	p->reposition.notify = popup_reposition;
	wl_signal_add(&xp->events.reposition, &p->reposition);
	/* attached after its initial commit (layer popups can be): configure now */
	if (xp->base->initialized && !xp->base->configured)
		wlr_xdg_surface_schedule_configure(xp->base);
}

static void new_popup(struct wl_listener *l, void *data) {
	struct wlr_xdg_popup *xp = data;
	/* popups of layer surfaces arrive with no parent yet; layers.c picks them
	 * up from wlr_layer_surface_v1.events.new_popup once get_popup is called */
	if (!xp->parent) return;
	struct wlr_xdg_surface *parent = wlr_xdg_surface_try_from_wlr_surface(xp->parent);
	if (!parent) return;
	struct wlr_scene_tree *tree = parent->data;
	if (parent->role == WLR_XDG_SURFACE_ROLE_TOPLEVEL) {
		/* A window's menus go in a tree of their own, beside its surface, not
		 * inside it: the window's surface is clipped to the window's size, and
		 * that clip reaches everything underneath it — a menu taller or wider
		 * than its (small) window was cut off at the window's size. */
		struct lumen_server *s = wl_container_of(l, s, new_xdg_popup);
		struct lumen_view *v;
		wl_list_for_each(v, &s->views, link)
			if (v->type == VIEW_XDG && v->xdg && v->xdg->base == parent) { tree = X(v)->popups; break; }
	}
	popup_attach(xp, tree);
}

static void title_tone_idle(void *data) {
	struct lumen_view *v = g_server ? view_by_id(g_server, (uint32_t)(uintptr_t)data) : NULL;
	if (!v || !v->mapped) return;
	v->last_title[0] = 0;
	update_decor(v);
}

/* liquid.c, while drawing: this window's titlebar turned out dark (1) or pale (2).
 * The title is redrawn to suit, after the frame. */
void view_title_tone(struct lumen_view *v, int tone) {
	if (!v || X(v)->title_tone == tone) return;
	X(v)->title_tone = tone;
	wl_event_loop_add_idle(v->server->loop, title_tone_idle, (void *)(uintptr_t)v->id);
}

void views_refresh_style(struct lumen_server *s) {
	struct lumen_view *v;
	wl_list_for_each(v, &s->views, link) if (v->mapped) {
		v->last_title[0] = 0;   /* drawn again: its colour may have changed (dark ⇄ light) */
		update_decor(v);
	}
}

void views_init(struct lumen_server *s) {
	wl_list_init(&s->views);
	s->xdg_shell = wlr_xdg_shell_create(s->display, 6);
	s->new_xdg_toplevel.notify = new_toplevel;
	wl_signal_add(&s->xdg_shell->events.new_toplevel, &s->new_xdg_toplevel);
	s->new_xdg_popup.notify = new_popup;
	wl_signal_add(&s->xdg_shell->events.new_popup, &s->new_xdg_popup);

	s->deco_mgr = wlr_xdg_decoration_manager_v1_create(s->display);
	s->new_decoration.notify = new_decoration;
	wl_signal_add(&s->deco_mgr->events.new_toplevel_decoration, &s->new_decoration);
	s->ftl_mgr = wlr_foreign_toplevel_manager_v1_create(s->display);
}

void view_animate_to(struct lumen_view *v, struct wlr_box to) {
	if (v->maximized) {
		v->maximized = false;
		client_set_maximized(v, false);
		if (v->ftl) wlr_foreign_toplevel_handle_v1_set_maximized(v->ftl, false);
	}
	animate_to(v, to);
}
