/* XWayland: X11 apps get the same glass frames, traffic lights and animations
 * as Wayland apps. Override-redirect windows (menus, tooltips, drag icons)
 * float undecorated above everything at the position X asks for. */
#include <stdlib.h>
#include <wlr/util/log.h>
#include "lumen.h"

#if WLR_HAS_XWAYLAND
#include <wlr/xcursor.h>

struct xwl {
	struct lumen_server *s;
	struct wlr_xwayland_surface *xs;
	struct lumen_view *view;            /* managed window while mapped */
	struct wlr_scene_tree *or_tree;     /* override-redirect window while mapped */
	bool associated;
	struct wl_listener destroy, associate, dissociate, map, unmap, commit;
	struct wl_listener request_configure, request_activate, request_move, request_resize,
		request_maximize, request_fullscreen, request_minimize, request_close;
	struct wl_listener set_title, set_class, set_geometry, set_decorations;
};

static bool wants_ssd(struct wlr_xwayland_surface *xs) {
	/* apps that draw their own titlebar (Chrome, Steam, Spotify…) clear the
	 * Motif decorations; everyone else gets our glass titlebar */
	return xs->decorations == WLR_XWAYLAND_SURFACE_DECORATIONS_ALL;
}

/* ------------------------------------------------------------- surface life */
static void x_commit(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, commit);
	struct wlr_surface *sf = x->xs->surface;
	if (x->view && x->view->mapped)
		view_update_content(x->view, (struct wlr_box){ 0, 0, sf->current.width, sf->current.height });
	else if (x->or_tree)
		wlr_scene_node_set_position(&x->or_tree->node, x->xs->x, x->xs->y);
}

static void x_map(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, map);
	struct lumen_server *s = x->s;
	struct wlr_xwayland_surface *xs = x->xs;

	if (xs->override_redirect) {
		x->or_tree = wlr_scene_tree_create(s->layer[L_OVERLAY]);
		wlr_scene_subsurface_tree_create(x->or_tree, xs->surface);
		wlr_scene_node_set_position(&x->or_tree->node, xs->x, xs->y);
		if (wlr_xwayland_surface_override_redirect_wants_focus(xs)) {
			seat_focus(s, xs->surface);
		}
		pointer_refocus(s);
		return;
	}

	struct lumen_view *v = view_create(s, VIEW_X11);
	v->xsurf = xs;
	v->ssd = wants_ssd(xs);
	v->surface_tree = wlr_scene_subsurface_tree_create(v->content, xs->surface);
	x->view = v;
	view_handle_map(v);
}

static void x_unmap(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, unmap);
	if (x->or_tree) {
		wlr_scene_node_destroy(&x->or_tree->node);
		x->or_tree = NULL;
		struct lumen_view *f = focused_view(x->s);
		if (x->s->seat->keyboard_state.focused_surface == x->xs->surface) {
			if (f) focus_view(f);
			else wlr_seat_keyboard_notify_clear_focus(x->s->seat);
		}
		pointer_refocus(x->s);
		return;
	}
	if (x->view) {
		view_handle_unmap(x->view);
		view_destroy(x->view);
		x->view = NULL;
	}
}

static void x_associate(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, associate);
	struct wlr_surface *sf = x->xs->surface;
	x->map.notify = x_map;
	wl_signal_add(&sf->events.map, &x->map);
	x->unmap.notify = x_unmap;
	wl_signal_add(&sf->events.unmap, &x->unmap);
	x->commit.notify = x_commit;
	wl_signal_add(&sf->events.commit, &x->commit);
	x->associated = true;
}

static void x_dissociate(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, dissociate);
	if (!x->associated) return;
	wl_list_remove(&x->map.link);
	wl_list_remove(&x->unmap.link);
	wl_list_remove(&x->commit.link);
	x->associated = false;
}

/* ---------------------------------------------------------------- requests */
static void x_request_configure(struct wl_listener *l, void *data) {
	struct xwl *x = wl_container_of(l, x, request_configure);
	struct wlr_xwayland_surface_configure_event *e = data;
	struct lumen_view *v = x->view;
	if (!v || !v->mapped) {
		/* not managed yet (or a menu): grant exactly what was asked */
		wlr_xwayland_surface_configure(x->xs, e->x, e->y, e->width, e->height);
		if (x->or_tree) wlr_scene_node_set_position(&x->or_tree->node, e->x, e->y);
		return;
	}
	if (v->maximized || v->fullscreen) {   /* we own the geometry: re-assert it */
		wlr_xwayland_surface_configure(x->xs, v->geom.x, v->geom.y + (v->ssd ? TITLEBAR_H : 0),
			v->content_w, v->content_h);
		return;
	}
	int th = v->ssd ? TITLEBAR_H : 0;
	view_resize_to(v, (struct wlr_box){ e->x, e->y - th, e->width, e->height + th });
}

static void x_request_activate(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, request_activate);
	if (x->view) focus_view(x->view);
}

static void x_request_move(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, request_move);
	if (x->view) view_begin_grab(x->view, CURSOR_MOVE, 0);
}

static void x_request_resize(struct wl_listener *l, void *data) {
	struct xwl *x = wl_container_of(l, x, request_resize);
	struct wlr_xwayland_resize_event *e = data;
	if (x->view) view_begin_grab(x->view, CURSOR_RESIZE, e->edges);
}

static void x_request_maximize(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, request_maximize);
	bool want = x->xs->maximized_horz && x->xs->maximized_vert;
	if (x->view && x->view->mapped && want != x->view->maximized) view_toggle_maximize(x->view);
}

static void x_request_fullscreen(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, request_fullscreen);
	if (x->view && x->view->mapped) view_set_fullscreen(x->view, x->xs->fullscreen);
}

static void x_request_minimize(struct wl_listener *l, void *data) {
	struct xwl *x = wl_container_of(l, x, request_minimize);
	struct wlr_xwayland_minimize_event *e = data;
	/* fullscreen games minimise themselves when they lose focus (GLFW/SDL
	 * "auto iconify"): on a desktop with several monitors that's never wanted */
	if (x->view && x->view->mapped && e->minimize && x->view->fullscreen &&
			focused_view(x->view->server) != x->view) return;
	if (x->view && x->view->mapped) view_set_minimized(x->view, e->minimize);
}

static void x_request_close(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, request_close);
	wlr_xwayland_surface_close(x->xs);
}

static void x_set_title(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, set_title);
	if (x->view) view_title_changed(x->view);
}

static void x_set_class(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, set_class);
	if (x->view) view_app_id_changed(x->view);
}

static void x_set_geometry(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, set_geometry);
	if (x->or_tree) wlr_scene_node_set_position(&x->or_tree->node, x->xs->x, x->xs->y);
}

static void x_set_decorations(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, set_decorations);
	if (x->view) view_set_ssd(x->view, wants_ssd(x->xs));
}

static void x_destroy(struct wl_listener *l, void *data) {
	(void)data;
	struct xwl *x = wl_container_of(l, x, destroy);
	if (x->view) {  /* destroyed while mapped */
		if (x->view->mapped) view_handle_unmap(x->view);
		view_destroy(x->view);
	}
	if (x->or_tree) wlr_scene_node_destroy(&x->or_tree->node);
	if (x->associated) {
		wl_list_remove(&x->map.link);
		wl_list_remove(&x->unmap.link);
		wl_list_remove(&x->commit.link);
	}
	struct wl_listener *ls[] = { &x->destroy, &x->associate, &x->dissociate,
		&x->request_configure, &x->request_activate, &x->request_move, &x->request_resize,
		&x->request_maximize, &x->request_fullscreen, &x->request_minimize, &x->request_close,
		&x->set_title, &x->set_class, &x->set_geometry, &x->set_decorations };
	for (size_t i = 0; i < sizeof(ls) / sizeof(ls[0]); i++) wl_list_remove(&ls[i]->link);
	free(x);
}

static void new_xsurface(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, xwayland_new_surface);
	struct wlr_xwayland_surface *xs = data;
	struct xwl *x = calloc(1, sizeof(*x));
	x->s = s;
	x->xs = xs;
	xs->data = x;
#define LISTEN(sig, fn) do { x->sig.notify = fn; wl_signal_add(&xs->events.sig, &x->sig); } while (0)
	LISTEN(destroy, x_destroy);
	LISTEN(associate, x_associate);
	LISTEN(dissociate, x_dissociate);
	LISTEN(request_configure, x_request_configure);
	LISTEN(request_activate, x_request_activate);
	LISTEN(request_move, x_request_move);
	LISTEN(request_resize, x_request_resize);
	LISTEN(request_maximize, x_request_maximize);
	LISTEN(request_fullscreen, x_request_fullscreen);
	LISTEN(request_minimize, x_request_minimize);
	LISTEN(request_close, x_request_close);
	LISTEN(set_title, x_set_title);
	LISTEN(set_class, x_set_class);
	LISTEN(set_geometry, x_set_geometry);
	LISTEN(set_decorations, x_set_decorations);
#undef LISTEN
}

static void xwayland_ready(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_server *s = wl_container_of(l, s, xwayland_ready);
	wlr_xwayland_set_seat(s->xwayland, s->seat);
	/* give X11 apps the same cursor theme as everything else */
	if (wlr_xcursor_manager_load(s->cursor_mgr, 1)) {
		struct wlr_xcursor *xc = wlr_xcursor_manager_get_xcursor(s->cursor_mgr, "default", 1);
		if (xc && xc->image_count > 0) {
			struct wlr_xcursor_image *img = xc->images[0];
			wlr_xwayland_set_cursor(s->xwayland, wlr_xcursor_image_get_buffer(img),
				img->hotspot_x, img->hotspot_y);
		}
	}
	wlr_log(WLR_INFO, "Xwayland ready on DISPLAY=%s", s->xwayland->display_name);
}

void xwayland_init(struct lumen_server *s) {
	if (!s->cfg.xwayland) return;
	/* started right away (not lazily on first connect): X11 apps such as Steam,
	 * Tk/IDLE and game launchers then find a running server, and a server that
	 * can't start shows up in the session log at login instead of as
	 * "Unable to open a connection to X" in some app later */
	s->xwayland = wlr_xwayland_create(s->display, s->compositor, false);
	if (!s->xwayland) {
		wlr_log(WLR_ERROR, "Xwayland unavailable (is xorg-xwayland installed?); X11 apps disabled");
		return;
	}
	s->xwayland_ready.notify = xwayland_ready;
	wl_signal_add(&s->xwayland->events.ready, &s->xwayland_ready);
	s->xwayland_new_surface.notify = new_xsurface;
	wl_signal_add(&s->xwayland->events.new_surface, &s->xwayland_new_surface);
	setenv("DISPLAY", s->xwayland->display_name, 1);
}

void xwayland_finish(struct lumen_server *s) {
	if (!s->xwayland) return;
	wl_list_remove(&s->xwayland_ready.link);
	wl_list_remove(&s->xwayland_new_surface.link);
	wlr_xwayland_destroy(s->xwayland);
	s->xwayland = NULL;
}

#else  /* wlroots built without Xwayland */
void xwayland_init(struct lumen_server *s) {
	if (s->cfg.xwayland)
		wlr_log(WLR_INFO, "wlroots was built without Xwayland; X11 apps disabled");
}
void xwayland_finish(struct lumen_server *s) { (void)s; }
#endif
