/* Liquid Glass (glass_style = liquid).
 *
 * Glass items are the shell's panes (the shell sends their exact shapes:
 * "glass NAMESPACE  x y w h  r_tl r_tr r_br r_bl  b_top b_right b_bottom b_left
 *  shadow frost …", surface-local, -1 = full width/height) and app windows with
 * see-through backgrounds (kitty with background_opacity, …), plus every
 * server-decorated titlebar.
 *
 * Each frame:
 *   1. the scene renders with every glass item made invisible (opacity 0, so no
 *      surface enter/leave churn) — leaving only what is BEHIND the glass;
 *   2. bottom → top, for each item: capture what is under it from the frame so
 *      far (so lower glass shows through upper glass), draw the lens + drop
 *      shadow (liquid_gl.c), redraw the item's own content crisp on top, then
 *      redraw anything non-glass stacked above it in that area (app menus,
 *      notifications) so stacking stays correct;
 *   3. the software cursor (if the GPU has no cursor plane) goes back on top.
 * Any GL failure turns the effect off for the session (frosted fallback). */
#include <fcntl.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <wlr/render/swapchain.h>
#include <wlr/render/wlr_renderer.h>
#include <wlr/types/wlr_buffer.h>
#include <wlr/types/wlr_compositor.h>
#include <wlr/types/wlr_damage_ring.h>
#include <wlr/types/wlr_layer_shell_v1.h>
#include <wlr/types/wlr_output.h>
#include <wlr/util/log.h>
#include <scenefx/render/fx_renderer/fx_renderer.h>
#include "lumen.h"
#include "liquid_gl.h"

#define MAX_NS 64
#define MAX_RECTS 8
#define VALS 14

struct ns_rects {
	char ns[80];
	int n;
	float r[MAX_RECTS][VALS];
};

static struct {
	struct ns_rects tab[MAX_NS];
	int count;
	bool failed;            /* GL trouble once → stay off, never risk the session */
	unsigned long frames;   /* Liquid Glass frames drawn (lumenctl state: is it redrawing?) */
} L;

unsigned long liquid_frames(void) { return L.frames; }

/* ------------------------------------------------------------- IPC table */
static struct ns_rects *lookup(const char *ns, bool create) {
	for (int i = 0; i < L.count; i++)
		if (!strcmp(L.tab[i].ns, ns)) return &L.tab[i];
	if (!create || L.count >= MAX_NS) return NULL;
	struct ns_rects *e = &L.tab[L.count++];
	memset(e, 0, sizeof(*e));
	snprintf(e->ns, sizeof(e->ns), "%s", ns);
	return e;
}

void liquid_set_from_ipc(struct lumen_server *s, char *arg) {
	char *save = NULL;
	char *ns = strtok_r(arg, " ", &save);
	if (!ns) return;
	if (strlen(ns) >= sizeof(((struct ns_rects *)0)->ns)) ns[sizeof(((struct ns_rects *)0)->ns) - 1] = 0;
	struct ns_rects *e = lookup(ns, true);
	if (!e) return;
	float v[MAX_RECTS * VALS];
	int k = 0;
	for (char *tok; k < MAX_RECTS * VALS && (tok = strtok_r(NULL, " ", &save));) v[k++] = strtof(tok, NULL);
	int n = k / VALS;
	bool same = n == e->n && !memcmp(e->r, v, sizeof(float) * VALS * n);
	e->n = n;
	memcpy(e->r, v, sizeof(float) * VALS * n);
	if (!same && s->cfg.liquid) schedule_frames(s);
}

/* crash guard: while Liquid Glass is drawing, a marker file exists. If Lumen
 * ever dies mid-frame, the next session finds it and starts in frosted mode
 * (and says so) instead of crashing again. */
static char marker[256];
static bool marker_set, checked;

static void marker_path(void) {
	const char *rt = getenv("XDG_RUNTIME_DIR");
	snprintf(marker, sizeof(marker), "%s/lumen-liquid-active", rt && *rt ? rt : "/tmp");
}

void liquid_startup_check(struct lumen_server *s) {
	marker_path();
	checked = true;
	if (access(marker, F_OK) == 0) {
		unlink(marker);
		if (s->cfg.liquid) {
			L.failed = true;
			wlr_log(WLR_ERROR, "liquid glass: the last session ended while it was drawing — "
				"starting in frosted mode (pick Liquid Glass again in Settings to retry)");
			spawn("sleep 4; notify-send -a Lumen 'Liquid Glass paused' "
				"'The last session stopped unexpectedly while drawing glass, so this one uses frosted glass. "
				"Re-select Liquid Glass in Settings to turn it back on.'");
		}
	}
}

void liquid_shutdown(void) {
	if (marker_set) unlink(marker);
	marker_set = false;
}

/* -------------------------------------------------------------------- pour
 * Changing the glass style doesn't cut: for most of a second every frame is
 * drawn both ways, frosted and liquid, and liquid_gl pours one into the other
 * (the screen fills with liquid from the bottom, or drains). Both ends of the
 * pour are the real thing, so nothing jumps when it starts or stops. */
static struct { bool active, to_liquid; double t0, dur; } P;

static double mono_ms(void) {
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}

void liquid_pour_start(struct lumen_server *s, bool to_liquid) {
	if (!s->cfg.animations || s->cfg.performance_mode || L.failed || session_locked()) return;
	P.active = true;
	P.to_liquid = to_liquid;
	P.t0 = mono_ms();
	P.dur = s->cfg.anim_ms * 1.9;
	if (P.dur < 250) P.dur = 250;
	schedule_frames(s);
}

/* the pour is over (or can't go on): every screen redraws in its final style */
static void pour_end(struct lumen_server *s) {
	if (!P.active) return;
	P.active = false;
	struct lumen_output *o;
	wl_list_for_each(o, &s->outputs, link) {
		if (!o->scene_output) continue;
		wlr_damage_ring_add_whole(&o->scene_output->damage_ring);
		wlr_output_schedule_frame(o->wlr_output);
	}
}

bool liquid_enabled(struct lumen_server *s) {
	return (s->cfg.liquid || P.active) && !L.failed && !s->cfg.performance_mode;
}

/* Settings → Liquid Glass re-selected: give it another chance */
void liquid_retry(void) { L.failed = false; }

/* a rect's (premultiplied) colour, across SceneFX versions */
#ifdef LUMEN_RECT_FILL
#define RECT_COLOR(r) ((r)->fill.type == 0 ? (r)->fill.solid_color : NULL)
#else
#define RECT_COLOR(r) ((r)->color)
#endif

/* --------------------------------------------------------------- items */
enum { MAX_ITEMS = 24, MAX_HIDE = 512 };

struct item {
	struct wlr_scene_node *root;
	struct wlr_scene_node *bg;      /* a window's tint rect (replaced by the lens) */
	bool view;                      /* an app window (not a shell pane) */
	int first, n;                   /* shapes */
};

struct entry {
	struct wlr_scene_node *node;
	int lx, ly;                     /* layout coords */
	int item;                       /* -1: not glass */
};

static struct {
	struct item items[MAX_ITEMS];
	int nitems;
	struct liquid_shape shapes[LIQUID_MAX_SHAPES];
	int nshapes;
	struct entry *e;
	int ne, cap;
	struct { struct wlr_scene_node *node; float v[4]; } hid[MAX_HIDE];
	int nhid;
} F;

/* is the app's window body opaque? Self-decorated apps (GTK, Chrome…) leave
 * their rounded corners and drop shadow transparent, so only the middle of the
 * window geometry counts: corners/shadow don't make a window "see-through". */
static bool body_opaque(struct lumen_view *v, struct wlr_surface *sf) {
	if (!sf) return true;
	struct wlr_box g = { 0, 0, sf->current.width, sf->current.height };
	if (v->type == VIEW_XDG && v->xdg->base->geometry.width > 0) g = v->xdg->base->geometry;
	int inset = 24;
	if (g.width <= inset * 2 || g.height <= inset * 2) inset = 0;
	pixman_box32_t b = { g.x + inset, g.y + inset, g.x + g.width - inset, g.y + g.height - inset };
	return pixman_region32_contains_rectangle(&sf->opaque_region, &b) == PIXMAN_REGION_IN;
}

struct find_buf { struct wlr_surface *sf; struct wlr_scene_buffer *b; int sx, sy; };
static void find_main(struct wlr_scene_buffer *b, int sx, int sy, void *data) {
	struct find_buf *f = data;
	struct wlr_scene_surface *ss = wlr_scene_surface_try_from_buffer(b);
	if (!f->b && ss && ss->surface == f->sf) { f->b = b; f->sx = sx; f->sy = sy; }
}

static int add_item(struct wlr_scene_node *root) {
	for (int i = 0; i < F.nitems; i++)
		if (F.items[i].root == root) return i;
	if (F.nitems >= MAX_ITEMS) return -1;
	struct item *it = &F.items[F.nitems];
	memset(it, 0, sizeof(*it));
	it->root = root;
	it->first = F.nshapes;
	return F.nitems++;
}

static struct liquid_shape *add_shape(int item) {
	if (item < 0 || F.nshapes >= LIQUID_MAX_SHAPES) return NULL;
	struct item *it = &F.items[item];
	/* an item's shapes must be contiguous */
	if (it->n && it->first + it->n != F.nshapes) return NULL;
	struct liquid_shape *sh = &F.shapes[F.nshapes++];
	memset(sh, 0, sizeof(*sh));
	it->n++;
	return sh;
}

static bool fullscreen_on(struct lumen_output *o) {
	struct lumen_view *v;
	wl_list_for_each(v, &o->server->views, link)
		if (v->mapped && v->fullscreen && !v->minimized && v->workspace == o->ws &&
				wlr_box_intersection(&(struct wlr_box){0}, &v->geom, &o->full))
			return true;
	return false;
}

/* trim a panel's glass to what the panel actually draws (its rounded corners
 * exactly, whatever radius the CSS gives it): liquid.css leaves every pane a
 * faint 1% fill, so its own alpha outlines it */
static void layer_mask(struct lumen_output *o, struct lumen_layer_surface *l, struct liquid_shape *p) {
	float scale = o->wlr_output->scale;
	struct find_buf fb = { l->layer_surface->surface, NULL, 0, 0 };
	wlr_scene_node_for_each_buffer(&l->scene->tree->node, find_main, &fb);
	if (!fb.b) return;
	struct wlr_texture *tex = fb.b->WLR_PRIVATE.texture;
	if (!tex && fb.b->buffer) {
		struct wlr_client_buffer *cb = wlr_client_buffer_get(fb.b->buffer);
		if (cb) tex = cb->texture;
	}
	if (!tex) return;
	int tlx, tly;
	wlr_scene_node_coords(&fb.b->node, &tlx, &tly);
	int bw = fb.b->dst_width > 0 ? fb.b->dst_width : fb.b->WLR_PRIVATE.buffer_width;
	int bh = fb.b->dst_height > 0 ? fb.b->dst_height : fb.b->WLR_PRIVATE.buffer_height;
	struct fx_texture_attribs at;
	fx_texture_get_attribs(tex, &at);
	if (!at.has_alpha) return;
	p->mask_tex = at.tex;
	p->mask_target = at.target;
	p->mask_w = tex->width;
	p->mask_h = tex->height;
	p->mask_rect[0] = (tlx - o->full.x) * scale;
	p->mask_rect[1] = (tly - o->full.y) * scale;
	p->mask_rect[2] = bw * scale;
	p->mask_rect[3] = bh * scale;
	p->mask_src[0] = 0; p->mask_src[1] = 0; p->mask_src[2] = 1; p->mask_src[3] = 1;
	if (fb.b->src_box.width > 0 && tex->width && tex->height) {
		p->mask_src[0] = fb.b->src_box.x / tex->width;
		p->mask_src[1] = fb.b->src_box.y / tex->height;
		p->mask_src[2] = (fb.b->src_box.x + fb.b->src_box.width) / tex->width;
		p->mask_src[3] = (fb.b->src_box.y + fb.b->src_box.height) / tex->height;
	}
	p->mask_lo = 0.001f;     /* the 1% pane fill counts; fully clear pixels don't */
	p->mask_hi = 0.004f;
}

static void collect_layers(struct lumen_output *o, bool fs) {
	float scale = o->wlr_output->scale;
	for (int layer = 0; layer < 4; layer++) {
		if (fs && layer != ZWLR_LAYER_SHELL_V1_LAYER_OVERLAY) continue;
		struct lumen_layer_surface *l;
		wl_list_for_each(l, &o->layers[layer], link) {
			if (!l->mapped || l->alpha < 0.02) continue;
			const char *ns = l->layer_surface->namespace;
			/* panes reported for this screen ("lumen-taskbar@DP-1") come first:
			 * screens of different sizes have their docks in different places */
			struct ns_rects *e = NULL;
			if (ns) {
				char key[sizeof(e->ns)];
				int kn = snprintf(key, sizeof(key), "%s@%s", ns, o->wlr_output->name);
				if (kn > 0 && kn < (int)sizeof(key)) e = lookup(key, false);
				if (!e) e = lookup(ns, false);
			}
			if ((!e || e->n == 0) && ns && !strcmp(ns, "rofi")) {
				/* Spotlight: its whole window is one pane (lumen-liquid.rasi, 22px corners) */
				static struct ns_rects spot = { "rofi", 1,
					{ { 0, 0, -1, -1, 22, 22, 22, 22, 999, 999, 999, 999, 1, 1 } } };
				e = &spot;
			}
			if (!e || e->n == 0) continue;
			int lx, ly;
			if (!wlr_scene_node_coords(&l->scene->tree->node, &lx, &ly)) continue;
			int item = add_item(&l->scene->tree->node);
			int sw = l->layer_surface->surface->current.width;
			int sh = l->layer_surface->surface->current.height;
			for (int i = 0; i < e->n; i++) {
				struct liquid_shape *p = add_shape(item);
				if (!p) break;
				float *r = e->r[i];
				float w = r[2] < 0 ? sw - r[0] : r[2], h = r[3] < 0 ? sh - r[1] : r[3];
				p->x = (lx - o->full.x + r[0]) * scale;
				p->y = (ly - o->full.y + r[1]) * scale;
				p->w = w * scale;
				p->h = h * scale;
				for (int c = 0; c < 4; c++) {
					p->radius[c] = r[4 + c] * scale;
					p->band[c] = r[8 + c] * scale;
				}
				p->shadow = r[12];
				p->frost = r[13];
				p->alpha = (float)(l->alpha > 1 ? 1 : l->alpha);
				if (strcmp(ns, "rofi")) layer_mask(o, l, p);   /* rofi draws no pane fill to mask by */
			}
		}
	}
}

static void collect_views(struct lumen_output *o) {
	struct lumen_server *s = o->server;
	float scale = o->wlr_output->scale;
	struct lumen_view *v;
	/* views list is front = top; items are ordered later by the scene walk */
	wl_list_for_each(v, &s->views, link) {
		/* (on this desktop, sliding off it, or hanging over into it from next door) */
		if (!v->mapped || v->minimized || v->fullscreen || !view_visible_on(v, o) || v->alpha < 0.02)
			continue;
		int lx, ly;
		if (!wlr_scene_node_coords(&v->tree->node, &lx, &ly)) continue;
		struct wlr_surface *sf = view_surface(v);
		bool see_through = !body_opaque(v, sf);
		if (!v->ssd && !see_through) continue;   /* opaque self-decorated app: nothing glassy */
		int w = v->ssd ? v->frame->width : v->geom.width;
		int h = v->ssd ? v->frame->height : v->geom.height;
		if (!v->ssd) {
			/* glass under what the app really draws, not its reported geometry */
			struct wlr_box bb;
			if (view_body_box(v, &bb)) {
				struct wlr_box frame = { 0, 0, w, h }, body;
				if (!wlr_box_intersection(&body, &bb, &frame)) continue;
				lx += body.x; ly += body.y; w = body.width; h = body.height;
			}
		}
		struct wlr_box box = { lx, ly, w, h };
		if (!wlr_box_intersection(&(struct wlr_box){0}, &box, &o->full)) continue;
		int item = add_item(&v->tree->node);
		struct liquid_shape *p = add_shape(item);
		if (!p) continue;
		F.items[item].bg = v->ssd ? &v->frame->node : NULL;
		F.items[item].view = true;
		float r = (v->maximized ? 0 : s->cfg.corner_radius) * scale;
		p->x = (lx - o->full.x) * scale;
		p->y = (ly - o->full.y) * scale;
		p->w = w * scale;
		p->h = (see_through ? h : TITLEBAR_H) * scale;   /* opaque app: only the titlebar is glass */
		for (int c = 0; c < 4; c++) { p->radius[c] = r; p->band[c] = 999; }
		if (!see_through) { p->radius[2] = p->radius[3] = 0; p->band[2] = 0; }
		p->shadow = 0;
		p->frost = 1.0f;
		p->alpha = (float)(v->alpha > 1 ? 1 : v->alpha);
		if (v->ssd && see_through) {
			/* a see-through app under our titlebar (kitty): its translucent
			 * background used to sit on the glass as a dark box with square top
			 * corners under a light titlebar. Give the titlebar the app's own
			 * background colour (read from its top row in compose()) and put the
			 * rim light on after the content: one pane, round all the way. */
			struct find_buf fb = { sf, NULL, 0, 0 };
			wlr_scene_node_for_each_buffer(&v->surface_tree->node, find_main, &fb);
			struct wlr_texture *tex = fb.b ? fb.b->WLR_PRIVATE.texture : NULL;
			if (!tex && fb.b && fb.b->buffer) {
				struct wlr_client_buffer *cb = wlr_client_buffer_get(fb.b->buffer);
				if (cb) tex = cb->texture;
			}
			if (tex && tex->width > 4 && tex->height > 4) {
				struct fx_texture_attribs at;
				fx_texture_get_attribs(tex, &at);
				if (at.has_alpha) {
					float x0 = 0, x1 = tex->width, y0 = 0;
					if (fb.b->src_box.width > 0 && fb.b->src_box.height > 0) {
						x0 = (float)fb.b->src_box.x;
						x1 = (float)(fb.b->src_box.x + fb.b->src_box.width);
						y0 = (float)fb.b->src_box.y;
					}
					p->bg_tex = at.tex;
					p->bg_target = at.target;
					p->bg_u0 = x0 / tex->width;
					p->bg_u1 = x1 / tex->width;
					p->bg_v = (y0 + 1.5f) / tex->height;      /* just under the titlebar */
					p->bg_key = v;
					p->cap_h = TITLEBAR_H * scale;
				}
			}
			p->rim_over = true;
		}
		if (!v->ssd) {
			/* self-decorated: the app draws its own (unknown) corners — trim the
			 * glass with the app's own alpha so it fits whatever shape it drew */
			struct find_buf fb = { sf, NULL, 0, 0 };
			wlr_scene_node_for_each_buffer(&v->surface_tree->node, find_main, &fb);
			struct wlr_texture *tex = fb.b ? fb.b->WLR_PRIVATE.texture : NULL;
			if (!tex && fb.b && fb.b->buffer) {
				struct wlr_client_buffer *cb = wlr_client_buffer_get(fb.b->buffer);
				if (cb) tex = cb->texture;
			}
			if (tex) {
				int tlx, tly;
				wlr_scene_node_coords(&fb.b->node, &tlx, &tly);
				int bw = fb.b->dst_width > 0 ? fb.b->dst_width : fb.b->WLR_PRIVATE.buffer_width;
				int bh = fb.b->dst_height > 0 ? fb.b->dst_height : fb.b->WLR_PRIVATE.buffer_height;
				struct fx_texture_attribs at;
				fx_texture_get_attribs(tex, &at);
				p->mask_tex = at.tex;
				p->mask_target = at.target;
				p->mask_w = tex->width;
				p->mask_h = tex->height;
				p->mask_rect[0] = (tlx - o->full.x) * scale;
				p->mask_rect[1] = (tly - o->full.y) * scale;
				p->mask_rect[2] = bw * scale;
				p->mask_rect[3] = bh * scale;
				p->mask_src[0] = 0; p->mask_src[1] = 0; p->mask_src[2] = 1; p->mask_src[3] = 1;
				if (fb.b->src_box.width > 0 && tex->width && tex->height) {
					p->mask_src[0] = fb.b->src_box.x / tex->width;
					p->mask_src[1] = fb.b->src_box.y / tex->height;
					p->mask_src[2] = (fb.b->src_box.x + fb.b->src_box.width) / tex->width;
					p->mask_src[3] = (fb.b->src_box.y + fb.b->src_box.height) / tex->height;
				}
				/* The lens is a plain rounded rectangle on the box the window's
				 * content is painted in. Its corners: the system radius — we round
				 * every self-decorated window to that ourselves (set_buffer_alpha)
				 * — or the app's own, if those are rounder (measured from its
				 * picture in compose(), which needs GL). The app's picture is only
				 * read for that measurement; it doesn't trim the glass. */
				for (int c = 0; c < 4; c++) p->radius[c] = (v->maximized ? 0 : s->cfg.corner_radius) * scale;
				p->min_radius = p->radius[0];
				p->measure_only = true;
				struct wlr_box g = { 0 };
				if (v->type == VIEW_XDG) g = v->xdg->base->geometry;
				float bs = tex->width / (float)(bw > 0 ? bw : 1);   /* buffer px per logical px */
				p->measure_x = (int)(g.x * bs);
				p->measure_y = (int)(g.y * bs);
				p->measure_scale = scale / bs;
				p->measure = true;
			}
		}
		/* the window's glass colour, a little lighter than in frosted mode */
		float a = s->cfg.glass_tint[3] * 0.55f;
		p->tint[0] = s->cfg.glass_tint[0] * a;
		p->tint[1] = s->cfg.glass_tint[1] * a;
		p->tint[2] = s->cfg.glass_tint[2] * a;
		p->tint[3] = a;
	}
}

/* scene walk in render order (bottom → top), tagging nodes with their item */
static void push(struct wlr_scene_node *n, int lx, int ly, int item) {
	if (F.ne == F.cap) {
		F.cap = F.cap ? F.cap * 2 : 256;
		F.e = realloc(F.e, sizeof(*F.e) * F.cap);
	}
	F.e[F.ne++] = (struct entry){ n, lx, ly, item };
}

static void walk(struct wlr_scene_node *n, int x, int y, int item) {
	if (!n->enabled) return;
	x += n->x;
	y += n->y;
	if (item < 0)
		for (int i = 0; i < F.nitems; i++)
			if (F.items[i].root == n) { item = i; break; }
	if (n->type == WLR_SCENE_NODE_TREE) {
		struct wlr_scene_tree *t = wlr_scene_tree_from_node(n);
		struct wlr_scene_node *c;
		wl_list_for_each(c, &t->children, link) walk(c, x, y, item);
		return;
	}
	push(n, x, y, item);
}

static struct wlr_box node_box(struct entry *e) {
	struct wlr_scene_node *n = e->node;
	if (n->type == WLR_SCENE_NODE_RECT) {
		struct wlr_scene_rect *r = wlr_scene_rect_from_node(n);
		return (struct wlr_box){ e->lx, e->ly, r->width, r->height };
	}
	if (n->type == WLR_SCENE_NODE_BUFFER) {
		struct wlr_scene_buffer *b = wlr_scene_buffer_from_node(n);
		int w = b->dst_width > 0 ? b->dst_width : b->WLR_PRIVATE.buffer_width;
		int h = b->dst_height > 0 ? b->dst_height : b->WLR_PRIVATE.buffer_height;
		return (struct wlr_box){ e->lx, e->ly, w, h };
	}
	return (struct wlr_box){ 0 };
}

/* does this node put pixels on screen that paint_entry() redraws? */
static bool paints(struct wlr_scene_node *n) {
	if (n->type == WLR_SCENE_NODE_RECT) {
		const float *col = RECT_COLOR(wlr_scene_rect_from_node(n));
		return col && col[3] > 0;
	}
	if (n->type == WLR_SCENE_NODE_BUFFER) {
		struct wlr_scene_buffer *b = wlr_scene_buffer_from_node(n);
		return (b->buffer || b->WLR_PRIVATE.texture) && b->opacity > 0;
	}
	return false;
}

/* ------------------------------------------------------ hide / restore */
static void hide(struct wlr_scene_node *n) {
	if (F.nhid >= MAX_HIDE) return;
	float zero[4] = { 0 };
	switch (n->type) {
	case WLR_SCENE_NODE_BUFFER: {
		struct wlr_scene_buffer *b = wlr_scene_buffer_from_node(n);
		if (b->opacity <= 0) return;
		F.hid[F.nhid].node = n;
		F.hid[F.nhid++].v[0] = b->opacity;
		wlr_scene_buffer_set_opacity(b, 0);
		break;
	}
	case WLR_SCENE_NODE_RECT: {
		struct wlr_scene_rect *r = wlr_scene_rect_from_node(n);
		const float *col = RECT_COLOR(r);
		if (!col || col[3] <= 0) return;
		F.hid[F.nhid].node = n;
		memcpy(F.hid[F.nhid++].v, col, sizeof(float) * 4);
		wlr_scene_rect_set_color(r, zero);
		break;
	}
	case WLR_SCENE_NODE_BLUR: {
		struct wlr_scene_blur *b = wlr_scene_blur_from_node(n);
		if (b->alpha <= 0) return;
		F.hid[F.nhid].node = n;
		F.hid[F.nhid++].v[0] = b->alpha;
		wlr_scene_blur_set_alpha(b, 0);
		break;
	}
	default:
		break;
	}
}

static void unhide(void) {
	for (int i = 0; i < F.nhid; i++) {
		struct wlr_scene_node *n = F.hid[i].node;
		if (n->type == WLR_SCENE_NODE_BUFFER) wlr_scene_buffer_set_opacity(wlr_scene_buffer_from_node(n), F.hid[i].v[0]);
		else if (n->type == WLR_SCENE_NODE_RECT) wlr_scene_rect_set_color(wlr_scene_rect_from_node(n), F.hid[i].v);
		else if (n->type == WLR_SCENE_NODE_BLUR) wlr_scene_blur_set_alpha(wlr_scene_blur_from_node(n), F.hid[i].v[0]);
	}
	F.nhid = 0;
}

/* ------------------------------------------------------------ painting */
static struct wlr_texture *temps[64];
static int ntemps;

static bool paint_entry(struct lumen_output *o, struct entry *e, const struct liquid_clip *clip) {
	float sc = o->wlr_output->scale;
	struct wlr_scene_node *n = e->node;
	struct liquid_paint pt = {0};
	pt.x = (e->lx - o->full.x) * sc;
	pt.y = (e->ly - o->full.y) * sc;
	if (n->type == WLR_SCENE_NODE_RECT) {
		struct wlr_scene_rect *r = wlr_scene_rect_from_node(n);
		const float *col = RECT_COLOR(r);
		if (!col || col[3] <= 0) return true;
		pt.w = r->width * sc;
		pt.h = r->height * sc;
		pt.radius[0] = r->corners.top_left * sc;
		pt.radius[1] = r->corners.top_right * sc;
		pt.radius[2] = r->corners.bottom_right * sc;
		pt.radius[3] = r->corners.bottom_left * sc;
		struct clipped_region *cr = &r->clipped_region;
		if (cr->area.width > 0 && cr->area.height > 0) {
			pt.hole[0] = pt.x + cr->area.x * sc;
			pt.hole[1] = pt.y + cr->area.y * sc;
			pt.hole[2] = cr->area.width * sc;
			pt.hole[3] = cr->area.height * sc;
			pt.hole_radius[0] = cr->corners.top_left * sc;
			pt.hole_radius[1] = cr->corners.top_right * sc;
			pt.hole_radius[2] = cr->corners.bottom_right * sc;
			pt.hole_radius[3] = cr->corners.bottom_left * sc;
		}
		liquid_gl_paint_rect(&pt, col, clip);
		return true;
	}
	if (n->type != WLR_SCENE_NODE_BUFFER) return true;
	struct wlr_scene_buffer *b = wlr_scene_buffer_from_node(n);
	/* A picture we drew ourselves (a window's title, the glyphs on its
	 * controls) is kept by the scene as a texture only: its buffer is gone
	 * (NULL) once uploaded. Skipping every node without a buffer left
	 * titlebars without their title in Liquid Glass. */
	struct wlr_texture *tex = b->WLR_PRIVATE.texture;
	if ((!b->buffer && !tex) || b->opacity <= 0) return true;
	if (b->transform != WL_OUTPUT_TRANSFORM_NORMAL) return true;   /* rotated video etc.: rare, skip */
	if (!tex) {
		struct wlr_client_buffer *cb = wlr_client_buffer_get(b->buffer);
		if (cb) tex = cb->texture;
	}
	if (!tex && ntemps < 64) {
		tex = wlr_texture_from_buffer(o->server->renderer, b->buffer);
		if (tex) temps[ntemps++] = tex;
	}
	if (!tex) return true;
	struct wlr_box bx = node_box(e);
	pt.w = bx.width * sc;
	pt.h = bx.height * sc;
	pt.radius[0] = b->corners.top_left * sc;
	pt.radius[1] = b->corners.top_right * sc;
	pt.radius[2] = b->corners.bottom_right * sc;
	pt.radius[3] = b->corners.bottom_left * sc;
	float src[4] = { 0, 0, 1, 1 };
	if (b->src_box.width > 0 && b->src_box.height > 0 && tex->width && tex->height) {
		src[0] = b->src_box.x / tex->width;
		src[1] = b->src_box.y / tex->height;
		src[2] = (b->src_box.x + b->src_box.width) / tex->width;
		src[3] = (b->src_box.y + b->src_box.height) / tex->height;
	}
	struct fx_texture_attribs at;
	fx_texture_get_attribs(tex, &at);
	return liquid_gl_paint_texture(&pt, at.tex, at.target, at.has_alpha, src, b->opacity, clip);
}

static bool is_ours(struct wlr_output *wo, struct wlr_buffer *b) {
	if (!wo->swapchain || !b) return false;
	for (size_t i = 0; i < WLR_SWAPCHAIN_CAP; i++)
		if (wo->swapchain->slots[i].buffer == b) return true;
	return false;
}

static struct liquid_params params(struct lumen_server *s) {
	struct lumen_config *c = &s->cfg;
	return (struct liquid_params){ .band = c->liquid_rim, .strength = c->liquid_refraction,
		.zoom = 0.025f, .frost = c->liquid_frost, .specular = c->liquid_highlight, .tint = 0.02f };
}

/* an app's background colour, remembered for a moment: reading pixels back
 * from the GPU every frame would stall it */
static bool app_background(struct liquid_shape *s) {
	static struct { const void *key; double at; bool ok; float c[4]; } memo[12];
	static int next;
	double now = now_ms();
	int slot = -1;
	for (int i = 0; i < 12; i++)
		if (memo[i].key == s->bg_key) { slot = i; break; }
	if (slot < 0 || now - memo[slot].at > 350) {
		if (slot < 0) { slot = next; next = (next + 1) % 12; }
		memo[slot].key = s->bg_key;
		memo[slot].at = now;
		memo[slot].ok = liquid_gl_sample_row(s->bg_tex, s->bg_target, s->bg_u0, s->bg_u1, s->bg_v, memo[slot].c);
		/* nothing see-through there (or nearly opaque): the titlebar stays plain glass */
		if (memo[slot].ok && (memo[slot].c[3] < 0.03f || memo[slot].c[3] > 0.97f)) memo[slot].ok = false;
	}
	if (!memo[slot].ok) return false;
	memcpy(s->cap_tint, memo[slot].c, sizeof(s->cap_tint));
	return true;
}

/* the glass, item by item, bottom → top */
static bool compose(struct lumen_output *o, struct wlr_buffer *buf) {
	struct wlr_output *wo = o->wlr_output;
	struct liquid_params prm = params(o->server);
	float sc = wo->scale;
	int W = buf->width, H = buf->height;

	/* which item comes first in the stacking order, and where each one ends */
	int order[MAX_ITEMS], last[MAX_ITEMS], no = 0;
	for (int i = 0; i < F.nitems; i++) last[i] = -1;
	for (int k = 0; k < F.ne; k++) {
		int it = F.e[k].item;
		if (it < 0) continue;
		if (last[it] < 0) order[no++] = it;
		last[it] = k;
	}
	bool ok = true;
	for (int oi = 0; oi < no && ok; oi++) {
		int it = order[oi];
		struct item *I = &F.items[it];
		if (!I->n) continue;
		/* R: the item's shapes + everything it draws, in fb pixels */
		struct wlr_box R = { 0 };
		for (int k = I->first; k < I->first + I->n; k++) {
			struct liquid_shape *s = &F.shapes[k];
			struct wlr_box sb = { (int)s->x - (s->shadow > 0 ? (int)(34 * sc) : 1),
				(int)s->y - (s->shadow > 0 ? (int)(34 * sc) : 1),
				(int)s->w + (s->shadow > 0 ? (int)(68 * sc) : 2), (int)s->h + (s->shadow > 0 ? (int)(68 * sc) : 2) };
			if (R.width == 0) R = sb;
			else {
				int x0 = R.x < sb.x ? R.x : sb.x, y0 = R.y < sb.y ? R.y : sb.y;
				int x1 = R.x + R.width > sb.x + sb.width ? R.x + R.width : sb.x + sb.width;
				int y1 = R.y + R.height > sb.y + sb.height ? R.y + R.height : sb.y + sb.height;
				R = (struct wlr_box){ x0, y0, x1 - x0, y1 - y0 };
			}
		}
		if (I->view) {
			/* windows: what they draw may reach outside the glass — an opaque app
			 * body under our titlebar, and any app's menus and popovers, which
			 * open past the window's edge (they used to be cut off there) */
			for (int k = 0; k <= last[it]; k++) {
				if (F.e[k].item != it || !paints(F.e[k].node)) continue;
				struct wlr_box b = node_box(&F.e[k]);
				if (b.width <= 0) continue;
				struct wlr_box fbb = { (int)((b.x - o->full.x) * sc), (int)((b.y - o->full.y) * sc),
					(int)(b.width * sc), (int)(b.height * sc) };
				int x0 = R.x < fbb.x ? R.x : fbb.x, y0 = R.y < fbb.y ? R.y : fbb.y;
				int x1 = R.x + R.width > fbb.x + fbb.width ? R.x + R.width : fbb.x + fbb.width;
				int y1 = R.y + R.height > fbb.y + fbb.height ? R.y + R.height : fbb.y + fbb.height;
				R = (struct wlr_box){ x0, y0, x1 - x0, y1 - y0 };
			}
		}
		struct wlr_box fbbox = { 0, 0, W, H };
		if (!wlr_box_intersection(&R, &R, &fbbox)) continue;
		struct liquid_clip clip = { R.x, R.y, R.width, R.height };

		for (int k = I->first; k < I->first + I->n; k++) {
			struct liquid_shape *s = &F.shapes[k];
			if (!s->mask_tex) continue;
			unsigned key = s->mask_tex;
			if (s->mask_target != GL_TEXTURE_2D) {
				/* dmabuf apps (GTK4, kitty…): make the texture readable first, or
				 * the glass ignores the app's shape and shows as a square */
				unsigned t2 = liquid_gl_to_2d(k, s->mask_tex, s->mask_target, s->mask_w, s->mask_h);
				s->mask_tex = t2;
				s->mask_target = GL_TEXTURE_2D;
				if (!t2) continue;
			}
			if (!s->measure) continue;
			float r = liquid_gl_corner_radius(key, s->mask_tex, s->measure_x, s->measure_y, 64);
			if (r >= 0 && r < 80) {
				float rr = r * s->measure_scale;
				if (rr < s->min_radius) rr = s->min_radius;
				for (int c = 0; c < 4; c++) s->radius[c] = rr;
			}
		}
		bool rim_after = false;
		for (int k = I->first; k < I->first + I->n; k++) {
			struct liquid_shape *s = &F.shapes[k];
			if (s->bg_tex && !app_background(s)) s->cap_h = 0;
			if (s->bg_key) {
				/* how bright the titlebar ends up: the app's colour over the glass */
				int tone = 0;
				if (s->cap_h > 0) {
					float lum = 0.299f * s->cap_tint[0] + 0.587f * s->cap_tint[1] + 0.114f * s->cap_tint[2];
					lum += (1 - s->cap_tint[3]) * (o->server->cfg.light ? 0.80f : 0.22f);
					tone = lum < 0.52f ? 1 : 2;
				}
				view_title_tone((struct lumen_view *)s->bg_key, tone);
			}
			rim_after = rim_after || s->rim_over;
		}
		ok = liquid_gl_capture(W, H, sc, F.shapes, I->first, I->n, &prm) &&
			liquid_gl_draw(W, H, sc, F.shapes, I->first, I->n, &prm);
		if (!ok) break;
		if (!liquid_gl_paint_begin(W, H)) { ok = false; break; }
		/* the item's own content (not its old tint, blur or shadow) */
		for (int k = 0; k <= last[it] && ok; k++) {
			struct entry *e = &F.e[k];
			if (e->item != it || e->node == I->bg) continue;
			if (e->node->type != WLR_SCENE_NODE_BUFFER && e->node->type != WLR_SCENE_NODE_RECT) continue;
			ok = paint_entry(o, e, &clip);
		}
		if (rim_after && ok) {
			/* the light on the glass edge goes over what the app drew */
			ok = liquid_gl_paint_end() && liquid_gl_draw_rim(W, H, sc, F.shapes, I->first, I->n, &prm) &&
				liquid_gl_paint_begin(W, H);
			if (!ok) break;
		}
		/* whatever non-glass sits above it here */
		for (int k = last[it] + 1; k < F.ne && ok; k++) {
			struct entry *e = &F.e[k];
			if (e->item >= 0) continue;
			if (e->node->type != WLR_SCENE_NODE_BUFFER && e->node->type != WLR_SCENE_NODE_RECT) continue;
			struct wlr_box b = node_box(e), fbb = { (int)((b.x - o->full.x) * sc), (int)((b.y - o->full.y) * sc),
				(int)(b.width * sc), (int)(b.height * sc) };
			if (!wlr_box_intersection(&(struct wlr_box){0}, &fbb, &R)) continue;
			ok = paint_entry(o, e, &clip);
		}
		ok = liquid_gl_paint_end() && ok;
	}
	return ok;
}

/* the frame as Frosted draws it (nothing hidden, SceneFX's own blur), kept for the pour */
static bool pour_frosted(struct lumen_output *o) {
	struct wlr_scene_output *so = o->scene_output;
	struct wlr_output *wo = o->wlr_output;
	struct wlr_output_cursor *cur;
	bool cur_was[16];
	int nc = 0;
	wl_list_for_each(cur, &wo->cursors, link) {
		if (nc < 16) cur_was[nc] = cur->enabled;
		if (cur != wo->hardware_cursor) cur->enabled = false;
		nc++;
	}
	wlr_damage_ring_add_whole(&so->damage_ring);
	struct wlr_output_state st;
	wlr_output_state_init(&st);
	bool ok = wlr_scene_output_build_state(so, &st, NULL);
	nc = 0;
	wl_list_for_each(cur, &wo->cursors, link) {
		if (nc < 16) cur->enabled = cur_was[nc];
		nc++;
	}
	if (ok && (st.committed & WLR_OUTPUT_STATE_BUFFER) && is_ours(wo, st.buffer)) {
		struct wlr_render_pass *pass = wlr_renderer_begin_buffer_pass(o->server->renderer, st.buffer, NULL);
		ok = pass != NULL;
		if (pass) {
			ok = liquid_gl_pour_grab(0, st.buffer->width, st.buffer->height);
			wlr_render_pass_submit(pass);
		}
	} else {
		ok = false;
	}
	wlr_output_state_finish(&st);   /* never shown: the buffer goes straight back */
	return ok;
}

/* drop-in replacement for wlr_scene_output_commit() */
bool liquid_output_commit(struct lumen_output *o) {
	struct lumen_server *s = o->server;
	struct wlr_scene_output *so = o->scene_output;
	struct wlr_output *wo = o->wlr_output;
	if (P.active && (mono_ms() - P.t0 >= P.dur || session_locked())) pour_end(s);
	if (!liquid_enabled(s) || session_locked() || wo->transform != WL_OUTPUT_TRANSFORM_NORMAL || !wo->swapchain)
		return wlr_scene_output_commit(so, NULL);
	if (!P.active && !wlr_scene_output_needs_frame(so)) return true;

	F.nitems = F.nshapes = F.ne = 0;
	bool fs = fullscreen_on(o);
	collect_layers(o, fs);
	if (!fs) collect_views(o);
	/* drop anything degenerate (windows dragged half off-screen, mid-animation sizes) */
	for (int i = 0; i < F.nshapes; i++) {
		struct liquid_shape *p = &F.shapes[i];
		if (!(p->w > 2 && p->h > 2 && p->w < 32768 && p->h < 32768 && isfinite(p->x) && isfinite(p->y)))
			p->alpha = 0;
		if (p->mask_tex && !(p->mask_rect[2] > 0 && p->mask_rect[3] > 0)) p->mask_tex = 0;
	}
	if (F.nshapes == 0) return wlr_scene_output_commit(so, NULL);
	walk(&s->scene->tree.node, 0, 0, -1);

	/* mid-pour: first the frame the frosted way */
	bool pouring = P.active;
	if (pouring && !pour_frosted(o)) {
		pour_end(s);
		pouring = false;
	}

	if (!checked) marker_path();
	if (!marker_set) {
		int fd = open(marker, O_CREAT | O_WRONLY | O_CLOEXEC, 0600);
		if (fd >= 0) close(fd);
		marker_set = true;
	}

	L.frames++;
	/* 1. the frame with the glass invisible — and without the mouse pointer,
	 *    so the lens never bends it (it goes back on top at the end) */
	for (int k = 0; k < F.ne; k++)
		if (F.e[k].item >= 0 && F.e[k].node->type != WLR_SCENE_NODE_SHADOW) hide(F.e[k].node);
	struct wlr_output_cursor *cur;
	bool cur_was[16];
	int nc = 0;
	wl_list_for_each(cur, &wo->cursors, link) {
		if (nc < 16) cur_was[nc] = cur->enabled;
		if (cur != wo->hardware_cursor) cur->enabled = false;
		nc++;
	}
	wlr_damage_ring_add_whole(&so->damage_ring);
	struct wlr_output_state st;
	wlr_output_state_init(&st);
	bool ok = wlr_scene_output_build_state(so, &st, NULL);
	nc = 0;
	wl_list_for_each(cur, &wo->cursors, link) {
		if (nc < 16) cur->enabled = cur_was[nc];
		nc++;
	}
	unhide();   /* before the commit, so the restore damage is consumed by it */
	if (ok && (st.committed & WLR_OUTPUT_STATE_BUFFER) && is_ours(wo, st.buffer)) {
		struct wlr_render_pass *pass = wlr_renderer_begin_buffer_pass(s->renderer, st.buffer, NULL);
		if (pass) {
			/* 2. the glass */
			if (!compose(o, st.buffer)) {
				wlr_log(WLR_ERROR, "liquid glass: GL pass failed, falling back to frosted glass");
				L.failed = true;
			}
			/* mid-pour: this was the liquid frame; pour the two together */
			if (pouring && !L.failed) {
				double t = (mono_ms() - P.t0) / P.dur;
				t = t < 0 ? 0 : (t > 1 ? 1 : t);
				double e = t * t * (3 - 2 * t);
				if (!liquid_gl_pour_grab(1, st.buffer->width, st.buffer->height) ||
						!liquid_gl_pour_mix(st.buffer->width, st.buffer->height, wo->scale,
							(float)(P.to_liquid ? e : 1 - e), (float)t))
					pour_end(s);
			}
			/* 3. cursor on top */
			if (!wo->hardware_cursor) wlr_output_add_software_cursors_to_render_pass(wo, pass, NULL);
			glFinish();   /* the page flip must not overtake us */
			wlr_render_pass_submit(pass);
			pixman_region32_t full;
			pixman_region32_init_rect(&full, 0, 0, st.buffer->width, st.buffer->height);
			wlr_output_state_set_damage(&st, &full);
			pixman_region32_fini(&full);
		}
	}
	for (int i = 0; i < ntemps; i++) wlr_texture_destroy(temps[i]);
	ntemps = 0;
	if (ok) ok = wlr_output_commit_state(wo, &st);
	wlr_output_state_finish(&st);
	if (L.failed) {
		P.active = false;
		apply_blur(s);
		wlr_damage_ring_add_whole(&so->damage_ring);
		wlr_output_schedule_frame(wo);
	}
	if (P.active) wlr_output_schedule_frame(wo);   /* the pour keeps moving */
	return ok;
}

/* frosted: the configured blur. liquid: the lens does the work, SceneFX blur
 * only remains for things that aren't glass items. */
void apply_blur(struct lumen_server *s) {
	struct lumen_config *c = &s->cfg;
	wlr_scene_set_blur_data(s->scene, c->blur_passes, c->blur_radius,
		c->blur_noise, c->blur_brightness, 1.0f, c->blur_saturation);
}
