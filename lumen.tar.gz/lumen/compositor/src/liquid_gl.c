/* Liquid Glass lens (pure GLES2, no wlroots types — unit-testable).
 *
 * Two steps per frame, both with the target framebuffer bound and the
 * renderer's EGL context current:
 *
 *   liquid_gl_capture()  on the BACKDROP frame (scene rendered with the glass
 *                        panes invisible): copy each pane's area + margin.
 *   liquid_gl_draw()     on the FINAL frame: draw a soft drop shadow around each
 *                        pane, then the pane itself as a thick convex lens over
 *                        the captured backdrop. The caller then redraws the
 *                        pane's own content (text, icons) crisp on top.
 *
 * The lens: a slab with a flat-ish top and a rounded bevel all round. The top
 * magnifies slightly; across the bevel the surface tilts steeply, so light from
 * further inside is pulled out to the rim (content there gets squeezed, and for
 * strong refraction flips) — like a glass cube or a drop of water. Each colour
 * bends a little differently, giving the coloured fringes at the edge.
 *
 * Framebuffer convention (wlroots buffer passes): GL window y = 0 is the TOP of
 * the screen, so gl_FragCoord.y grows downward like layout coordinates. */
#include <GLES2/gl2.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "liquid_gl.h"

static const char *VS =
	"attribute vec2 pos;\n"
	"uniform vec2 fb;\n"
	"void main() { gl_Position = vec4(pos / fb * 2.0 - 1.0, 0.0, 1.0); }\n";

static const char *FS =
	"precision highp float;\n"
	"uniform sampler2D tex;\n"     /* sharp backdrop */
	"uniform sampler2D btex;\n"    /* the same, frosted (two-pass gaussian) */
	"uniform vec2 tex_origin;\n"   /* fb pixel of the capture's (0,0) */
	"uniform vec2 tex_size;\n"
	"uniform vec4 rect;\n"         /* x, y, w, h (fb pixels, y down) */
	"uniform vec4 radii;\n"        /* tl, tr, br, bl */
	"uniform vec4 bands;\n"        /* bevel width per edge: top, right, bottom, left */
	"uniform float refr;\n"        /* refraction strength */
	"uniform float zoom;\n"        /* magnification of the flat top */
	"uniform float frost;\n"       /* blur radius, px */
	"uniform float px;\n"          /* output scale */
	"uniform float spec_amt;\n"
	"uniform float tint;\n"
	"uniform float alpha;\n"
	"uniform float shadow;\n"      /* > 0: shadow pass */
	"uniform vec4 tintc;\n"        /* premultiplied tint over the glass (window glass colour) */
	"uniform sampler2D mask;\n"    /* optional: the app's own pixels — glass only where it draws */
	"uniform vec4 mask_rect;\n"    /* where that texture lands (fb px) */
	"uniform vec4 mask_src;\n"     /* its uv sub-rect */
	"uniform float use_mask;\n"
	"uniform vec2 mask_thr;\n"    /* alpha that counts as the app's own pixels */
	"uniform float hl;\n"         /* rim light: 0 none in this pass, 1 with it, 2 only it */
	"uniform vec4 capc;\n"        /* premultiplied colour laid over the top cap_y rows (a titlebar) */
	"uniform float cap_y;\n"
	"float sdf(vec2 p) {\n"
	"  vec2 q = p - (rect.xy + rect.zw * 0.5);\n"
	"  float r = q.x > 0.0 ? (q.y > 0.0 ? radii.z : radii.y) : (q.y > 0.0 ? radii.w : radii.x);\n"
	"  vec2 k = abs(q) - rect.zw * 0.5 + vec2(r);\n"
	/* Deeper in than the corner's own curve, the plain distance field has a
	 * crease along each corner's diagonal (nearest edge flips from the side to
	 * the top), which showed as a diagonal seam in every corner of the bevel.
	 * Blend the two edge distances there instead: the bevel turns the corner
	 * smoothly. The outline itself (and everything outside) stays exact. */
	"  if (k.x < 0.0 && k.y < 0.0) {\n"
	"    vec2 m = max(-k, vec2(0.001));\n"
	"    return -(m.x * m.y) * inversesqrt(dot(m, m)) - r;\n"
	"  }\n"
	"  return min(max(k.x, k.y), 0.0) + length(max(k, 0.0)) - r;\n"
	"}\n"
	/* the same outline with rounder corners (never rounder than the pane allows):
	 * only its direction is used, see main() */
	"float sdf_round(vec2 p, float grow) {\n"
	"  vec2 q = p - (rect.xy + rect.zw * 0.5);\n"
	"  float r = q.x > 0.0 ? (q.y > 0.0 ? radii.z : radii.y) : (q.y > 0.0 ? radii.w : radii.x);\n"
	"  r = min(r + grow, min(rect.z, rect.w) * 0.5);\n"
	"  vec2 k = abs(q) - rect.zw * 0.5 + vec2(r);\n"
	"  return min(max(k.x, k.y), 0.0) + length(max(k, 0.0)) - r;\n"
	"}\n"
	"vec3 samp(vec2 p) {\n"
	"  vec2 uv = (p - tex_origin) / tex_size;\n"
	"  return texture2D(tex, clamp(uv, vec2(0.0005), vec2(0.9995))).rgb;\n"
	"}\n"
	"vec3 frosted(vec2 p) {\n"
	"  if (frost < 0.5) return samp(p);\n"
	"  vec2 uv = (p - tex_origin) / tex_size;\n"
	"  return texture2D(btex, clamp(uv, vec2(0.0005), vec2(0.9995))).rgb;\n"
	"}\n"
	/* how far light is pulled in from the inside at `depth` px from the rim:
	 * the surface tilt of a rounded bevel, which grows steeply toward the edge */
	"float bend(float depth, float band) {\n"
	"  float x = band > 0.75 ? clamp(1.0 - depth / band, 0.0, 1.0) : 0.0;\n"
	"  float slope = x / sqrt(max(1.0 - x * x, 0.04));\n"
	"  return refr * band * 0.42 * min(slope, 3.2);\n"
	"}\n"
	"void main() {\n"
	"  vec2 p = gl_FragCoord.xy;\n"
	"  if (shadow > 0.0) {\n"
	/* soft shadow under the floating pane (only outside it) */
	"    float ds = sdf(p - vec2(0.0, 5.0 * px));\n"
	"    float s = shadow * exp(-max(ds, 0.0) / (10.0 * px)) * clamp(sdf(p) + 0.5, 0.0, 1.0);\n"
	"    gl_FragColor = vec4(0.0, 0.0, 0.0, s * alpha);\n"
	"    return;\n"
	"  }\n"
	"  float d = sdf(p);\n"
	"  float a = clamp(0.5 - d, 0.0, 1.0) * alpha;\n"         /* same 1px edge AA as GTK */
	"  if (use_mask > 0.5) {\n"
	"    vec2 t = (p - mask_rect.xy) / mask_rect.zw;\n"
	"    float ma = (t.x < 0.0 || t.y < 0.0 || t.x > 1.0 || t.y > 1.0) ? 0.0\n"
	"             : texture2D(mask, mix(mask_src.xy, mask_src.zw, t)).a;\n"
	"    a *= smoothstep(mask_thr.x, mask_thr.y, ma);\n"                  /* app's rounded corners, exactly */
	"  }\n"
	"  if (a <= 0.0) { gl_FragColor = vec4(0.0); return; }\n"
	"  vec2 g = vec2(sdf(p + vec2(0.5, 0.0)) - sdf(p - vec2(0.5, 0.0)),\n"
	"                sdf(p + vec2(0.0, 0.5)) - sdf(p - vec2(0.0, 0.5)));\n"
	"  vec2 n = g / max(length(g), 1e-4);\n"                    /* outward normal */
	"  float depth = max(-d, 0.0);\n"
	/* Which way the bevel leans: right at the edge, straight out from the
	 * outline; further in, as if the corner were as round as the bevel is wide.
	 * (Following the outline all the way in pinches the picture at the centre of
	 * each corner's curve and leaves a diagonal mark there.) */
	"  float bmax = max(max(bands.x, bands.y), max(bands.z, bands.w));\n"
	"  if (bmax > 0.75) {\n"
	"    vec2 g2 = vec2(sdf_round(p + vec2(0.5, 0.0), bmax) - sdf_round(p - vec2(0.5, 0.0), bmax),\n"
	"                   sdf_round(p + vec2(0.0, 0.5), bmax) - sdf_round(p - vec2(0.0, 0.5), bmax));\n"
	"    vec2 qc = p - (rect.xy + rect.zw * 0.5);\n"
	"    float rc = qc.x > 0.0 ? (qc.y > 0.0 ? radii.z : radii.y) : (qc.y > 0.0 ? radii.w : radii.x);\n"
	"    vec2 nn = mix(n, g2 / max(length(g2), 1e-4), smoothstep(0.0, max(rc * 0.8, 2.0 * px), depth));\n"
	"    n = nn / max(length(nn), 1e-4);\n"
	"  }\n"
	"  float band = (n.x > 0.0 ? bands.y : bands.w) * n.x * n.x + (n.y > 0.0 ? bands.z : bands.x) * n.y * n.y;\n"
	"  float x = band > 0.75 ? clamp(1.0 - depth / band, 0.0, 1.0) : 0.0;\n"   /* 1 at rim → 0 on top */
	/* specular rim, key light top-left + weaker bounce bottom-right, all the way round */
	"  vec2 L = normalize(vec2(-0.55, -0.85));\n"
	"  float rim = exp(-depth / (0.9 * px)) + 0.4 * exp(-depth / (3.0 * px));\n"
	"  float lit = 0.62 * pow(max(dot(n, L), 0.0), 1.3) + 0.36 * pow(max(dot(n, -L), 0.0), 1.6) + 0.14;\n"
	"  vec3 high = vec3(spec_amt * rim * lit + 0.10 * pow(x, 3.0) * (0.4 + 0.6 * max(dot(n, L), 0.0)));\n"
	"  if (hl > 1.5) { gl_FragColor = vec4(high * a, 0.0); return; }\n"   /* light only, added on top */
	"  float disp = bend(depth, band);\n"
	"  vec2 c = rect.xy + rect.zw * 0.5;\n"
	"  vec2 base = c + (p - c) * (1.0 - zoom);\n"               /* gently magnified top */
	/* The bevel squeezes a long stretch of backdrop into a few pixels. Sampling
	 * that once per pixel turned text and fine detail behind the rim into
	 * sparkling garbage, so each pixel averages the whole stretch it covers
	 * (da..db), and the colour fringes are taken from that same soft image:
	 * red bends least, blue most. */
	"  float da = bend(max(depth - 0.5, 0.0), band), db = bend(depth + 0.5, band);\n"
	"  float foot = abs(db - da);\n"
	"  vec3 col;\n"
	"  if (foot < 0.6) {\n"
	"    col = vec3(frosted(base - n * disp * 0.93).r, frosted(base - n * disp).g, frosted(base - n * disp * 1.08).b);\n"
	"  } else {\n"
	/* a little wider than the footprint: neighbouring pixels overlap, no shimmer */
	"    float mid = (da + db) * 0.5, hw = (db - da) * 0.5 * 1.35;\n"
	"    col = vec3(0.0);\n"
	"    for (int k = 0; k < 10; k++) {\n"
	"      float dk = mid + hw * ((float(k) + 0.5) / 5.0 - 1.0);\n"
	"      col += vec3(frosted(base - n * dk * 0.93).r, frosted(base - n * dk).g, frosted(base - n * dk * 1.08).b);\n"
	"    }\n"
	"    col *= 0.1;\n"
	"  }\n"
	"  col = clamp(col, 0.0, 1.0);\n"
/* glass body: slightly brighter and more saturated than what's behind it */
	"  float lum = dot(col, vec3(0.299, 0.587, 0.114));\n"
	"  col = mix(vec3(lum), col, 1.12) * (1.0 + 0.04) + vec3(tint);\n"
	"  col = col * (1.0 - tintc.a) + tintc.rgb;\n"
	"  if (p.y < cap_y) col = col * (1.0 - capc.a) + capc.rgb;\n"   /* titlebar in the app's own colour */
	/* bevel shading: light gathers on the inner slope, the outer slope dims */
	"  col *= 1.0 + 0.10 * smoothstep(0.15, 0.6, x) - 0.12 * smoothstep(0.7, 1.0, x);\n"
	"  col += high * hl;\n"
	"  gl_FragColor = vec4(min(col, vec3(1.0)) * a, a);\n"     /* premultiplied */
	"}\n";

/* separable gaussian (13 taps, linear filtering in between) */
static const char *BFS =
	"precision highp float;\n"
	"uniform sampler2D src;\n"
	"uniform vec2 step;\n"       /* uv offset between taps */
	"uniform vec2 scale_uv;\n"   /* fb px → src uv */
	"uniform vec2 origin;\n"
	"void main() {\n"
	"  vec2 uv = (gl_FragCoord.xy - origin) * scale_uv;\n"
	"  vec3 acc = vec3(0.0);\n"
	"  float ws = 0.0;\n"
	"  for (int k = -6; k <= 6; k++) {\n"
	"    float fk = float(k);\n"
	"    float w = exp(-fk * fk / 18.0);\n"
	"    acc += texture2D(src, uv + step * fk).rgb * w;\n"
	"    ws += w;\n"
	"  }\n"
	"  gl_FragColor = vec4(acc / ws, 1.0);\n"
	"}\n";

static struct {
	bool tried, ok;
	GLuint bprog, fbo, tmp;
	GLuint btex[LIQUID_MAX_SHAPES];
	int tmw, tmh;
	GLint b_pos, b_src, b_step, b_scale, b_org, b_fb, u_btex;
	GLuint prog, vbo;
	GLuint tex[LIQUID_MAX_SHAPES];
	int tw[LIQUID_MAX_SHAPES], th[LIQUID_MAX_SHAPES];
	int ox[LIQUID_MAX_SHAPES], oy[LIQUID_MAX_SHAPES];
	bool have[LIQUID_MAX_SHAPES];
	GLint a_pos, u_fb, u_tex, u_org, u_tsz, u_rect, u_radii, u_bands, u_refr, u_zoom, u_frost,
		u_px, u_spec, u_tint, u_alpha, u_shadow, u_tintc,
		u_mask, u_mrect, u_msrc, u_usemask, u_mthr, u_hl, u_capc, u_capy;
	GLuint smp;      /* 8×1 scratch texture for liquid_gl_sample_row */
} G;

static GLuint compile(GLenum type, const char *src) {
	GLuint sh = glCreateShader(type);
	glShaderSource(sh, 1, &src, NULL);
	glCompileShader(sh);
	GLint ok = 0;
	glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
	if (!ok) {
		char log[1024];
		glGetShaderInfoLog(sh, sizeof(log), NULL, log);
		fprintf(stderr, "lumen: liquid glass shader: %s\n", log);
		glDeleteShader(sh);
		return 0;
	}
	return sh;
}

static bool init(void) {
	if (G.tried) return G.ok;
	G.tried = true;
	GLuint vs = compile(GL_VERTEX_SHADER, VS), fs = compile(GL_FRAGMENT_SHADER, FS);
	if (!vs || !fs) return false;
	G.prog = glCreateProgram();
	glAttachShader(G.prog, vs);
	glAttachShader(G.prog, fs);
	glLinkProgram(G.prog);
	glDeleteShader(vs);
	glDeleteShader(fs);
	GLint ok = 0;
	glGetProgramiv(G.prog, GL_LINK_STATUS, &ok);
	if (!ok) { fprintf(stderr, "lumen: liquid glass: link failed\n"); return false; }
#define U(v, n) G.v = glGetUniformLocation(G.prog, n)
	G.a_pos = glGetAttribLocation(G.prog, "pos");
	U(u_fb, "fb"); U(u_tex, "tex"); U(u_org, "tex_origin"); U(u_tsz, "tex_size"); U(u_rect, "rect");
	U(u_radii, "radii"); U(u_bands, "bands"); U(u_refr, "refr"); U(u_zoom, "zoom"); U(u_frost, "frost");
	U(u_px, "px"); U(u_spec, "spec_amt"); U(u_tint, "tint"); U(u_alpha, "alpha"); U(u_shadow, "shadow");
	U(u_tintc, "tintc"); U(u_mask, "mask"); U(u_mrect, "mask_rect"); U(u_msrc, "mask_src"); U(u_usemask, "use_mask"); U(u_mthr, "mask_thr");
	U(u_hl, "hl"); U(u_capc, "capc"); U(u_capy, "cap_y");
#undef U
	G.u_btex = glGetUniformLocation(G.prog, "btex");
	GLuint bvs = compile(GL_VERTEX_SHADER, VS), bfs = compile(GL_FRAGMENT_SHADER, BFS);
	if (!bvs || !bfs) return false;
	G.bprog = glCreateProgram();
	glAttachShader(G.bprog, bvs);
	glAttachShader(G.bprog, bfs);
	glLinkProgram(G.bprog);
	glDeleteShader(bvs);
	glDeleteShader(bfs);
	glGetProgramiv(G.bprog, GL_LINK_STATUS, &ok);
	if (!ok) { fprintf(stderr, "lumen: liquid glass: blur link failed\n"); return false; }
	G.b_pos = glGetAttribLocation(G.bprog, "pos");
	G.b_src = glGetUniformLocation(G.bprog, "src");
	G.b_step = glGetUniformLocation(G.bprog, "step");
	G.b_scale = glGetUniformLocation(G.bprog, "scale_uv");
	G.b_org = glGetUniformLocation(G.bprog, "origin");
	G.b_fb = glGetUniformLocation(G.bprog, "fb");
	glGenTextures(LIQUID_MAX_SHAPES, G.tex);
	glGenTextures(LIQUID_MAX_SHAPES, G.btex);
	glGenTextures(1, &G.tmp);
	glGenFramebuffers(1, &G.fbo);
	glGenBuffers(1, &G.vbo);
	G.ok = true;
	return true;
}

/* GL state save/restore so the renderer never notices us */
struct saved { GLint prog, tex, tex1, tex2, vbo, active, vp[4], bsrc, bdst, fbo; GLboolean blend, scissor; };

static void save(struct saved *sv) {
	sv->blend = glIsEnabled(GL_BLEND);
	sv->scissor = glIsEnabled(GL_SCISSOR_TEST);
	glGetIntegerv(GL_CURRENT_PROGRAM, &sv->prog);
	glGetIntegerv(GL_ACTIVE_TEXTURE, &sv->active);
	glActiveTexture(GL_TEXTURE2);
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &sv->tex2);
	glActiveTexture(GL_TEXTURE1);
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &sv->tex1);
	glActiveTexture(GL_TEXTURE0);
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &sv->tex);
	glGetIntegerv(GL_FRAMEBUFFER_BINDING, &sv->fbo);
	glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &sv->vbo);
	glGetIntegerv(GL_VIEWPORT, sv->vp);
	glGetIntegerv(GL_BLEND_SRC_RGB, &sv->bsrc);
	glGetIntegerv(GL_BLEND_DST_RGB, &sv->bdst);
}

static void restore(const struct saved *sv) {
	glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)sv->fbo);
	glBindBuffer(GL_ARRAY_BUFFER, (GLuint)sv->vbo);
	glActiveTexture(GL_TEXTURE2);
	glBindTexture(GL_TEXTURE_2D, (GLuint)sv->tex2);
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, (GLuint)sv->tex1);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, (GLuint)sv->tex);
	glActiveTexture((GLenum)sv->active);
	glUseProgram((GLuint)sv->prog);
	glViewport(sv->vp[0], sv->vp[1], sv->vp[2], sv->vp[3]);
	glBlendFunc((GLenum)sv->bsrc, (GLenum)sv->bdst);
	(sv->blend ? glEnable : glDisable)(GL_BLEND);
	(sv->scissor ? glEnable : glDisable)(GL_SCISSOR_TEST);
}

static void tex_alloc(GLuint t, int w, int h, GLenum fmt) {
	glBindTexture(GL_TEXTURE_2D, t);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexImage2D(GL_TEXTURE_2D, 0, fmt, w, h, 0, fmt, GL_UNSIGNED_BYTE, NULL);
}

static void quad(float x0, float y0, float x1, float y1);

/* one gaussian pass: src texture (w×h used of tw×th) → dst texture via our FBO */
static bool blur_pass(GLuint src, int tw, int th, GLuint dst, int w, int h, float dx, float dy) {
	glBindFramebuffer(GL_FRAMEBUFFER, G.fbo);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, dst, 0);
	if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) return false;
	glViewport(0, 0, w, h);
	glBindTexture(GL_TEXTURE_2D, src);
	glUniform2f(G.b_fb, (float)w, (float)h);
	glUniform2f(G.b_step, dx / tw, dy / th);
	glUniform2f(G.b_scale, 1.0f / tw, 1.0f / th);
	glUniform2f(G.b_org, 0, 0);
	quad(0, 0, (float)w, (float)h);
	return true;
}

static float margin_for(const struct liquid_shape *s, const struct liquid_params *prm, float scale) {
	return ceilf(s->frost * prm->frost * scale) + 6;
}

bool liquid_gl_capture(int fb_w, int fb_h, float scale, const struct liquid_shape *shapes, int first, int n,
		const struct liquid_params *prm) {
	if (!init()) return false;
	while (glGetError() != GL_NO_ERROR) {}
	struct saved sv;
	save(&sv);
	glDisable(GL_SCISSOR_TEST);
	bool ok = true;
	for (int i = first; i < first + n && i < LIQUID_MAX_SHAPES; i++) {
		const struct liquid_shape *s = &shapes[i];
		G.have[i] = false;
		float m = margin_for(s, prm, scale);
		int x0 = (int)floorf(s->x - m), y0 = (int)floorf(s->y - m);
		int x1 = (int)ceilf(s->x + s->w + m), y1 = (int)ceilf(s->y + s->h + m);
		if (x0 < 0) x0 = 0;
		if (y0 < 0) y0 = 0;
		if (x1 > fb_w) x1 = fb_w;
		if (y1 > fb_h) y1 = fb_h;
		int cw = x1 - x0, ch = y1 - y0;
		if (cw <= 0 || ch <= 0) continue;
		if (cw > G.tw[i] || ch > G.th[i]) {
			G.tw[i] = cw > G.tw[i] ? cw : G.tw[i];
			G.th[i] = ch > G.th[i] ? ch : G.th[i];
			tex_alloc(G.tex[i], G.tw[i], G.th[i], GL_RGB);
			tex_alloc(G.btex[i], G.tw[i], G.th[i], GL_RGBA);
		}
		glBindTexture(GL_TEXTURE_2D, G.tex[i]);
		glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, x0, y0, cw, ch);
		if (glGetError() != GL_NO_ERROR) { ok = false; break; }
		G.ox[i] = x0;
		G.oy[i] = y0;
		G.have[i] = true;

		/* frost it once, now: horizontal then vertical gaussian */
		float fr = s->frost * prm->frost * scale;
		if (fr >= 0.5f) {
			if (G.tw[i] > G.tmw || G.th[i] > G.tmh) {
				G.tmw = G.tw[i] > G.tmw ? G.tw[i] : G.tmw;
				G.tmh = G.th[i] > G.tmh ? G.th[i] : G.tmh;
				tex_alloc(G.tmp, G.tmw, G.tmh, GL_RGBA);
			}
			glUseProgram(G.bprog);
			glUniform1i(G.b_src, 0);
			glBindBuffer(GL_ARRAY_BUFFER, G.vbo);
			glEnableVertexAttribArray(G.b_pos);
			glVertexAttribPointer(G.b_pos, 2, GL_FLOAT, GL_FALSE, 0, 0);
			glDisable(GL_BLEND);
			float st = fr / 6.0f;   /* 13 taps span ±frost */
			ok = blur_pass(G.tex[i], G.tw[i], G.th[i], G.tmp, cw, ch, st, 0) &&
				blur_pass(G.tmp, G.tmw, G.tmh, G.btex[i], cw, ch, 0, st);
			glDisableVertexAttribArray(G.b_pos);
			glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)sv.fbo);
			if (!ok) break;
		}
	}
	restore(&sv);
	return ok && glGetError() == GL_NO_ERROR;
}

static void quad(float x0, float y0, float x1, float y1) {
	float q[12] = { x0, y0, x1, y0, x0, y1, x1, y0, x1, y1, x0, y1 };
	glBufferData(GL_ARRAY_BUFFER, sizeof(q), q, GL_STREAM_DRAW);
	glDrawArrays(GL_TRIANGLES, 0, 6);
}

static bool draw(int fb_w, int fb_h, float scale, const struct liquid_shape *shapes, int first, int n,
		const struct liquid_params *prm, bool rim_pass) {
	if (!init()) return false;
	while (glGetError() != GL_NO_ERROR) {}
	struct saved sv;
	save(&sv);
	glViewport(0, 0, fb_w, fb_h);
	glDisable(GL_SCISSOR_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);   /* premultiplied */
	glUseProgram(G.prog);
	glActiveTexture(GL_TEXTURE0);
	glUniform1i(G.u_tex, 0);
	glUniform1i(G.u_btex, 1);
	glUniform1i(G.u_mask, 2);
	glUniform2f(G.u_fb, (float)fb_w, (float)fb_h);
	glUniform1f(G.u_px, scale);
	glUniform1f(G.u_spec, prm->specular);
	glUniform1f(G.u_tint, prm->tint);
	glUniform1f(G.u_refr, prm->strength);
	glBindBuffer(GL_ARRAY_BUFFER, G.vbo);
	glEnableVertexAttribArray(G.a_pos);
	glVertexAttribPointer(G.a_pos, 2, GL_FLOAT, GL_FALSE, 0, 0);

	for (int i = first; i < first + n && i < LIQUID_MAX_SHAPES; i++) {
		const struct liquid_shape *s = &shapes[i];
		if (!G.have[i] || s->w < 4 || s->h < 4 || s->alpha <= 0.01f) continue;
		if (rim_pass && !s->rim_over) continue;
		float half = fminf(s->w, s->h) * 0.5f;
		float rad[4], bd[4];
		for (int k = 0; k < 4; k++) {
			rad[k] = fminf(fmaxf(s->radius[k], 0), half);
			bd[k] = fminf(fminf(fmaxf(s->band[k], 0), prm->band * scale), half);
		}
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, G.btex[i]);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, G.tex[i]);
		glUniform2f(G.u_org, (float)G.ox[i], (float)G.oy[i]);
		glUniform2f(G.u_tsz, (float)G.tw[i], (float)G.th[i]);
		glUniform4f(G.u_rect, s->x, s->y, s->w, s->h);
		glUniform4f(G.u_radii, rad[0], rad[1], rad[2], rad[3]);
		glUniform4f(G.u_bands, bd[0], bd[1], bd[2], bd[3]);
		glUniform1f(G.u_alpha, s->alpha);
		glUniform4f(G.u_tintc, s->tint[0], s->tint[1], s->tint[2], s->tint[3]);
		bool um = s->mask_tex && s->mask_target == GL_TEXTURE_2D && !s->measure_only;
		glUniform1f(G.u_usemask, um ? 1 : 0);
		if (um) {
			glActiveTexture(GL_TEXTURE2);
			glBindTexture(GL_TEXTURE_2D, s->mask_tex);
			glActiveTexture(GL_TEXTURE0);
			glUniform4f(G.u_mrect, s->mask_rect[0], s->mask_rect[1], s->mask_rect[2], s->mask_rect[3]);
			glUniform4f(G.u_msrc, s->mask_src[0], s->mask_src[1], s->mask_src[2], s->mask_src[3]);
			glUniform2f(G.u_mthr, s->mask_hi > 0 ? s->mask_lo : 0.015f, s->mask_hi > 0 ? s->mask_hi : 0.08f);
		}
		glUniform1f(G.u_zoom, prm->zoom);
		glUniform1f(G.u_frost, s->frost * prm->frost * scale);
		glUniform1f(G.u_hl, rim_pass ? 2.0f : (s->rim_over ? 0.0f : 1.0f));
		glUniform4f(G.u_capc, s->cap_tint[0], s->cap_tint[1], s->cap_tint[2], s->cap_tint[3]);
		glUniform1f(G.u_capy, s->cap_h > 0 && s->cap_tint[3] > 0 ? s->y + s->cap_h : -1.0f);
		if (s->shadow > 0 && !rim_pass) {
			float m = 34 * scale;
			glUniform1f(G.u_shadow, 0.24f * s->shadow);
			quad(s->x - m, s->y - m, s->x + s->w + m, s->y + s->h + m);
		}
		glUniform1f(G.u_shadow, 0);
		quad(s->x - 1, s->y - 1, s->x + s->w + 1, s->y + s->h + 1);
	}
	glDisableVertexAttribArray(G.a_pos);
	restore(&sv);
	return glGetError() == GL_NO_ERROR;
}

bool liquid_gl_draw(int fb_w, int fb_h, float scale, const struct liquid_shape *shapes, int first, int n,
		const struct liquid_params *prm) {
	return draw(fb_w, fb_h, scale, shapes, first, n, prm, false);
}

bool liquid_gl_draw_rim(int fb_w, int fb_h, float scale, const struct liquid_shape *shapes, int first, int n,
		const struct liquid_params *prm) {
	return draw(fb_w, fb_h, scale, shapes, first, n, prm, true);
}

/* --------------------------------------------------------------------- pour
 * Switching between Frosted and Liquid Glass: for a moment both frames exist,
 * the frosted one (0) and the liquid one (1), and the screen fills with liquid
 * from the bottom (or drains to the bottom): below a rising, sloshing surface
 * you see the liquid frame, above it the frosted one. Light catches the surface
 * where it crosses glass (where the two frames differ), nowhere else. */
static const char *POUR_FS =
	"precision highp float;\n"
	"uniform sampler2D ftex;\n"    /* the frosted frame */
	"uniform sampler2D ltex;\n"    /* the liquid frame */
	"uniform vec2 size;\n"
	"uniform float level;\n"       /* 0 = empty, 1 = full */
	"uniform float slosh;\n"       /* wave height, px */
	"uniform float phase;\n"
	"uniform float px;\n"
	"uniform float glint;\n"       /* strength of the light on the surface */
	"void main() {\n"
	"  vec2 p = gl_FragCoord.xy;\n"
	"  vec2 uv = p / size;\n"
	"  float u = uv.x * (size.x / (1600.0 * px));\n"
	"  float wave = sin(u * 7.0 + phase) * 0.55 + sin(u * 17.0 - phase * 1.6) * 0.25\n"
	"             + sin(u * 3.1 + phase * 0.5) * 0.45;\n"
	"  float surf = mix(size.y + 6.0 * px, -6.0 * px, level) + wave * slosh;\n"   /* y grows downward */
	"  float d = p.y - surf;\n"                                   /* > 0: under the surface */
	"  float under = smoothstep(-px, px, d);\n"
	"  vec3 f = texture2D(ftex, uv).rgb;\n"
	"  vec3 l = texture2D(ltex, uv).rgb;\n"
	"  float glass = clamp(length(f - l) * 16.0, 0.0, 1.0);\n"   /* only glass differs between the two */
	"  float line = exp(-abs(d) / (1.7 * px));\n"
	"  float deep = d > 0.0 ? exp(-d / (10.0 * px)) : 0.0;\n"
	"  vec3 col = mix(f, l, under) + vec3(line * 0.30 + deep * 0.07) * glass * glint;\n"
	"  gl_FragColor = vec4(col, 1.0);\n"
	"}\n";

static struct {
	bool tried, ok;
	GLuint prog, tex[2];
	int w[2], h[2];
	GLint a_pos, u_fb, u_ftex, u_ltex, u_size, u_level, u_slosh, u_phase, u_px, u_glint;
} PG;

static bool pour_init(void) {
	if (!init()) return false;
	if (PG.tried) return PG.ok;
	PG.tried = true;
	GLuint vs = compile(GL_VERTEX_SHADER, VS), fs = compile(GL_FRAGMENT_SHADER, POUR_FS);
	if (!vs || !fs) return false;
	PG.prog = glCreateProgram();
	glAttachShader(PG.prog, vs);
	glAttachShader(PG.prog, fs);
	glLinkProgram(PG.prog);
	glDeleteShader(vs);
	glDeleteShader(fs);
	GLint ok = 0;
	glGetProgramiv(PG.prog, GL_LINK_STATUS, &ok);
	if (!ok) { fprintf(stderr, "lumen: liquid glass: pour link failed\n"); return false; }
	PG.a_pos = glGetAttribLocation(PG.prog, "pos");
	PG.u_fb = glGetUniformLocation(PG.prog, "fb");
	PG.u_ftex = glGetUniformLocation(PG.prog, "ftex");
	PG.u_ltex = glGetUniformLocation(PG.prog, "ltex");
	PG.u_size = glGetUniformLocation(PG.prog, "size");
	PG.u_level = glGetUniformLocation(PG.prog, "level");
	PG.u_slosh = glGetUniformLocation(PG.prog, "slosh");
	PG.u_phase = glGetUniformLocation(PG.prog, "phase");
	PG.u_px = glGetUniformLocation(PG.prog, "px");
	PG.u_glint = glGetUniformLocation(PG.prog, "glint");
	glGenTextures(2, PG.tex);
	PG.ok = true;
	return true;
}

/* keep the frame that is in the bound framebuffer: which = 0 frosted, 1 liquid */
bool liquid_gl_pour_grab(int which, int fb_w, int fb_h) {
	if (which < 0 || which > 1 || fb_w <= 0 || fb_h <= 0 || !pour_init()) return false;
	while (glGetError() != GL_NO_ERROR) {}
	GLint tex0, active;
	glGetIntegerv(GL_ACTIVE_TEXTURE, &active);
	glActiveTexture(GL_TEXTURE0);
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &tex0);
	if (PG.w[which] != fb_w || PG.h[which] != fb_h) {
		tex_alloc(PG.tex[which], fb_w, fb_h, GL_RGB);
		PG.w[which] = fb_w;
		PG.h[which] = fb_h;
	}
	glBindTexture(GL_TEXTURE_2D, PG.tex[which]);
	glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, fb_w, fb_h);
	glBindTexture(GL_TEXTURE_2D, (GLuint)tex0);
	glActiveTexture((GLenum)active);
	return glGetError() == GL_NO_ERROR;
}

/* the two kept frames, poured together into the bound framebuffer.
 * level: how full (0…1); t: progress of the whole pour (0…1), for the waves */
bool liquid_gl_pour_mix(int fb_w, int fb_h, float scale, float level, float t) {
	if (!pour_init() || PG.w[0] != fb_w || PG.h[0] != fb_h || PG.w[1] != fb_w || PG.h[1] != fb_h) return false;
	while (glGetError() != GL_NO_ERROR) {}
	struct saved sv;
	save(&sv);
	glViewport(0, 0, fb_w, fb_h);
	glDisable(GL_SCISSOR_TEST);
	glDisable(GL_BLEND);
	glUseProgram(PG.prog);
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, PG.tex[1]);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, PG.tex[0]);
	glUniform1i(PG.u_ftex, 0);
	glUniform1i(PG.u_ltex, 1);
	glUniform2f(PG.u_fb, (float)fb_w, (float)fb_h);
	glUniform2f(PG.u_size, (float)fb_w, (float)fb_h);
	float calm = sinf(3.14159265f * fminf(fmaxf(t, 0), 1));     /* still at both ends */
	glUniform1f(PG.u_level, level);
	glUniform1f(PG.u_slosh, 11.0f * scale * calm);
	glUniform1f(PG.u_phase, t * 9.0f);
	glUniform1f(PG.u_px, scale);
	glUniform1f(PG.u_glint, fminf(1.0f, calm * 1.6f));
	glBindBuffer(GL_ARRAY_BUFFER, G.vbo);
	glEnableVertexAttribArray(PG.a_pos);
	glVertexAttribPointer(PG.a_pos, 2, GL_FLOAT, GL_FALSE, 0, 0);
	quad(0, 0, (float)fb_w, (float)fb_h);
	glDisableVertexAttribArray(PG.a_pos);
	restore(&sv);
	return glGetError() == GL_NO_ERROR;
}

/* ------------------------------------------------------------------ painter
 * Redraws scene content (rects, client textures) on top of a lensed pane, with
 * SceneFX's rounded corners and clipped holes, premultiplied like the scene. */
#define PAINT_FS_BODY \
	"uniform vec2 fb;\n" \
	"uniform vec4 rect;\n"       /* dst x y w h */ \
	"uniform vec4 radii;\n"      /* tl tr br bl */ \
	"uniform vec4 hole;\n"       /* clipped region x y w h (w = 0: none) */ \
	"uniform vec4 hradii;\n" \
	"uniform vec4 color;\n"      /* premultiplied, rects */ \
	"uniform vec4 src;\n"        /* u0 v0 u1 v1 */ \
	"uniform float mode;\n"      /* 0 rect, 1 texture */ \
	"uniform float opacity;\n" \
	"uniform float has_alpha;\n" \
	"float rbox(vec2 p, vec4 r4, vec4 b) {\n" \
	"  vec2 q = p - (b.xy + b.zw * 0.5);\n" \
	"  float r = q.x > 0.0 ? (q.y > 0.0 ? r4.z : r4.y) : (q.y > 0.0 ? r4.w : r4.x);\n" \
	"  vec2 k = abs(q) - b.zw * 0.5 + vec2(r);\n" \
	"  return min(max(k.x, k.y), 0.0) + length(max(k, 0.0)) - r;\n" \
	"}\n" \
	"void main() {\n" \
	"  vec2 p = gl_FragCoord.xy;\n" \
	"  float m = clamp(0.5 - rbox(p, radii, rect), 0.0, 1.0);\n" \
	"  if (hole.z > 0.0) m *= clamp(0.5 + rbox(p, hradii, hole), 0.0, 1.0);\n" \
	"  vec4 c = color;\n" \
	"  if (mode > 0.5) {\n" \
	"    vec2 t = (p - rect.xy) / rect.zw;\n" \
	"    c = TEX(mix(src.xy, src.zw, t));\n" \
	"    if (has_alpha < 0.5) c.a = 1.0;\n" \
	"    c *= opacity;\n" \
	"  }\n" \
	"  gl_FragColor = c * m;\n" \
	"}\n"

static const char *PFS_2D =
	"precision highp float;\n"
	"uniform sampler2D tex;\n"
	"#define TEX(uv) texture2D(tex, uv)\n"
	PAINT_FS_BODY;

static const char *PFS_EXT =
	"#extension GL_OES_EGL_image_external : require\n"
	"precision highp float;\n"
	"uniform samplerExternalOES tex;\n"
	"#define TEX(uv) texture2D(tex, uv)\n"
	PAINT_FS_BODY;

struct paint_prog {
	GLuint prog;
	GLint pos, fb, tex, rect, radii, hole, hradii, color, src, mode, opacity, has_alpha;
};

static struct {
	bool tried;
	struct paint_prog p2d, pext;
	bool ext_ok;
	struct saved sv;
	int fb_w, fb_h;
	struct paint_prog *cur;
} P;

static bool paint_link(struct paint_prog *pp, const char *fs_src) {
	GLuint vs = compile(GL_VERTEX_SHADER, VS), fs = compile(GL_FRAGMENT_SHADER, fs_src);
	if (!vs || !fs) {
		if (vs) glDeleteShader(vs);
		if (fs) glDeleteShader(fs);
		return false;
	}
	pp->prog = glCreateProgram();
	glAttachShader(pp->prog, vs);
	glAttachShader(pp->prog, fs);
	glLinkProgram(pp->prog);
	glDeleteShader(vs);
	glDeleteShader(fs);
	GLint ok = 0;
	glGetProgramiv(pp->prog, GL_LINK_STATUS, &ok);
	if (!ok) return false;
	pp->pos = glGetAttribLocation(pp->prog, "pos");
#define PU(f, n) pp->f = glGetUniformLocation(pp->prog, n)
	PU(fb, "fb"); PU(tex, "tex"); PU(rect, "rect"); PU(radii, "radii"); PU(hole, "hole");
	PU(hradii, "hradii"); PU(color, "color"); PU(src, "src"); PU(mode, "mode");
	PU(opacity, "opacity"); PU(has_alpha, "has_alpha");
#undef PU
	return true;
}

static bool paint_init(void) {
	if (!init()) return false;
	if (!P.tried) {
		P.tried = true;
		if (!paint_link(&P.p2d, PFS_2D)) return false;
		const char *ext = (const char *)glGetString(GL_EXTENSIONS);
		P.ext_ok = ext && strstr(ext, "GL_OES_EGL_image_external") && paint_link(&P.pext, PFS_EXT);
	}
	return P.p2d.prog != 0;
}

bool liquid_gl_sample_row(unsigned tex, unsigned target, float u0, float u1, float v, float out[4]) {
	enum { N = 5 };
	if (!tex || !paint_init()) return false;
	struct paint_prog *pp = target == GL_TEXTURE_2D ? &P.p2d : (P.ext_ok ? &P.pext : NULL);
	if (!pp) return false;
	while (glGetError() != GL_NO_ERROR) {}
	struct saved sv;
	save(&sv);
	if (!G.smp) {
		glGenTextures(1, &G.smp);
		tex_alloc(G.smp, 8, 1, GL_RGBA);
	}
	unsigned char px[N * 4] = { 0 };
	glBindFramebuffer(GL_FRAMEBUFFER, G.fbo);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, G.smp, 0);
	bool ok = glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
	if (ok) {
		glViewport(0, 0, 8, 1);
		glDisable(GL_BLEND);
		glDisable(GL_SCISSOR_TEST);
		glUseProgram(pp->prog);
		glBindBuffer(GL_ARRAY_BUFFER, G.vbo);
		glEnableVertexAttribArray(pp->pos);
		glVertexAttribPointer(pp->pos, 2, GL_FLOAT, GL_FALSE, 0, 0);
		glUniform2f(pp->fb, 8.0f, 1.0f);
		glUniform1i(pp->tex, 0);
		glUniform4f(pp->radii, 0, 0, 0, 0);
		glUniform4f(pp->hole, 0, 0, 0, 0);
		glUniform4f(pp->hradii, 0, 0, 0, 0);
		glUniform1f(pp->mode, 1);
		glUniform1f(pp->opacity, 1);
		glUniform1f(pp->has_alpha, 1);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture((GLenum)target, (GLuint)tex);
		glTexParameteri((GLenum)target, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri((GLenum)target, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		/* texel i: a point a little in from the left edge … a little in from the right */
		static const float at[N] = { 0.004f, 0.25f, 0.5f, 0.75f, 0.996f };
		for (int i = 0; i < N; i++) {
			float u = u0 + (u1 - u0) * at[i];
			glUniform4f(pp->rect, (float)i, 0, 1, 1);
			glUniform4f(pp->src, u, v, u, v);
			quad((float)i, 0, (float)i + 1, 1);
		}
		glDisableVertexAttribArray(pp->pos);
		glReadPixels(0, 0, N, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);
		glBindTexture((GLenum)target, 0);
	}
	restore(&sv);
	ok = ok && glGetError() == GL_NO_ERROR;
	while (glGetError() != GL_NO_ERROR) {}
	if (!ok) return false;
	/* the colour most of them agree on (text or a tab under one sample doesn't win) */
	int best = 0, best_n = 0;
	for (int i = 0; i < N; i++) {
		int same = 0;
		for (int j = 0; j < N; j++) {
			int dd = 0;
			for (int c = 0; c < 4; c++) dd += abs((int)px[i * 4 + c] - (int)px[j * 4 + c]);
			if (dd <= 6) same++;
		}
		if (same > best_n) { best_n = same; best = i; }
	}
	if (best_n < 3) return false;          /* no clear background: leave the titlebar alone */
	for (int c = 0; c < 4; c++) out[c] = px[best * 4 + c] / 255.0f;
	return true;
}

bool liquid_gl_paint_begin(int fb_w, int fb_h) {
	if (!paint_init()) return false;
	while (glGetError() != GL_NO_ERROR) {}
	save(&P.sv);
	P.fb_w = fb_w;
	P.fb_h = fb_h;
	P.cur = NULL;
	glViewport(0, 0, fb_w, fb_h);
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_SCISSOR_TEST);
	glBindBuffer(GL_ARRAY_BUFFER, G.vbo);
	glActiveTexture(GL_TEXTURE0);
	return true;
}

static void use(struct paint_prog *pp) {
	if (P.cur == pp) return;
	if (P.cur) glDisableVertexAttribArray(P.cur->pos);
	P.cur = pp;
	glUseProgram(pp->prog);
	glEnableVertexAttribArray(pp->pos);
	glVertexAttribPointer(pp->pos, 2, GL_FLOAT, GL_FALSE, 0, 0);
	glUniform2f(pp->fb, (float)P.fb_w, (float)P.fb_h);
	glUniform1i(pp->tex, 0);
}

static void common(struct paint_prog *pp, const struct liquid_paint *pt, const struct liquid_clip *clip) {
	glScissor(clip->x, clip->y, clip->w, clip->h);
	glUniform4f(pp->rect, pt->x, pt->y, pt->w, pt->h);
	glUniform4f(pp->radii, pt->radius[0], pt->radius[1], pt->radius[2], pt->radius[3]);
	glUniform4f(pp->hole, pt->hole[0], pt->hole[1], pt->hole[2], pt->hole[3]);
	glUniform4f(pp->hradii, pt->hole_radius[0], pt->hole_radius[1], pt->hole_radius[2], pt->hole_radius[3]);
}

void liquid_gl_paint_rect(const struct liquid_paint *pt, const float color[4], const struct liquid_clip *clip) {
	struct paint_prog *pp = &P.p2d;
	use(pp);
	common(pp, pt, clip);
	glUniform1f(pp->mode, 0);
	glUniform4f(pp->color, color[0], color[1], color[2], color[3]);
	quad(pt->x - 1, pt->y - 1, pt->x + pt->w + 1, pt->y + pt->h + 1);
}

bool liquid_gl_paint_texture(const struct liquid_paint *pt, unsigned tex, unsigned target, bool has_alpha,
		const float src[4], float opacity, const struct liquid_clip *clip) {
	struct paint_prog *pp = target == GL_TEXTURE_2D ? &P.p2d : (P.ext_ok ? &P.pext : NULL);
	if (!pp) return false;
	use(pp);
	common(pp, pt, clip);
	glBindTexture((GLenum)target, (GLuint)tex);
	glTexParameteri((GLenum)target, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri((GLenum)target, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glUniform1f(pp->mode, 1);
	glUniform4f(pp->src, src[0], src[1], src[2], src[3]);
	glUniform1f(pp->opacity, opacity);
	glUniform1f(pp->has_alpha, has_alpha ? 1 : 0);
	quad(pt->x, pt->y, pt->x + pt->w, pt->y + pt->h);
	return true;
}

bool liquid_gl_paint_end(void) {
	if (P.cur) glDisableVertexAttribArray(P.cur->pos);
	P.cur = NULL;
	restore(&P.sv);
	return glGetError() == GL_NO_ERROR;
}

/* How round are an app's own corners? Read a small block of its texture at the
 * top-left of its window geometry and find where the drawn edge starts along
 * the diagonal: for a circular corner of radius r that is at k = r(1 - 1/√2). */
float liquid_gl_corner_radius(unsigned key, unsigned tex, int x, int y, int max_r) {
	static struct { unsigned key; int x, y; float r; } cache[16];
	static int next;
	for (int i = 0; i < 16; i++)
		if (cache[i].key == key && cache[i].x == x && cache[i].y == y) return cache[i].r;
	if (!init()) return -1;
	int n = max_r > 64 ? 64 : max_r;
	if (n < 4) return -1;
	GLint old_fbo;
	glGetIntegerv(GL_FRAMEBUFFER_BINDING, &old_fbo);
	glBindFramebuffer(GL_FRAMEBUFFER, G.fbo);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
	float r = -1;
	if (glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE) {
		unsigned char px[64 * 64 * 4];
		glReadPixels(x, y, n, n, GL_RGBA, GL_UNSIGNED_BYTE, px);
		if (glGetError() == GL_NO_ERROR) {
#define A(cx, cy) px[((cy) * n + (cx)) * 4 + 3]
			/* how opaque is the app's body along its straight edges (away from the
			 * corner)? Translucent apps can be far below 50%, and a soft shadow in
			 * the corner must not count as window — so the edge is where the alpha
			 * reaches half of the body's own. */
			int body = 0;
			for (int i = n / 2; i < n; i++) {
				if (A(i, 1) > body) body = A(i, 1);
				if (A(1, i) > body) body = A(1, i);
			}
			if (body >= 6) {
				int th = body / 2 > 3 ? body / 2 : 3;
				int k = 0;
				while (k < n && A(k, k) < th) k++;
				if (k < n) r = k / (1.0f - 0.70710678f);
			}
#undef A
		}
	}
	glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)old_fbo);
	while (glGetError() != GL_NO_ERROR) {}
	cache[next].key = key; cache[next].x = x; cache[next].y = y; cache[next].r = r;
	next = (next + 1) % 16;
	return r;
}

/* external (dmabuf) textures can't be read back or sampled by the lens shader:
 * draw them once into a 2D texture with the painter's OES program */
unsigned liquid_gl_to_2d(int slot, unsigned tex, unsigned target, int w, int h) {
	static GLuint t2d[LIQUID_MAX_SHAPES];
	static int tw[LIQUID_MAX_SHAPES], th[LIQUID_MAX_SHAPES];
	if (slot < 0 || slot >= LIQUID_MAX_SHAPES || w <= 0 || h <= 0 || w > 16384 || h > 16384) return 0;
	if (target == GL_TEXTURE_2D) return tex;
	if (!paint_init() || !P.ext_ok) return 0;
	while (glGetError() != GL_NO_ERROR) {}
	struct saved sv;
	save(&sv);
	if (!t2d[slot]) glGenTextures(1, &t2d[slot]);
	if (tw[slot] != w || th[slot] != h) {
		tex_alloc(t2d[slot], w, h, GL_RGBA);
		tw[slot] = w; th[slot] = h;
	}
	glBindFramebuffer(GL_FRAMEBUFFER, G.fbo);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, t2d[slot], 0);
	bool ok = glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
	if (ok) {
		struct paint_prog *pp = &P.pext;
		glViewport(0, 0, w, h);
		glDisable(GL_BLEND);
		glDisable(GL_SCISSOR_TEST);
		glUseProgram(pp->prog);
		glBindBuffer(GL_ARRAY_BUFFER, G.vbo);
		glEnableVertexAttribArray(pp->pos);
		glVertexAttribPointer(pp->pos, 2, GL_FLOAT, GL_FALSE, 0, 0);
		glUniform2f(pp->fb, (float)w, (float)h);
		glUniform1i(pp->tex, 0);
		glUniform4f(pp->rect, 0, 0, (float)w, (float)h);
		glUniform4f(pp->radii, 0, 0, 0, 0);
		glUniform4f(pp->hole, 0, 0, 0, 0);
		glUniform4f(pp->hradii, 0, 0, 0, 0);
		glUniform1f(pp->mode, 1);
		glUniform4f(pp->src, 0, 0, 1, 1);
		glUniform1f(pp->opacity, 1);
		glUniform1f(pp->has_alpha, 1);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture((GLenum)target, (GLuint)tex);
		glTexParameteri((GLenum)target, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri((GLenum)target, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		quad(0, 0, (float)w, (float)h);
		glDisableVertexAttribArray(pp->pos);
		glBindTexture((GLenum)target, 0);
	}
	restore(&sv);
	ok = ok && glGetError() == GL_NO_ERROR;
	return ok ? t2d[slot] : 0;
}
