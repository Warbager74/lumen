/* Lumen compositor entry point: backend, renderer, outputs, protocols. */
#include <dlfcn.h>
#include <fcntl.h>
#include <math.h>
#include <getopt.h>
#include <signal.h>
#include <execinfo.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include <scenefx/render/fx_renderer/fx_renderer.h>
#include <wlr/render/swapchain.h>
#include <wlr/types/wlr_compositor.h>
#include <wlr/types/wlr_data_control_v1.h>
#include <wlr/types/wlr_data_device.h>
#include <wlr/types/wlr_export_dmabuf_v1.h>
#include <wlr/types/wlr_fractional_scale_v1.h>
#include <wlr/types/wlr_gamma_control_v1.h>
#include <wlr/types/wlr_idle_inhibit_v1.h>
#include <wlr/types/wlr_idle_notify_v1.h>
#include <wlr/types/wlr_linux_dmabuf_v1.h>
#include <wlr/types/wlr_pointer_gestures_v1.h>
#include <wlr/types/wlr_presentation_time.h>
#include <wlr/types/wlr_primary_selection_v1.h>
#include <wlr/types/wlr_screencopy_v1.h>
#include <wlr/types/wlr_single_pixel_buffer_v1.h>
#include <wlr/types/wlr_subcompositor.h>
#include <wlr/types/wlr_viewporter.h>
#include <wlr/types/wlr_xdg_output_v1.h>
#include <wlr/util/log.h>
#include "lumen.h"

struct lumen_server *g_server;

void spawn(const char *cmd) {
	if (!cmd || !*cmd) return;
	pid_t pid = fork();
	if (pid == 0) {
		/* double fork so children are reparented and never become zombies */
		setsid();
		sigset_t set;
		sigemptyset(&set);
		sigprocmask(SIG_SETMASK, &set, NULL);
		/* apps start with ordinary signal behaviour, not ours */
		signal(SIGCHLD, SIG_DFL);
		signal(SIGPIPE, SIG_DFL);
		signal(SIGTERM, SIG_DFL);
		signal(SIGINT, SIG_DFL);
		signal(SIGHUP, SIG_DFL);
		if (fork() == 0) {
			execl("/bin/sh", "/bin/sh", "-c", cmd, (char *)NULL);
			_exit(127);
		}
		_exit(0);
	}
	if (pid > 0) waitpid(pid, NULL, 0);
}

void schedule_frames(struct lumen_server *s) {
	struct lumen_output *o;
	wl_list_for_each(o, &s->outputs, link) wlr_output_schedule_frame(o->wlr_output);
}

struct lumen_output *output_at(struct lumen_server *s, double x, double y) {
	struct wlr_output *wo = wlr_output_layout_output_at(s->output_layout, x, y);
	return wo ? wo->data : NULL;
}

struct lumen_output *output_focused(struct lumen_server *s) {
	struct lumen_output *o = s->cursor ? output_at(s, s->cursor->x, s->cursor->y) : NULL;
	if (!o && !wl_list_empty(&s->outputs)) o = wl_container_of(s->outputs.next, o, link);
	return o;
}

/* ------------------------------------------------------------------ outputs */
/* every blur node in the scene (to switch them off for one screen's frame) */
#define MAX_BLURS 256
static struct wlr_scene_blur *blurs[MAX_BLURS];
static float blur_alpha[MAX_BLURS];
static int nblurs;
static void collect_blurs(struct wlr_scene_node *n) {
	if (!n->enabled) return;
	if (n->type == WLR_SCENE_NODE_TREE) {
		struct wlr_scene_node *c;
		wl_list_for_each(c, &wlr_scene_tree_from_node(n)->children, link) collect_blurs(c);
	} else if (n->type == WLR_SCENE_NODE_BLUR && nblurs < MAX_BLURS) {
		blurs[nblurs++] = wlr_scene_blur_from_node(n);
	}
}

static void output_frame(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_output *o = wl_container_of(l, o, frame);
	bool more = anim_tick();
	workspace_strip_refresh(o->server);   /* a window left hanging over the edge shows next door too */
	bool rotated = o->wlr_output->transform != WL_OUTPUT_TRANSFORM_NORMAL;
	/* SceneFX's blur mishandles partial redraws (stale blue/teal blocks where
	 * the cursor or a clock changed): redraw whole frames when anything changed */
	if ((rotated || o->server->cfg.blur_full_redraw) && wlr_scene_output_needs_frame(o->scene_output))
		wlr_damage_ring_add_whole(&o->scene_output->damage_ring);
	if (rotated || o->server->cfg.performance_mode) {
		/* …and on a rotated screen it samples the wrong place altogether: draw
		 * this screen's glass without blur (tinted only). The alpha is set on the
		 * nodes directly, so nothing else gets damaged or redrawn. */
		nblurs = 0;
		collect_blurs(&o->server->scene->tree.node);
		for (int i = 0; i < nblurs; i++) { blur_alpha[i] = blurs[i]->alpha; blurs[i]->alpha = 0; }
		liquid_output_commit(o);
		for (int i = 0; i < nblurs; i++) blurs[i]->alpha = blur_alpha[i];
	} else {
		liquid_output_commit(o);
	}
	struct timespec now;
	clock_gettime(CLOCK_MONOTONIC, &now);
	wlr_scene_output_send_frame_done(o->scene_output, &now);
	if (more) schedule_frames(o->server);
}

static void update_output_box(struct lumen_output *o) {
	wlr_output_layout_get_box(o->server->output_layout, o->wlr_output, &o->full);
	if (wlr_box_empty(&o->usable) || !wlr_box_contains_point(&o->full, o->usable.x, o->usable.y))
		o->usable = o->full;
	arrange_layers(o);
	lock_outputs_changed();
	workspace_output_moved(o);   /* rotated / moved / new resolution: windows follow */
}

static void output_request_state(struct wl_listener *l, void *data) {
	struct lumen_output *o = wl_container_of(l, o, request_state);
	const struct wlr_output_event_request_state *e = data;
	wlr_output_commit_state(o->wlr_output, e->state);
	outputs_refresh(o->server);
}

static void output_destroy(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_output *o = wl_container_of(l, o, destroy);
	/* anything in flight on this screen ends now (it is about to be freed) */
	workspace_output_gone(o);
	if (switcher_active()) switcher_cancel();
	snap_cancel(o->server);
	for (int i = 0; i < 4; i++) {
		struct lumen_layer_surface *ls, *tmp;
		wl_list_for_each_safe(ls, tmp, &o->layers[i], link) {
			ls->output = NULL;
			wlr_layer_surface_v1_destroy(ls->layer_surface);
		}
	}
	wl_list_remove(&o->frame.link);
	wl_list_remove(&o->request_state.link);
	wl_list_remove(&o->destroy.link);
	wl_list_remove(&o->link);
	if (o->liquid_sc) wlr_swapchain_destroy(o->liquid_sc);
	struct lumen_server *s = o->server;
	free(o);
	outputs_refresh(s);   /* the others may re-flow into the gap */
}

/* ------------------------------------------------- per-monitor settings
 * lumen.conf:  output = NAME mode=WxH@HZ scale=1.25 transform=90 pos=X,Y
 * (transform: 0 landscape, 90 portrait, 180, 270 portrait flipped) */
static const char *output_conf(struct lumen_server *s, const char *name) {
	size_t n = strlen(name);
	for (int i = 0; i < s->cfg.output_count; i++)
		if (!strncmp(s->cfg.outputs[i], name, n) && (s->cfg.outputs[i][n] == ' ' || !s->cfg.outputs[i][n]))
			return s->cfg.outputs[i] + n;
	return NULL;
}

static enum wl_output_transform parse_transform(int deg, bool flipped) {
	enum wl_output_transform t = deg == 90 ? WL_OUTPUT_TRANSFORM_90 : deg == 180 ? WL_OUTPUT_TRANSFORM_180 :
		deg == 270 ? WL_OUTPUT_TRANSFORM_270 : WL_OUTPUT_TRANSFORM_NORMAL;
	if (flipped) t = (enum wl_output_transform)(t + 4);
	return t;
}

/* fill `st` from the config line; returns true when a position was given */
static bool output_conf_state(struct wlr_output *wo, const char *conf, struct wlr_output_state *st, int *px, int *py) {
	bool pos = false;
	if (!conf) return false;
	char buf[160];
	snprintf(buf, sizeof(buf), "%s", conf);
	char *save = NULL;
	for (char *tok = strtok_r(buf, " ", &save); tok; tok = strtok_r(NULL, " ", &save)) {
		int w, h, x, y; float hz = 0, sc; int deg;
		if (sscanf(tok, "mode=%dx%d@%f", &w, &h, &hz) >= 2) {
			struct wlr_output_mode *m, *best = NULL;
			wl_list_for_each(m, &wo->modes, link)
				if (m->width == w && m->height == h &&
						(!best || (hz > 0 ? fabsf(m->refresh / 1000.f - hz) < fabsf(best->refresh / 1000.f - hz)
							: m->refresh > best->refresh)))
					best = m;
			if (best) wlr_output_state_set_mode(st, best);
		} else if (sscanf(tok, "scale=%f", &sc) == 1 && sc >= 0.5f && sc <= 4) {
			wlr_output_state_set_scale(st, sc);
		} else if (sscanf(tok, "transform=%d", &deg) == 1) {
			/* mirrored only with an "f" right after the number ("transform=90f"): the
			 * word "transform" has an f in it, which used to mirror every screen */
			const char *num = tok + strlen("transform=");
			while (*num == '-' || (*num >= '0' && *num <= '9')) num++;
			wlr_output_state_set_transform(st, parse_transform(deg, *num == 'f'));
		} else if (sscanf(tok, "pos=%d,%d", &x, &y) == 2) {
			*px = x; *py = y; pos = true;
		} else if (!strcmp(tok, "disable")) {
			wlr_output_state_set_enabled(st, false);
		}
	}
	return pos;
}

/* Monitors must never overlap (a rotated screen got wider/taller and slid under
 * its neighbour: "cut off"). Walk them left → right and push any that overlap an
 * earlier one to the right edge of it, keeping their height. */
static void resolve_overlaps(struct lumen_server *s) {
	struct lumen_output *list[16];
	int n = 0;
	struct lumen_output *o;
	wl_list_for_each(o, &s->outputs, link) {
		if (n >= 16 || !o->wlr_output->enabled) continue;
		wlr_output_layout_get_box(s->output_layout, o->wlr_output, &o->full);
		if (!wlr_box_empty(&o->full)) list[n++] = o;
	}
	for (int i = 1; i < n; i++)    /* by x, then y */
		for (int j = i; j > 0 && (list[j]->full.x < list[j - 1]->full.x ||
				(list[j]->full.x == list[j - 1]->full.x && list[j]->full.y < list[j - 1]->full.y)); j--) {
			struct lumen_output *t = list[j]; list[j] = list[j - 1]; list[j - 1] = t;
		}
	for (int i = 1; i < n; i++) {
		for (int pass = 0; pass < 16; pass++) {
			bool moved = false;
			for (int j = 0; j < i; j++) {
				struct wlr_box a = list[i]->full, b = list[j]->full, x;
				if (!wlr_box_intersection(&x, &a, &b)) continue;
				list[i]->full.x = b.x + b.width;
				wlr_output_layout_add(s->output_layout, list[i]->wlr_output, list[i]->full.x, list[i]->full.y);
				moved = true;
			}
			if (!moved) break;
		}
	}
}

/* any monitor changed: every monitor's box may have moved (auto-placed ones
 * re-flow when a neighbour rotates), so refresh them all */
void outputs_refresh(struct lumen_server *s) {
	resolve_overlaps(s);
	struct lumen_output *o;
	wl_list_for_each(o, &s->outputs, link) update_output_box(o);
	workspace_strip_sync(s);
	schedule_frames(s);
	ipc_state_changed(s);
}

void outputs_apply_config(struct lumen_server *s) {
	struct lumen_output *o;
	wl_list_for_each(o, &s->outputs, link) {
		const char *conf = output_conf(s, o->wlr_output->name);
		if (!conf) continue;
		struct wlr_output_state st;
		wlr_output_state_init(&st);
		int x = 0, y = 0;
		bool pos = output_conf_state(o->wlr_output, conf, &st, &x, &y);
		if (st.committed) wlr_output_commit_state(o->wlr_output, &st);
		wlr_output_state_finish(&st);
		if (pos) wlr_output_layout_add(s->output_layout, o->wlr_output, x, y);
	}
	outputs_refresh(s);
}

static void new_output(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, new_output);
	struct wlr_output *wo = data;
	wlr_output_init_render(wo, s->allocator, s->renderer);

	struct wlr_output_state st;
	wlr_output_state_init(&st);
	wlr_output_state_set_enabled(&st, true);
	struct wlr_output_mode *mode = wlr_output_preferred_mode(wo);
	if (mode) wlr_output_state_set_mode(&st, mode);
	else {
		/* headless / nested outputs have no modes: LUMEN_MODE=WxH (default 1920x1080) */
		int w = 1920, h = 1080;
		const char *m = getenv("LUMEN_MODE");
		if (m) sscanf(m, "%dx%d", &w, &h);
		wlr_output_state_set_custom_mode(&st, w, h, 0);
	}
	/* HiDPI panels get 1.5x by default, override with LUMEN_SCALE */
	const char *sc = getenv("LUMEN_SCALE");
	if (sc) wlr_output_state_set_scale(&st, strtof(sc, NULL));
	else if (mode && mode->width >= 2560 && wo->phys_width > 0 && wo->phys_width < 400)
		wlr_output_state_set_scale(&st, 1.5f);
	int px = 0, py = 0;
	bool has_pos = output_conf_state(wo, output_conf(s, wo->name), &st, &px, &py);
	if (!wlr_output_commit_state(wo, &st) && mode) {
		/* the saved mode was refused: fall back to the preferred one */
		wlr_output_state_finish(&st);
		wlr_output_state_init(&st);
		wlr_output_state_set_enabled(&st, true);
		wlr_output_state_set_mode(&st, mode);
		wlr_output_commit_state(wo, &st);
	}
	wlr_output_state_finish(&st);

	struct lumen_output *o = calloc(1, sizeof(*o));
	o->server = s;
	/* each monitor shows its own workspace: the first one nobody shows */
	o->ws = 0;
	for (int i = 0; i < LUMEN_WORKSPACES; i++)
		if (!output_showing(s, i)) { o->ws = i; break; }
	o->wlr_output = wo;
	wo->data = o;
	for (int i = 0; i < 4; i++) wl_list_init(&o->layers[i]);
	o->frame.notify = output_frame;
	wl_signal_add(&wo->events.frame, &o->frame);
	o->request_state.notify = output_request_state;
	wl_signal_add(&wo->events.request_state, &o->request_state);
	o->destroy.notify = output_destroy;
	wl_signal_add(&wo->events.destroy, &o->destroy);
	wl_list_insert(&s->outputs, &o->link);

	struct wlr_output_layout_output *lo = has_pos
		? wlr_output_layout_add(s->output_layout, wo, px, py)
		: wlr_output_layout_add_auto(s->output_layout, wo);
	o->scene_output = wlr_scene_output_create(s->scene, wo);
	wlr_scene_output_layout_add_output(s->scene_layout, lo, o->scene_output);
	outputs_refresh(s);
	if (s->ws_home[o->ws].width == 0) s->ws_home[o->ws] = o->full;
	for (int i = 0; i < LUMEN_WORKSPACES; i++)   /* unclaimed workspaces live on the first monitor */
		if (s->ws_home[i].width == 0) s->ws_home[i] = o->full;
	workspace_strip_sync(s);
	ipc_state_changed(s);
}

/* --------------------------------------------------------------------- main */
static void crash_handler(int sig) {
	static const char msg[] = "\n*** lumen crashed — backtrace (send this to the developer):\n";
	if (write(STDERR_FILENO, msg, sizeof(msg) - 1) < 0) { /* nothing to do */ }
	void *frames[64];
	int n = backtrace(frames, 64);
	backtrace_symbols_fd(frames, n, STDERR_FILENO);
	signal(sig, SIG_DFL);   /* and still dump core for coredumpctl */
	raise(sig);
}

static void autostart(struct lumen_server *s) {
	if (s->cfg.autostart_count == 0) {
		/* sensible defaults: our own shell (it is also the notification service) + portals */
		spawn("lumen-shell");
		spawn("dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP LUMEN_SOCK");
	}
	/* always: give the portals our environment (screen sharing needs it) */
	spawn("lumen-portals");
	/* Files and Settings wait in the background (≈60 MB each), so they open
	 * instantly; started a few seconds in, at low priority, to keep login quick */
	if (s->cfg.preload_apps)
		spawn("sleep 4; nice -n 10 lumen-files --service & nice -n 10 lumen-settings --service &");
	/* The desktop first: the shell gets the first second of the session to
	 * itself. Tray applets, the password agent and the rest of the list start
	 * right behind it instead of competing with it for the disk and the CPU
	 * while the bars are coming up. */
	for (int pass = 0; pass < 2; pass++) {
		for (int i = 0; i < s->cfg.autostart_count; i++) {
			const char *cmd = s->cfg.autostart[i];
			/* the shell handles notifications now: an old "mako …" line would fight it */
			if (!strncmp(cmd, "mako", 4)) continue;
			bool first = !strncmp(cmd, "lumen-shell", 11) || !strncmp(cmd, "dbus-update-activation-environment", 34);
			if (first != (pass == 0)) continue;
			if (first) { spawn(cmd); continue; }
			char later[1100];
			snprintf(later, sizeof(later), "sleep 1; %s", cmd);
			spawn(later);
		}
	}
}

/* Asked to stop from outside (the login manager ending the session, shutdown,
 * a plain `kill`): leave through the normal way out, so the glass marker and
 * the socket are put away. Without this the process just died where it stood,
 * and the next login could find the marker and start in frosted mode "after a
 * crash" that never happened. (A pipe, not a signalfd: nothing our children
 * inherit changes.) */
static int term_pipe[2] = { -1, -1 };

static void on_term_signal(int sig) {
	(void)sig;
	if (term_pipe[1] >= 0) {
		char c = 1;
		ssize_t r = write(term_pipe[1], &c, 1);
		(void)r;
	}
}

static int on_term_event(int fd, uint32_t mask, void *data) {
	(void)mask;
	char buf[16];
	ssize_t r = read(fd, buf, sizeof(buf));
	(void)r;
	wl_display_terminate(data);
	return 0;
}

int main(int argc, char *argv[]) {
	const char *startup = NULL;
	enum wlr_log_importance lvl = WLR_ERROR;
	int c;
	while ((c = getopt(argc, argv, "s:dvh")) != -1) {
		switch (c) {
		case 's': startup = optarg; break;
		case 'd': lvl = WLR_DEBUG; break;
		case 'v': printf("lumen " LUMEN_VERSION "\n"); return 0;
		default:
			printf("Usage: lumen [-s startup-cmd] [-d]\n");
			return 0;
		}
	}
	wlr_log_init(lvl, NULL);

	/* SceneFX must own the wlr_scene_* symbols (it must be linked before wlroots).
	 * A mis-linked build would mix two scene implementations and corrupt memory. */
	Dl_info di;
	if (dladdr((void *)wlr_scene_create, &di) && di.dli_fname && !strstr(di.dli_fname, "scenefx")) {
		fprintf(stderr, "lumen: wlr_scene_create resolves to %s, not SceneFX.\n"
			"This build is mis-linked (scenefx must precede wlroots); refusing to start.\n",
			di.dli_fname);
		return 1;
	}
	/* a crash leaves a backtrace in the session log (~/.local/state/lumen/lumen.log) */
	signal(SIGSEGV, crash_handler);
	signal(SIGABRT, crash_handler);
	signal(SIGBUS, crash_handler);
	signal(SIGFPE, crash_handler);
	signal(SIGCHLD, SIG_IGN);
	signal(SIGPIPE, SIG_IGN);

	static struct lumen_server server = {0};
	struct lumen_server *s = &server;
	g_server = s;
	config_load(&s->cfg);
	anim_init();

	s->display = wl_display_create();
	s->loop = wl_display_get_event_loop(s->display);
	if (pipe2(term_pipe, O_CLOEXEC | O_NONBLOCK) == 0) {
		wl_event_loop_add_fd(s->loop, term_pipe[0], WL_EVENT_READABLE, on_term_event, s->display);
		signal(SIGTERM, on_term_signal);
		signal(SIGINT, on_term_signal);
		signal(SIGHUP, on_term_signal);
	}
	s->backend = wlr_backend_autocreate(s->loop, &s->session);
	if (!s->backend) { wlr_log(WLR_ERROR, "no backend"); return 1; }
	s->renderer = fx_renderer_create(s->backend);
	if (!s->renderer) { wlr_log(WLR_ERROR, "SceneFX renderer failed (needs GLES2)"); return 1; }
	wlr_renderer_init_wl_display(s->renderer, s->display);
	s->allocator = wlr_allocator_autocreate(s->backend, s->renderer);
	if (!s->allocator) { wlr_log(WLR_ERROR, "no allocator"); return 1; }

	s->compositor = wlr_compositor_create(s->display, 6, s->renderer);
	wlr_subcompositor_create(s->display);
	wlr_data_device_manager_create(s->display);
	wlr_primary_selection_v1_device_manager_create(s->display);
	wlr_data_control_manager_v1_create(s->display);
	wlr_viewporter_create(s->display);
	wlr_single_pixel_buffer_manager_v1_create(s->display);
	wlr_fractional_scale_manager_v1_create(s->display, 1);
	wlr_export_dmabuf_manager_v1_create(s->display);
	wlr_screencopy_manager_v1_create(s->display);
	wlr_presentation_create(s->display, s->backend, 2);
	s->idle_notifier = wlr_idle_notifier_v1_create(s->display);
	s->pointer_gestures = wlr_pointer_gestures_v1_create(s->display);
	wlr_idle_inhibit_v1_create(s->display);

	s->output_layout = wlr_output_layout_create(s->display);
	wlr_xdg_output_manager_v1_create(s->display, s->output_layout);
	wl_list_init(&s->outputs);
	s->new_output.notify = new_output;
	wl_signal_add(&s->backend->events.new_output, &s->new_output);

	s->scene = wlr_scene_create();
	s->scene_layout = wlr_scene_attach_output_layout(s->scene, s->output_layout);
	if (wlr_renderer_get_texture_formats(s->renderer, WLR_BUFFER_CAP_DMABUF)) {
		struct wlr_linux_dmabuf_v1 *dmabuf =
			wlr_linux_dmabuf_v1_create_with_renderer(s->display, 4, s->renderer);
		if (dmabuf) wlr_scene_set_linux_dmabuf_v1(s->scene, dmabuf);
	}
	wlr_scene_set_gamma_control_manager_v1(s->scene,
		wlr_gamma_control_manager_v1_create(s->display));
	apply_blur(s);

	for (int i = 0; i < L_COUNT; i++) {
		s->layer[i] = wlr_scene_tree_create(&s->scene->tree);
		if (i == L_WS) {
			for (int w = 0; w < LUMEN_WORKSPACES; w++) {
				s->ws_tree[w] = wlr_scene_tree_create(s->layer[L_WS]);
				wlr_scene_node_set_enabled(&s->ws_tree[w]->node, w == 0);
			}
		}
	}

	views_init(s);
	layers_init(s);
	input_init(s);
	overview_init(s);
	switcher_init(s);
	lock_init(s);
	snap_init(s);
	liquid_startup_check(s);

	const char *sock = wl_display_add_socket_auto(s->display);
	if (!sock) { wlr_backend_destroy(s->backend); return 1; }
	setenv("WAYLAND_DISPLAY", sock, 1);
	setenv("XDG_CURRENT_DESKTOP", "Lumen", 1);
	setenv("XDG_SESSION_DESKTOP", "lumen", 1);
	setenv("XDG_SESSION_TYPE", "wayland", 1);
	setenv("MOZ_ENABLE_WAYLAND", "1", 1);
	setenv("QT_QPA_PLATFORM", "wayland;xcb", 0);
	setenv("SDL_VIDEODRIVER", "wayland", 0);
	setenv("_JAVA_AWT_WM_NONREPARENTING", "1", 1);
	setenv("MOZ_DBUS_REMOTE", "1", 0);   /* Firefox: reach the running instance (new tab / window) */
	unsetenv("DISPLAY");
	xwayland_init(s);   /* sets DISPLAY when enabled */

	if (!wlr_backend_start(s->backend)) {
		wlr_backend_destroy(s->backend);
		wl_display_destroy(s->display);
		return 1;
	}
	ipc_init(s);
	if (startup) spawn(startup);
	else autostart(s);

	wlr_log(WLR_INFO, "Lumen running on WAYLAND_DISPLAY=%s", sock);
	wl_display_run(s->display);

	/* The session is over. What outlives this process is put away here: the
	 * Liquid Glass marker, our socket, the X server, the apps. Everything else
	 * (scene, cursor, renderer, screens) goes back to the kernel as we exit.
	 * Taking those apart by hand needs every listener in the program detached
	 * first — wlroots aborts otherwise, and every single logout used to end in
	 * that abort: "lumen crashed" in the session log and a core dump, after the
	 * goodbye animation had already played. */
	liquid_shutdown();
	ipc_finish(s);
	xwayland_finish(s);
	wl_display_destroy_clients(s->display);
	wlr_log(WLR_INFO, "Lumen session ended");
	fflush(NULL);
	_exit(0);
}
