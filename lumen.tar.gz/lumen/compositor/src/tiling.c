/* Autotiling (tiling = true): Hyprland-style dwindle.
 *
 * The windows of a workspace, in the order they were opened, spiral into the
 * monitor's free area: each one takes half of what is left, split along the
 * longer side, and the last one takes the rest. Floating, maximised,
 * fullscreen and minimised windows are left alone. Super+Shift+V floats a window;
 * dragging a tiled window onto another swaps them. */
#include <stdlib.h>
#include "lumen.h"

static bool tiled(struct lumen_view *v, int ws) {
	return v->mapped && !v->closing && v->workspace == ws && !v->floating && !v->minimized &&
		!v->maximized && !v->fullscreen;
}

static int by_order(const void *a, const void *b) {
	const struct lumen_view *x = *(struct lumen_view *const *)a, *y = *(struct lumen_view *const *)b;
	return x->tile_order < y->tile_order ? -1 : x->tile_order > y->tile_order;
}

void tile_workspace(struct lumen_server *s, int ws) {
	if (!s->cfg.tiling || ws < 0 || ws >= LUMEN_WORKSPACES) return;
	struct lumen_output *o = output_showing(s, ws);
	struct wlr_box area;
	if (o) area = o->usable;
	else if (s->ws_home[ws].width > 0) {
		struct lumen_output *h = output_at(s, s->ws_home[ws].x + 1, s->ws_home[ws].y + 1);
		if (!h) return;
		area = h->usable;
	} else return;

	struct lumen_view *list[64], *v;
	int n = 0;
	wl_list_for_each(v, &s->views, link)
		if (n < 64 && tiled(v, ws)) list[n++] = v;
	if (n == 0) return;
	qsort(list, n, sizeof(list[0]), by_order);

	int g = s->cfg.gaps;
	struct wlr_box r = { area.x + g, area.y + g, area.width - 2 * g, area.height - 2 * g };
	for (int i = 0; i < n; i++) {
		struct wlr_box mine = r;
		if (i < n - 1) {
			if (r.width >= r.height) {        /* split side by side */
				mine.width = (r.width - g) / 2;
				r.x += mine.width + g;
				r.width -= mine.width + g;
			} else {                          /* split top / bottom */
				mine.height = (r.height - g) / 2;
				r.y += mine.height + g;
				r.height -= mine.height + g;
			}
		}
		if (mine.width < 120) mine.width = 120;
		if (mine.height < 80) mine.height = 80;
		struct wlr_box cur = list[i]->geom;
		if (cur.x != mine.x || cur.y != mine.y || cur.width != mine.width || cur.height != mine.height)
			view_animate_to(list[i], mine);
	}
}

void tile_all(struct lumen_server *s) {
	for (int i = 0; i < LUMEN_WORKSPACES; i++) tile_workspace(s, i);
}

void view_toggle_floating(struct lumen_view *v) {
	if (!v) return;
	struct lumen_server *s = v->server;
	v->floating = !v->floating;
	if (v->floating && s->cfg.tiling) {
		/* pop out to a comfortable centred size */
		struct lumen_output *o = output_showing(s, v->workspace);
		if (o) {
			int w = o->usable.width * 0.6, h = o->usable.height * 0.66;
			view_animate_to(v, (struct wlr_box){ o->usable.x + (o->usable.width - w) / 2,
				o->usable.y + (o->usable.height - h) / 2, w, h });
		}
	}
	tile_workspace(s, v->workspace);
	ipc_state_changed(s);
}

/* a tiled window was dragged and dropped at (x, y): swap places with the tiled
 * window under it. Returns true when the layout took care of the drop. */
bool tiling_drop(struct lumen_view *v, double x, double y) {
	struct lumen_server *s = v->server;
	if (!s->cfg.tiling || v->floating) return false;
	struct lumen_view *t;
	wl_list_for_each(t, &s->views, link) {
		if (t == v || !tiled(t, v->workspace)) continue;
		struct wlr_box b = t->geom;
		if (x >= b.x && x < b.x + b.width && y >= b.y && y < b.y + b.height) {
			uint32_t o = v->tile_order;
			v->tile_order = t->tile_order;
			t->tile_order = o;
			break;
		}
	}
	tile_workspace(s, v->workspace);   /* snaps the dragged window back into the grid too */
	return true;
}
