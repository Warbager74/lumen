/* Alt+Tab switcher: a glass panel of live window previews.
 *
 * Hold Alt and tap Tab to walk the windows (most recently used first,
 * Shift+Tab / arrows go back). Letting go of Alt switches. A quick Alt+Tab
 * tap switches straight away without flashing the panel. The panel rises and
 * fades in, the accent highlight glides between cards with a little liquid
 * stretch, and the previews are the windows' own live buffers, so video keeps
 * playing in them. Esc cancels, Enter or a click picks, Delete/W closes. */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <wlr/types/wlr_buffer.h>
#include <wlr/types/wlr_compositor.h>
#include <wlr/types/wlr_keyboard.h>
#include <xkbcommon/xkbcommon.h>
#include "lumen.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#define MAX_CARDS 32
#define PAD 22          /* panel padding */
#define CP 10           /* card padding around the preview */
#define GAP 10          /* between cards */
#define LABEL_H 30
#define RADIUS 26
#define SHOW_DELAY 90   /* ms: a quick Alt+Tab tap never shows the panel */

enum { T_FADE = 1, T_GLIDE = 2 };

struct card {
	struct lumen_view *v;
	struct wlr_scene_tree *tree;
	struct wlr_scene_shadow *shadow;
	struct wlr_scene_rect *ph;
	struct wlr_scene_buffer *buf, *label;
	struct wlr_box box;            /* card box, panel-relative */
	int tw, th;                    /* preview size */
};

static struct {
	struct lumen_server *s;
	bool active, shown, closing;
	struct lumen_output *o;
	struct wlr_scene_tree *tree, *cards;
	struct wlr_scene_shadow *shadow;
	struct wlr_scene_blur *blur;
	struct wlr_scene_rect *tint, *rim, *hl, *hl_rim;
	struct card c[MAX_CARDS];
	int n, sel;
	struct wlr_box panel;          /* layout coords */
	struct wlr_box hl_box;         /* current highlight box, panel-relative */
	double fade;                   /* 0..1 */
	struct wl_event_source *timer;
} W;

bool switcher_active(void) { return W.active; }

/* ------------------------------------------------------------- previews */
static void card_set_buffer(struct card *c) {
	struct wlr_surface *sf = view_surface(c->v);
	struct wlr_buffer *b = sf && sf->buffer ? &sf->buffer->base : NULL;
	wlr_scene_buffer_set_buffer(c->buf, b);
	wlr_scene_node_set_enabled(&c->ph->node, b == NULL);
	if (!b) return;
	/* crop to the window geometry: no client-side shadows in the preview */
	struct wlr_box g = c->v->type == VIEW_XDG ? c->v->xdg->base->geometry
		: (struct wlr_box){ 0, 0, sf->current.width, sf->current.height };
	float sc = sf->current.scale > 0 ? (float)sf->current.scale : 1.f;
	if (b->width > 0 && sf->current.width > 0)
		sc = (float)b->width / sf->current.width;      /* fractional scale / viewporter */
	struct wlr_fbox src = { g.x * sc, g.y * sc, g.width * sc, g.height * sc };
	if (src.width > 0 && src.height > 0 && src.x + src.width <= b->width + 0.5 &&
			src.y + src.height <= b->height + 0.5)
		wlr_scene_buffer_set_source_box(c->buf, &src);
	else
		wlr_scene_buffer_set_source_box(c->buf, NULL);
	wlr_scene_buffer_set_dest_size(c->buf, c->tw, c->th);
}

/* ---------------------------------------------------------------- paint */
static void premul(const float in[4], float a, float out[4]) {
	out[0] = in[0] * a; out[1] = in[1] * a; out[2] = in[2] * a; out[3] = in[3] * a;
}

/* a straight (un-premultiplied) colour at opacity `a`, as the scene wants it */
static void straight(float r, float g, float b, float a, float out[4]) {
	out[0] = r * a; out[1] = g * a; out[2] = b * a; out[3] = a;
}

static void paint(void) {
	if (!W.tree) return;
	double a = W.fade < 0 ? 0 : (W.fade > 1 ? 1 : W.fade);
	struct lumen_config *cfg = &W.s->cfg;
	/* rise into place while fading in */
	int rise = (int)lround((1 - a) * 18);
	wlr_scene_node_set_position(&W.tree->node, W.panel.x, W.panel.y + rise);
	wlr_scene_node_set_enabled(&W.tree->node, a > 0.004);

	float c[4];
	wlr_scene_blur_set_alpha(W.blur, (float)a);
	wlr_scene_blur_set_strength(W.blur, (float)a);
	float tint[4] = { cfg->glass_tint[0], cfg->glass_tint[1], cfg->glass_tint[2],
		fminf(cfg->glass_tint[3] + 0.12f, 0.85f) };
	premul(tint, (float)a, c);
	wlr_scene_rect_set_color(W.tint, c);
	straight(1, 1, 1, 0.22f * (float)a, c);
	wlr_scene_rect_set_color(W.rim, c);
	premul((float[4]){ 0, 0, 0, 0.42f }, (float)a, c);
	wlr_scene_shadow_set_color(W.shadow, c);

	const float *ac = cfg->accent;
	straight(ac[0], ac[1], ac[2], 0.38f * (float)a, c);
	wlr_scene_rect_set_color(W.hl, c);
	straight(fminf(ac[0] * 1.25f, 1), fminf(ac[1] * 1.25f, 1), fminf(ac[2] * 1.25f, 1), 0.95f * (float)a, c);
	wlr_scene_rect_set_color(W.hl_rim, c);

	for (int i = 0; i < W.n; i++) {
		struct card *k = &W.c[i];
		wlr_scene_buffer_set_opacity(k->buf, (float)a);
		wlr_scene_buffer_set_opacity(k->label, (float)(a * (i == W.sel ? 1.0 : 0.72)));
		straight(0.10f, 0.11f, 0.15f, 0.85f * (float)a, c);
		wlr_scene_rect_set_color(k->ph, c);
		premul((float[4]){ 0, 0, 0, 0.35f }, (float)a, c);
		wlr_scene_shadow_set_color(k->shadow, c);
	}
}

static void place_hl(struct wlr_box b) {
	W.hl_box = b;
	wlr_scene_node_set_position(&W.hl->node, b.x, b.y);
	wlr_scene_rect_set_size(W.hl, b.width, b.height);
	wlr_scene_node_set_position(&W.hl_rim->node, b.x, b.y);
	wlr_scene_rect_set_size(W.hl_rim, b.width, b.height);
	wlr_scene_rect_set_clipped_region(W.hl_rim, (struct clipped_region){
		.corners = corner_radii_all(15), .area = { 2, 2, b.width - 4, b.height - 4 } });
}

static void glide_step(struct anim *an, double t) {
	(void)an;
	struct wlr_box b = {
		(int)lround(lerp(an->from[0], an->to[0], t)), (int)lround(lerp(an->from[1], an->to[1], t)),
		(int)lround(lerp(an->from[2], an->to[2], t)), (int)lround(lerp(an->from[3], an->to[3], t)) };
	/* stretches while it travels, like a droplet */
	double stretch = sin(fmin(fmax(t, 0), 1) * M_PI) * fmin(fabs(an->to[0] - an->from[0]) * 0.18, 30);
	b.x -= (int)(stretch / 2);
	b.width += (int)stretch;
	if (b.width < 8) b.width = 8;
	if (b.height < 8) b.height = 8;
	place_hl(b);
}

static void select_card(int i, bool animate) {
	if (W.n == 0) return;
	i = ((i % W.n) + W.n) % W.n;
	int prev = W.sel;
	W.sel = i;
	struct wlr_box to = W.c[i].box;
	anim_cancel(&W, T_GLIDE);
	if (!animate || !W.shown || !W.s->cfg.animations) place_hl(to);
	else {
		struct anim *an = anim_start(&W, T_GLIDE, anim_scaled(260), EASE_SPRING, glide_step, NULL);
		struct wlr_box f = W.hl_box;
		an->from[0] = f.x; an->from[1] = f.y; an->from[2] = f.width; an->from[3] = f.height;
		an->to[0] = to.x; an->to[1] = to.y; an->to[2] = to.width; an->to[3] = to.height;
	}
	if (prev != i) paint();
}

/* --------------------------------------------------------------- build */
static void teardown(void) {
	anim_cancel(&W, -1);
	if (W.timer) wl_event_source_timer_update(W.timer, 0);
	if (W.tree) wlr_scene_node_destroy(&W.tree->node);
	W.tree = NULL;
	W.n = 0;
	W.shown = W.closing = false;
	W.fade = 0;
}

static int collect(struct lumen_view **out) {
	struct lumen_server *s = W.s;
	int n = 0;
	struct lumen_view *v;
	/* s->views is most-recently-focused first */
	wl_list_for_each(v, &s->views, link) {
		if (n >= MAX_CARDS) break;
		if (!v->mapped || v->closing || v->workspace < 0) continue;
		if (!output_showing(s, v->workspace)) continue;   /* desktops on screen right now */
		out[n++] = v;
	}
	return n;
}

static void layout(struct lumen_output *o, struct lumen_view **vs, int n) {
	int maxw = (int)(o->usable.width * 0.88) - 2 * PAD;
	int TH = 150;
	int cw[MAX_CARDS], tw[MAX_CARDS], rows = 1, roww[8] = { 0 }, rowi[MAX_CARDS];
	for (int attempt = 0; attempt < 4; attempt++) {
		TH = (int[]){ 150, 128, 110, 96 }[attempt];
		rows = 1;
		memset(roww, 0, sizeof(roww));
		int x = 0;
		for (int i = 0; i < n; i++) {
			struct wlr_box g = vs[i]->geom;
			int th = vs[i]->ssd && !vs[i]->fullscreen ? TITLEBAR_H : 0;
			double ww = vs[i]->content_w > 0 ? vs[i]->content_w : g.width;
			double hh = vs[i]->content_h > 0 ? vs[i]->content_h : g.height - th;
			double asp = hh > 0 ? ww / hh : 1.5;
			int w = (int)(TH * asp);
			if (w < TH * 0.6) w = (int)(TH * 0.6);
			if (w > TH * 1.9) w = (int)(TH * 1.9);
			tw[i] = w;
			cw[i] = w + 2 * CP;
			int need = (x ? GAP : 0) + cw[i];
			if (x && x + need > maxw && rows < 8) { rows++; x = 0; need = cw[i]; }
			x += need;
			roww[rows - 1] = x;
			rowi[i] = rows - 1;
		}
		if (rows <= 2) break;
	}
	int ch = TH + 2 * CP + LABEL_H;
	int pw = 0;
	for (int r = 0; r < rows; r++) if (roww[r] > pw) pw = roww[r];
	pw += 2 * PAD;
	int ph = rows * ch + (rows - 1) * GAP + 2 * PAD;
	W.panel = (struct wlr_box){ o->usable.x + (o->usable.width - pw) / 2,
		o->usable.y + (o->usable.height - ph) / 2, pw, ph };
	int x = 0, r = -1;
	for (int i = 0; i < n; i++) {
		if (rowi[i] != r) { r = rowi[i]; x = PAD + (pw - 2 * PAD - roww[r]) / 2; }
		W.c[i].box = (struct wlr_box){ x, PAD + r * (ch + GAP), cw[i], ch };
		W.c[i].tw = tw[i];
		W.c[i].th = TH;
		x += cw[i] + GAP;
	}
}

static void build(void) {
	struct lumen_server *s = W.s;
	struct lumen_output *o = output_focused(s);
	struct lumen_view *vs[MAX_CARDS];
	int n = collect(vs);
	W.o = o;
	W.n = 0;
	if (!o || n == 0) return;
	layout(o, vs, n);
	float scale = o->wlr_output->scale;

	W.tree = wlr_scene_tree_create(s->layer[L_OVERLAY]);
	wlr_scene_node_set_enabled(&W.tree->node, false);
	int pw = W.panel.width, ph = W.panel.height;
	W.shadow = wlr_scene_shadow_create(W.tree, pw + 80, ph + 80, RADIUS, 34, (float[4]){ 0, 0, 0, 0 });
	wlr_scene_node_set_position(&W.shadow->node, -40, -32);
	wlr_scene_shadow_set_clipped_region(W.shadow, (struct clipped_region){
		.corners = corner_radii_all(RADIUS), .area = { 40, 32, pw, ph } });
	W.blur = wlr_scene_blur_create(W.tree, pw, ph);
	wlr_scene_blur_set_corner_radius(W.blur, RADIUS);
	W.tint = wlr_scene_rect_create(W.tree, pw, ph, (float[4]){ 0, 0, 0, 0 });
	wlr_scene_rect_set_corner_radius(W.tint, RADIUS);
	W.rim = wlr_scene_rect_create(W.tree, pw, ph, (float[4]){ 0, 0, 0, 0 });
	wlr_scene_rect_set_corner_radius(W.rim, RADIUS);
	wlr_scene_rect_set_clipped_region(W.rim, (struct clipped_region){
		.corners = corner_radii_all(RADIUS - 1), .area = { 1, 1, pw - 2, ph - 2 } });
	W.hl = wlr_scene_rect_create(W.tree, 10, 10, (float[4]){ 0, 0, 0, 0 });
	wlr_scene_rect_set_corner_radius(W.hl, 16);
	W.hl_rim = wlr_scene_rect_create(W.tree, 10, 10, (float[4]){ 0, 0, 0, 0 });
	wlr_scene_rect_set_corner_radius(W.hl_rim, 16);
	W.tint->accepts_input = W.rim->accepts_input = W.hl->accepts_input = W.hl_rim->accepts_input = false;
	W.cards = wlr_scene_tree_create(W.tree);

	for (int i = 0; i < n; i++) {
		struct card *k = &W.c[i];
		k->v = vs[i];
		k->tree = wlr_scene_tree_create(W.cards);
		wlr_scene_node_set_position(&k->tree->node, k->box.x + CP, k->box.y + CP);
		k->shadow = wlr_scene_shadow_create(k->tree, k->tw + 24, k->th + 24, 11, 10, (float[4]){ 0, 0, 0, 0 });
		wlr_scene_node_set_position(&k->shadow->node, -12, -9);
		wlr_scene_shadow_set_clipped_region(k->shadow, (struct clipped_region){
			.corners = corner_radii_all(11), .area = { 12, 9, k->tw, k->th } });
		k->ph = wlr_scene_rect_create(k->tree, k->tw, k->th, (float[4]){ 0, 0, 0, 0 });
		wlr_scene_rect_set_corner_radius(k->ph, 11);
		k->buf = wlr_scene_buffer_create(k->tree, NULL);
		wlr_scene_buffer_set_corner_radii(k->buf, corner_radii_all(11));
		card_set_buffer(k);
		const char *title = view_title(k->v);
		if (!title || !*title) title = view_app_id(k->v);
		int lw = k->box.width - 8;
		struct wlr_buffer *lb = text_buffer_create(title ? title : "", "Inter Medium 10.5",
			(float[4]){ 1, 1, 1, 0.96f }, lw, LABEL_H, scale);
		k->label = wlr_scene_buffer_create(k->tree, lb);
		wlr_scene_buffer_set_dest_size(k->label, lw, LABEL_H);
		wlr_scene_node_set_position(&k->label->node, -CP + 4, k->th + 2);
		wlr_buffer_drop(lb);
	}
	W.n = n;
}

/* -------------------------------------------------------------- fading */
static void fade_step(struct anim *an, double t) {
	W.fade = lerp(an->from[0], an->to[0], t);
	paint();
}

static void fade_done(struct anim *an) {
	(void)an;
	if (W.closing) teardown();
}

static void fade_to(double target, double ms) {
	anim_cancel(&W, T_FADE);
	ms = anim_scaled(ms);   /* speed slider; 1 ms when animations are off */
	struct anim *an = anim_start(&W, T_FADE, ms, target > 0.5 ? EASE_OUT_EXPO : EASE_OUT_CUBIC,
		fade_step, fade_done);
	an->from[0] = W.fade;
	an->to[0] = target;
}

static int show_now(void *data) {
	(void)data;
	if (!W.active || !W.tree || W.shown) return 0;
	W.shown = true;
	select_card(W.sel, false);
	paint();
	fade_to(1, 240);
	return 0;
}

/* ------------------------------------------------------------- control */
static void finish(struct lumen_view *pick) {
	if (!W.active) return;
	W.active = false;
	if (W.shown && W.tree) {
		W.closing = true;
		fade_to(0, 150);
	} else {
		teardown();
	}
	if (pick && pick->mapped) focus_view(pick);
}

void switcher_init(struct lumen_server *s) {
	W.s = s;
	W.timer = wl_event_loop_add_timer(s->loop, show_now, NULL);
}

/* Alt+Tab (dir 1) / Alt+Shift+Tab (dir -1) */
void switcher_step(struct lumen_server *s, int dir) {
	W.s = s;
	if (!W.active) {
		if (overview_active()) return;
		if (W.tree) teardown();        /* still fading out from last time */
		build();
		if (W.n < 2) {                 /* nothing to switch between */
			struct lumen_view *only = W.n == 1 ? W.c[0].v : NULL;
			teardown();
			if (only && only->minimized) focus_view(only);
			return;
		}
		W.active = true;
		W.sel = 0;
		select_card(dir > 0 ? 1 : W.n - 1, false);
		if (W.timer) wl_event_source_timer_update(W.timer, SHOW_DELAY);
		else show_now(NULL);
		return;
	}
	select_card(W.sel + dir, true);
	if (!W.shown) show_now(NULL);      /* tapping Tab again: show right away */
}

void switcher_commit(void) {
	if (!W.active) return;
	finish(W.n ? W.c[W.sel].v : NULL);
}

void switcher_cancel(void) {
	if (W.active) finish(NULL);
}

/* keys while the switcher is up (Alt held). true = swallowed */
bool switcher_key(uint32_t sym, bool shift) {
	if (!W.active) return false;
	switch (sym) {
	case XKB_KEY_Tab: select_card(W.sel + (shift ? -1 : 1), true); break;
	case XKB_KEY_ISO_Left_Tab: select_card(W.sel - 1, true); break;
	case XKB_KEY_Right: case XKB_KEY_l: select_card(W.sel + 1, true); break;
	case XKB_KEY_Left: case XKB_KEY_h: select_card(W.sel - 1, true); break;
	case XKB_KEY_Down: case XKB_KEY_Up: {
		/* jump to the nearest card in the next/previous row */
		struct wlr_box cur = W.c[W.sel].box;
		int best = -1, bd = 1 << 30;
		for (int i = 0; i < W.n; i++) {
			struct wlr_box b = W.c[i].box;
			if (sym == XKB_KEY_Down ? b.y <= cur.y : b.y >= cur.y) continue;
			int d = abs((b.x + b.width / 2) - (cur.x + cur.width / 2)) + abs(b.y - cur.y) * 4;
			if (d < bd) { bd = d; best = i; }
		}
		if (best >= 0) select_card(best, true);
		break;
	}
	case XKB_KEY_Return: case XKB_KEY_KP_Enter: case XKB_KEY_space: switcher_commit(); break;
	case XKB_KEY_Escape: switcher_cancel(); break;
	case XKB_KEY_Delete: case XKB_KEY_w: case XKB_KEY_q:
		if (W.n) view_close(W.c[W.sel].v);    /* the list rebuilds when it unmaps */
		break;
	default: break;
	}
	if (W.active && !W.shown) show_now(NULL);
	return true;
}

/* modifiers changed: letting go of Alt picks the highlighted window */
void switcher_modifiers(uint32_t mods) {
	if (W.active && !(mods & WLR_MODIFIER_ALT)) switcher_commit();
}

static int card_at(double x, double y) {
	if (!W.tree || !W.shown) return -1;
	for (int i = 0; i < W.n; i++) {
		struct wlr_box b = W.c[i].box;
		b.x += W.panel.x; b.y += W.panel.y;
		if (wlr_box_contains_point(&b, x, y)) return i;
	}
	return -1;
}

/* pointer over the panel: true = handled (hovering a card highlights it) */
bool switcher_motion(double x, double y) {
	if (!W.active) return false;
	int i = card_at(x, y);
	if (i >= 0 && i != W.sel) select_card(i, true);
	return true;
}

bool switcher_click(double x, double y) {
	if (!W.active) return false;
	int i = card_at(x, y);
	if (i >= 0) { W.sel = i; switcher_commit(); }
	else if (!wlr_box_contains_point(&W.panel, x, y)) switcher_cancel();
	return true;
}

/* a window's buffer changed: keep its preview live */
void switcher_view_updated(struct lumen_view *v) {
	if (!W.tree) return;
	for (int i = 0; i < W.n; i++)
		if (W.c[i].v == v) { card_set_buffer(&W.c[i]); break; }
}

/* windows opened/closed while the switcher is up: rebuild, keep the selection */
void switcher_views_changed(void) {
	if (!W.tree) return;
	if (!W.active) { teardown(); return; }   /* fading out: just drop it */
	struct lumen_view *keep = W.n ? W.c[W.sel].v : NULL;
	int old = W.sel;
	bool shown = W.shown;
	anim_cancel(&W, -1);
	if (W.tree) wlr_scene_node_destroy(&W.tree->node);
	W.tree = NULL;
	build();
	if (W.n < 1) { W.active = false; teardown(); return; }
	int sel = old < W.n ? old : W.n - 1;
	for (int i = 0; i < W.n; i++) if (W.c[i].v == keep) sel = i;
	W.shown = shown;
	W.fade = shown ? 1 : 0;
	select_card(sel, false);
	paint();
}
