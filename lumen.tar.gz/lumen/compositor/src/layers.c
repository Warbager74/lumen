/* wlr-layer-shell: bars, docks, launchers, wallpapers — all get backdrop blur. */
#include <stdlib.h>
#include <string.h>
#include <wlr/util/log.h>
#include "lumen.h"

static enum lumen_scene_layer scene_layer_for(enum zwlr_layer_shell_v1_layer l) {
	switch (l) {
	case ZWLR_LAYER_SHELL_V1_LAYER_BACKGROUND: return L_BG;
	case ZWLR_LAYER_SHELL_V1_LAYER_BOTTOM: return L_BOTTOM;
	case ZWLR_LAYER_SHELL_V1_LAYER_TOP: return L_TOP;
	default: return L_OVERLAY;
	}
}

static void fx_buffers(struct wlr_scene_buffer *b, int sx, int sy, void *data) {
	struct lumen_layer_surface *l = data;
	wlr_scene_buffer_set_opacity(b, (float)l->alpha);
	struct wlr_scene_surface *ss = wlr_scene_surface_try_from_buffer(b);
	if (!ss || ss->surface != l->layer_surface->surface || !l->blur) return;
	/* the blur follows the main surface and is masked by its alpha, so only
	 * pixels the client actually drew (rounded pills, cards) get frosted.
	 * sx/sy from for_each_buffer include the layer tree's own position, but the
	 * blur is a child of that tree: convert to tree-relative coordinates. */
	struct wlr_scene_node *root = &l->scene->tree->node;
	wlr_scene_node_set_position(&l->blur->node, sx - root->x, sy - root->y);
	wlr_scene_blur_set_size(l->blur, b->dst_width > 0 ? b->dst_width : ss->surface->current.width,
		b->dst_height > 0 ? b->dst_height : ss->surface->current.height);
	if (wlr_scene_blur_get_transparency_mask_source(l->blur) != b)
		wlr_scene_blur_set_transparency_mask_source(l->blur, b);
}

/* namespaces that are glass panels (everything else is drawn as-is) */
bool layer_is_glass(const char *ns) {
	static const char *glass[] = { "rofi", "notifications", "mako", "launcher", "fuzzel", "wofi",
		"waybar", "swaync", "anyrun", "walker", "ulauncher", NULL };
	if (!ns) return false;
	if (!strncmp(ns, "lumen-", 6)) return strcmp(ns, "lumen-wallpaper") != 0;
	for (int i = 0; glass[i]; i++) if (!strcmp(ns, glass[i])) return true;
	return false;
}

static void apply_fx(struct lumen_layer_surface *l) {
	if (l->blur) {
		wlr_scene_blur_set_alpha(l->blur, (float)l->alpha);
		wlr_scene_blur_set_strength(l->blur, (float)l->alpha);
	}
	wlr_scene_node_for_each_buffer(&l->scene->tree->node, fx_buffers, l);
}

/* which edge a surface slides in from, based on its anchors */
static void slide_vector(struct lumen_layer_surface *l, int *dx, int *dy) {
	uint32_t a = l->layer_surface->current.anchor;
	const uint32_t T = ZWLR_LAYER_SURFACE_V1_ANCHOR_TOP, B = ZWLR_LAYER_SURFACE_V1_ANCHOR_BOTTOM,
		Le = ZWLR_LAYER_SURFACE_V1_ANCHOR_LEFT, R = ZWLR_LAYER_SURFACE_V1_ANCHOR_RIGHT;
	*dx = 0; *dy = 0;
	if ((a & T) && !(a & B)) *dy = -1;
	else if ((a & B) && !(a & T)) *dy = 1;
	else if ((a & Le) && !(a & R)) *dx = -1;
	else if ((a & R) && !(a & Le)) *dx = 1;
	/* anchored nowhere = floating in the middle (Spotlight): it lifts into place */
	else if (!(a & (T | B | Le | R))) *dy = 1;
}

/* ------------------------------------------------------------ closing ghost
 * A panel that goes away (Spotlight closing, a bar when the shell restarts)
 * leaves its last picture behind for a moment: it fades and sinks back the way
 * it came instead of vanishing. The picture is the client's last buffer, which
 * the scene keeps alive on its own. */
struct layer_ghost {
	struct wlr_scene_tree *tree;
	struct wlr_scene_buffer *buf;
	struct wlr_scene_blur *blur;
	int x, y, dx, dy;
	double a0, dist;
};

static void ghost_step(struct anim *a, double t) {
	struct layer_ghost *g = a->owner;
	double k = t < 0 ? 0 : (t > 1 ? 1 : t);
	double al = g->a0 * (1 - k);
	wlr_scene_buffer_set_opacity(g->buf, (float)al);
	if (g->blur) {
		wlr_scene_blur_set_alpha(g->blur, (float)al);
		wlr_scene_blur_set_strength(g->blur, (float)al);
	}
	wlr_scene_node_set_position(&g->tree->node, g->x + (int)(g->dx * g->dist * k), g->y + (int)(g->dy * g->dist * k));
}

static void ghost_done(struct anim *a) {
	struct layer_ghost *g = a->owner;
	wlr_scene_node_destroy(&g->tree->node);
	free(g);
}

static bool ghost_no_input(struct wlr_scene_buffer *b, double *sx, double *sy) {
	(void)b; (void)sx; (void)sy;
	return false;     /* a picture: clicks go to whatever is really there */
}

static void find_main_buffer(struct wlr_scene_buffer *b, int sx, int sy, void *data) {
	(void)sx; (void)sy;
	struct wlr_scene_buffer **out = data;
	if (!*out && b->buffer && wlr_scene_surface_try_from_buffer(b)) *out = b;
}

static void leave_ghost(struct lumen_layer_surface *l) {
	struct lumen_server *s = l->server;
	struct wlr_layer_surface_v1 *ls = l->layer_surface;
	if (!s->cfg.animations || s->cfg.performance_mode || l->alpha < 0.05 || !l->output) return;
	if (ls->current.layer < ZWLR_LAYER_SHELL_V1_LAYER_TOP) return;
	struct wlr_scene_node *n = &l->scene->tree->node;
	if (!n->enabled || !n->parent) return;
	struct wlr_scene_buffer *src = NULL;
	wlr_scene_node_for_each_buffer(n, find_main_buffer, &src);
	if (!src || !src->buffer) return;                    /* nothing left to show */
	int w = src->dst_width > 0 ? src->dst_width : (int)ls->surface->current.width;
	int h = src->dst_height > 0 ? src->dst_height : (int)ls->surface->current.height;
	if (w < 2 || h < 2) return;
	struct layer_ghost *g = calloc(1, sizeof(*g));
	if (!g) return;
	g->tree = wlr_scene_tree_create(n->parent);
	wlr_scene_node_place_above(&g->tree->node, n);
	int nx = 0, ny = 0, bx = 0, by = 0;
	wlr_scene_node_coords(n, &nx, &ny);
	wlr_scene_node_coords(&src->node, &bx, &by);
	g->x = n->x + (bx - nx);
	g->y = n->y + (by - ny);
	slide_vector(l, &g->dx, &g->dy);
	g->dist = g->dx || g->dy ? 12 : 0;
	g->a0 = l->alpha > 1 ? 1 : l->alpha;
	if (l->blur) {
		g->blur = wlr_scene_blur_create(g->tree, w, h);
#ifdef LUMEN_HAVE_BLUR_THRESHOLD
		wlr_scene_blur_set_ignore_alpha_threshold(g->blur, 0.2f);
#endif
	}
	g->buf = wlr_scene_buffer_create(g->tree, src->buffer);   /* the scene keeps its own lock */
	if (!g->buf) { wlr_scene_node_destroy(&g->tree->node); free(g); return; }
	g->buf->point_accepts_input = ghost_no_input;
	wlr_scene_buffer_set_dest_size(g->buf, w, h);
	if (src->src_box.width > 0 && src->src_box.height > 0) wlr_scene_buffer_set_source_box(g->buf, &src->src_box);
	wlr_scene_buffer_set_corner_radii(g->buf, src->corners);
	if (g->blur) wlr_scene_blur_set_transparency_mask_source(g->blur, g->buf);
	ghost_step(&(struct anim){ .owner = g }, 0);
	double ms = s->cfg.anim_ms * 0.45;
	anim_start(g, 1, ms > 90 ? ms : 90, EASE_OUT_CUBIC, ghost_step, ghost_done);
}

static void layer_step(struct anim *a, double t) {
	struct lumen_layer_surface *l = a->owner;
	l->alpha = lerp(a->from[0], a->to[0], t < 0 ? 0 : (t > 1 ? 1 : t));
	l->slide = lerp(a->from[1], a->to[1], t);
	int dx, dy;
	slide_vector(l, &dx, &dy);
	struct wlr_scene_node *n = &l->scene->tree->node;
	/* base position is re-applied by arrange; we only add the offset */
	int bx = (int)a->from[2], by = (int)a->from[3];
	wlr_scene_node_set_position(n, bx + (int)(dx * l->slide), by + (int)(dy * l->slide));
	apply_fx(l);
}

static void animate_in(struct lumen_layer_surface *l) {
	struct lumen_server *s = l->server;
	bool overlay = l->layer_surface->current.layer >= ZWLR_LAYER_SHELL_V1_LAYER_TOP;
	/* glass cards on the desktop (the widgets) arrive softly too: a fade and a
	 * short drift, so they don't pop in next to bars that slide */
	bool desk = l->blur && !s->cfg.performance_mode &&
		l->layer_surface->current.layer == ZWLR_LAYER_SHELL_V1_LAYER_BOTTOM;
	if ((!overlay && !desk) || !s->cfg.animations) { l->alpha = 1; apply_fx(l); return; }
	struct anim *a = anim_start(l, 1, s->cfg.anim_ms, EASE_SPRING, layer_step, NULL);
	int h = l->layer_surface->current.actual_height ? (int)l->layer_surface->current.actual_height : 40;
	a->from[0] = 0; a->to[0] = 1;
	uint32_t anchor = l->layer_surface->current.anchor;
	bool floating = !(anchor & (ZWLR_LAYER_SURFACE_V1_ANCHOR_TOP | ZWLR_LAYER_SURFACE_V1_ANCHOR_BOTTOM |
		ZWLR_LAYER_SURFACE_V1_ANCHOR_LEFT | ZWLR_LAYER_SURFACE_V1_ANCHOR_RIGHT));
	a->from[1] = desk ? 12 : (floating ? 16 : (h < 60 ? h : 28)); a->to[1] = 0;
	a->from[2] = l->scene->tree->node.x; a->from[3] = l->scene->tree->node.y;
}

static void arrange_one_layer(struct lumen_output *o, int layer, struct wlr_box *usable,
		bool exclusive) {
	struct lumen_layer_surface *l;
	wl_list_for_each(l, &o->layers[layer], link) {
		struct wlr_layer_surface_v1 *ls = l->layer_surface;
		if (!ls->initialized || l->unmapping) continue;
		if ((ls->current.exclusive_zone > 0) != exclusive) continue;
		wlr_scene_layer_surface_v1_configure(l->scene, &o->full, usable);
		wlr_scene_node_set_position(&l->popup_tree->node,
			l->scene->tree->node.x, l->scene->tree->node.y);
	}
}

void arrange_layers(struct lumen_output *o) {
	struct wlr_box usable = o->full;
	/* exclusive surfaces first so they carve out the usable area */
	for (int pass = 1; pass >= 0; pass--)
		for (int i = 3; i >= 0; i--)
			arrange_one_layer(o, i, &usable, pass == 1);
	bool changed = memcmp(&usable, &o->usable, sizeof(usable)) != 0;
	o->usable = usable;
	if (changed) views_reflow_maximized(o);

	/* keyboard-interactive overlays (launcher, power menu) grab focus */
	struct lumen_layer_surface *topmost = NULL;
	for (int i = ZWLR_LAYER_SHELL_V1_LAYER_OVERLAY; i >= ZWLR_LAYER_SHELL_V1_LAYER_TOP && !topmost; i--) {
		struct lumen_layer_surface *l;
		wl_list_for_each_reverse(l, &o->layers[i], link) {
			if (l->mapped && l->layer_surface->current.keyboard_interactive ==
					ZWLR_LAYER_SURFACE_V1_KEYBOARD_INTERACTIVITY_EXCLUSIVE) {
				topmost = l; break;
			}
		}
	}
	focus_layer(o->server, topmost);
}

static void layer_commit(struct wl_listener *li, void *data) {
	(void)data;
	struct lumen_layer_surface *l = wl_container_of(li, l, commit);
	struct wlr_layer_surface_v1 *ls = l->layer_surface;
	if (!l->output) return;
	uint32_t committed = ls->current.committed;
	if (ls->initial_commit || committed) {
		enum lumen_scene_layer want = scene_layer_for(ls->current.layer);
		if (l->scene->tree->node.parent != l->server->layer[want]) {
			wlr_scene_node_reparent(&l->scene->tree->node, l->server->layer[want]);
			wl_list_remove(&l->link);
			wl_list_insert(l->output->layers[ls->current.layer].prev, &l->link);
		}
		arrange_layers(l->output);
	}
	apply_fx(l);
}

static void layer_map(struct wl_listener *li, void *data) {
	(void)data;
	struct lumen_layer_surface *l = wl_container_of(li, l, map);
	l->mapped = true;
	if (l->output) arrange_layers(l->output);
	animate_in(l);
	pointer_refocus(l->server);
}

static void layer_unmap(struct wl_listener *li, void *data) {
	(void)data;
	struct lumen_layer_surface *l = wl_container_of(li, l, unmap);
	leave_ghost(l);
	l->mapped = false;
	anim_cancel(l, -1);
	if (l->server->exclusive_layer == l) focus_layer(l->server, NULL);
	/* unmap is often the first step of destruction: re-arrange the others
	 * (the work area may change) but never configure this one */
	l->unmapping = true;
	if (l->output) arrange_layers(l->output);
	l->unmapping = false;
	pointer_refocus(l->server);
}

static void layer_destroy(struct wl_listener *li, void *data) {
	(void)data;
	struct lumen_layer_surface *l = wl_container_of(li, l, destroy);
	anim_cancel(l, -1);
	if (l->server->exclusive_layer == l) l->server->exclusive_layer = NULL;
	wl_list_remove(&l->link);
	wl_list_remove(&l->map.link);
	wl_list_remove(&l->unmap.link);
	wl_list_remove(&l->commit.link);
	wl_list_remove(&l->destroy.link);
	wl_list_remove(&l->new_popup.link);
	wlr_scene_node_destroy(&l->popup_tree->node);
	struct lumen_output *o = l->output;
	free(l);
	if (o) arrange_layers(o);
}

/* tooltips / menus opened from a bar */
static void layer_new_popup(struct wl_listener *li, void *data) {
	struct lumen_layer_surface *l = wl_container_of(li, l, new_popup);
	popup_attach(data, l->popup_tree);
}

static void new_layer_surface(struct wl_listener *li, void *data) {
	struct lumen_server *s = wl_container_of(li, s, new_layer_surface);
	struct wlr_layer_surface_v1 *ls = data;
	if (!ls->output) {
		struct lumen_output *o = output_focused(s);
		if (!o) { wlr_layer_surface_v1_destroy(ls); return; }
		ls->output = o->wlr_output;
	}
	struct lumen_output *o = ls->output->data;
	struct lumen_layer_surface *l = calloc(1, sizeof(*l));
	l->server = s;
	l->output = o;
	l->layer_surface = ls;
	l->alpha = 1;
	ls->data = l;
	l->scene = wlr_scene_layer_surface_v1_create(
		s->layer[scene_layer_for(ls->pending.layer)], ls);
	l->popup_tree = wlr_scene_tree_create(s->layer[L_OVERLAY]);
	if (ls->pending.layer != ZWLR_LAYER_SHELL_V1_LAYER_BACKGROUND && layer_is_glass(ls->namespace)) {
		/* only glass panels get frosted — never wallpapers or tools like
		 * slurp (screenshot selection), whose full-screen dim would blur everything */
		l->blur = wlr_scene_blur_create(l->scene->tree, 0, 0);
		wlr_scene_node_lower_to_bottom(&l->blur->node);
		/* frost the glass, not its soft drop shadow (shadows stay below this alpha) */
#ifdef LUMEN_HAVE_BLUR_THRESHOLD
		wlr_scene_blur_set_ignore_alpha_threshold(l->blur, 0.2f);
#endif
	}
	wl_list_insert(o->layers[ls->pending.layer].prev, &l->link);

	l->map.notify = layer_map;
	wl_signal_add(&ls->surface->events.map, &l->map);
	l->unmap.notify = layer_unmap;
	wl_signal_add(&ls->surface->events.unmap, &l->unmap);
	l->commit.notify = layer_commit;
	wl_signal_add(&ls->surface->events.commit, &l->commit);
	l->destroy.notify = layer_destroy;
	wl_signal_add(&ls->events.destroy, &l->destroy);
	l->new_popup.notify = layer_new_popup;
	wl_signal_add(&ls->events.new_popup, &l->new_popup);
}

void layers_init(struct lumen_server *s) {
	s->layer_shell = wlr_layer_shell_v1_create(s->display, 4);
	s->new_layer_surface.notify = new_layer_surface;
	wl_signal_add(&s->layer_shell->events.new_surface, &s->new_layer_surface);
}
