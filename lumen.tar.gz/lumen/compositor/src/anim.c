/* Tiny frame-driven animation engine with easing + damped spring. */
#include <math.h>
#include <stdlib.h>
#include "lumen.h"

static struct wl_list anims;
static bool ticking;   /* while true, cancelled anims are only marked dead */

void anim_init(void) { wl_list_init(&anims); }

double now_ms(void) {
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}

double ease(enum easing e, double t) {
	if (t <= 0) return 0;
	if (t >= 1) return 1;
	switch (e) {
	case EASE_OUT_EXPO:
		return 1 - pow(2, -10 * t);
	case EASE_OUT_BACK: {
		const double c1 = 1.40158, c3 = c1 + 1;
		return 1 + c3 * pow(t - 1, 3) + c1 * pow(t - 1, 2);
	}
	case EASE_IN_OUT_CUBIC:
		return t < 0.5 ? 4 * t * t * t : 1 - pow(-2 * t + 2, 3) / 2;
	case EASE_OUT_CUBIC:
		return 1 - pow(1 - t, 3);
	case EASE_SPRING: {
		/* critically-under-damped spring: soft overshoot, settles at 1 */
		const double zeta = 0.62, omega = 13.0;
		const double wd = omega * sqrt(1 - zeta * zeta);
		double x = t * 1.15;
		return 1 - exp(-zeta * omega * x) *
			(cos(wd * x) + (zeta * omega / wd) * sin(wd * x));
	}
	case EASE_SPRING_SOFT: {
		/* nearly critically damped (about 1.5% past the target): windows and
		 * desktops glide into place and settle without a visible bounce */
		const double zeta = 0.80, omega = 14.0;
		const double wd = omega * sqrt(1 - zeta * zeta);
		double x = t * 1.1;
		return 1 - exp(-zeta * omega * x) *
			(cos(wd * x) + (zeta * omega / wd) * sin(wd * x));
	}
	case EASE_OUT_QUINT:
		return 1 - pow(1 - t, 5);
	}
	return t;
}

struct anim *anim_start(void *owner, int tag, double dur, enum easing e,
		void (*step)(struct anim *, double), void (*done)(struct anim *)) {
	anim_cancel(owner, tag);
	struct anim *a = calloc(1, sizeof(*a));
	a->owner = owner;
	a->tag = tag;
	a->start_ms = now_ms();
	a->dur_ms = dur > 1 ? dur : 1;
	a->ease = e;
	a->step = step;
	a->done = done;
	wl_list_insert(anims.prev, &a->link);
	if (g_server) schedule_frames(g_server);
	return a;
}

void anim_cancel(void *owner, int tag) {
	struct anim *a, *tmp;
	wl_list_for_each_safe(a, tmp, &anims, link) {
		if (a->owner == owner && (tag < 0 || a->tag == tag)) {
			if (ticking) { a->dead = true; continue; }  /* freed after the tick */
			wl_list_remove(&a->link);
			free(a);
		}
	}
}

bool anim_tick(void) {
	double now = now_ms();
	struct anim *a, *tmp;
	ticking = true;
	/* callbacks may start or cancel animations (even other owners'), so nothing
	 * is freed until the pass is over: finished/cancelled ones are marked dead */
	wl_list_for_each(a, &anims, link) {
		if (a->dead) continue;
		double t = (now - a->start_ms) / a->dur_ms;
		bool finished = t >= 1.0;
		if (a->step) a->step(a, ease(a->ease, finished ? 1.0 : t));
		if (finished && !a->dead) {
			a->dead = true;
			if (a->done) a->done(a);
		}
	}
	ticking = false;
	wl_list_for_each_safe(a, tmp, &anims, link) {
		if (a->dead) { wl_list_remove(&a->link); free(a); }
	}
	return !wl_list_empty(&anims);
}

/* durations written for the default speed (380 ms) follow the speed slider */
double anim_scaled(double ms) {
	extern struct lumen_server *g_server;
	if (!g_server || !g_server->cfg.animations) return 1;
	double k = g_server->cfg.anim_ms / 380.0;
	if (k < 0.3) k = 0.3;
	if (k > 2.5) k = 2.5;
	return ms * k;
}
