/* Line-based JSON IPC on $XDG_RUNTIME_DIR/lumen-$WAYLAND_DISPLAY.sock
 *
 *   -> "subscribe"            <- state JSON line now and after every change
 *   -> "state"                <- one state JSON line
 *   -> "workspace N" | "focus ID" | "toggle ID" | "close ID" | "minimize ID"
 *      "maximize ID" | "move ID WS" | "place ID X Y" | "snap ID left|right" | "exec CMD" | "reload" | "quit"
 *      "shell WHAT"   → broadcast {"event":"shell","what":WHAT} to subscribers
 *                       (the shell opens start/control/… instantly, no process spawn)
 */
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <wlr/util/log.h>
#include <cairo.h>
#include <drm_fourcc.h>
#include <wlr/render/wlr_texture.h>
#include "lumen.h"

struct ipc_client {
	struct wl_list link;
	int fd;
	bool subscribed;
	struct wl_event_source *src;
	char buf[2048];
	size_t len;
};

static char sock_path[100];   /* must fit sockaddr_un.sun_path (108) */

static void json_str(FILE *f, const char *s) {
	fputc('"', f);
	for (; s && *s; s++) {
		unsigned char c = *s;
		if (c == '"' || c == '\\') fprintf(f, "\\%c", c);
		else if (c < 0x20) fprintf(f, "\\u%04x", c);
		else fputc(c, f);
	}
	fputc('"', f);
}

static char *build_state(struct lumen_server *s, size_t *len) {
	char *out = NULL;
	FILE *f = open_memstream(&out, len);
	struct lumen_view *fv = focused_view(s);
	fprintf(f, "{\"workspace\":%d,\"workspaces\":%d,\"focused\":%u,\"windows\":[",
		s->ws_current + 1, LUMEN_WORKSPACES, fv ? fv->id : 0);
	bool first = true;
	struct lumen_view *v;
	/* oldest first so taskbar order is stable */
	wl_list_for_each_reverse(v, &s->views, link) {
		if (!v->mapped) continue;
		fprintf(f, "%s{\"id\":%u,\"app_id\":", first ? "" : ",", v->id);
		json_str(f, view_app_id(v));
		fputs(",\"title\":", f);
		json_str(f, view_title(v));
		fprintf(f, ",\"workspace\":%d,\"minimized\":%s,\"maximized\":%s,\"fullscreen\":%s,"
			"\"focused\":%s,\"floating\":%s,\"on_top\":%s}",
			v->workspace + 1, v->minimized ? "true" : "false", v->maximized ? "true" : "false",
			v->fullscreen ? "true" : "false", v == fv ? "true" : "false", v->floating ? "true" : "false",
			view_on_top(v) ? "true" : "false");
		first = false;
	}
	fputs("],\"outputs\":[", f);
	struct lumen_output *o, *fo = output_focused(s);
	first = true;
	wl_list_for_each(o, &s->outputs, link) {
		fprintf(f, "%s{\"name\":", first ? "" : ",");
		json_str(f, o->wlr_output->name);
		fprintf(f, ",\"ws\":%d,\"x\":%d,\"y\":%d,\"w\":%d,\"h\":%d,\"focused\":%s}", o->ws + 1,
			o->full.x, o->full.y, o->full.width, o->full.height, o == fo ? "true" : "false");
		first = false;
	}
	fputs("]}\n", f);
	fclose(f);
	return out;
}

/* "outputs": every monitor with its modes, for Settings → Displays */
static char *build_outputs(struct lumen_server *s, size_t *len) {
	char *out = NULL;
	FILE *f = open_memstream(&out, len);
	fputs("{\"outputs\":[", f);
	bool first = true;
	struct lumen_output *o;
	wl_list_for_each(o, &s->outputs, link) {
		struct wlr_output *wo = o->wlr_output;
		fprintf(f, "%s{\"name\":", first ? "" : ",");
		json_str(f, wo->name);
		fputs(",\"description\":", f);
		json_str(f, wo->description ? wo->description : "");
		fputs(",\"make\":", f);
		json_str(f, wo->make ? wo->make : "");
		fputs(",\"model\":", f);
		json_str(f, wo->model ? wo->model : "");
		static const int deg[] = { 0, 90, 180, 270, 0, 90, 180, 270 };
		fprintf(f, ",\"enabled\":%s,\"width\":%d,\"height\":%d,\"refresh\":%.2f,\"scale\":%.2f,"
			"\"transform\":%d,\"flipped\":%s,\"x\":%d,\"y\":%d,\"ws\":%d,\"modes\":[",
			wo->enabled ? "true" : "false", wo->width, wo->height, wo->refresh / 1000.0, wo->scale,
			deg[wo->transform & 7], wo->transform >= 4 ? "true" : "false", o->full.x, o->full.y, o->ws + 1);
		struct wlr_output_mode *m;
		bool mf = true;
		wl_list_for_each(m, &wo->modes, link) {
			fprintf(f, "%s\"%dx%d@%.2f\"", mf ? "" : ",", m->width, m->height, m->refresh / 1000.0);
			mf = false;
		}
		fputs("]}", f);
		first = false;
	}
	fputs("]}\n", f);
	fclose(f);
	return out;
}

/* "output NAME mode=… scale=… transform=… pos=X,Y": apply right away
 * (Settings also saves the same line to lumen.conf) */
/* "outputs-set LINE;LINE;…": several monitors at once (dragging the layout in
 * Settings moves more than one; applying them one by one would overlap midway) */
static void set_output_line(struct lumen_server *s, const char *line) {
	const char *sp = strchr(line, ' ');
	if (!sp || sp == line) return;
	size_t n = (size_t)(sp - line);
	int i;
	for (i = 0; i < s->cfg.output_count; i++)
		if (!strncmp(s->cfg.outputs[i], line, n) && s->cfg.outputs[i][n] == ' ') break;
	if (i >= 8) return;
	snprintf(s->cfg.outputs[i], sizeof(s->cfg.outputs[0]), "%s", line);
	if (i == s->cfg.output_count) s->cfg.output_count++;
}

static void apply_outputs_set(struct lumen_server *s, char *arg) {
	char *save = NULL;
	for (char *l = strtok_r(arg, ";", &save); l; l = strtok_r(NULL, ";", &save)) {
		while (*l == ' ') l++;
		if (*l) set_output_line(s, l);
	}
	outputs_apply_config(s);
}

/* "outputs-try SECS LINE;LINE;…": apply, and put the old layout back by
 * itself after SECS unless "outputs-keep" arrives. Lives here, not in Settings,
 * so a blank screen or a closed Settings window still gets rescued. */
static struct {
	char lines[8][160];
	int count;
	bool pending;
	struct wl_event_source *timer;
} TRY;

static void outputs_revert(struct lumen_server *s, bool tell) {
	if (!TRY.pending) return;
	TRY.pending = false;
	if (TRY.timer) wl_event_source_timer_update(TRY.timer, 0);
	memcpy(s->cfg.outputs, TRY.lines, sizeof(TRY.lines));
	s->cfg.output_count = TRY.count;
	outputs_apply_config(s);
	if (tell) spawn("notify-send -a Lumen -i video-display -h int:transient:1 "
		"'Display settings reverted' 'The previous layout is back.'");
}

static int try_timeout(void *data) {
	outputs_revert(data, true);
	return 0;
}

static void outputs_try(struct lumen_server *s, char *arg) {
	int secs = 15;
	char *rest = arg;
	if (sscanf(arg, "%d", &secs) == 1) {
		rest = strchr(arg, ' ');
		rest = rest ? rest + 1 : arg + strlen(arg);
	}
	if (secs < 3) secs = 3;
	if (secs > 120) secs = 120;
	if (!TRY.pending) {          /* remember what to go back to (only the first try) */
		memcpy(TRY.lines, s->cfg.outputs, sizeof(TRY.lines));
		TRY.count = s->cfg.output_count;
	}
	TRY.pending = true;
	if (!TRY.timer) TRY.timer = wl_event_loop_add_timer(s->loop, try_timeout, s);
	wl_event_source_timer_update(TRY.timer, secs * 1000);
	apply_outputs_set(s, rest);
}

static void apply_output_cmd(struct lumen_server *s, char *arg) {
	char *sp = strchr(arg, ' ');
	if (!sp) return;
	*sp = 0;
	struct lumen_output *o, *hit = NULL;
	wl_list_for_each(o, &s->outputs, link) if (!strcmp(o->wlr_output->name, arg)) hit = o;
	if (!hit) return;
	/* temporarily make this the config line and reuse the startup path */
	if (s->cfg.output_count < 8) {
		int i;
		for (i = 0; i < s->cfg.output_count; i++)
			if (!strncmp(s->cfg.outputs[i], arg, strlen(arg)) && s->cfg.outputs[i][strlen(arg)] == ' ') break;
		snprintf(s->cfg.outputs[i], sizeof(s->cfg.outputs[0]), "%s %s", arg, sp + 1);
		if (i == s->cfg.output_count) s->cfg.output_count++;
	}
	outputs_apply_config(s);
	ipc_state_changed(s);
}

/* "thumb ID MAXW PATH": PNG of a window's content (taskbar hover previews) */
static bool write_thumb(struct lumen_server *s, char *arg) {
	unsigned id = 0, maxw = 0;
	char path[256];
	if (sscanf(arg, "%u %u %255s", &id, &maxw, path) != 3 || maxw < 16 || maxw > 1024) return false;
	struct lumen_view *v = view_by_id(s, id);
	if (!v) return false;
	struct wlr_surface *sf = view_surface(v);
	if (!sf || !sf->buffer || !sf->buffer->texture) return false;
	struct wlr_texture *tex = sf->buffer->texture;
	int tw = tex->width, th = tex->height;
	if (tw <= 0 || th <= 0 || tw > 16384 || th > 16384) return false;
	unsigned char *px = malloc((size_t)tw * th * 4);
	if (!px) return false;
	bool ok = wlr_texture_read_pixels(tex, &(struct wlr_texture_read_pixels_options){
		.data = px, .format = DRM_FORMAT_ARGB8888, .stride = tw * 4 });
	if (ok) {
		/* crop to the window geometry (drop client-side shadows) */
		double bs = sf->current.width > 0 ? tw / (double)sf->current.width : 1;
		struct wlr_box g = { 0, 0, sf->current.width, sf->current.height };
		if (v->type == VIEW_XDG && v->xdg->base->geometry.width > 0) g = v->xdg->base->geometry;
		int cx = (int)(g.x * bs), cy = (int)(g.y * bs), cw = (int)(g.width * bs), ch = (int)(g.height * bs);
		if (cx < 0) cx = 0;
		if (cy < 0) cy = 0;
		if (cx + cw > tw) cw = tw - cx;
		if (cy + ch > th) ch = th - cy;
		cairo_surface_t *src = cairo_image_surface_create_for_data(px, CAIRO_FORMAT_ARGB32, tw, th, tw * 4);
		double k = cw > (int)maxw ? maxw / (double)cw : 1.0;
		int ow = (int)(cw * k), oh = (int)(ch * k);
		if (ow < 1) ow = 1;
		if (oh < 1) oh = 1;
		cairo_surface_t *dst = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, ow, oh);
		cairo_t *cr = cairo_create(dst);
		cairo_scale(cr, k, k);
		cairo_set_source_surface(cr, src, -cx, -cy);
		cairo_pattern_set_filter(cairo_get_source(cr), CAIRO_FILTER_GOOD);
		cairo_paint(cr);
		cairo_destroy(cr);
		ok = cairo_surface_write_to_png(dst, path) == CAIRO_STATUS_SUCCESS;
		cairo_surface_destroy(dst);
		cairo_surface_destroy(src);
	}
	free(px);
	return ok;
}

static void client_free(struct ipc_client *c) {
	wl_event_source_remove(c->src);
	close(c->fd);
	wl_list_remove(&c->link);
	free(c);
}

static void send_line(struct ipc_client *c, const char *data, size_t len) {
	ssize_t w = send(c->fd, data, len, MSG_NOSIGNAL | MSG_DONTWAIT);
	(void)w;
}

static void run_cmd(struct lumen_server *s, struct ipc_client *c, char *line) {
	char *arg = strchr(line, ' ');
	if (arg) *arg++ = 0;
	uint32_t id = arg ? (uint32_t)strtoul(arg, NULL, 10) : 0;
	struct lumen_view *v = id ? view_by_id(s, id) : NULL;

	if (!strcmp(line, "subscribe") || !strcmp(line, "state")) {
		if (line[1] == 'u') c->subscribed = true;
		size_t len; char *st = build_state(s, &len);
		send_line(c, st, len);
		free(st);
		return;
	}
	if (!strcmp(line, "stats")) {     /* how busy are we? (frames drawn so far) */
		char buf[96];
		int n = snprintf(buf, sizeof(buf), "{\"liquid_frames\":%lu}\n", liquid_frames());
		send_line(c, buf, (size_t)n);
		return;
	}
	if (!strcmp(line, "outputs")) {
		size_t len; char *st = build_outputs(s, &len);
		send_line(c, st, len);
		free(st);
		return;
	}
	if (!strcmp(line, "thumb") && arg) {
		bool ok = write_thumb(s, arg);
		send_line(c, ok ? "ok\n" : "err\n", ok ? 3 : 4);
		return;
	}
	if (!strcmp(line, "output") && arg) { apply_output_cmd(s, arg); send_line(c, "ok\n", 3); return; }
	if (!strcmp(line, "outputs-set") && arg) { apply_outputs_set(s, arg); send_line(c, "ok\n", 3); return; }
	if (!strcmp(line, "outputs-try") && arg) { outputs_try(s, arg); send_line(c, "ok\n", 3); return; }
	if (!strcmp(line, "outputs-keep")) {
		TRY.pending = false;
		if (TRY.timer) wl_event_source_timer_update(TRY.timer, 0);
		send_line(c, "ok\n", 3);
		return;
	}
	if (!strcmp(line, "outputs-revert")) { outputs_revert(s, false); send_line(c, "ok\n", 3); return; }
	if (!strcmp(line, "float")) { view_toggle_floating(v ? v : focused_view(s)); send_line(c, "ok\n", 3); return; }
	if (!strcmp(line, "workspace") && arg) workspace_switch(s, atoi(arg) - 1);
	else if (!strcmp(line, "focus")) focus_view(v);
	else if (!strcmp(line, "toggle") && v) {
		/* Windows taskbar semantics: click focused = minimise, else bring forward */
		if (focused_view(s) == v && !v->minimized) view_set_minimized(v, true);
		else focus_view(v);
	}
	else if (!strcmp(line, "close")) view_close(v);
	else if (!strcmp(line, "minimize")) view_set_minimized(v, true);
	else if (!strcmp(line, "maximize")) view_toggle_maximize(v);
	else if (!strcmp(line, "ontop")) view_toggle_on_top(v);
	else if (!strcmp(line, "move") && v) {
		const char *ws = strchr(arg, ' ');
		if (ws) view_move_to_workspace(v, atoi(ws + 1) - 1);
	}
	else if (!strcmp(line, "snap") && v) {      /* "snap ID left|right" */
		const char *side = strchr(arg, ' ');
		if (side) snap_half(v, !strncmp(side + 1, "left", 4));
	}
	else if (!strcmp(line, "place") && v) {     /* "place ID X Y": the window's top-left corner */
		int x, y;
		const char *xy = strchr(arg, ' ');
		if (xy && sscanf(xy, "%d %d", &x, &y) == 2 && !v->maximized && !v->fullscreen) view_move_to(v, x, y);
	}
	else if (!strcmp(line, "exec") && arg) spawn(arg);
	else if (!strcmp(line, "paste")) input_paste(s);      /* clipboard history: Ctrl+V into the app */
	else if (!strcmp(line, "icons")) {     /* taskbar icon positions (genie); no reply */
		if (arg) genie_set_icons(s, arg);
		return;
	}
	else if (!strcmp(line, "glass")) {     /* streamed by the shell; no reply */
		if (arg) liquid_set_from_ipc(s, arg);
		return;
	}
	else if (!strcmp(line, "shell") && arg) ipc_shell(s, arg);
	else if (!strcmp(line, "overview")) overview_toggle();
	else if (!strcmp(line, "desktop")) views_show_desktop(s, !views_desktop_shown());
	else if (!strcmp(line, "lock")) spawn("lumen-lock");
	else if (!strcmp(line, "reload")) {
		bool was_liquid = liquid_enabled(s);
		config_load(&s->cfg);
		apply_blur(s);
		views_refresh_style(s);
		input_reload(s);
		outputs_apply_config(s);
		tile_all(s);
		liquid_retry();
		/* the glass style changed: pour from one into the other */
		if (liquid_enabled(s) != was_liquid) liquid_pour_start(s, !was_liquid);
	}
	else if (!strcmp(line, "quit")) wl_display_terminate(s->display);
	send_line(c, "ok\n", 3);
}

static int client_readable(int fd, uint32_t mask, void *data) {
	struct ipc_client *c = data;
	if (mask & (WL_EVENT_HANGUP | WL_EVENT_ERROR)) { client_free(c); return 0; }
	ssize_t n = read(fd, c->buf + c->len, sizeof(c->buf) - c->len - 1);
	if (n <= 0) { client_free(c); return 0; }
	c->len += n;
	c->buf[c->len] = 0;
	char *nl;
	while ((nl = memchr(c->buf, '\n', c->len))) {
		*nl = 0;
		run_cmd(g_server, c, c->buf);
		size_t used = nl - c->buf + 1;
		memmove(c->buf, nl + 1, c->len - used);
		c->len -= used;
	}
	if (c->len >= sizeof(c->buf) - 1) c->len = 0;  /* overlong line: drop */
	return 0;
}

static int accept_client(int fd, uint32_t mask, void *data) {
	(void)mask;
	struct lumen_server *s = data;
	int cfd = accept4(fd, NULL, NULL, SOCK_CLOEXEC | SOCK_NONBLOCK);
	if (cfd < 0) return 0;
	struct ipc_client *c = calloc(1, sizeof(*c));
	c->fd = cfd;
	c->src = wl_event_loop_add_fd(s->loop, cfd, WL_EVENT_READABLE, client_readable, c);
	wl_list_insert(&s->ipc_clients, &c->link);
	return 0;
}

/* coalesce bursts of changes into one broadcast per ~16ms */
static int flush_state(void *data) {
	struct lumen_server *s = data;
	s->state_dirty = false;
	size_t len; char *st = build_state(s, &len);
	struct ipc_client *c, *tmp;
	wl_list_for_each_safe(c, tmp, &s->ipc_clients, link)
		if (c->subscribed) send_line(c, st, len);
	free(st);
	return 0;
}

/* ask the running shell to toggle a panel; false if no shell is listening */
bool ipc_shell(struct lumen_server *s, const char *what) {
	char line[160];
	int n = snprintf(line, sizeof(line), "{\"event\":\"shell\",\"what\":\"%s\"}\n", what);
	bool sent = false;
	struct ipc_client *c, *tmp;
	wl_list_for_each_safe(c, tmp, &s->ipc_clients, link) {
		if (!c->subscribed) continue;
		send_line(c, line, (size_t)n);
		sent = true;
	}
	return sent;
}

void ipc_state_changed(struct lumen_server *s) {
	if (!s || !s->state_timer || s->state_dirty) return;
	s->state_dirty = true;
	wl_event_source_timer_update(s->state_timer, 16);
}

void ipc_init(struct lumen_server *s) {
	wl_list_init(&s->ipc_clients);
	const char *rt = getenv("XDG_RUNTIME_DIR");
	const char *wd = getenv("WAYLAND_DISPLAY");
	snprintf(sock_path, sizeof(sock_path), "%s/lumen-%s.sock", rt ? rt : "/tmp", wd ? wd : "0");
	setenv("LUMEN_SOCK", sock_path, 1);
	unlink(sock_path);
	s->ipc_fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
	struct sockaddr_un addr = { .sun_family = AF_UNIX };
	snprintf(addr.sun_path, sizeof(addr.sun_path), "%s", sock_path);
	if (bind(s->ipc_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0 || listen(s->ipc_fd, 8) < 0) {
		wlr_log(WLR_ERROR, "IPC: cannot listen on %s: %s", sock_path, strerror(errno));
		close(s->ipc_fd);
		s->ipc_fd = -1;
		return;
	}
	s->ipc_source = wl_event_loop_add_fd(s->loop, s->ipc_fd, WL_EVENT_READABLE, accept_client, s);
	s->state_timer = wl_event_loop_add_timer(s->loop, flush_state, s);
	wlr_log(WLR_INFO, "IPC listening on %s", sock_path);
}

void ipc_finish(struct lumen_server *s) {
	struct ipc_client *c, *tmp;
	wl_list_for_each_safe(c, tmp, &s->ipc_clients, link) client_free(c);
	if (s->ipc_fd >= 0) { close(s->ipc_fd); unlink(sock_path); }
}
