/* Genie: windows flow out of their taskbar icon when they open (and when they
 * come back from being minimised), and pour back into it when minimised.
 *
 * The real window is hidden while a stand-in made of thin horizontal strips of
 * its own picture runs the effect. Each strip has its own width and position:
 * the part already "out" of the icon is wide, the part still near the icon is
 * squeezed toward it — that funnel is what reads as a genie.
 *
 * Where the icons are: the shell reports its taskbar buttons ("icons" over IPC)
 * per monitor, relative to the taskbar surface; we add the surface's position
 * at the moment the animation starts. */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <wlr/types/wlr_buffer.h>
#include <wlr/types/wlr_compositor.h>
#include <wlr/types/wlr_layer_shell_v1.h>
#include "lumen.h"

#define STRIPS 26
#define MAX_ICONS 40
#define MAX_GENIES 8

/* ------------------------------------------------------- icon positions */
struct icon_entry {
	char output[32];
	char keys[200];        /* ",firefox,org.mozilla.firefox," */
	struct wlr_box box;    /* relative to that monitor's taskbar surface */
};
static struct icon_entry icons[MAX_ICONS];
static int n_icons;

static void lower(char *s) { for (; *s; s++) if (*s >= 'A' && *s <= 'Z') *s += 32; }

/* "icons OUTPUT keys x y w h|keys x y w h|…" (keys comma-separated, lowercase) */
void genie_set_icons(struct lumen_server *s, char *arg) {
	(void)s;
	char *sp = strchr(arg, ' ');
	char out[32];
	snprintf(out, sizeof(out), "%.*s", sp ? (int)(sp - arg) : (int)strlen(arg), arg);
	/* drop this monitor's old entries */
	int w = 0;
	for (int i = 0; i < n_icons; i++)
		if (strcmp(icons[i].output, out)) icons[w++] = icons[i];
	n_icons = w;
	if (!sp) return;
	char *save = NULL;
	for (char *e = strtok_r(sp + 1, "|", &save); e && n_icons < MAX_ICONS; e = strtok_r(NULL, "|", &save)) {
		char keys[180];
		int x, y, bw, bh;
		if (sscanf(e, " %179s %d %d %d %d", keys, &x, &y, &bw, &bh) != 5 || bw <= 0 || bh <= 0) continue;
		struct icon_entry *ic = &icons[n_icons++];
		snprintf(ic->output, sizeof(ic->output), "%s", out);
		snprintf(ic->keys, sizeof(ic->keys), ",%s,", keys);
		lower(ic->keys);
		ic->box = (struct wlr_box){ x, y, bw, bh };
	}
}

/* the taskbar surface of a monitor, in layout coordinates */
static bool taskbar_origin(struct lumen_server *s, const char *output, int *ox, int *oy) {
	struct lumen_output *o;
	wl_list_for_each(o, &s->outputs, link) {
		if (strcmp(o->wlr_output->name, output)) continue;
		for (int i = 0; i < 4; i++) {
			struct lumen_layer_surface *l;
			wl_list_for_each(l, &o->layers[i], link) {
				const char *ns = l->layer_surface->namespace;
				if (l->mapped && ns && !strcmp(ns, "lumen-taskbar"))
					return wlr_scene_node_coords(&l->scene->tree->node, ox, oy) || true;
			}
		}
	}
	return false;
}

/* where `v`'s icon is: its app's taskbar button on the monitor it's on (or any
 * monitor), else the Start button, else the bottom middle of the screen */
static struct wlr_box icon_for_view(struct lumen_view *v) {
	struct lumen_server *s = v->server;
	struct lumen_output *o = output_at(s, v->geom.x + v->geom.width / 2.0, v->geom.y + v->geom.height / 2.0);
	if (!o) o = output_focused(s);
	char id[160], last[160], k1[170], k2[170];
	snprintf(id, sizeof(id), "%s", view_app_id(v) ? view_app_id(v) : "");
	lower(id);
	const char *dot = strrchr(id, '.');
	snprintf(last, sizeof(last), "%s", dot ? dot + 1 : id);
	snprintf(k1, sizeof(k1), ",%s,", id);
	snprintf(k2, sizeof(k2), ",%s,", last);
	struct icon_entry *best = NULL, *start = NULL;
	for (int pass = 0; pass < 2 && !best; pass++)
		for (int i = 0; i < n_icons; i++) {
			struct icon_entry *ic = &icons[i];
			bool here = o && !strcmp(ic->output, o->wlr_output->name);
			if (pass == 0 && !here) continue;          /* this monitor's taskbar first */
			if (here && !start && strstr(ic->keys, ",@start,")) start = ic;
			if (*id && (strstr(ic->keys, k1) || (*last && strstr(ic->keys, k2)))) { best = ic; break; }
		}
	struct icon_entry *use = best ? best : start;
	int ox, oy;
	if (use && taskbar_origin(s, use->output, &ox, &oy))
		return (struct wlr_box){ ox + use->box.x, oy + use->box.y, use->box.width, use->box.height };
	if (!o) return (struct wlr_box){ 0, 0, 48, 48 };
	return (struct wlr_box){ o->full.x + o->full.width / 2 - 24, o->full.y + o->full.height - 52, 48, 48 };
}

/* ------------------------------------------------------------ the effect */
struct genie {
	struct lumen_view *v;
	struct wlr_scene_tree *tree;
	struct wlr_scene_rect *rect[STRIPS];
	struct wlr_scene_buffer *buf[STRIPS];
	struct wlr_box win, icon;
	int title_h;                   /* top part drawn as the titlebar colour (server-side frames) */
	struct wlr_fbox src;           /* the window's picture within its buffer */
	bool opening;
	double proxy_k;                /* stand-in opacity during the hand-over */
	void (*done)(struct lumen_view *v);
};
static struct genie G[MAX_GENIES];

static double clamp01(double x) { return x < 0 ? 0 : (x > 1 ? 1 : x); }
static double ease_io(double x) { x = clamp01(x); return x < 0.5 ? 4 * x * x * x : 1 - pow(-2 * x + 2, 3) / 2; }
static double ease_out(double x) { x = clamp01(x); return 1 - pow(1 - x, 3); }

static void layout(struct genie *g, double p) {
	/* p: 0 = in the icon, 1 = the full window */
	struct wlr_box W = g->win, I = g->icon;
	double icx = I.x + I.width / 2.0, wcx = W.x + W.width / 2.0;
	/* vertical: the top leaves the icon first, the bottom follows */
	double ytop = lerp(I.y, W.y, ease_out(p * 1.25));
	double ybot = lerp(I.y + I.height, W.y + W.height, ease_io(p));
	double a = clamp01(p * 2.4) * g->proxy_k;
	float tint[4];
	const float *gt = g->v->server->cfg.glass_tint;
	float ta = fminf(1.f, gt[3] + 0.25f) * (float)a;
	tint[0] = gt[0] * ta; tint[1] = gt[1] * ta; tint[2] = gt[2] * ta; tint[3] = ta;
	double H = W.height > 0 ? W.height : 1;
	for (int i = 0; i < STRIPS; i++) {
		double f0 = i / (double)STRIPS, f1 = (i + 1) / (double)STRIPS, fc = (f0 + f1) / 2;
		int y0 = (int)lround(lerp(ytop, ybot, f0)), y1 = (int)lround(lerp(ytop, ybot, f1));
		int h = y1 - y0 < 1 ? 1 : y1 - y0;
		/* horizontal funnel: strips far from the icon (top) widen first */
		double ph = ease_io(p * 1.7 - fc * 0.7);
		double cx = lerp(icx, wcx, ph);
		double w = lerp(I.width, W.width, ph);
		if (w < 2) w = 2;
		int x = (int)lround(cx - w / 2);
		bool title = fc * H < g->title_h;
		wlr_scene_node_set_enabled(&g->rect[i]->node, title);
		wlr_scene_node_set_enabled(&g->buf[i]->node, !title);
		if (title) {
			wlr_scene_node_set_position(&g->rect[i]->node, x, y0);
			wlr_scene_rect_set_size(g->rect[i], (int)w, h);
			wlr_scene_rect_set_color(g->rect[i], tint);
		} else {
			/* this strip's slice of the window's picture */
			double c0 = (f0 * H - g->title_h) / (H - g->title_h), c1 = (f1 * H - g->title_h) / (H - g->title_h);
			c0 = clamp01(c0); c1 = clamp01(c1);
			struct wlr_fbox sb = { g->src.x, g->src.y + c0 * g->src.height, g->src.width,
				(c1 - c0) * g->src.height };
			if (sb.height < 0.5) sb.height = 0.5;
			if (sb.y + sb.height > g->src.y + g->src.height) sb.y = g->src.y + g->src.height - sb.height;
			if (sb.y < 0) sb.y = 0;
			wlr_scene_buffer_set_source_box(g->buf[i], &sb);
			wlr_scene_buffer_set_dest_size(g->buf[i], (int)w, h);
			wlr_scene_node_set_position(&g->buf[i]->node, x, y0);
			wlr_scene_buffer_set_opacity(g->buf[i], (float)a);
		}
	}
}

/* the window's picture: its geometry within the buffer (no client shadows) */
bool genie_source(struct lumen_view *v, struct wlr_buffer **out, struct wlr_fbox *src) {
	struct wlr_surface *sf = view_surface(v);
	struct wlr_buffer *b = sf && sf->buffer ? &sf->buffer->base : NULL;
	if (!b) return false;
	struct wlr_box geo = v->type == VIEW_XDG ? v->xdg->base->geometry
		: (struct wlr_box){ 0, 0, sf->current.width, sf->current.height };
	double bs = sf->current.width > 0 ? b->width / (double)sf->current.width : 1;
	*src = (struct wlr_fbox){ geo.x * bs, geo.y * bs, geo.width * bs, geo.height * bs };
	if (src->width <= 0 || src->height <= 0 || src->x + src->width > b->width + 0.5 ||
			src->y + src->height > b->height + 0.5)
		*src = (struct wlr_fbox){ 0, 0, b->width, b->height };
	*out = b;
	return true;
}

/* apps resize right as they open (we hand them their size then): follow the
 * window's real box and picture so the effect lands exactly where it ends up */
static void refresh_source(struct genie *g) {
	struct lumen_view *v = g->v;
	struct wlr_buffer *b;
	struct wlr_fbox src;
	if (!v->mapped || !genie_source(v, &b, &src)) return;
	g->src = src;
	for (int i = 0; i < STRIPS; i++) wlr_scene_buffer_set_buffer(g->buf[i], b);
	if (g->opening && v->geom.width >= 40 && v->geom.height >= 40) g->win = v->geom;
}

static void finish(struct genie *g) {
	struct lumen_view *v = g->v;
	void (*done)(struct lumen_view *) = g->done;
	if (g->tree) wlr_scene_node_destroy(&g->tree->node);
	memset(g, 0, sizeof(*g));
	if (v && done) done(v);
}

static void step(struct anim *a, double t) {
	struct genie *g = a->owner;
	if (!g->v) return;
	/* layout() shapes the motion itself: feed it plain time */
	double lin = a->dur_ms > 0 ? (now_ms() - a->start_ms) / a->dur_ms : 1;
	(void)t;
	lin = clamp01(lin);
	refresh_source(g);
	/* hand-over: the real window (rounded corners, shadow, titlebar) fades in
	 * over the stand-in for the last stretch — or out of it at the start of a
	 * minimise — so nothing pops when they swap */
	const double H = 0.24;
	double hand = g->opening ? clamp01((lin - (1 - H)) / H) : clamp01(1 - lin / H);
	hand = hand * hand * (3 - 2 * hand);
	g->proxy_k = 1 - hand;
	view_set_alpha(g->v, hand);
	layout(g, g->opening ? lin : 1 - lin);
}

static void anim_done(struct anim *a) {
	struct genie *g = a->owner;
	if (g->v) finish(g);
}

bool genie_active(struct lumen_view *v) {
	for (int i = 0; i < MAX_GENIES; i++) if (G[i].v == v) return true;
	return false;
}

/* the window is going away for good: drop its stand-in without callbacks */
void genie_cancel(struct lumen_view *v) {
	for (int i = 0; i < MAX_GENIES; i++)
		if (G[i].v == v) {
			anim_cancel(&G[i], -1);
			G[i].done = NULL;
			finish(&G[i]);
		}
}

/* run the effect for `v` (whose tree the caller has hidden). false = couldn't
 * (no picture yet etc.): the caller falls back to its plain animation */
bool genie_run(struct lumen_view *v, bool opening, void (*done)(struct lumen_view *v)) {
	struct lumen_server *s = v->server;
	if (!s->cfg.animations) return false;
	struct wlr_buffer *b;
	struct wlr_fbox src;
	if (!genie_source(v, &b, &src) || v->geom.width < 40 || v->geom.height < 40) return false;
	genie_cancel(v);
	struct genie *g = NULL;
	for (int i = 0; i < MAX_GENIES && !g; i++) if (!G[i].v) g = &G[i];
	if (!g) return false;
	memset(g, 0, sizeof(*g));
	g->v = v;
	g->opening = opening;
	g->proxy_k = opening ? 1 : 0;
	g->done = done;
	g->win = v->geom;
	g->icon = icon_for_view(v);
	g->title_h = v->ssd && !v->fullscreen ? TITLEBAR_H : 0;
	g->src = src;
	g->tree = wlr_scene_tree_create(s->layer[L_WS]);
	wlr_scene_node_raise_to_top(&g->tree->node);
	for (int i = 0; i < STRIPS; i++) {
		g->rect[i] = wlr_scene_rect_create(g->tree, 1, 1, (float[4]){ 0, 0, 0, 0 });
		g->rect[i]->accepts_input = false;
		g->buf[i] = wlr_scene_buffer_create(g->tree, b);
		wlr_scene_buffer_set_filter_mode(g->buf[i], WLR_SCALE_FILTER_BILINEAR);
	}
	layout(g, opening ? 0 : 1);
	anim_start(g, 1, anim_scaled(opening ? 460 : 400), EASE_OUT_CUBIC, step, anim_done);
	return true;
}

/* ------------------------------------------------------------ close ghost
 * A window that closes itself (Ctrl+Q, the app's own X, `exit`) disappears at
 * once; leave its last frame behind for a moment to fade and settle. */
struct ghost {
	struct wlr_scene_tree *tree;
	struct wlr_scene_rect *title;
	struct wlr_scene_buffer *buf;
	struct wlr_box box;
	int title_h;
	double a0;
};

static void ghost_step(struct anim *a, double t) {
	struct ghost *gh = a->owner;
	double k = lerp(1.0, 0.94, t);             /* settles back a little */
	int w = (int)(gh->box.width * k), h = (int)(gh->box.height * k);
	if (w < 1) w = 1;
	if (h < 1) h = 1;
	int x = gh->box.x + (gh->box.width - w) / 2, y = gh->box.y + (gh->box.height - h) / 2 + (int)(t * 10);
	double alpha = clamp01(gh->a0 * (1 - t));
	wlr_scene_node_set_position(&gh->tree->node, x, y);
	int th = (int)(gh->title_h * k);
	if (gh->title) {
		wlr_scene_rect_set_size(gh->title, w, th > 0 ? th : 1);
		float c[4] = { 0.11f * (float)alpha, 0.12f * (float)alpha, 0.16f * (float)alpha, 0.8f * (float)alpha };
		wlr_scene_rect_set_color(gh->title, c);
	}
	wlr_scene_node_set_position(&gh->buf->node, 0, th);
	wlr_scene_buffer_set_dest_size(gh->buf, w, h - th > 1 ? h - th : 1);
	wlr_scene_buffer_set_opacity(gh->buf, (float)alpha);
}

static void ghost_done(struct anim *a) {
	struct ghost *gh = a->owner;
	wlr_scene_node_destroy(&gh->tree->node);
	free(gh);
}

/* `buf`: the window's last picture (locked by the caller until this returns) */
void genie_close_ghost(struct lumen_view *v, struct wlr_buffer *buf, struct wlr_fbox src) {
	struct lumen_server *s = v->server;
	if (!s->cfg.animations || !buf || v->alpha < 0.05 || v->minimized || v->geom.width < 20) return;
	if (!v->tree->node.enabled) return;                 /* not on screen anyway */
	struct ghost *gh = calloc(1, sizeof(*gh));
	if (!gh) return;
	int lx = 0, ly = 0;
	wlr_scene_node_coords(&v->tree->node, &lx, &ly);
	gh->box = (struct wlr_box){ lx, ly, v->geom.width, v->geom.height };
	gh->title_h = v->ssd && !v->fullscreen ? TITLEBAR_H : 0;
	gh->a0 = v->alpha > 1 ? 1 : v->alpha;
	gh->tree = wlr_scene_tree_create(v->tree->node.parent ? v->tree->node.parent : s->layer[L_WS]);
	wlr_scene_node_place_above(&gh->tree->node, &v->tree->node);
	if (gh->title_h) {
		gh->title = wlr_scene_rect_create(gh->tree, 1, 1, (float[4]){ 0, 0, 0, 0 });
		gh->title->accepts_input = false;
		wlr_scene_rect_set_corner_radius(gh->title, 0);
	}
	gh->buf = wlr_scene_buffer_create(gh->tree, buf);   /* the scene keeps its own lock */
	if (src.width > 0 && src.height > 0 && src.x >= 0 && src.y >= 0 &&
			src.x + src.width <= buf->width + 0.5 && src.y + src.height <= buf->height + 0.5)
		wlr_scene_buffer_set_source_box(gh->buf, &src);
	wlr_scene_buffer_set_filter_mode(gh->buf, WLR_SCALE_FILTER_BILINEAR);
	ghost_step(&(struct anim){ .owner = gh }, 0);
	anim_start(gh, 1, s->cfg.anim_ms * 0.75 > 120 ? s->cfg.anim_ms * 0.75 : 180, EASE_OUT_CUBIC,
		ghost_step, ghost_done);
}
