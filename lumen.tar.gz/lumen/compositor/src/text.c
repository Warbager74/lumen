/* Render a line of text with Pango/Cairo into a wlr_buffer for the scene. */
#include <cairo.h>
#include <drm_fourcc.h>
#include <pango/pangocairo.h>
#include <stdlib.h>
#include <wlr/interfaces/wlr_buffer.h>
#include "lumen.h"

struct cairo_buffer {
	struct wlr_buffer base;
	cairo_surface_t *surface;
};

static void cb_destroy(struct wlr_buffer *wb) {
	struct cairo_buffer *b = wl_container_of(wb, b, base);
	cairo_surface_destroy(b->surface);
	free(b);
}

static bool cb_begin(struct wlr_buffer *wb, uint32_t flags, void **data,
		uint32_t *format, size_t *stride) {
	struct cairo_buffer *b = wl_container_of(wb, b, base);
	if (flags & WLR_BUFFER_DATA_PTR_ACCESS_WRITE) return false;
	*data = cairo_image_surface_get_data(b->surface);
	*format = DRM_FORMAT_ARGB8888;
	*stride = cairo_image_surface_get_stride(b->surface);
	return true;
}

static void cb_end(struct wlr_buffer *wb) { (void)wb; }

static const struct wlr_buffer_impl cb_impl = {
	.destroy = cb_destroy,
	.begin_data_ptr_access = cb_begin,
	.end_data_ptr_access = cb_end,
};

struct wlr_buffer *text_buffer_create(const char *text, const char *font,
		const float color[4], int max_w, int height, float scale) {
	if (max_w < 1) max_w = 1;
	int pw = (int)(max_w * scale), ph = (int)(height * scale);
	cairo_surface_t *s = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, pw, ph);
	cairo_t *cr = cairo_create(s);
	cairo_scale(cr, scale, scale);

	PangoLayout *layout = pango_cairo_create_layout(cr);
	PangoFontDescription *desc = pango_font_description_from_string(font);
	pango_layout_set_font_description(layout, desc);
	pango_layout_set_text(layout, text, -1);
	pango_layout_set_width(layout, max_w * PANGO_SCALE);
	pango_layout_set_ellipsize(layout, PANGO_ELLIPSIZE_END);
	pango_layout_set_alignment(layout, PANGO_ALIGN_CENTER);
	int tw, th;
	pango_layout_get_pixel_size(layout, &tw, &th);

	/* soft glow under the text keeps it legible on any glass tint */
	cairo_set_source_rgba(cr, 0, 0, 0, 0.18);
	cairo_move_to(cr, 0, (height - th) / 2.0 + 1);
	pango_cairo_show_layout(cr, layout);
	cairo_set_source_rgba(cr, color[0], color[1], color[2], color[3]);
	cairo_move_to(cr, 0, (height - th) / 2.0);
	pango_cairo_show_layout(cr, layout);

	pango_font_description_free(desc);
	g_object_unref(layout);
	cairo_destroy(cr);
	cairo_surface_flush(s);

	struct cairo_buffer *b = calloc(1, sizeof(*b));
	b->surface = s;
	wlr_buffer_init(&b->base, &cb_impl, pw, ph);
	return &b->base;
}

/* a small window-control glyph: 0 close ×, 1 minimise −, 2 maximise □ (or
 * restore ⧉ when `alt`), thin strokes like Windows 11's Segoe Fluent icons */
struct wlr_buffer *glyph_buffer_create(int kind, bool alt, const float color[4], int size, float scale) {
	int px = (int)(size * scale + 0.5f);
	if (px < 2) px = 2;
	cairo_surface_t *surf = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, px, px);
	cairo_t *cr = cairo_create(surf);
	cairo_scale(cr, scale, scale);
	cairo_set_source_rgba(cr, color[0], color[1], color[2], color[3]);
	cairo_set_line_width(cr, 1.15);
	cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
	double c = size / 2.0, r = size * 0.28;
	switch (kind) {
	case 0:
		cairo_move_to(cr, c - r, c - r); cairo_line_to(cr, c + r, c + r);
		cairo_move_to(cr, c + r, c - r); cairo_line_to(cr, c - r, c + r);
		break;
	case 1:
		cairo_move_to(cr, c - r, c + 0.5); cairo_line_to(cr, c + r, c + 0.5);
		break;
	default:
		if (alt) {
			cairo_rectangle(cr, c - r + 0.5, c - r + 2.5, 2 * r - 2, 2 * r - 2);
			cairo_move_to(cr, c - r + 2.5, c - r + 0.5);
			cairo_line_to(cr, c + r + 0.5, c - r + 0.5);
			cairo_line_to(cr, c + r + 0.5, c + r - 1.5);
		} else {
			cairo_rectangle(cr, c - r + 0.5, c - r + 0.5, 2 * r, 2 * r);
		}
		break;
	}
	cairo_stroke(cr);
	cairo_destroy(cr);
	cairo_surface_flush(surf);
	struct cairo_buffer *b = calloc(1, sizeof(*b));
	wlr_buffer_init(&b->base, &cb_impl, px, px);
	b->surface = surf;
	return &b->base;
}
