/* ext-session-lock-v1: lets swaylock (lumen-lock) lock the session.
 * While locked: a solid cover hides everything, keyboard/pointer go only to
 * the lock surfaces, and compositor shortcuts are disabled. If the lock client
 * dies without unlocking, the session stays locked (run swaylock again from a
 * TTY to get back in) — it never fails open. */
#include <stdlib.h>
#include <wlr/types/wlr_session_lock_v1.h>
#include <wlr/util/log.h>
#include "lumen.h"

struct lock_surface {
	struct lumen_server *s;
	struct wlr_session_lock_surface_v1 *ls;
	struct wl_listener map, destroy;
};

static struct {
	struct lumen_server *s;
	struct wlr_session_lock_manager_v1 *mgr;
	struct wl_listener new_lock;
	struct wlr_session_lock_v1 *lock;          /* NULL if the client went away */
	struct wl_listener new_surface, unlock, destroy;
	struct wlr_scene_tree *tree;
	struct wlr_scene_rect *cover;
	bool locked;
	struct wlr_surface *focus;                 /* lock surface holding the keyboard */
} L;

bool session_locked(void) { return L.locked; }

static void cover_outputs(void) {
	struct wlr_box box;
	wlr_output_layout_get_box(L.s->output_layout, NULL, &box);
	wlr_scene_rect_set_size(L.cover, box.width, box.height);
	wlr_scene_node_set_position(&L.cover->node, box.x, box.y);
}

static void focus_lock_surface(struct wlr_surface *surface) {
	L.focus = surface;
	seat_focus(L.s, surface);
}

static void ls_map(struct wl_listener *l, void *data) {
	(void)data;
	struct lock_surface *x = wl_container_of(l, x, map);
	if (!L.focus) focus_lock_surface(x->ls->surface);
	pointer_refocus(x->s);
}

static void ls_destroy(struct wl_listener *l, void *data) {
	(void)data;
	struct lock_surface *x = wl_container_of(l, x, destroy);
	if (L.focus == x->ls->surface) L.focus = NULL;
	wl_list_remove(&x->map.link);
	wl_list_remove(&x->destroy.link);
	free(x);
}

static void new_surface(struct wl_listener *l, void *data) {
	(void)l;
	struct wlr_session_lock_surface_v1 *ls = data;
	struct lock_surface *x = calloc(1, sizeof(*x));
	x->s = L.s;
	x->ls = ls;
	struct wlr_box box;
	wlr_output_layout_get_box(L.s->output_layout, ls->output, &box);
	struct wlr_scene_tree *t = wlr_scene_subsurface_tree_create(L.tree, ls->surface);
	wlr_scene_node_set_position(&t->node, box.x, box.y);
	wlr_session_lock_surface_v1_configure(ls, box.width, box.height);
	x->map.notify = ls_map;
	wl_signal_add(&ls->surface->events.map, &x->map);
	x->destroy.notify = ls_destroy;
	wl_signal_add(&ls->events.destroy, &x->destroy);
}

static void drop_lock_listeners(void) {
	if (!L.lock) return;
	wl_list_remove(&L.new_surface.link);
	wl_list_remove(&L.unlock.link);
	wl_list_remove(&L.destroy.link);
	L.lock = NULL;
}

static void unlock(struct wl_listener *l, void *data) {
	(void)l; (void)data;
	struct lumen_server *s = L.s;
	drop_lock_listeners();
	L.locked = false;
	L.focus = NULL;
	if (L.tree) wlr_scene_node_destroy(&L.tree->node);
	L.tree = NULL;
	/* back to the desktop: keyboard to the top window */
	wlr_seat_keyboard_notify_clear_focus(s->seat);
	struct lumen_view *v;
	wl_list_for_each(v, &s->views, link)
		if (v->mapped && !v->minimized && v->workspace == s->ws_current) { focus_view(v); break; }
	pointer_refocus(s);
	wlr_log(WLR_INFO, "session unlocked");
}

static void lock_destroy(struct wl_listener *l, void *data) {
	(void)l; (void)data;
	/* client gone without unlocking: stay locked (fail closed) */
	drop_lock_listeners();
	L.focus = NULL;
	wlr_log(WLR_ERROR, "lock client died while locked; staying locked (run lumen-lock again)");
}

static void new_lock(struct wl_listener *l, void *data) {
	(void)l;
	struct wlr_session_lock_v1 *lock = data;
	struct lumen_server *s = L.s;
	if (L.lock) {            /* already locked by a live client */
		wlr_session_lock_v1_destroy(lock);
		return;
	}
	if (!L.tree) {
		L.tree = wlr_scene_tree_create(s->layer[L_LOCK]);
		L.cover = wlr_scene_rect_create(L.tree, 0, 0, (float[4]){ 0.02f, 0.02f, 0.04f, 1 });
		cover_outputs();
	}
	L.lock = lock;
	L.locked = true;
	wlr_seat_keyboard_notify_clear_focus(s->seat);
	wlr_seat_pointer_clear_focus(s->seat);
	if (overview_active()) overview_close(NULL);
	L.new_surface.notify = new_surface;
	wl_signal_add(&lock->events.new_surface, &L.new_surface);
	L.unlock.notify = unlock;
	wl_signal_add(&lock->events.unlock, &L.unlock);
	L.destroy.notify = lock_destroy;
	wl_signal_add(&lock->events.destroy, &L.destroy);
	wlr_session_lock_v1_send_locked(lock);
	wlr_log(WLR_INFO, "session locked");
}

void lock_init(struct lumen_server *s) {
	L.s = s;
	L.mgr = wlr_session_lock_manager_v1_create(s->display);
	L.new_lock.notify = new_lock;
	wl_signal_add(&L.mgr->events.new_lock, &L.new_lock);
}

void lock_outputs_changed(void) {
	if (L.tree) cover_outputs();
}

/* pointer while locked: only lock surfaces receive events */
struct wlr_surface *lock_surface_at(double lx, double ly, double *sx, double *sy) {
	if (!L.tree) return NULL;
	struct wlr_scene_node *n = wlr_scene_node_at(&L.tree->node, lx, ly, sx, sy);
	if (!n || n->type != WLR_SCENE_NODE_BUFFER) return NULL;
	struct wlr_scene_surface *ss = wlr_scene_surface_try_from_buffer(wlr_scene_buffer_from_node(n));
	return ss ? ss->surface : NULL;
}

void lock_focus_surface(struct wlr_surface *surface) {
	if (L.locked && surface && surface != L.focus) focus_lock_surface(surface);
}
