/* Lumen — a liquid-glass Wayland compositor built on wlroots + SceneFX. */
#ifndef LUMEN_H
#define LUMEN_H


#include <stdbool.h>
#include <wlr/config.h>
#include <stdint.h>
#include <time.h>
#include <wayland-server-core.h>
#include <wlr/backend.h>
#include <wlr/backend/session.h>
#include <wlr/render/allocator.h>
#include <wlr/render/wlr_renderer.h>
#include <wlr/types/wlr_compositor.h>
#include <wlr/types/wlr_cursor.h>
#include <wlr/types/wlr_foreign_toplevel_management_v1.h>
#include <wlr/types/wlr_keyboard.h>
#include <wlr/types/wlr_layer_shell_v1.h>
#include <wlr/types/wlr_output.h>
#include <wlr/types/wlr_output_layout.h>
#include <wlr/types/wlr_seat.h>
#include <wlr/types/wlr_xcursor_manager.h>
#include <wlr/types/wlr_xdg_decoration_v1.h>
#include <wlr/types/wlr_xdg_shell.h>
#include <wlr/types/wlr_cursor_shape_v1.h>
#include <wlr/util/box.h>
#if WLR_HAS_XWAYLAND
#include <wlr/xwayland.h>
#endif
#include <scenefx/types/wlr_scene.h>
#include <scenefx/types/fx/clipped_region.h>

#define LUMEN_WORKSPACES 10
#define TITLEBAR_H 36

/* ------------------------------------------------------------------ config */
struct lumen_config {
	char terminal[256];
	char launcher[256];
	char browser[256];
	char file_manager[256];
	char autostart[16][512];
	int autostart_count;
	char kb_layout[64];
	char kb_options[128];
	int corner_radius;
	int blur_passes;
	int blur_radius;
	float blur_brightness, blur_saturation, blur_noise;
	char glass_style[16];       /* "frosted" | "liquid" */
	bool liquid;
	float liquid_rim, liquid_refraction, liquid_highlight, liquid_frost;
	float shadow_sigma;
	float shadow_color[4];
	float glass_tint[4];        /* tint painted behind translucent chrome */
	float title_color[4];
	char color_scheme[16];      /* dark | light (Settings → Appearance) */
	bool light;
	int gaps;
	int anim_ms;                /* base animation duration */
	bool animations;
	bool xwayland;              /* run X11 apps through Xwayland (lazy-started) */
	bool gestures;              /* touchpad: swipe up = overview, sideways = desktops */
	int gesture_fingers;
	bool natural_scroll;        /* touchpads */
	bool mouse_natural_scroll;
	bool blur_full_redraw;
	bool focus_follows_mouse;
	bool performance_mode;
	bool preload_apps;          /* keep Files / Settings resident for instant opening */      /* games / battery: no blur, shadows or animations */   /* keyboard focus goes to the window under the pointer */      /* redraw whole frames (works around SceneFX partial-redraw blur glitches) */  /* mice / wheels (off: classic wheel direction) */
	int repeat_rate, repeat_delay;
	/* window management */
	bool tiling;                /* Hyprland-style dwindle autotiling */
	bool snapping;              /* Windows 11 snap layouts + edge snaps */
	char controls_side[8];      /* "left" (macOS, default) | "right" (Windows) */
	float accent[4];            /* shell accent colour (snap layouts, previews) */
	/* displays: "NAME mode=WxH@Hz scale=S transform=0|90|180|270 pos=X,Y" */
	char outputs[8][160];
	int output_count;
};
void config_load(struct lumen_config *cfg);
struct lumen_server;
void outputs_apply_config(struct lumen_server *s);
void outputs_refresh(struct lumen_server *s);
void input_apply_pointer_config(struct lumen_server *s);
void input_init_constraints(struct lumen_server *s);
bool pointer_locked(void);
void input_paste(struct lumen_server *s);
void pointer_warp_init(struct lumen_server *s);

/* --------------------------------------------------------------- animation */
enum easing { EASE_OUT_EXPO, EASE_OUT_BACK, EASE_IN_OUT_CUBIC, EASE_OUT_CUBIC, EASE_SPRING,
	EASE_SPRING_SOFT,    /* a spring that barely overshoots: big moves land softly, no wobble */
	EASE_OUT_QUINT };    /* fast start, long gentle landing */

struct anim {
	struct wl_list link;
	void *owner;
	int tag;                    /* lets owners cancel a specific animation */
	double start_ms, dur_ms;
	enum easing ease;
	void (*step)(struct anim *a, double t);   /* t = eased progress 0..1 (may overshoot) */
	void (*done)(struct anim *a);
	double from[4], to[4];
	bool dead;
};
double now_ms(void);
double ease(enum easing e, double t);
struct anim *anim_start(void *owner, int tag, double dur, enum easing e,
	void (*step)(struct anim *, double), void (*done)(struct anim *));
void anim_cancel(void *owner, int tag);   /* tag < 0 → all tags of owner */
bool anim_tick(void);                     /* returns true while animations remain */
void anim_init(void);
double anim_scaled(double ms);   /* a fixed duration, at the user's animation speed */
static inline double lerp(double a, double b, double t) { return a + (b - a) * t; }

/* --------------------------------------------------------------- text */
struct wlr_buffer *glyph_buffer_create(int kind, bool alt, const float color[4], int size, float scale);
struct wlr_buffer *text_buffer_create(const char *text, const char *font,
	const float color[4], int max_w, int height, float scale);

/* ---------------------------------------------------------------- objects */
enum cursor_mode { CURSOR_PASSTHROUGH, CURSOR_MOVE, CURSOR_RESIZE };
enum lumen_scene_layer { L_BG, L_BOTTOM, L_WS, L_OVERVIEW, L_TOP, L_OVERLAY, L_DRAG, L_LOCK, L_COUNT };

struct lumen_server;

struct lumen_output {
	struct wl_list link;
	struct lumen_server *server;
	struct wlr_output *wlr_output;
	struct wlr_scene_output *scene_output;
	struct wlr_box full, usable;
	struct wl_list layers[4];   /* lumen_layer_surface by zwlr layer */
	int ws;                     /* workspace shown on this monitor */
	struct wlr_swapchain *liquid_sc;
	struct wl_listener frame, request_state, destroy;
};

struct lumen_layer_surface {
	struct wl_list link;
	struct lumen_server *server;
	struct lumen_output *output;
	struct wlr_layer_surface_v1 *layer_surface;
	struct wlr_scene_layer_surface_v1 *scene;
	struct wlr_scene_tree *popup_tree;
	struct wlr_scene_blur *blur;  /* masked by the surface's own alpha */
	bool mapped;
	double alpha, slide;        /* animation state */
	bool unmapping;             /* don't configure a surface that is going away */
	struct wl_listener map, unmap, commit, destroy, new_popup;
};

enum view_type { VIEW_XDG, VIEW_X11 };

struct lumen_view {
	struct wl_list link;          /* server->views, focus order (front = top) */
	struct lumen_server *server;
	enum view_type type;
	struct wlr_xdg_toplevel *xdg;           /* VIEW_XDG */
#if WLR_HAS_XWAYLAND
	struct wlr_xwayland_surface *xsurf;     /* VIEW_X11 */
#endif
	uint32_t id;
	int workspace;

	struct wlr_scene_tree *tree;          /* positioned at frame origin */
	struct wlr_scene_shadow *shadow;
	struct wlr_scene_blur *blur;          /* backdrop blur under the glass */
	struct wlr_scene_rect *frame;         /* glass tint over the blur */
	struct wlr_scene_tree *titlebar;
	struct wlr_scene_rect *lights[3];     /* close, minimize, zoom */
	struct wlr_scene_buffer *title;
	struct wlr_scene_tree *content;       /* positions the client surfaces */
	struct wlr_scene_tree *surface_tree;  /* xdg / subsurface tree (clipped) */

	struct wlr_xdg_toplevel_decoration_v1 *decoration;
	bool ssd;                     /* we draw the titlebar */
	bool mapped, minimized, maximized, fullscreen, closing;
	struct wlr_box geom;          /* frame box in layout coords (incl. titlebar) */
	struct wlr_box saved;         /* geometry before maximize */
	double alpha, scale_y_off;    /* animation state */
	int content_w, content_h;
	char last_title[256];
	bool hover_lights;
	int hover_part;               /* control under the pointer (-1 none) */
	bool floating;                /* excluded from autotiling */
	uint32_t tile_order;
	struct wlr_scene_buffer *glyphs[3];

	struct wlr_foreign_toplevel_handle_v1 *ftl;
	struct wl_listener map, unmap, commit, destroy;
	struct wl_listener request_move, request_resize, request_maximize,
		request_fullscreen, request_minimize, set_title, set_app_id;
	struct wl_listener deco_request_mode, deco_destroy;
	struct wl_listener ftl_activate, ftl_close, ftl_minimize, ftl_maximize;
};

struct lumen_keyboard {
	struct wl_list link;
	struct lumen_server *server;
	struct wlr_keyboard *wlr_keyboard;
	struct wl_listener modifiers, key, destroy;
};

struct lumen_server {
	struct wl_display *display;
	struct wl_event_loop *loop;
	struct wlr_backend *backend;
	struct wlr_session *session;
	struct wlr_compositor *compositor;
#if WLR_HAS_XWAYLAND
	struct wlr_xwayland *xwayland;
	struct wl_listener xwayland_ready, xwayland_new_surface;
#endif
	struct wlr_renderer *renderer;
	struct wlr_allocator *allocator;
	struct wlr_scene *scene;
	struct wlr_scene_output_layout *scene_layout;
	struct wlr_scene_tree *layer[L_COUNT];
	struct wlr_scene_tree *ws_tree[LUMEN_WORKSPACES];
	int ws_current;               /* workspace of the focused monitor */
	struct wlr_box ws_home[LUMEN_WORKSPACES];   /* monitor box a workspace's windows live on */

	struct wlr_output_layout *output_layout;
	struct wl_list outputs;
	struct wl_listener new_output;

	struct wlr_xdg_shell *xdg_shell;
	struct wl_listener new_xdg_toplevel, new_xdg_popup;
	struct wl_list views;
	uint32_t next_view_id;

	struct wlr_layer_shell_v1 *layer_shell;
	struct wl_listener new_layer_surface;
	struct lumen_layer_surface *exclusive_layer;   /* layer holding kb focus */

	struct wlr_xdg_decoration_manager_v1 *deco_mgr;
	struct wl_listener new_decoration;
	struct wlr_foreign_toplevel_manager_v1 *ftl_mgr;
	struct wlr_cursor_shape_manager_v1 *cursor_shape_mgr;
	struct wlr_pointer_gestures_v1 *pointer_gestures;
	struct wlr_idle_notifier_v1 *idle_notifier;
	struct wl_listener swipe_begin, swipe_update, swipe_end, pinch_begin, pinch_update,
		pinch_end, hold_begin, hold_end;
	struct wl_listener request_cursor_shape;

	struct wlr_cursor *cursor;
	struct wlr_xcursor_manager *cursor_mgr;
	struct wl_listener cursor_motion, cursor_motion_abs, cursor_button,
		cursor_axis, cursor_frame;
	enum cursor_mode cursor_mode;
	struct lumen_view *grabbed;
	double grab_x, grab_y;
	struct wlr_box grab_box;
	uint32_t resize_edges;
	uint32_t last_click_ms;
	struct lumen_view *last_click_view;

	struct wlr_seat *seat;
	struct wl_list keyboards;
	struct wl_listener new_input, request_cursor, request_set_selection,
		request_set_primary_selection;

	struct lumen_config cfg;
	int ipc_fd;
	struct wl_event_source *ipc_source;
	struct wl_list ipc_clients;
	bool state_dirty;
	struct wl_event_source *state_timer;
};

extern struct lumen_server *g_server;

/* main.c */
void schedule_frames(struct lumen_server *s);
struct lumen_output *output_at(struct lumen_server *s, double x, double y);
struct lumen_output *output_focused(struct lumen_server *s);
void spawn(const char *cmd);

/* layers.c */
void layers_init(struct lumen_server *s);
void arrange_layers(struct lumen_output *o);
bool layer_is_glass(const char *ns);

/* view.c */
void views_init(struct lumen_server *s);
void focus_view(struct lumen_view *v);
void view_title_tone(struct lumen_view *v, int tone);
/* give a surface the keyboard — also while no keyboard is plugged in (a tablet,
 * a Bluetooth keyboard that connects later): the window is focused all the same */
void seat_focus(struct lumen_server *s, struct wlr_surface *surface);
struct lumen_view *focused_view(struct lumen_server *s);
struct lumen_view *view_at(struct lumen_server *s, double lx, double ly,
	struct wlr_surface **surface, double *sx, double *sy, int *part);
void view_close(struct lumen_view *v);
void view_set_minimized(struct lumen_view *v, bool min);
void view_toggle_maximize(struct lumen_view *v);
void view_animate_to(struct lumen_view *v, struct wlr_box to);
void view_set_fullscreen(struct lumen_view *v, bool fs);
void view_move_to(struct lumen_view *v, int x, int y);
void view_resize_to(struct lumen_view *v, struct wlr_box box);
void view_drag_begin(struct lumen_view *v);
bool view_drag_motion(struct lumen_view *v);
void view_drag_end(struct lumen_view *v);
void view_move_to_workspace(struct lumen_view *v, int ws);
void view_hover_lights(struct lumen_view *v, bool hover);
void view_hover_part(struct lumen_view *v, int part);
void workspace_switch(struct lumen_server *s, int ws);
struct lumen_view *view_by_id(struct lumen_server *s, uint32_t id);
void focus_next_view(struct lumen_server *s);
void popup_attach(struct wlr_xdg_popup *xp, struct wlr_scene_tree *parent_tree);
void views_refresh_style(struct lumen_server *s);
void views_reflow_maximized(struct lumen_output *o);
struct lumen_view *view_create(struct lumen_server *s, enum view_type type);
void view_handle_map(struct lumen_view *v);
void view_handle_unmap(struct lumen_view *v);
void view_destroy(struct lumen_view *v);
void view_update_content(struct lumen_view *v, struct wlr_box g);
void view_title_changed(struct lumen_view *v);
void view_app_id_changed(struct lumen_view *v);
void view_set_ssd(struct lumen_view *v, bool ssd);
void view_begin_grab(struct lumen_view *v, enum cursor_mode mode, uint32_t edges);
struct wlr_surface *view_surface(struct lumen_view *v);
bool view_body_box(struct lumen_view *v, struct wlr_box *out);
const char *view_title(struct lumen_view *v);
const char *view_app_id(struct lumen_view *v);

enum view_part { PART_NONE, PART_CONTENT, PART_TITLE, PART_CLOSE, PART_MIN, PART_ZOOM, PART_EDGE };

/* input.c */
void input_init(struct lumen_server *s);
void focus_layer(struct lumen_server *s, struct lumen_layer_surface *l);
void pointer_refocus(struct lumen_server *s);
void pointer_forget_view(struct lumen_view *v);
void input_reload(struct lumen_server *s);

/* overview.c */
/* liquid.c */
bool liquid_output_commit(struct lumen_output *o);
void liquid_set_from_ipc(struct lumen_server *s, char *arg);
unsigned long liquid_frames(void);
bool liquid_enabled(struct lumen_server *s);
void liquid_startup_check(struct lumen_server *s);
void liquid_shutdown(void);
void liquid_retry(void);
void liquid_pour_start(struct lumen_server *s, bool to_liquid);
void apply_blur(struct lumen_server *s);

/* genie.c — windows flow out of / into their taskbar icon */
void genie_set_icons(struct lumen_server *s, char *arg);
bool genie_run(struct lumen_view *v, bool opening, void (*done)(struct lumen_view *v));
bool genie_active(struct lumen_view *v);
void genie_cancel(struct lumen_view *v);
void view_set_alpha(struct lumen_view *v, double a);
void focus_view_noraise(struct lumen_view *v);
void views_show_desktop(struct lumen_server *s, bool show);
bool views_desktop_shown(void);
bool view_on_top(struct lumen_view *v);
void view_toggle_on_top(struct lumen_view *v);
bool genie_source(struct lumen_view *v, struct wlr_buffer **out, struct wlr_fbox *src);
void genie_close_ghost(struct lumen_view *v, struct wlr_buffer *buf, struct wlr_fbox src);
/* switcher.c — Alt+Tab */
void switcher_init(struct lumen_server *s);
bool switcher_active(void);
void switcher_step(struct lumen_server *s, int dir);
void switcher_commit(void);
void switcher_cancel(void);
bool switcher_key(uint32_t sym, bool shift);
void switcher_modifiers(uint32_t mods);
bool switcher_motion(double x, double y);
bool switcher_click(double x, double y);
void switcher_view_updated(struct lumen_view *v);
void switcher_views_changed(void);
void overview_init(struct lumen_server *s);
bool overview_active(void);
double overview_t(void);
void overview_open(void);
void overview_close(struct lumen_view *focus);
void overview_toggle(void);
void overview_set_t(double t);
void overview_release(double velocity);
void overview_set_ws(int ws);
void overview_drag(double total_dx);
void overview_drag_end(double vx, bool cancelled);
void overview_views_changed(void);
void overview_view_updated(struct lumen_view *v);
void overview_motion(double x, double y);
void overview_click(double x, double y);
bool overview_key(uint32_t sym);

/* lock.c — ext-session-lock-v1 */
void lock_init(struct lumen_server *s);
bool session_locked(void);
void lock_outputs_changed(void);
struct wlr_surface *lock_surface_at(double lx, double ly, double *sx, double *sy);
void lock_focus_surface(struct wlr_surface *surface);

/* view.c — finger-tracked desktop switching */
void workspace_drag_update(struct lumen_server *s, double total_dx);
void workspace_drag_end(struct lumen_server *s, double vx, bool cancelled);
void workspace_strip_sync(struct lumen_server *s);
void workspace_strip_refresh(struct lumen_server *s);
bool view_visible_on(struct lumen_view *v, struct lumen_output *o);
bool view_peeking(struct lumen_view *v);
bool view_adopt_peek(struct lumen_view *v);
struct lumen_output *output_showing(struct lumen_server *s, int ws);
void workspace_assign(struct lumen_server *s, struct lumen_output *o, int ws);
void workspace_output_moved(struct lumen_output *o);
void workspace_output_gone(struct lumen_output *o);
/* tiling.c */
void tile_workspace(struct lumen_server *s, int ws);
void tile_all(struct lumen_server *s);
void view_toggle_floating(struct lumen_view *v);
bool tiling_drop(struct lumen_view *v, double x, double y);
/* snap.c */
void snap_init(struct lumen_server *s);
void snap_motion(struct lumen_server *s, struct lumen_view *v, double x, double y);
bool snap_release(struct lumen_server *s, struct lumen_view *v);
void snap_cancel(struct lumen_server *s);
void snap_half(struct lumen_view *v, bool left);
void snap_flyout_hover(struct lumen_view *v, bool on);
bool snap_flyout_click(double x, double y);
bool snap_flyout_motion(double x, double y);
bool snap_flyout_open(void);

/* xwayland.c */
void xwayland_init(struct lumen_server *s);
void xwayland_finish(struct lumen_server *s);

/* ipc.c */
void ipc_init(struct lumen_server *s);
void ipc_state_changed(struct lumen_server *s);
bool ipc_shell(struct lumen_server *s, const char *what);
void ipc_finish(struct lumen_server *s);

#endif
