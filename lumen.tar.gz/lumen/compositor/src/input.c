/* Keyboard shortcuts, pointer focus, titlebar interaction, move/resize grabs. */
#include <linux/input-event-codes.h>
#include <stdlib.h>
#include <string.h>
#include <wlr/backend/libinput.h>
#include <wlr/types/wlr_data_device.h>
#include <wlr/types/wlr_idle_notify_v1.h>
#include <wlr/types/wlr_input_device.h>
#include <wlr/types/wlr_pointer_gestures_v1.h>
#include <wlr/types/wlr_pointer.h>
#include <wlr/types/wlr_primary_selection.h>
#include <wlr/util/edges.h>
#include <wlr/util/log.h>
#include <xkbcommon/xkbcommon.h>
#include <libinput.h>
#include <math.h>
#include <wlr/types/wlr_pointer_constraints_v1.h>
#include <wlr/types/wlr_relative_pointer_v1.h>
#include <wlr/util/region.h>
#include "lumen.h"

static void activity(struct lumen_server *s) {
	if (s->idle_notifier) wlr_idle_notifier_v1_notify_activity(s->idle_notifier, s->seat);
}


/* ------------------------------------------------------------- layer focus */
void seat_focus(struct lumen_server *s, struct wlr_surface *surface) {
	if (!surface) return;
	struct wlr_keyboard *kb = wlr_seat_get_keyboard(s->seat);
	if (kb) wlr_seat_keyboard_notify_enter(s->seat, surface, kb->keycodes, kb->num_keycodes, &kb->modifiers);
	else wlr_seat_keyboard_notify_enter(s->seat, surface, NULL, 0, NULL);
}

void focus_layer(struct lumen_server *s, struct lumen_layer_surface *l) {
	if (s->exclusive_layer == l) return;
	if (session_locked()) { s->exclusive_layer = l; return; }   /* the lock screen keeps the keyboard */
	s->exclusive_layer = l;
	if (l) {
		seat_focus(s, l->layer_surface->surface);
		return;
	}
	/* launcher closed: give the keyboard back to the top window */
	struct lumen_view *v;
	wl_list_for_each(v, &s->views, link) {
		if (v->mapped && !v->minimized && v->workspace == s->ws_current) {
			seat_focus(s, view_surface(v));
			return;
		}
	}
	wlr_seat_keyboard_notify_clear_focus(s->seat);
}

/* ---------------------------------------------------------------- keyboard */
/* open a shell panel instantly over IPC; only spawn a helper if no shell listens */
static void toggle_panel(struct lumen_server *s, const char *what) {
	if (!ipc_shell(s, what)) {
		char cmd[64];
		snprintf(cmd, sizeof(cmd), "lumen-shell --toggle %s", what);
		spawn(cmd);
	}
}
static bool super_alone;   /* a lone Super tap (no other key/click) opens Start */
static bool handle_bind(struct lumen_server *s, uint32_t mods, xkb_keysym_t sym) {
	struct lumen_view *v = focused_view(s);
	bool super = mods & WLR_MODIFIER_LOGO, shift = mods & WLR_MODIFIER_SHIFT,
		alt = mods & WLR_MODIFIER_ALT, ctrl = mods & WLR_MODIFIER_CTRL;

	if (ctrl && alt && sym >= XKB_KEY_XF86Switch_VT_1 && sym <= XKB_KEY_XF86Switch_VT_12) {
		if (s->session) wlr_session_change_vt(s->session, sym - XKB_KEY_XF86Switch_VT_1 + 1);
		return true;
	}
	if (alt && !super && (sym == XKB_KEY_Tab || sym == XKB_KEY_ISO_Left_Tab)) {
		switcher_step(s, shift || sym == XKB_KEY_ISO_Left_Tab ? -1 : 1);
		return true;
	}
	if (ctrl && alt && !super && sym == XKB_KEY_Delete) {   /* Ctrl+Alt+Del: log out / restart / shut down */
		ipc_shell(s, "logout");
		return true;
	}
	if (alt && !super && !ctrl && sym == XKB_KEY_F4) {   /* Alt+F4, as everywhere */
		view_close(v);
		return true;
	}
	if (!super) {
		/* media keys work without modifiers; the shell shows the new level (it
		 * reads it a moment later, once the command has run) */
		switch (sym) {
		case XKB_KEY_XF86AudioRaiseVolume: spawn("wpctl set-volume -l 1.0 @DEFAULT_AUDIO_SINK@ 5%+");
			ipc_shell(s, "osd-volume"); return true;
		case XKB_KEY_XF86AudioLowerVolume: spawn("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-");
			ipc_shell(s, "osd-volume"); return true;
		case XKB_KEY_XF86AudioMute: spawn("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle");
			ipc_shell(s, "osd-volume"); return true;
		case XKB_KEY_XF86AudioMicMute: spawn("wpctl set-mute @DEFAULT_AUDIO_SOURCE@ toggle");
			ipc_shell(s, "osd-mic"); return true;
		case XKB_KEY_XF86MonBrightnessUp: spawn("brightnessctl set 5%+");
			ipc_shell(s, "osd-brightness"); return true;
		case XKB_KEY_XF86MonBrightnessDown: spawn("brightnessctl set 5%-");
			ipc_shell(s, "osd-brightness"); return true;
		case XKB_KEY_XF86AudioStop: spawn("playerctl stop"); return true;
		case XKB_KEY_XF86AudioPlay: spawn("playerctl play-pause"); return true;
		case XKB_KEY_XF86AudioNext: spawn("playerctl next"); return true;
		case XKB_KEY_XF86AudioPrev: spawn("playerctl previous"); return true;
		case XKB_KEY_Print: spawn("lumen-screenshot region"); return true;
		default: return false;
		}
	}
	if (shift) {
		/* Super+Shift+1..0 (US layout keysyms for the shifted digits) */
		static const xkb_keysym_t map[] = { XKB_KEY_exclam, XKB_KEY_at, XKB_KEY_numbersign, XKB_KEY_dollar,
			XKB_KEY_percent, XKB_KEY_asciicircum, XKB_KEY_ampersand, XKB_KEY_asterisk, XKB_KEY_parenleft,
			XKB_KEY_parenright };
		for (int i = 0; i < 10; i++) if (sym == map[i]) { view_move_to_workspace(v, i); return true; }
		if (sym == XKB_KEY_S || sym == XKB_KEY_s) { spawn("lumen-screenshot region"); return true; }
		if (sym == XKB_KEY_V || sym == XKB_KEY_v) { view_toggle_floating(v); return true; }
	}
	switch (sym) {
	case XKB_KEY_Return: case XKB_KEY_q: spawn(s->cfg.terminal); return true;
	case XKB_KEY_b: {
		/* a running browser just opens another window */
		char cmd[320];
		const char *b = s->cfg.browser;
		bool known = strstr(b, "firefox") || strstr(b, "chrom") || strstr(b, "brave") ||
			strstr(b, "librewolf") || strstr(b, "zen") || strstr(b, "vivaldi") || strstr(b, "edge");
		snprintf(cmd, sizeof(cmd), "%s%s", b, known && !strstr(b, " --") ? " --new-window" : "");
		spawn(cmd);
		return true;
	}
	case XKB_KEY_v: toggle_panel(s, "clipboard"); return true;   /* clipboard history */
	case XKB_KEY_s: views_show_desktop(s, !views_desktop_shown()); return true;   /* show the desktop, and back */
	case XKB_KEY_t: view_toggle_on_top(v); return true;      /* keep this window above the others */
	case XKB_KEY_period: toggle_panel(s, "emoji"); return true;
	case XKB_KEY_i: spawn("lumen-settings"); return true;
	case XKB_KEY_space: case XKB_KEY_d:
		/* Spotlight is a panel of the shell (instant over IPC); another launcher
		 * chosen in lumen.conf is simply started */
		if (!strcmp(s->cfg.launcher, "lumen-launcher")) toggle_panel(s, "spotlight");
		else spawn(s->cfg.launcher);
		return true;
	case XKB_KEY_a: toggle_panel(s, "start"); return true;
	case XKB_KEY_n: toggle_panel(s, "notifications"); return true;
	case XKB_KEY_c: toggle_panel(s, "control"); return true;
	case XKB_KEY_w: view_close(v); return true;
	case XKB_KEY_f: view_toggle_maximize(v); return true;
	case XKB_KEY_F11: if (v) view_set_fullscreen(v, !v->fullscreen); return true;
	case XKB_KEY_m: case XKB_KEY_h: view_set_minimized(v, true); return true;
	case XKB_KEY_Tab: overview_toggle(); return true;
	case XKB_KEY_e: spawn(s->cfg.file_manager); return true;
	case XKB_KEY_l: spawn("lumen-lock"); return true;
	case XKB_KEY_Left: case XKB_KEY_Right: {
		int dir = sym == XKB_KEY_Left ? -1 : 1;
		if (ctrl) {                       /* Super+Ctrl+←/→: the window takes that half of the screen */
			snap_half(v, dir < 0);
		} else if (shift) {               /* Super+Shift+←/→: the window comes along to the next desktop */
			int to = s->ws_current + dir;
			if (v && to >= 0 && to < LUMEN_WORKSPACES) {
				view_move_to_workspace(v, to);
				workspace_switch(s, to);
				focus_view(v);
			}
		} else {
			workspace_switch(s, s->ws_current + dir);
		}
		return true;
	}
	case XKB_KEY_Up:                      /* Super+↑: maximise */
		if (v && !v->maximized) view_toggle_maximize(v);
		return true;
	case XKB_KEY_Down:                    /* Super+↓: back to its size; again: to the dock */
		if (v && v->maximized) view_toggle_maximize(v);
		else if (v) view_set_minimized(v, true);
		return true;
	case XKB_KEY_1: case XKB_KEY_2: case XKB_KEY_3: case XKB_KEY_4: case XKB_KEY_5:
	case XKB_KEY_6: case XKB_KEY_7: case XKB_KEY_8: case XKB_KEY_9: case XKB_KEY_0: {
		int ws = sym == XKB_KEY_0 ? 9 : (int)(sym - XKB_KEY_1);
		if (shift) view_move_to_workspace(v, ws);
		else workspace_switch(s, ws);
		return true;
	}
	case XKB_KEY_Escape:
		if (shift) { wl_display_terminate(s->display); return true; }
		if (overview_active()) { overview_close(NULL); return true; }
		view_close(v);
		return true;
	case XKB_KEY_E:
		if (shift) {
			/* log out: the shell plays the farewell and then asks us to quit. No
			 * shell listening, or the shortcut pressed again within a few seconds
			 * (the shell didn't manage): just go. Super+Shift+Esc always goes at once. */
			static struct timespec asked;
			struct timespec now;
			clock_gettime(CLOCK_MONOTONIC, &now);
			bool again = asked.tv_sec && now.tv_sec - asked.tv_sec < 5;
			asked = now;
			if (again || !ipc_shell(s, "logout")) wl_display_terminate(s->display);
			return true;
		}
		return false;
	case XKB_KEY_R:
		bool was_liquid = liquid_enabled(s);
		config_load(&s->cfg);
		apply_blur(s);
		views_refresh_style(s);
		input_reload(s);
		outputs_apply_config(s);
		tile_all(s);
		liquid_retry();
		/* the glass style changed: pour from one into the other */
		if (liquid_enabled(s) != was_liquid) liquid_pour_start(s, !was_liquid);
		return true;
	}
	return false;
}

static void kb_key(struct wl_listener *l, void *data) {
	struct lumen_keyboard *k = wl_container_of(l, k, key);
	struct lumen_server *s = k->server;
	struct wlr_keyboard_key_event *e = data;
	uint32_t keycode = e->keycode + 8;
	const xkb_keysym_t *syms;
	int n = xkb_state_key_get_syms(k->wlr_keyboard->xkb_state, keycode, &syms);
	uint32_t mods = wlr_keyboard_get_modifiers(k->wlr_keyboard);
	bool handled = false;
	bool pressed = e->state == WL_KEYBOARD_KEY_STATE_PRESSED;
	activity(s);

	if (session_locked()) {
		/* only VT switching; everything else goes to the lock screen */
		for (int i = 0; pressed && i < n; i++)
			if ((mods & WLR_MODIFIER_CTRL) && (mods & WLR_MODIFIER_ALT) &&
					syms[i] >= XKB_KEY_XF86Switch_VT_1 && syms[i] <= XKB_KEY_XF86Switch_VT_12) {
				if (s->session) wlr_session_change_vt(s->session, syms[i] - XKB_KEY_XF86Switch_VT_1 + 1);
				return;
			}
		wlr_seat_set_keyboard(s->seat, k->wlr_keyboard);
		wlr_seat_keyboard_notify_key(s->seat, e->time_msec, e->keycode, e->state);
		return;
	}

	if (switcher_active()) {
		/* Alt+Tab panel up: it owns the keys (Alt itself still reaches the app) */
		bool is_alt = false;
		for (int i = 0; i < n; i++)
			if (syms[i] == XKB_KEY_Alt_L || syms[i] == XKB_KEY_Alt_R || syms[i] == XKB_KEY_Meta_L) is_alt = true;
		if (!is_alt) {
			if (pressed)
				for (int i = 0; i < n; i++) switcher_key(syms[i], mods & WLR_MODIFIER_SHIFT);
			return;
		}
	}
	if (pressed) {
		for (int i = 0; i < n; i++) handled |= handle_bind(s, mods, syms[i]);
		if (!handled && overview_active())
			for (int i = 0; i < n; i++) handled |= overview_key(syms[i]);
	} else if (overview_active()) {
		handled = true;          /* nothing reaches windows while the overview is up */
	}
	/* a lone Super tap opens the Start menu, like Windows (or closes the overview) */
	for (int i = 0; i < n; i++) {
		if (syms[i] == XKB_KEY_Super_L || syms[i] == XKB_KEY_Super_R) {
			if (pressed) super_alone = true;
			else if (super_alone) {
				super_alone = false;
				if (overview_active()) overview_close(NULL);
				else toggle_panel(s, "start");
			}
		} else if (pressed) super_alone = false;
	}
	if (!handled) {
		wlr_seat_set_keyboard(s->seat, k->wlr_keyboard);
		wlr_seat_keyboard_notify_key(s->seat, e->time_msec, e->keycode, e->state);
	}
}

static void kb_modifiers(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_keyboard *k = wl_container_of(l, k, modifiers);
	wlr_seat_set_keyboard(k->server->seat, k->wlr_keyboard);
	wlr_seat_keyboard_notify_modifiers(k->server->seat, &k->wlr_keyboard->modifiers);
	switcher_modifiers(wlr_keyboard_get_modifiers(k->wlr_keyboard));   /* Alt let go → switch */
}

static void kb_destroy(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_keyboard *k = wl_container_of(l, k, destroy);
	wl_list_remove(&k->modifiers.link);
	wl_list_remove(&k->key.link);
	wl_list_remove(&k->destroy.link);
	wl_list_remove(&k->link);
	free(k);
}

static void apply_keymap(struct lumen_server *s, struct wlr_keyboard *wk) {
	struct xkb_context *ctx = xkb_context_new(XKB_CONTEXT_NO_FLAGS);
	struct xkb_rule_names names = { .layout = s->cfg.kb_layout,
		.options = s->cfg.kb_options[0] ? s->cfg.kb_options : NULL };
	struct xkb_keymap *km = xkb_keymap_new_from_names(ctx, &names, XKB_KEYMAP_COMPILE_NO_FLAGS);
	if (!km) km = xkb_keymap_new_from_names(ctx, NULL, XKB_KEYMAP_COMPILE_NO_FLAGS);
	wlr_keyboard_set_keymap(wk, km);
	xkb_keymap_unref(km);
	xkb_context_unref(ctx);
	wlr_keyboard_set_repeat_info(wk, s->cfg.repeat_rate, s->cfg.repeat_delay);
}

/* config reloaded: new layout / repeat rate apply to keyboards already plugged in */
/* "paste": press Ctrl+V (Ctrl+Shift+V in terminals) in the focused window, for
 * the clipboard history. The V key is looked up in the current layout. */
void input_paste(struct lumen_server *s) {
	struct wlr_keyboard *kb = wlr_seat_get_keyboard(s->seat);
	if (!kb || !kb->xkb_state || !s->seat->keyboard_state.focused_surface) return;
	struct xkb_keymap *km = xkb_state_get_keymap(kb->xkb_state);
	uint32_t vkey = 0, ctrl_key = 0, shift_key = 0;
	for (xkb_keycode_t kc = xkb_keymap_min_keycode(km); kc <= xkb_keymap_max_keycode(km); kc++) {
		const xkb_keysym_t *syms;
		int n = xkb_keymap_key_get_syms_by_level(km, kc, 0, 0, &syms);
		for (int i = 0; i < n; i++) {
			if (!vkey && (syms[i] == XKB_KEY_v)) vkey = kc - 8;
			if (!ctrl_key && syms[i] == XKB_KEY_Control_L) ctrl_key = kc - 8;
			if (!shift_key && syms[i] == XKB_KEY_Shift_L) shift_key = kc - 8;
		}
	}
	if (!vkey) return;
	struct lumen_view *v = focused_view(s);
	const char *id = v ? view_app_id(v) : NULL;
	bool term = id && (strstr(id, "kitty") || strstr(id, "foot") || strstr(id, "alacritty") ||
		strstr(id, "wezterm") || strstr(id, "konsole") || strstr(id, "terminal") || strstr(id, "Terminal"));
	struct wlr_keyboard_modifiers mods = kb->modifiers;
	xkb_mod_index_t ci = xkb_keymap_mod_get_index(km, XKB_MOD_NAME_CTRL);
	xkb_mod_index_t si = xkb_keymap_mod_get_index(km, XKB_MOD_NAME_SHIFT);
	struct wlr_keyboard_modifiers held = mods;
	held.depressed = (ci != XKB_MOD_INVALID ? 1u << ci : 0) | (term && si != XKB_MOD_INVALID ? 1u << si : 0);
	held.latched = 0;
	uint32_t t = (uint32_t)now_ms();
	wlr_seat_set_keyboard(s->seat, kb);
	if (ctrl_key) wlr_seat_keyboard_notify_key(s->seat, t, ctrl_key, WL_KEYBOARD_KEY_STATE_PRESSED);
	if (term && shift_key) wlr_seat_keyboard_notify_key(s->seat, t, shift_key, WL_KEYBOARD_KEY_STATE_PRESSED);
	wlr_seat_keyboard_notify_modifiers(s->seat, &held);
	wlr_seat_keyboard_notify_key(s->seat, t, vkey, WL_KEYBOARD_KEY_STATE_PRESSED);
	wlr_seat_keyboard_notify_key(s->seat, t + 1, vkey, WL_KEYBOARD_KEY_STATE_RELEASED);
	if (term && shift_key) wlr_seat_keyboard_notify_key(s->seat, t + 1, shift_key, WL_KEYBOARD_KEY_STATE_RELEASED);
	if (ctrl_key) wlr_seat_keyboard_notify_key(s->seat, t + 1, ctrl_key, WL_KEYBOARD_KEY_STATE_RELEASED);
	struct wlr_keyboard_modifiers none = mods;
	none.depressed = 0;
	none.latched = 0;
	wlr_seat_keyboard_notify_modifiers(s->seat, &none);
}

void input_reload(struct lumen_server *s) {
	struct lumen_keyboard *k;
	wl_list_for_each(k, &s->keyboards, link) apply_keymap(s, k->wlr_keyboard);
	input_apply_pointer_config(s);   /* scroll direction etc., live */
}

static void new_keyboard(struct lumen_server *s, struct wlr_input_device *dev) {
	struct wlr_keyboard *wk = wlr_keyboard_from_input_device(dev);
	struct lumen_keyboard *k = calloc(1, sizeof(*k));
	k->server = s;
	k->wlr_keyboard = wk;
	apply_keymap(s, wk);
	k->modifiers.notify = kb_modifiers;
	wl_signal_add(&wk->events.modifiers, &k->modifiers);
	k->key.notify = kb_key;
	wl_signal_add(&wk->events.key, &k->key);
	k->destroy.notify = kb_destroy;
	wl_signal_add(&dev->events.destroy, &k->destroy);
	wlr_seat_set_keyboard(s->seat, wk);
	wl_list_insert(&s->keyboards, &k->link);
}

/* every pointer, so settings changes apply to devices already plugged in */
struct lumen_pointer { struct wl_list link; struct wlr_input_device *dev; struct wl_listener destroy; };
static struct wl_list pointers;
static bool pointers_init;

static void configure_pointer(struct lumen_server *s, struct wlr_input_device *dev) {
	if (!wlr_input_device_is_libinput(dev)) return;
	struct libinput_device *li = wlr_libinput_get_device_handle(dev);
	bool touchpad = libinput_device_config_tap_get_finger_count(li) > 0;
	if (touchpad)
		libinput_device_config_tap_set_enabled(li, LIBINPUT_CONFIG_TAP_ENABLED);
	/* touchpads and mice have separate settings: "natural" feels right on one
	 * and inverted on the other */
	if (libinput_device_config_scroll_has_natural_scroll(li))
		libinput_device_config_scroll_set_natural_scroll_enabled(li,
			touchpad ? s->cfg.natural_scroll : s->cfg.mouse_natural_scroll);
}

static void pointer_destroy(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_pointer *p = wl_container_of(l, p, destroy);
	wl_list_remove(&p->destroy.link);
	wl_list_remove(&p->link);
	free(p);
}

void input_apply_pointer_config(struct lumen_server *s) {
	if (!pointers_init) return;
	struct lumen_pointer *p;
	wl_list_for_each(p, &pointers, link) configure_pointer(s, p->dev);
}

static void new_pointer(struct lumen_server *s, struct wlr_input_device *dev) {
	if (!pointers_init) { wl_list_init(&pointers); pointers_init = true; }
	struct lumen_pointer *p = calloc(1, sizeof(*p));
	if (p) {
		p->dev = dev;
		p->destroy.notify = pointer_destroy;
		wl_signal_add(&dev->events.destroy, &p->destroy);
		wl_list_insert(&pointers, &p->link);
	}
	configure_pointer(s, dev);
	wlr_cursor_attach_input_device(s->cursor, dev);
}

static void new_input(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, new_input);
	struct wlr_input_device *dev = data;
	if (dev->type == WLR_INPUT_DEVICE_KEYBOARD) new_keyboard(s, dev);
	else if (dev->type == WLR_INPUT_DEVICE_POINTER) new_pointer(s, dev);
	uint32_t caps = WL_SEAT_CAPABILITY_POINTER;
	if (!wl_list_empty(&s->keyboards)) caps |= WL_SEAT_CAPABILITY_KEYBOARD;
	wlr_seat_set_capabilities(s->seat, caps);
}

/* ------------------------------------------------------------------ pointer */
static struct wlr_surface *layer_surface_at(struct lumen_server *s, double lx, double ly,
		double *sx, double *sy, enum lumen_scene_layer from, enum lumen_scene_layer to) {
	for (int i = to; i >= (int)from; i--) {
		if (i == L_WS) continue;
		struct wlr_scene_node *n = wlr_scene_node_at(&s->layer[i]->node, lx, ly, sx, sy);
		if (n && n->type == WLR_SCENE_NODE_BUFFER) {
			struct wlr_scene_surface *ss =
				wlr_scene_surface_try_from_buffer(wlr_scene_buffer_from_node(n));
			if (ss) return ss->surface;
		}
	}
	return NULL;
}

static const char *edge_cursor(uint32_t e) {
	switch (e) {
	case WLR_EDGE_TOP: return "n-resize";
	case WLR_EDGE_BOTTOM: return "s-resize";
	case WLR_EDGE_LEFT: return "w-resize";
	case WLR_EDGE_RIGHT: return "e-resize";
	case WLR_EDGE_TOP | WLR_EDGE_LEFT: return "nw-resize";
	case WLR_EDGE_TOP | WLR_EDGE_RIGHT: return "ne-resize";
	case WLR_EDGE_BOTTOM | WLR_EDGE_LEFT: return "sw-resize";
	case WLR_EDGE_BOTTOM | WLR_EDGE_RIGHT: return "se-resize";
	}
	return "default";
}

static uint32_t edges_for(struct lumen_view *v, double x, double y) {
	uint32_t e = 0;
	const int corner = 18;
	if (y < v->geom.y + corner * (x < v->geom.x || x > v->geom.x + v->geom.width ? 1 : 0)
			|| y < v->geom.y) e |= WLR_EDGE_TOP;
	if (y > v->geom.y + v->geom.height) e |= WLR_EDGE_BOTTOM;
	if (x < v->geom.x) e |= WLR_EDGE_LEFT;
	if (x > v->geom.x + v->geom.width) e |= WLR_EDGE_RIGHT;
	/* generous corners */
	if ((e & (WLR_EDGE_LEFT | WLR_EDGE_RIGHT)) && y > v->geom.y + v->geom.height - corner) e |= WLR_EDGE_BOTTOM;
	if ((e & (WLR_EDGE_TOP | WLR_EDGE_BOTTOM)) && x < v->geom.x + corner) e |= WLR_EDGE_LEFT;
	if ((e & (WLR_EDGE_TOP | WLR_EDGE_BOTTOM)) && x > v->geom.x + v->geom.width - corner) e |= WLR_EDGE_RIGHT;
	return e;
}

static struct lumen_view *hover_view;

/* A button held on an app's surface keeps the pointer there until it's let go
 * (an "implicit grab"): dragging a scrollbar or a selection past the window's
 * edge keeps working, and focus-follows-mouse doesn't jump to whatever the
 * cursor crosses on the way. */
static struct { struct wlr_surface *surface; double ox, oy; int buttons; } down;

/* drag and drop between (and inside) apps */
static struct wlr_scene_tree *drag_icon;
static bool dragging;
static struct wl_listener request_start_drag_l, start_drag_l, drag_destroy_l;

static void forward_button(struct lumen_server *s, struct wlr_pointer_button_event *e) {
	wlr_seat_pointer_notify_button(s->seat, e->time_msec, e->button, e->state);
	if (e->state == WL_POINTER_BUTTON_STATE_PRESSED) {
		if (down.buttons++ == 0) {
			down.surface = s->seat->pointer_state.focused_surface;
			down.ox = s->cursor->x - s->seat->pointer_state.sx;
			down.oy = s->cursor->y - s->seat->pointer_state.sy;
		}
	} else if (down.buttons > 0 && --down.buttons == 0) {
		down.surface = NULL;
		pointer_refocus(s);     /* whatever is under the cursor now gets the pointer */
	}
}

/* a view is going away: drop any pointer-side references to it */
void pointer_forget_view(struct lumen_view *v) {
	if (hover_view == v) hover_view = NULL;
}

static void process_motion(struct lumen_server *s, uint32_t time) {
	if (drag_icon) wlr_scene_node_set_position(&drag_icon->node, (int)s->cursor->x, (int)s->cursor->y);
	/* the monitor under the pointer is the focused one */
	struct lumen_output *po = output_at(s, s->cursor->x, s->cursor->y);
	if (po && po->ws != s->ws_current && !overview_active()) {
		s->ws_current = po->ws;
		ipc_state_changed(s);
	}
	if (s->cursor_mode == CURSOR_MOVE && s->grabbed) {
		view_move_to(s->grabbed, (int)(s->cursor->x - s->grab_x), (int)(s->cursor->y - s->grab_y));
		if (view_drag_motion(s->grabbed)) snap_motion(s, s->grabbed, s->cursor->x, s->cursor->y);
		else snap_cancel(s);
		return;
	}
	if (s->cursor_mode == CURSOR_RESIZE && s->grabbed) {
		struct wlr_box b = s->grab_box;
		double dx = s->cursor->x - s->grab_x, dy = s->cursor->y - s->grab_y;
		int minw = 220, minh = 120;
		if (s->resize_edges & WLR_EDGE_LEFT) { b.x += dx; b.width -= dx; }
		if (s->resize_edges & WLR_EDGE_RIGHT) b.width += dx;
		if (s->resize_edges & WLR_EDGE_TOP) { b.y += dy; b.height -= dy; }
		if (s->resize_edges & WLR_EDGE_BOTTOM) b.height += dy;
		if (b.width < minw) { if (s->resize_edges & WLR_EDGE_LEFT) b.x -= minw - b.width; b.width = minw; }
		if (b.height < minh) { if (s->resize_edges & WLR_EDGE_TOP) b.y -= minh - b.height; b.height = minh; }
		view_resize_to(s->grabbed, b);
		return;
	}

	double sx, sy;
	struct wlr_surface *surface = NULL;
	if (session_locked()) {
		surface = lock_surface_at(s->cursor->x, s->cursor->y, &sx, &sy);
		if (surface) {
			wlr_seat_pointer_notify_enter(s->seat, surface, sx, sy);
			wlr_seat_pointer_notify_motion(s->seat, time, sx, sy);
		} else {
			wlr_cursor_set_xcursor(s->cursor, s->cursor_mgr, "default");
			wlr_seat_pointer_clear_focus(s->seat);
		}
		return;
	}
	/* a held button keeps the pointer on the surface it was pressed on */
	if (down.buttons > 0 && down.surface && !dragging && !wlr_seat_pointer_has_grab(s->seat) &&
			s->seat->pointer_state.focused_surface == down.surface) {
		wlr_seat_pointer_notify_motion(s->seat, time, s->cursor->x - down.ox, s->cursor->y - down.oy);
		return;
	}
	/* overlay/top layers (bars, launcher) sit above windows (the drag icon in
	 * L_DRAG is only a picture: it never takes the pointer) */
	surface = layer_surface_at(s, s->cursor->x, s->cursor->y, &sx, &sy, L_TOP, L_OVERLAY);
	if (switcher_active() && switcher_motion(s->cursor->x, s->cursor->y)) {
		wlr_cursor_set_xcursor(s->cursor, s->cursor_mgr, "default");
		wlr_seat_pointer_clear_focus(s->seat);
		return;
	}
	if (!surface && overview_active()) {
		overview_motion(s->cursor->x, s->cursor->y);
		wlr_cursor_set_xcursor(s->cursor, s->cursor_mgr, "default");
		wlr_seat_pointer_clear_focus(s->seat);
		return;
	}
	if (!surface && snap_flyout_motion(s->cursor->x, s->cursor->y)) {
		wlr_cursor_set_xcursor(s->cursor, s->cursor_mgr, "pointer");
		wlr_seat_pointer_clear_focus(s->seat);
		return;
	}
	struct lumen_view *v = NULL;
	int part = PART_NONE;
	if (!surface) {
		v = view_at(s, s->cursor->x, s->cursor->y, &surface, &sx, &sy, &part);
		if (!v) surface = layer_surface_at(s, s->cursor->x, s->cursor->y, &sx, &sy, L_BG, L_BOTTOM);
	}

	bool on_lights = v && (part == PART_CLOSE || part == PART_MIN || part == PART_ZOOM);
	/* focus follows the mouse (not while a menu/popup holds the pointer or keys,
	 * or a panel like the launcher has the keyboard) */
	if (v && s->cfg.focus_follows_mouse && s->cursor_mode == CURSOR_PASSTHROUGH &&
			!wlr_seat_pointer_has_grab(s->seat) && !wlr_seat_keyboard_has_grab(s->seat) &&
			focused_view(s) != v && !view_peeking(v))   /* next door's window: a click takes it, not a hover */
		focus_view_noraise(v);
	if (hover_view && hover_view != v) view_hover_lights(hover_view, false);
	if (v) view_hover_part(v, on_lights ? part : PART_NONE);
	hover_view = v;

	if (!surface) {
		const char *name = "default";
		if (v && part == PART_EDGE) name = edge_cursor(edges_for(v, s->cursor->x, s->cursor->y));
		else if (on_lights) name = "pointer";
		wlr_cursor_set_xcursor(s->cursor, s->cursor_mgr, name);
		wlr_seat_pointer_clear_focus(s->seat);
		return;
	}
	wlr_seat_pointer_notify_enter(s->seat, surface, sx, sy);
	wlr_seat_pointer_notify_motion(s->seat, time, sx, sy);
}

void pointer_refocus(struct lumen_server *s) {
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	process_motion(s, ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
}

/* ------------------------------------------- games: mouse lock + raw motion
 * pointer-constraints lets a game lock the pointer (mouse-look) or keep it
 * inside its window; relative-pointer sends raw movement even while locked.
 * XWayland games (Minecraft, Steam/Proton) use these too. */
static struct wlr_pointer_constraints_v1 *constraints;
static struct wlr_relative_pointer_manager_v1 *relative_mgr;
static struct wlr_pointer_constraint_v1 *active;
static struct wl_listener new_constraint_l, active_destroy_l, focus_change_l;
static bool active_destroy_hooked;

/* the lock ends: put the cursor where the app asked (a game opening its
 * inventory wants it in the middle; Xwayland's XWarpPointer arrives this way)
 * and show it again */
static void lock_released(struct lumen_server *s, struct wlr_pointer_constraint_v1 *c) {
	if (c->type != WLR_POINTER_CONSTRAINT_V1_LOCKED) return;
	if (c->current.committed & WLR_POINTER_CONSTRAINT_V1_STATE_CURSOR_HINT) {
		double sx = c->current.cursor_hint.x, sy = c->current.cursor_hint.y;
		double ox = s->cursor->x - s->seat->pointer_state.sx, oy = s->cursor->y - s->seat->pointer_state.sy;
		wlr_cursor_warp(s->cursor, NULL, ox + sx, oy + sy);
		wlr_seat_pointer_warp(s->seat, sx, sy);
	}
	wlr_cursor_set_xcursor(s->cursor, s->cursor_mgr, "default");
}

static void constraint_deactivate(struct lumen_server *s) {
	if (!active) return;
	struct wlr_pointer_constraint_v1 *c = active;
	active = NULL;
	if (active_destroy_hooked) { wl_list_remove(&active_destroy_l.link); active_destroy_hooked = false; }
	lock_released(s, c);
	wlr_pointer_constraint_v1_send_deactivated(c);
}

static void active_destroyed(struct wl_listener *l, void *data) {
	(void)l;
	struct wlr_pointer_constraint_v1 *c = data;
	if (active_destroy_hooked) { wl_list_remove(&active_destroy_l.link); active_destroy_hooked = false; }
	if (active == c) lock_released(g_server, c);
	active = NULL;
}

bool pointer_locked(void) {
	return active && active->type == WLR_POINTER_CONSTRAINT_V1_LOCKED;
}

static void constraint_activate(struct lumen_server *s, struct wlr_pointer_constraint_v1 *c) {
	if (active == c) return;
	constraint_deactivate(s);
	if (!c) return;
	active = c;
	active_destroy_l.notify = active_destroyed;
	wl_signal_add(&c->events.destroy, &active_destroy_l);
	active_destroy_hooked = true;
	/* mouse-look: no cursor on screen while the game has the pointer */
	if (c->type == WLR_POINTER_CONSTRAINT_V1_LOCKED) wlr_cursor_unset_image(s->cursor);
	wlr_pointer_constraint_v1_send_activated(c);
}

/* the pointer moved onto another surface: its constraint (if any) takes over */
static void focus_changed(struct wl_listener *l, void *data) {
	(void)l;
	struct wlr_seat_pointer_focus_change_event *e = data;
	struct lumen_server *s = g_server;
	struct wlr_pointer_constraint_v1 *c = e->new_surface && constraints
		? wlr_pointer_constraints_v1_constraint_for_surface(constraints, e->new_surface, s->seat) : NULL;
	constraint_activate(s, c);
}

static void new_constraint(struct wl_listener *l, void *data) {
	(void)l;
	struct wlr_pointer_constraint_v1 *c = data;
	struct lumen_server *s = g_server;
	if (s->seat->pointer_state.focused_surface == c->surface)
		constraint_activate(s, c);
}

void input_init_constraints(struct lumen_server *s) {
	constraints = wlr_pointer_constraints_v1_create(s->display);
	relative_mgr = wlr_relative_pointer_manager_v1_create(s->display);
	new_constraint_l.notify = new_constraint;
	wl_signal_add(&constraints->events.new_constraint, &new_constraint_l);
	focus_change_l.notify = focus_changed;
	wl_signal_add(&s->seat->pointer_state.events.focus_change, &focus_change_l);
}

static void cursor_motion(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, cursor_motion);
	struct wlr_pointer_motion_event *e = data;
	activity(s);
	double dx = e->delta_x, dy = e->delta_y;
	/* raw movement for games, locked or not */
	if (relative_mgr)
		wlr_relative_pointer_manager_v1_send_relative_motion(relative_mgr, s->seat,
			(uint64_t)e->time_msec * 1000, dx, dy, e->unaccel_dx, e->unaccel_dy);
	if (active && s->seat->pointer_state.focused_surface == active->surface &&
			s->cursor_mode == CURSOR_PASSTHROUGH && !overview_active() && !switcher_active()) {
		if (active->type == WLR_POINTER_CONSTRAINT_V1_LOCKED) {
			wlr_seat_pointer_notify_frame(s->seat);   /* the cursor stays put */
			return;
		}
		/* confined: keep the cursor inside the game's region */
		double sx = s->seat->pointer_state.sx, sy = s->seat->pointer_state.sy, nx, ny;
		if (wlr_region_confine(&active->region, sx, sy, sx + dx, sy + dy, &nx, &ny)) {
			dx = nx - sx;
			dy = ny - sy;
		}
	}
	wlr_cursor_move(s->cursor, &e->pointer->base, dx, dy);
	process_motion(s, e->time_msec);
}

static void cursor_motion_abs(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, cursor_motion_abs);
	struct wlr_pointer_motion_absolute_event *e = data;
	activity(s);
	wlr_cursor_warp_absolute(s->cursor, &e->pointer->base, e->x, e->y);
	process_motion(s, e->time_msec);
}

static void cursor_button(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, cursor_button);
	struct wlr_pointer_button_event *e = data;
	activity(s);

	if (session_locked()) {
		double lsx, lsy;
		struct wlr_surface *ls = lock_surface_at(s->cursor->x, s->cursor->y, &lsx, &lsy);
		if (ls && e->state == WL_POINTER_BUTTON_STATE_PRESSED) lock_focus_surface(ls);
		wlr_seat_pointer_notify_button(s->seat, e->time_msec, e->button, e->state);
		down.buttons = 0; down.surface = NULL;
		return;
	}

	if (e->state == WL_POINTER_BUTTON_STATE_RELEASED) {
		if (s->cursor_mode != CURSOR_PASSTHROUGH) {
			struct lumen_view *g = s->grabbed;
			bool moving = s->cursor_mode == CURSOR_MOVE;
			s->cursor_mode = CURSOR_PASSTHROUGH;
			s->grabbed = NULL;
			/* the app that started this move/resize saw the press: it gets the
			 * release too, or the seat would think the button is still down */
			if (s->seat->pointer_state.button_count > 0)
				wlr_seat_pointer_notify_button(s->seat, e->time_msec, e->button, e->state);
			down.buttons = 0; down.surface = NULL;
			if (moving && g) {
				view_drag_end(g);   /* lands on the desktop under the pointer */
				/* dropped: Windows 11 snap, or swap places in the tiling */
				if (!snap_release(s, g)) tiling_drop(g, s->cursor->x, s->cursor->y);
			} else if (g) {
				tile_workspace(s, g->workspace);
			}
			ipc_state_changed(s);
			pointer_refocus(s);
			return;
		}
		forward_button(s, e);
		return;
	}

	super_alone = false;
	double sx, sy;
	if (snap_flyout_open() && snap_flyout_click(s->cursor->x, s->cursor->y)) return;
	struct wlr_surface *surface = layer_surface_at(s, s->cursor->x, s->cursor->y, &sx, &sy, L_TOP, L_OVERLAY);
	if (surface) {
		struct wlr_layer_surface_v1 *ls = wlr_layer_surface_v1_try_from_wlr_surface(surface);
		if (ls && ls->current.keyboard_interactive) {
			seat_focus(s, surface);
		}
		forward_button(s, e);
		return;
	}

	if (switcher_active()) {   /* Alt+Tab panel: click a preview to switch */
		if (e->state == WL_POINTER_BUTTON_STATE_PRESSED) switcher_click(s->cursor->x, s->cursor->y);
		return;
	}
	if (overview_active()) {   /* click a thumbnail to pick it, anywhere else to leave */
		overview_click(s->cursor->x, s->cursor->y);
		return;
	}

	int part;
	struct lumen_view *v = view_at(s, s->cursor->x, s->cursor->y, &surface, &sx, &sy, &part);
	if (!v) {
		forward_button(s, e);
		return;
	}
	/* the part of a window hanging over from the desktop next door: touching it
	 * makes it this desktop's window (it stays exactly where it is) */
	if (view_peeking(v) && !view_adopt_peek(v)) {
		forward_button(s, e);   /* mid-slide or mid-animation: just a click */
		return;
	}
	focus_view(v);

	struct wlr_keyboard *kb = wlr_seat_get_keyboard(s->seat);
	bool super = kb && (wlr_keyboard_get_modifiers(kb) & WLR_MODIFIER_LOGO);
	if (super && e->button == BTN_LEFT) { view_begin_grab(v, CURSOR_MOVE, 0); return; }
	if (super && e->button == BTN_RIGHT) {
		uint32_t edges = (s->cursor->x > v->geom.x + v->geom.width / 2 ? WLR_EDGE_RIGHT : WLR_EDGE_LEFT) |
			(s->cursor->y > v->geom.y + v->geom.height / 2 ? WLR_EDGE_BOTTOM : WLR_EDGE_TOP);
		view_begin_grab(v, CURSOR_RESIZE, edges);
		return;
	}

	switch (part) {
	case PART_CLOSE: view_close(v); return;
	case PART_MIN: view_set_minimized(v, true); return;
	case PART_ZOOM: view_toggle_maximize(v); return;
	case PART_EDGE:
		view_begin_grab(v, CURSOR_RESIZE, edges_for(v, s->cursor->x, s->cursor->y));
		return;
	case PART_TITLE:
		if (e->button == BTN_LEFT) {
			if (s->last_click_view == v && e->time_msec - s->last_click_ms < 400) {
				view_toggle_maximize(v);   /* double-click titlebar = zoom */
				s->last_click_view = NULL;
				return;
			}
			s->last_click_view = v;
			s->last_click_ms = e->time_msec;
			view_begin_grab(v, CURSOR_MOVE, 0);
		}
		return;
	default:
		forward_button(s, e);
	}
}

static void cursor_axis(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, cursor_axis);
	struct wlr_pointer_axis_event *e = data;
	activity(s);
	wlr_seat_pointer_notify_axis(s->seat, e->time_msec, e->orientation, e->delta,
		e->delta_discrete, e->source, e->relative_direction);
}

static void cursor_frame(struct wl_listener *l, void *data) {
	(void)data;
	struct lumen_server *s = wl_container_of(l, s, cursor_frame);
	wlr_seat_pointer_notify_frame(s->seat);
}

/* ---------------------------------------------------------------- gestures
 * 3+ finger swipe (GNOME-style): up/down drives the overview 1:1, left/right
 * drags between desktops. Everything else is forwarded to the focused app
 * (pinch-zoom in browsers, etc.). */
#define OVERVIEW_TRAVEL 300.0   /* px of finger travel for a full open */
static struct {
	bool ours;
	bool four;                   /* one finger more than the overview gesture */
	int axis;                    /* 0 undecided, 1 horizontal, 2 vertical */
	double dx, dy, t0, vx, vy;
	uint32_t last_ms;
} sw;

/* pinches with 3+ fingers are ours: in = overview, out = show the desktop */
static struct { bool ours; double scale; } pn;

static void swipe_begin(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, swipe_begin);
	struct wlr_pointer_swipe_begin_event *e = data;
	activity(s);
	sw.ours = !session_locked() && s->cfg.gestures && e->fingers >= (uint32_t)s->cfg.gesture_fingers;
	if (!sw.ours) {
		wlr_pointer_gestures_v1_send_swipe_begin(s->pointer_gestures, s->seat, e->time_msec, e->fingers);
		return;
	}
	sw.four = e->fingers >= (uint32_t)s->cfg.gesture_fingers + 1;
	sw.axis = 0;
	sw.dx = sw.dy = sw.vx = sw.vy = 0;
	sw.t0 = overview_t();
	sw.last_ms = e->time_msec;
}

static void swipe_update(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, swipe_update);
	struct wlr_pointer_swipe_update_event *e = data;
	activity(s);
	if (!sw.ours) {
		wlr_pointer_gestures_v1_send_swipe_update(s->pointer_gestures, s->seat, e->time_msec, e->dx, e->dy);
		return;
	}
	sw.dx += e->dx;
	sw.dy += e->dy;
	double dt = e->time_msec > sw.last_ms ? (double)(e->time_msec - sw.last_ms) : 1.0;
	sw.vx = 0.6 * sw.vx + 0.4 * (e->dx / dt);   /* smoothed px/ms */
	sw.vy = 0.6 * sw.vy + 0.4 * (e->dy / dt);
	sw.last_ms = e->time_msec;
	if (sw.axis == 0) {
		if (fabs(sw.dx) < 12 && fabs(sw.dy) < 12) return;
		sw.axis = fabs(sw.dy) > fabs(sw.dx) ? 2 : 1;
	}
	if (sw.four) return;          /* four fingers: decided when they lift */
	if (sw.axis == 2) {
		double t = sw.t0 + (-sw.dy) / OVERVIEW_TRAVEL;   /* fingers up = open */
		if (!overview_active() && t <= 0) return;
		overview_set_t(t);
	} else if (overview_active()) {
		overview_drag(sw.dx);
	} else {
		workspace_drag_update(s, sw.dx);
	}
}

static void swipe_end(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, swipe_end);
	struct wlr_pointer_swipe_end_event *e = data;
	if (!sw.ours) {
		wlr_pointer_gestures_v1_send_swipe_end(s->pointer_gestures, s->seat, e->time_msec, e->cancelled);
		return;
	}
	sw.ours = false;
	if (sw.four) {
		/* four fingers: ↓ show the desktop, ↑ bring the windows back,
		 * ← → jump to the previous / next window */
		if (e->cancelled) return;
		bool far_x = fabs(sw.dx) > 70 || fabs(sw.vx) > 0.5, far_y = fabs(sw.dy) > 70 || fabs(sw.vy) > 0.5;
		if (sw.axis == 2 && far_y) views_show_desktop(s, sw.dy > 0);
		else if (sw.axis == 1 && far_x) {
			switcher_step(s, sw.dx < 0 ? 1 : -1);
			switcher_commit();
		}
		return;
	}
	if (sw.axis == 2) {
		if (e->cancelled) overview_set_t(sw.t0);
		overview_release(e->cancelled ? 0 : sw.vy);
	} else if (sw.axis == 1) {
		if (overview_active()) {
			overview_drag_end(sw.vx, e->cancelled);
		} else {
			workspace_drag_end(s, sw.vx, e->cancelled);
		}
	}
}

static void pinch_begin(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, pinch_begin);
	struct wlr_pointer_pinch_begin_event *e = data;
	activity(s);
	/* two-finger pinches stay with the app (zooming a page or photo) */
	pn.ours = !session_locked() && s->cfg.gestures && e->fingers >= 3;
	pn.scale = 1;
	if (!pn.ours)
		wlr_pointer_gestures_v1_send_pinch_begin(s->pointer_gestures, s->seat, e->time_msec, e->fingers);
}
static void pinch_update(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, pinch_update);
	struct wlr_pointer_pinch_update_event *e = data;
	if (pn.ours) { pn.scale = e->scale; return; }
	wlr_pointer_gestures_v1_send_pinch_update(s->pointer_gestures, s->seat, e->time_msec,
		e->dx, e->dy, e->scale, e->rotation);
}
static void pinch_end(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, pinch_end);
	struct wlr_pointer_pinch_end_event *e = data;
	if (!pn.ours) {
		wlr_pointer_gestures_v1_send_pinch_end(s->pointer_gestures, s->seat, e->time_msec, e->cancelled);
		return;
	}
	pn.ours = false;
	if (e->cancelled) return;
	if (pn.scale < 0.78) {                  /* fingers together: everything at a glance */
		if (!overview_active()) overview_open();
	} else if (pn.scale > 1.3) {            /* fingers apart: out of the way / back again */
		if (overview_active()) overview_close(NULL);
		else views_show_desktop(s, true);
	}
}
static void hold_begin(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, hold_begin);
	struct wlr_pointer_hold_begin_event *e = data;
	wlr_pointer_gestures_v1_send_hold_begin(s->pointer_gestures, s->seat, e->time_msec, e->fingers);
}
static void hold_end(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, hold_end);
	struct wlr_pointer_hold_end_event *e = data;
	wlr_pointer_gestures_v1_send_hold_end(s->pointer_gestures, s->seat, e->time_msec, e->cancelled);
}

static void request_cursor(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, request_cursor);
	struct wlr_seat_pointer_request_set_cursor_event *e = data;
	if (pointer_locked()) return;   /* hidden while a game has the pointer */
	if (s->seat->pointer_state.focused_client == e->seat_client)
		wlr_cursor_set_surface(s->cursor, e->surface, e->hotspot_x, e->hotspot_y);
}

static void request_cursor_shape(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, request_cursor_shape);
	struct wlr_cursor_shape_manager_v1_request_set_shape_event *e = data;
	if (pointer_locked()) return;
	if (s->seat->pointer_state.focused_client == e->seat_client)
		wlr_cursor_set_xcursor(s->cursor, s->cursor_mgr, wlr_cursor_shape_v1_name(e->shape));
}

/* ------------------------------------------------------------ drag and drop
 * An app asks to start a drag (a file out of Files, a tab, selected text…):
 * if it really holds the button, the seat runs the drag — the picture being
 * dragged follows the cursor, and whatever it is dropped on receives it. */
static void drag_destroyed(struct wl_listener *l, void *data) {
	(void)l; (void)data;
	wl_list_remove(&drag_destroy_l.link);
	dragging = false;
	drag_icon = NULL;            /* the scene removes the icon's tree with the icon */
	down.buttons = 0; down.surface = NULL;
	pointer_refocus(g_server);
}

static void on_start_drag(struct wl_listener *l, void *data) {
	(void)l;
	struct wlr_drag *drag = data;
	struct lumen_server *s = g_server;
	if (dragging) wl_list_remove(&drag_destroy_l.link);
	dragging = true;
	drag_icon = drag->icon ? wlr_scene_drag_icon_create(s->layer[L_DRAG], drag->icon) : NULL;
	if (drag_icon) wlr_scene_node_set_position(&drag_icon->node, (int)s->cursor->x, (int)s->cursor->y);
	drag_destroy_l.notify = drag_destroyed;
	wl_signal_add(&drag->events.destroy, &drag_destroy_l);
}

static void on_request_start_drag(struct wl_listener *l, void *data) {
	(void)l;
	struct wlr_seat_request_start_drag_event *e = data;
	struct lumen_server *s = g_server;
	if (wlr_seat_validate_pointer_grab_serial(s->seat, e->origin, e->serial))
		wlr_seat_start_pointer_drag(s->seat, e->drag, e->serial);
	else
		wlr_data_source_destroy(e->drag->source);
}

static void request_set_selection(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, request_set_selection);
	struct wlr_seat_request_set_selection_event *e = data;
	wlr_seat_set_selection(s->seat, e->source, e->serial);
}

static void request_set_primary(struct wl_listener *l, void *data) {
	struct lumen_server *s = wl_container_of(l, s, request_set_primary_selection);
	struct wlr_seat_request_set_primary_selection_event *e = data;
	wlr_seat_set_primary_selection(s->seat, e->source, e->serial);
}

void input_init(struct lumen_server *s) {
	s->cursor = wlr_cursor_create();
	wlr_cursor_attach_output_layout(s->cursor, s->output_layout);
	const char *theme = getenv("XCURSOR_THEME");
	const char *size = getenv("XCURSOR_SIZE");
	s->cursor_mgr = wlr_xcursor_manager_create(theme, size ? atoi(size) : 24);
	s->cursor_mode = CURSOR_PASSTHROUGH;

	s->cursor_motion.notify = cursor_motion;
	wl_signal_add(&s->cursor->events.motion, &s->cursor_motion);
	s->cursor_motion_abs.notify = cursor_motion_abs;
	wl_signal_add(&s->cursor->events.motion_absolute, &s->cursor_motion_abs);
	s->cursor_button.notify = cursor_button;
	wl_signal_add(&s->cursor->events.button, &s->cursor_button);
	s->cursor_axis.notify = cursor_axis;
	wl_signal_add(&s->cursor->events.axis, &s->cursor_axis);
	s->cursor_frame.notify = cursor_frame;
	wl_signal_add(&s->cursor->events.frame, &s->cursor_frame);
#define G(name) do { s->name.notify = name; wl_signal_add(&s->cursor->events.name, &s->name); } while (0)
	G(swipe_begin); G(swipe_update); G(swipe_end);
	G(pinch_begin); G(pinch_update); G(pinch_end);
	G(hold_begin); G(hold_end);
#undef G

	wl_list_init(&s->keyboards);
	s->new_input.notify = new_input;
	wl_signal_add(&s->backend->events.new_input, &s->new_input);
	s->seat = wlr_seat_create(s->display, "seat0");
	s->request_cursor.notify = request_cursor;
	wl_signal_add(&s->seat->events.request_set_cursor, &s->request_cursor);
	s->request_set_selection.notify = request_set_selection;
	wl_signal_add(&s->seat->events.request_set_selection, &s->request_set_selection);
	s->request_set_primary_selection.notify = request_set_primary;
	wl_signal_add(&s->seat->events.request_set_primary_selection,
		&s->request_set_primary_selection);
	request_start_drag_l.notify = on_request_start_drag;
	wl_signal_add(&s->seat->events.request_start_drag, &request_start_drag_l);
	start_drag_l.notify = on_start_drag;
	wl_signal_add(&s->seat->events.start_drag, &start_drag_l);

	input_init_constraints(s);   /* games: pointer lock + raw mouse motion */
	pointer_warp_init(s);        /* games: re-centre the cursor */
	s->cursor_shape_mgr = wlr_cursor_shape_manager_v1_create(s->display, 1);
	s->request_cursor_shape.notify = request_cursor_shape;
	wl_signal_add(&s->cursor_shape_mgr->events.request_set_shape, &s->request_cursor_shape);
}
