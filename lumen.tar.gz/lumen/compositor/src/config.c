/* ~/.config/lumen/lumen.conf — simple "key = value" file. */
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "lumen.h"

static char *trim(char *s) {
	while (isspace((unsigned char)*s)) s++;
	char *e = s + strlen(s);
	while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
	return s;
}

/* "#RRGGBBAA" or "#RRGGBB" → premultiplied float rgba */
static void parse_color(const char *v, float out[4]) {
	if (*v == '#') v++;
	unsigned long c = strtoul(v, NULL, 16);
	float r, g, b, a = 1;
	if (strlen(v) >= 8) {
		r = ((c >> 24) & 0xff) / 255.f; g = ((c >> 16) & 0xff) / 255.f;
		b = ((c >> 8) & 0xff) / 255.f;  a = (c & 0xff) / 255.f;
	} else {
		r = ((c >> 16) & 0xff) / 255.f; g = ((c >> 8) & 0xff) / 255.f;
		b = (c & 0xff) / 255.f;
	}
	out[0] = r * a; out[1] = g * a; out[2] = b * a; out[3] = a;
}

static bool parse_bool(const char *v) {
	return !strcmp(v, "true") || !strcmp(v, "yes") || !strcmp(v, "1") || !strcmp(v, "on");
}

static void defaults(struct lumen_config *c) {
	memset(c, 0, sizeof(*c));
	snprintf(c->terminal, sizeof(c->terminal), "kitty");
	snprintf(c->launcher, sizeof(c->launcher),
		"lumen-launcher");
	snprintf(c->kb_layout, sizeof(c->kb_layout), "us");
	snprintf(c->browser, sizeof(c->browser), "firefox");
	snprintf(c->file_manager, sizeof(c->file_manager), "lumen-files");
	c->gestures = true;
	c->gesture_fingers = 3;
	c->corner_radius = 14;
	c->blur_passes = 3;
	c->blur_radius = 6;
	c->blur_brightness = 1.0f;
	c->blur_saturation = 1.35f;
	c->blur_noise = 0.025f;
	snprintf(c->glass_style, sizeof(c->glass_style), "frosted");
	c->liquid = false;
	c->liquid_rim = 28;
	c->liquid_refraction = 1.0f;
	c->liquid_highlight = 0.9f;
	c->liquid_frost = 10;
	c->shadow_sigma = 14;
	c->natural_scroll = true;
	c->blur_full_redraw = true;
	c->focus_follows_mouse = true;
	c->preload_apps = true;          /* touchpads */
	c->mouse_natural_scroll = false;   /* mouse wheels: classic direction */
	parse_color("#00000055", c->shadow_color);
	parse_color("#1c1f2a8c", c->glass_tint);
	parse_color("#ffffffe6", c->title_color);
	c->gaps = 10;
	c->anim_ms = 380;
	c->animations = true;
	c->xwayland = true;
	c->repeat_rate = 30;
	c->tiling = false;
	c->snapping = true;
	snprintf(c->controls_side, sizeof(c->controls_side), "left");
	parse_color("#8aa4ff", c->accent);
	c->output_count = 0;
	c->repeat_delay = 300;
}

void config_load(struct lumen_config *c) {
	defaults(c);
	char path[512];
	const char *xdg = getenv("XDG_CONFIG_HOME");
	if (xdg && *xdg) snprintf(path, sizeof(path), "%s/lumen/lumen.conf", xdg);
	else snprintf(path, sizeof(path), "%s/.config/lumen/lumen.conf", getenv("HOME"));

	FILE *f = fopen(path, "r");
	if (!f) f = fopen("/etc/lumen/lumen.conf", "r");
	if (!f) return;
	char line[1024];
	while (fgets(line, sizeof(line), f)) {
		char *l = trim(line);
		if (!*l || *l == '#') continue;
		char *eq = strchr(l, '=');
		if (!eq) continue;
		*eq = 0;
		char *val = trim(eq + 1);
		/* strip a trailing "  # comment"; a leading '#' is a colour, not a comment */
		for (char *p = val + 1; *p; p++)
			if (*p == '#' && isspace((unsigned char)p[-1])) { *p = 0; break; }
		char *k = trim(l), *v = trim(val);
#define S(name) else if (!strcmp(k, #name)) snprintf(c->name, sizeof(c->name), "%s", v)
#define I(name) else if (!strcmp(k, #name)) c->name = atoi(v)
#define F(name) else if (!strcmp(k, #name)) c->name = strtof(v, NULL)
#define C(name) else if (!strcmp(k, #name)) parse_color(v, c->name)
#define B(name) else if (!strcmp(k, #name)) c->name = parse_bool(v)
		if (!strcmp(k, "autostart")) {
			if (c->autostart_count < 16)
				snprintf(c->autostart[c->autostart_count++], 512, "%s", v);
		}
		else if (!strcmp(k, "output")) {
			if (c->output_count < 8)
				snprintf(c->outputs[c->output_count++], sizeof(c->outputs[0]), "%s", v);
		}
		S(terminal); S(launcher); S(kb_layout); S(kb_options); S(browser); S(file_manager); S(glass_style);
		S(controls_side); S(color_scheme); C(accent); B(tiling); B(snapping);
		I(gesture_fingers);
		I(corner_radius); I(blur_passes); I(blur_radius); I(gaps); I(anim_ms);
		I(repeat_rate); I(repeat_delay);
		F(blur_brightness); F(blur_saturation); F(blur_noise); F(shadow_sigma);
		F(liquid_rim); F(liquid_refraction); F(liquid_highlight); F(liquid_frost);
		C(shadow_color); C(glass_tint); C(title_color);
		B(animations); B(performance_mode); B(preload_apps); B(blur_full_redraw); B(focus_follows_mouse); B(natural_scroll); B(mouse_natural_scroll); B(xwayland); B(gestures);
#undef S
#undef I
#undef F
#undef C
#undef B
	}
	fclose(f);
	c->liquid = !strcmp(c->glass_style, "liquid");
	/* Light mode: pale glass and dark titles — unless those were given colours
	 * of their own (anything but the stock dark ones stays as chosen). */
	c->light = !strcmp(c->color_scheme, "light");
	if (c->light) {
		float dark_tint[4], white_title[4];
		parse_color("#1c1f2a8c", dark_tint);
		parse_color("#ffffffe6", white_title);
		if (!memcmp(dark_tint, c->glass_tint, sizeof(dark_tint))) parse_color("#eef0f6b0", c->glass_tint);
		if (!memcmp(white_title, c->title_color, sizeof(white_title))) parse_color("#1a1c28e0", c->title_color);
	}
	/* older configs: the generic opener → Lumen Files */
	if (!strcmp(c->file_manager, "xdg-open \"$HOME\"") && access("/usr/bin/lumen-files", X_OK) == 0)
		snprintf(c->file_manager, sizeof(c->file_manager), "lumen-files");
	/* older configs: the plain rofi line → the style-aware Spotlight launcher */
	if (!strcmp(c->launcher, "rofi -show drun -theme lumen"))
		snprintf(c->launcher, sizeof(c->launcher), "lumen-launcher");
}
