/* Windows 11-style snapping.
 *
 *  • drag a window to the top of a monitor → the snap-layout bar drops down;
 *    drop on a zone to snap there (the first layout is "maximise")
 *  • drag to the left/right edge → half; near a corner → quarter
 *  • hover a window's maximise button → the same layouts as a flyout; click one
 *
 * A glass preview behind the window shows where it will land. */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "lumen.h"

struct zone { float x, y, w, h; };
struct layout { int n; struct zone z[4]; };
static const struct layout LAYOUTS[] = {
	{ 1, { { 0, 0, 1, 1 } } },                                                   /* maximise */
	{ 2, { { 0, 0, .5f, 1 }, { .5f, 0, .5f, 1 } } },
	{ 2, { { 0, 0, .667f, 1 }, { .667f, 0, .333f, 1 } } },
	{ 3, { { 0, 0, .333f, 1 }, { .333f, 0, .334f, 1 }, { .667f, 0, .333f, 1 } } },
	{ 3, { { 0, 0, .5f, 1 }, { .5f, 0, .5f, .5f }, { .5f, .5f, .5f, .5f } } },
	{ 4, { { 0, 0, .5f, .5f }, { .5f, 0, .5f, .5f }, { 0, .5f, .5f, .5f }, { .5f, .5f, .5f, .5f } } },
	{ 3, { { 0, 0, .25f, 1 }, { .25f, 0, .5f, 1 }, { .75f, 0, .25f, 1 } } },
};
#define NLAYOUTS (int)(sizeof(LAYOUTS) / sizeof(LAYOUTS[0]))
#define GW 92
#define GH 56
#define GAP 10
#define PAD 12
#define ZG 3

static struct {
	struct lumen_server *s;
	bool bar, flyout;                  /* what is showing */
	struct lumen_output *o;
	struct lumen_view *v;              /* window being snapped */
	struct wlr_scene_tree *tree;       /* the bar / flyout */
	struct wlr_scene_rect *bg, *rim;
	struct wlr_scene_blur *blur;
	struct wlr_scene_rect *zr[NLAYOUTS][4];
	struct wlr_box zbox[NLAYOUTS][4];  /* layout coords of each zone tile */
	struct wlr_box rect;               /* bar rect, layout coords */
	int hl, hz;                        /* highlighted layout / zone (-1) */
	struct wlr_scene_tree *ptree;      /* preview */
	struct wlr_scene_rect *pfill, *prim;
	struct wlr_scene_blur *pblur;
	bool have_target;
	struct wlr_box target;
	bool maximise;
	struct wl_event_source *hover_timer;
	struct lumen_view *hover_v;
	double t;                          /* appear animation 0..1 */
} S = { .hl = -1, .hz = -1 };

static void accent(float a, float out[4]) {
	const float *c = S.s->cfg.accent;
	out[0] = c[0] * a; out[1] = c[1] * a; out[2] = c[2] * a; out[3] = a;
}

static void premul(float r, float g, float b, float a, float out[4]) {
	out[0] = r * a; out[1] = g * a; out[2] = b * a; out[3] = a;
}

/* ------------------------------------------------------------- target boxes */
static struct wlr_box zone_box(struct lumen_output *o, const struct zone *z) {
	int g = S.s->cfg.gaps;
	struct wlr_box u = o->usable;
	double ix = u.x + g / 2.0, iy = u.y + g / 2.0, iw = u.width - g, ih = u.height - g;
	return (struct wlr_box){ (int)(ix + z->x * iw + g / 2.0), (int)(iy + z->y * ih + g / 2.0),
		(int)(z->w * iw - g), (int)(z->h * ih - g) };
}

static void show_preview(struct lumen_output *o, struct wlr_box b, bool full) {
	if (!S.ptree) {
		S.ptree = wlr_scene_tree_create(S.s->layer[L_WS]);
		wlr_scene_node_lower_to_bottom(&S.ptree->node);   /* behind the windows, like Windows */
		S.pblur = wlr_scene_blur_create(S.ptree, 0, 0);
		S.pfill = wlr_scene_rect_create(S.ptree, 0, 0, (float[4]){ 0 });
		S.prim = wlr_scene_rect_create(S.ptree, 0, 0, (float[4]){ 0 });
	}
	if (full) b = o->usable;
	int r = full ? 0 : S.s->cfg.corner_radius;
	wlr_scene_node_set_enabled(&S.ptree->node, true);
	wlr_scene_node_set_position(&S.ptree->node, b.x, b.y);
	wlr_scene_blur_set_size(S.pblur, b.width, b.height);
	wlr_scene_blur_set_corner_radius(S.pblur, r);
	float c[4];
	accent(0.16f, c);
	wlr_scene_rect_set_size(S.pfill, b.width, b.height);
	wlr_scene_rect_set_corner_radius(S.pfill, r);
	wlr_scene_rect_set_color(S.pfill, c);
	accent(0.7f, c);
	wlr_scene_rect_set_size(S.prim, b.width, b.height);
	wlr_scene_rect_set_corner_radius(S.prim, r);
	wlr_scene_rect_set_color(S.prim, c);
	wlr_scene_rect_set_clipped_region(S.prim, (struct clipped_region){
		.corners = corner_radii_all(r > 2 ? r - 2 : 0), .area = { 2, 2, b.width - 4, b.height - 4 } });
	S.have_target = true;
	S.target = b;
	S.maximise = full;
}

static void hide_preview(void) {
	if (S.ptree) wlr_scene_node_set_enabled(&S.ptree->node, false);
	S.have_target = false;
	S.maximise = false;
}

/* ----------------------------------------------------------------- the bar */
static void paint_bar(void) {
	float c[4];
	premul(0.11f, 0.12f, 0.17f, 0.78f * (float)S.t, c);
	wlr_scene_rect_set_color(S.bg, c);
	premul(1, 1, 1, 0.20f * (float)S.t, c);
	wlr_scene_rect_set_color(S.rim, c);
	wlr_scene_blur_set_alpha(S.blur, (float)S.t);
	for (int l = 0; l < NLAYOUTS; l++)
		for (int k = 0; k < LAYOUTS[l].n; k++) {
			if (l == S.hl && k == S.hz) accent(0.95f * (float)S.t, c);
			else if (l == S.hl) premul(1, 1, 1, 0.30f * (float)S.t, c);
			else premul(1, 1, 1, 0.16f * (float)S.t, c);
			wlr_scene_rect_set_color(S.zr[l][k], c);
		}
}

static void appear_step(struct anim *a, double e) {
	(void)a;
	S.t = e;
	if (!S.tree) return;
	wlr_scene_node_set_position(&S.tree->node, S.rect.x, S.rect.y - (int)((1 - e) * 16));
	paint_bar();
}

static void build(struct lumen_output *o, int x, int y) {
	struct lumen_server *s = S.s;
	if (S.tree) wlr_scene_node_destroy(&S.tree->node);
	int W = NLAYOUTS * GW + (NLAYOUTS - 1) * GAP + 2 * PAD, H = GH + 2 * PAD;
	if (x + W > o->full.x + o->full.width - 8) x = o->full.x + o->full.width - 8 - W;
	if (x < o->full.x + 8) x = o->full.x + 8;
	S.rect = (struct wlr_box){ x, y, W, H };
	S.o = o;
	S.tree = wlr_scene_tree_create(s->layer[L_OVERLAY]);
	wlr_scene_node_set_position(&S.tree->node, x, y);
	S.blur = wlr_scene_blur_create(S.tree, W, H);
	wlr_scene_blur_set_corner_radius(S.blur, 14);
	S.bg = wlr_scene_rect_create(S.tree, W, H, (float[4]){ 0 });
	wlr_scene_rect_set_corner_radius(S.bg, 14);
	S.rim = wlr_scene_rect_create(S.tree, W, H, (float[4]){ 0 });
	wlr_scene_rect_set_corner_radius(S.rim, 14);
	wlr_scene_rect_set_clipped_region(S.rim, (struct clipped_region){
		.corners = corner_radii_all(13), .area = { 1, 1, W - 2, H - 2 } });
	for (int l = 0; l < NLAYOUTS; l++) {
		int gx = PAD + l * (GW + GAP), gy = PAD;
		for (int k = 0; k < LAYOUTS[l].n; k++) {
			const struct zone *z = &LAYOUTS[l].z[k];
			int zx = gx + (int)lround(z->x * GW), zy = gy + (int)lround(z->y * GH);
			int zw = (int)lround(z->w * GW) - ZG, zh = (int)lround(z->h * GH) - ZG;
			if (z->x + z->w >= 0.999f) zw = gx + GW - zx;
			if (z->y + z->h >= 0.999f) zh = gy + GH - zy;
			S.zr[l][k] = wlr_scene_rect_create(S.tree, zw, zh, (float[4]){ 0 });
			wlr_scene_rect_set_corner_radius(S.zr[l][k], 5);
			wlr_scene_node_set_position(&S.zr[l][k]->node, zx, zy);
			S.zbox[l][k] = (struct wlr_box){ x + zx, y + zy, zw, zh };
		}
	}
	S.hl = S.hz = -1;
	S.t = 0;
	struct anim *a = anim_start(&S, 1, anim_scaled(220), EASE_OUT_CUBIC, appear_step, NULL);
	(void)a;
	appear_step(NULL, 0);
}

static void close_bar(void) {
	anim_cancel(&S, 1);
	if (S.tree) wlr_scene_node_destroy(&S.tree->node);
	S.tree = NULL;
	S.bar = S.flyout = false;
	S.hl = S.hz = -1;
}

/* which zone tile is under (x, y)? */
static bool zone_at(double x, double y, int *l, int *k) {
	for (int i = 0; i < NLAYOUTS; i++)
		for (int j = 0; j < LAYOUTS[i].n; j++) {
			struct wlr_box b = S.zbox[i][j];
			b.x -= 2; b.y -= 2; b.width += 4; b.height += 4;
			if (wlr_box_contains_point(&b, x, y)) { *l = i; *k = j; return true; }
		}
	return false;
}

static void highlight(int l, int k) {
	if (l == S.hl && k == S.hz) return;
	S.hl = l; S.hz = k;
	paint_bar();
	if (l >= 0) show_preview(S.o, zone_box(S.o, &LAYOUTS[l].z[k]), l == 0);
	else hide_preview();
}

/* ------------------------------------------------------------------ dragging */
void snap_init(struct lumen_server *s) { S.s = s; }

void snap_motion(struct lumen_server *s, struct lumen_view *v, double x, double y) {
	if (!s->cfg.snapping || !v) return;
	struct lumen_output *o = output_at(s, x, y);
	if (!o) return;
	S.v = v;
	bool near_top = y <= o->usable.y + 6;
	if (!S.bar && near_top) {
		S.bar = true;
		build(o, (int)(o->full.x + (o->full.width - (NLAYOUTS * GW + (NLAYOUTS - 1) * GAP + 2 * PAD)) / 2),
			o->usable.y + 10);
	}
	if (S.bar) {
		struct wlr_box keep = S.rect;
		keep.x -= 60; keep.width += 120; keep.y = o->full.y; keep.height = S.rect.y - o->full.y + S.rect.height + 90;
		if (S.o != o || !wlr_box_contains_point(&keep, x, y)) {
			close_bar();
			hide_preview();
		} else {
			int l, k;
			if (zone_at(x, y, &l, &k)) highlight(l, k);
			else if (near_top) highlight(0, 0);   /* right at the top edge: maximise */
			else highlight(-1, -1);
			return;
		}
	}
	/* edges: halves, corners: quarters */
	double ex = 3, ey = o->full.height * 0.18;
	bool left = x <= o->full.x + ex, right = x >= o->full.x + o->full.width - ex;
	if (left || right) {
		struct zone z = { left ? 0.f : .5f, 0, .5f, 1 };
		if (y < o->usable.y + ey) z.h = .5f;
		else if (y > o->usable.y + o->usable.height - ey) { z.y = .5f; z.h = .5f; }
		S.o = o;
		show_preview(o, zone_box(o, &z), false);
	} else {
		hide_preview();
	}
}

/* drop: snap if a zone/edge is armed. true = handled */
bool snap_release(struct lumen_server *s, struct lumen_view *v) {
	(void)s;
	bool armed = S.have_target && v;
	struct wlr_box t = S.target;
	bool max = S.maximise;
	close_bar();
	hide_preview();
	if (!armed) return false;
	if (max) { if (!v->maximized) view_toggle_maximize(v); }
	else view_animate_to(v, t);
	return true;
}

/* keyboard snapping (Super+Ctrl+←/→, `lumenctl snap ID left|right`): the window
 * takes the left or right half of the screen it is on */
void snap_half(struct lumen_view *v, bool left) {
	if (!v || !v->mapped || v->fullscreen) return;
	struct lumen_output *o = output_at(v->server, v->geom.x + v->geom.width / 2.0,
		v->geom.y + v->geom.height / 2.0);
	if (!o) o = output_focused(v->server);
	if (!o) return;
	if (v->maximized) view_toggle_maximize(v);
	struct zone z = { left ? 0.f : .5f, 0, .5f, 1 };
	view_animate_to(v, zone_box(o, &z));
}

void snap_cancel(struct lumen_server *s) {
	(void)s;
	close_bar();
	hide_preview();
}

/* ------------------------------------------------- maximise-button flyout */
static int hover_fire(void *data) {
	(void)data;
	struct lumen_view *v = S.hover_v;
	if (!v || !v->mapped || S.bar || !S.s->cfg.snapping) return 0;
	struct lumen_output *o = output_at(S.s, v->geom.x + v->geom.width / 2.0, v->geom.y + 10);
	if (!o) return 0;
	/* under the maximise light */
	int lx, ly;
	wlr_scene_node_coords(&v->lights[2]->node, &lx, &ly);
	int W = NLAYOUTS * GW + (NLAYOUTS - 1) * GAP + 2 * PAD;
	S.flyout = true;
	S.v = v;
	build(o, lx + 6 - W / 2, ly + 22);
	return 0;
}

void snap_flyout_hover(struct lumen_view *v, bool on) {
	if (!S.s) return;
	if (!S.hover_timer) S.hover_timer = wl_event_loop_add_timer(S.s->loop, hover_fire, NULL);
	if (on) {
		if (S.hover_v != v || !S.flyout) {
			S.hover_v = v;
			wl_event_source_timer_update(S.hover_timer, 450);
		}
	} else {
		wl_event_source_timer_update(S.hover_timer, 0);
		S.hover_v = NULL;
	}
}

bool snap_flyout_open(void) { return S.flyout; }

/* pointer moves while the flyout is up: true = it's over the flyout */
bool snap_flyout_motion(double x, double y) {
	if (!S.flyout) return false;
	struct wlr_box keep = S.rect;
	keep.x -= 16; keep.y -= 40; keep.width += 32; keep.height += 56;
	if (!wlr_box_contains_point(&keep, x, y)) {
		close_bar();
		hide_preview();
		return false;
	}
	int l, k;
	if (zone_at(x, y, &l, &k)) highlight(l, k);
	else highlight(-1, -1);
	return wlr_box_contains_point(&S.rect, x, y);
}

bool snap_flyout_click(double x, double y) {
	if (!S.flyout) return false;
	struct lumen_view *v = S.v;
	int l, k;
	bool inside = wlr_box_contains_point(&S.rect, x, y);
	if (inside && zone_at(x, y, &l, &k) && v && v->mapped) {
		struct lumen_output *o = S.o;
		close_bar();
		hide_preview();
		if (l == 0) { if (!v->maximized) view_toggle_maximize(v); }
		else view_animate_to(v, zone_box(o, &LAYOUTS[l].z[k]));
		return true;
	}
	close_bar();
	hide_preview();
	return inside;
}
