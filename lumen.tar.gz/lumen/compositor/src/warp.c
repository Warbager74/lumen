/* wp_pointer_warp_v1: an app moves the pointer within its own surface.
 * Games use it to re-centre the cursor (Minecraft's inventory opening in the
 * middle); Xwayland uses it for XWarpPointer when the pointer isn't locked.
 * Only honoured for the surface that has pointer focus. */
#include <wayland-server-core.h>
#include <wlr/types/wlr_compositor.h>
#include <wlr/types/wlr_seat.h>
#include "lumen.h"

#ifdef LUMEN_HAVE_POINTER_WARP
#include "pointer-warp-v1-protocol.h"

static void warp_destroy(struct wl_client *c, struct wl_resource *r) {
	(void)c;
	wl_resource_destroy(r);
}

static void warp_pointer(struct wl_client *c, struct wl_resource *r, struct wl_resource *surface_res,
		struct wl_resource *pointer_res, wl_fixed_t fx, wl_fixed_t fy, uint32_t serial) {
	(void)c; (void)r; (void)pointer_res; (void)serial;
	struct lumen_server *s = g_server;
	struct wlr_surface *sf = wlr_surface_from_resource(surface_res);
	if (!sf || s->seat->pointer_state.focused_surface != sf) return;
	if (s->cursor_mode != CURSOR_PASSTHROUGH) return;
	double x = wl_fixed_to_double(fx), y = wl_fixed_to_double(fy);
	if (x < 0 || y < 0 || x > sf->current.width || y > sf->current.height) return;
	/* the surface's origin in the layout, from where the pointer is on it now */
	double ox = s->cursor->x - s->seat->pointer_state.sx, oy = s->cursor->y - s->seat->pointer_state.sy;
	wlr_cursor_warp(s->cursor, NULL, ox + x, oy + y);
	wlr_seat_pointer_warp(s->seat, x, y);
}

static const struct wp_pointer_warp_v1_interface warp_impl = {
	.destroy = warp_destroy,
	.warp_pointer = warp_pointer,
};

static void warp_bind(struct wl_client *client, void *data, uint32_t version, uint32_t id) {
	(void)data;
	struct wl_resource *r = wl_resource_create(client, &wp_pointer_warp_v1_interface, (int)version, id);
	if (!r) { wl_client_post_no_memory(client); return; }
	wl_resource_set_implementation(r, &warp_impl, NULL, NULL);
}

void pointer_warp_init(struct lumen_server *s) {
	wl_global_create(s->display, &wp_pointer_warp_v1_interface, 1, NULL, warp_bind);
}
#else
void pointer_warp_init(struct lumen_server *s) { (void)s; }
#endif
