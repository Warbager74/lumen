/* Desktop overview (GNOME-style): windows of the current desktop shrink into a
 * grid over a blurred, dimmed backdrop, with desktop pills along the top.
 * Driven either by an animation or 1:1 by a touchpad swipe (overview_set_t).
 *
 * Thumbnails reuse each window's current client buffer in our own scene node,
 * so the real windows are never touched (and are simply hidden meanwhile). */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <wlr/types/wlr_buffer.h>
#include <wlr/types/wlr_compositor.h>
#include <wlr/util/log.h>
#include <xkbcommon/xkbcommon.h>
#include "lumen.h"

#define MAX_THUMBS 64
#define STRIP_H 120
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

struct thumb {
	struct lumen_view *v;
	struct wlr_scene_tree *tree;
	struct wlr_scene_shadow *shadow;
	struct wlr_scene_buffer *buf;
	struct wlr_scene_rect *ph;      /* placeholder when there's no buffer */
	struct wlr_scene_rect *hl;      /* hover rim */
	struct wlr_scene_buffer *label;
	struct wlr_box from, to;
	int ws;
};

struct pill {
	struct wlr_scene_tree *tree;
	struct wlr_scene_rect *bg, *rim;
	struct wlr_box box;
};

static struct {
	struct lumen_server *s;
	bool active;                    /* scene exists, windows hidden */
	double t;                       /* 0 = closed, 1 = fully open */
	struct wlr_scene_tree *tree;
	struct wlr_scene_blur *blur;
	struct wlr_scene_rect *dim;
	struct wlr_scene_tree *strip;
	struct pill pills[LUMEN_WORKSPACES];
	struct wlr_scene_rect *sel, *sel_rim;          /* glides between the pills */
	struct wlr_scene_tree *pages;                  /* slides horizontally */
	struct wlr_scene_tree *page[LUMEN_WORKSPACES];
	struct wlr_scene_buffer *empty[LUMEN_WORKSPACES];
	double pos, PW;                                /* strip position (desktops) */
	bool dragging;
	double drag_base;
	struct thumb th[MAX_THUMBS];
	int n, hovered;
	struct lumen_view *focus_on_close;
} ov = { .hovered = -1 };

bool overview_active(void) { return ov.active; }
double overview_t(void) { return ov.active ? ov.t : 0; }

/* ------------------------------------------------------------------ build */
static void premul(float r, float g, float b, float a, float out[4]) {
	out[0] = r * a; out[1] = g * a; out[2] = b * a; out[3] = a;
}

static struct wlr_box content_rect(struct lumen_view *v) {
	int th = v->ssd && !v->fullscreen ? TITLEBAR_H : 0;
	return (struct wlr_box){ v->geom.x, v->geom.y + th,
		v->content_w > 0 ? v->content_w : v->geom.width,
		v->content_h > 0 ? v->content_h : v->geom.height - th };
}

static void thumb_set_buffer(struct thumb *t) {
	struct wlr_surface *sf = view_surface(t->v);
	struct wlr_buffer *b = sf && sf->buffer ? &sf->buffer->base : NULL;
	wlr_scene_buffer_set_buffer(t->buf, b);
	wlr_scene_node_set_enabled(&t->ph->node, b == NULL);
	if (b) {
		/* crop to the window geometry (drops client-side shadows) */
		struct wlr_box g = t->v->type == VIEW_XDG ? t->v->xdg->base->geometry
			: (struct wlr_box){ 0, 0, sf->current.width, sf->current.height };
		float sc = sf->current.scale > 0 ? (float)sf->current.scale : 1.f;
		struct wlr_fbox src = { g.x * sc, g.y * sc, g.width * sc, g.height * sc };
		if (src.width > 0 && src.height > 0 && src.x + src.width <= b->width + 0.5 &&
				src.y + src.height <= b->height + 0.5)
			wlr_scene_buffer_set_source_box(t->buf, &src);
	}
}

static void layout_grid(struct lumen_output *o, int ws) {
	struct wlr_box u = o->usable;
	struct wlr_box area = { u.x + 60, u.y + STRIP_H + 30, u.width - 120, u.height - STRIP_H - 70 };
	int idx[MAX_THUMBS], n = 0;
	for (int i = 0; i < ov.n; i++) if (ov.th[i].ws == ws) idx[n++] = i;
	if (n == 0) return;
	int cols = (int)ceil(sqrt((double)n * area.width / (area.height * 1.6)));
	if (cols < 1) cols = 1;
	if (cols > n) cols = n;
	int rows = (n + cols - 1) / cols;
	int cw = area.width / cols, ch = area.height / rows;

	/* stable order: by original position, so windows move as little as possible */
	int order[MAX_THUMBS];
	for (int i = 0; i < n; i++) order[i] = idx[i];
	for (int i = 1; i < n; i++)
		for (int j = i; j > 0; j--) {
			struct wlr_box a = ov.th[order[j - 1]].from, b = ov.th[order[j]].from;
			if (a.y / 200 > b.y / 200 || (a.y / 200 == b.y / 200 && a.x > b.x)) {
				int tmp = order[j]; order[j] = order[j - 1]; order[j - 1] = tmp;
			}
		}
	for (int k = 0; k < n; k++) {
		struct thumb *t = &ov.th[order[k]];
		int r = k / cols, c = k % cols;
		int in_row = (r == rows - 1) ? n - r * cols : cols;
		int row_x = area.x + (area.width - in_row * cw) / 2;
		double fw = t->from.width > 0 ? t->from.width : 400, fh = t->from.height > 0 ? t->from.height : 300;
		double sc = fmin(fmin((cw * 0.86) / fw, (ch * 0.78) / fh), 1.0);
		int w = (int)(fw * sc), h = (int)(fh * sc);
		t->to = (struct wlr_box){ row_x + c * cw + (cw - w) / 2, area.y + r * ch + (ch - 28 - h) / 2, w, h };
	}
}

static void build_pills(struct lumen_output *o) {
	struct lumen_server *s = ov.s;
	int gap = 14, ph = 84;
	int pw = (o->usable.width - 80 - (LUMEN_WORKSPACES - 1) * gap) / LUMEN_WORKSPACES;
	if (pw > 168) pw = 168;
	if (pw < 60) pw = 60;
	int total = LUMEN_WORKSPACES * pw + (LUMEN_WORKSPACES - 1) * gap;
	int x0 = o->usable.x + (o->usable.width - total) / 2, y0 = o->usable.y + 18;
	for (int i = 0; i < LUMEN_WORKSPACES; i++) {
		struct pill *p = &ov.pills[i];
		p->box = (struct wlr_box){ x0 + i * (pw + gap), y0, pw, ph };
		p->tree = wlr_scene_tree_create(ov.strip);
		wlr_scene_node_set_position(&p->tree->node, p->box.x, p->box.y);
		float c[4];
		premul(1, 1, 1, 0.08f, c);
		p->bg = wlr_scene_rect_create(p->tree, pw, ph, c);
		wlr_scene_rect_set_corner_radius(p->bg, 14);
		premul(1, 1, 1, 0.16f, c);
		p->rim = wlr_scene_rect_create(p->tree, pw, ph, c);
		wlr_scene_rect_set_corner_radius(p->rim, 14);
		wlr_scene_rect_set_clipped_region(p->rim, (struct clipped_region){
			.corners = corner_radii_all(13), .area = { 1, 1, pw - 2, ph - 2 } });
		if (i == 0) {
			/* one highlight that glides between the pills (drawn above their bg) */
			ov.sel = wlr_scene_rect_create(ov.strip, pw, ph, (float[4]){ 0, 0, 0, 0 });
			wlr_scene_rect_set_corner_radius(ov.sel, 14);
			ov.sel_rim = wlr_scene_rect_create(ov.strip, pw, ph, (float[4]){ 0, 0, 0, 0 });
			wlr_scene_rect_set_corner_radius(ov.sel_rim, 14);
			wlr_scene_node_lower_to_bottom(&ov.sel_rim->node);
			wlr_scene_node_lower_to_bottom(&ov.sel->node);
		}
		int count = 0;
		struct lumen_view *v;
		wl_list_for_each(v, &s->views, link) if (v->mapped && v->workspace == i) count++;
		char txt[64];
		snprintf(txt, sizeof(txt), pw >= 120 ? "Desktop %d" : "%d", i + 1);
		float scale = o->wlr_output->scale;
		struct wlr_buffer *b = text_buffer_create(txt, "Inter Semi-Bold 12",
			(float[4]){ 1, 1, 1, 0.95f }, pw, 30, scale);
		struct wlr_scene_buffer *lb = wlr_scene_buffer_create(p->tree, b);
		wlr_scene_buffer_set_dest_size(lb, pw, 30);
		wlr_scene_node_set_position(&lb->node, 0, ph / 2 - 26);
		wlr_buffer_drop(b);
		snprintf(txt, sizeof(txt), count == 1 ? "1 window" : "%d windows", count);
		b = text_buffer_create(txt, "Inter 10", (float[4]){ 1, 1, 1, 0.6f }, pw, 24, scale);
		lb = wlr_scene_buffer_create(p->tree, b);
		wlr_scene_buffer_set_dest_size(lb, pw, 24);
		wlr_scene_node_set_position(&lb->node, 0, ph / 2 + 2);
		wlr_buffer_drop(b);
	}
}

static void build(void) {
	struct lumen_server *s = ov.s;
	struct lumen_output *o = output_focused(s);
	if (!o) return;
	ov.tree = wlr_scene_tree_create(s->layer[L_OVERVIEW]);
	ov.blur = wlr_scene_blur_create(ov.tree, o->full.width, o->full.height);
	wlr_scene_node_set_position(&ov.blur->node, o->full.x, o->full.y);
	ov.dim = wlr_scene_rect_create(ov.tree, o->full.width, o->full.height, (float[4]){ 0, 0, 0, 0 });
	ov.dim->accepts_input = false;
	wlr_scene_node_set_position(&ov.dim->node, o->full.x, o->full.y);
	ov.strip = wlr_scene_tree_create(ov.tree);
	build_pills(o);

	ov.PW = o->full.width + 80;
	ov.pages = wlr_scene_tree_create(ov.tree);
	for (int w = 0; w < LUMEN_WORKSPACES; w++) {
		ov.page[w] = wlr_scene_tree_create(ov.pages);
		wlr_scene_node_set_position(&ov.page[w]->node, (int)(w * ov.PW), 0);
		ov.empty[w] = NULL;
	}

	/* thumbnails for every desktop, bottom of each stack first */
	ov.n = 0;
	ov.hovered = -1;
	struct lumen_view *v;
	wl_list_for_each_reverse(v, &s->views, link) {
		if (!v->mapped || v->workspace < 0 || v->workspace >= LUMEN_WORKSPACES || ov.n >= MAX_THUMBS)
			continue;
		struct thumb *t = &ov.th[ov.n++];
		memset(t, 0, sizeof(*t));
		t->v = v;
		t->ws = v->workspace;
		t->from = content_rect(v);
		if (v->minimized)   /* minimised windows rise from the taskbar */
			t->from = (struct wlr_box){ o->full.x + o->full.width / 2 - 40,
				o->full.y + o->full.height, 80, 50 };
		t->tree = wlr_scene_tree_create(ov.page[t->ws]);
		t->shadow = wlr_scene_shadow_create(t->tree, 0, 0, 12, 22, (float[4]){ 0, 0, 0, 0.45f });
		t->ph = wlr_scene_rect_create(t->tree, 0, 0, (float[4]){ 0.08f, 0.09f, 0.12f, 0.8f });
		wlr_scene_rect_set_corner_radius(t->ph, 12);
		t->buf = wlr_scene_buffer_create(t->tree, NULL);
		wlr_scene_buffer_set_corner_radius(t->buf, 12);
		t->hl = wlr_scene_rect_create(t->tree, 0, 0, (float[4]){ 0.85f, 0.85f, 0.85f, 0.85f });
		wlr_scene_rect_set_corner_radius(t->hl, 15);
		t->hl->accepts_input = false;
		wlr_scene_node_set_enabled(&t->hl->node, false);
		thumb_set_buffer(t);
	}
	int count[LUMEN_WORKSPACES] = { 0 };
	for (int i = 0; i < ov.n; i++) count[ov.th[i].ws]++;
	for (int w = 0; w < LUMEN_WORKSPACES; w++) layout_grid(o, w);

	/* titles under each thumbnail */
	for (int i = 0; i < ov.n; i++) {
		struct thumb *t = &ov.th[i];
		const char *title = view_title(t->v);
		if (!*title) title = view_app_id(t->v);
		int w = t->to.width < 120 ? 120 : t->to.width;
		struct wlr_buffer *b = text_buffer_create(title, "Inter Medium 10.5",
			(float[4]){ 1, 1, 1, 0.92f }, w, 26, o->wlr_output->scale);
		t->label = wlr_scene_buffer_create(t->tree, b);
		wlr_scene_buffer_set_dest_size(t->label, w, 26);
		wlr_buffer_drop(b);
	}
	for (int w = 0; w < LUMEN_WORKSPACES; w++) {
		if (count[w]) continue;
		struct wlr_buffer *b = text_buffer_create("No windows on this desktop", "Inter 13",
			(float[4]){ 1, 1, 1, 0.7f }, 400, 40, o->wlr_output->scale);
		ov.empty[w] = wlr_scene_buffer_create(ov.page[w], b);
		wlr_scene_buffer_set_dest_size(ov.empty[w], 400, 40);
		wlr_scene_node_set_position(&ov.empty[w]->node, o->full.x + (o->full.width - 400) / 2,
			o->full.y + o->full.height / 2 - 20);
		wlr_buffer_drop(b);
	}
}

static void teardown(void) {
	if (ov.tree) wlr_scene_node_destroy(&ov.tree->node);
	ov.tree = NULL;
	ov.pages = NULL;
	ov.sel = ov.sel_rim = NULL;
	memset(ov.page, 0, sizeof(ov.page));
	memset(ov.empty, 0, sizeof(ov.empty));
	memset(ov.pills, 0, sizeof(ov.pills));
	ov.n = 0;
	ov.hovered = -1;
}

/* ------------------------------------------------------------------ paint */
/* slide the pages and glide the pill highlight to ov.pos */
static void apply_pos(void) {
	if (!ov.pages) return;
	double tc = ov.t < 0 ? 0 : (ov.t > 1 ? 1 : ov.t);
	wlr_scene_node_set_position(&ov.pages->node, (int)lround(-ov.pos * ov.PW), 0);
	for (int w = 0; w < LUMEN_WORKSPACES; w++)
		wlr_scene_node_set_enabled(&ov.page[w]->node, fabs(w - ov.pos) < 0.999);
	if (ov.sel && ov.pills[0].tree) {
		double p = ov.pos < 0 ? 0 : (ov.pos > LUMEN_WORKSPACES - 1 ? LUMEN_WORKSPACES - 1 : ov.pos);
		int i0 = (int)floor(p), i1 = i0 + 1 < LUMEN_WORKSPACES ? i0 + 1 : i0;
		double f = p - i0;
		struct wlr_box a = ov.pills[i0].box, b = ov.pills[i1].box;
		/* stretches a little while moving, like a liquid droplet */
		double stretch = sin(f * M_PI) * 26;
		int x = (int)lround(lerp(a.x, b.x, f) - stretch / 2);
		int w = a.width + (int)lround(stretch);
		wlr_scene_node_set_position(&ov.sel->node, x, a.y);
		wlr_scene_node_set_position(&ov.sel_rim->node, x, a.y);
		wlr_scene_rect_set_size(ov.sel, w, a.height);
		wlr_scene_rect_set_size(ov.sel_rim, w, a.height);
		wlr_scene_rect_set_clipped_region(ov.sel_rim, (struct clipped_region){
			.corners = corner_radii_all(12), .area = { 2, 2, w - 4, a.height - 4 } });
		float c[4];
		premul(1, 1, 1, (float)(0.16 * tc), c);
		wlr_scene_rect_set_color(ov.sel, c);
		premul(1, 1, 1, (float)(0.6 * tc), c);
		wlr_scene_rect_set_color(ov.sel_rim, c);
	}
}

static void apply(void) {
	double t = ov.t;
	double tc = t < 0 ? 0 : (t > 1 ? 1 : t);
	float dim[4];
	premul(0.02f, 0.03f, 0.08f, (float)(0.38 * tc), dim);
	wlr_scene_rect_set_color(ov.dim, dim);
	wlr_scene_blur_set_alpha(ov.blur, (float)tc);
	wlr_scene_blur_set_strength(ov.blur, (float)tc);
	wlr_scene_node_set_position(&ov.strip->node, 0, (int)(-40 * (1 - tc)));
	wlr_scene_node_set_enabled(&ov.strip->node, tc > 0.02);
	for (int w = 0; w < LUMEN_WORKSPACES; w++)
		if (ov.empty[w]) wlr_scene_buffer_set_opacity(ov.empty[w], (float)(tc * tc));
	for (int i = 0; i < LUMEN_WORKSPACES; i++) {
		if (!ov.pills[i].tree) continue;
		float c[4];
		premul(1, 1, 1, (float)(0.08 * tc), c);
		wlr_scene_rect_set_color(ov.pills[i].bg, c);
		premul(1, 1, 1, (float)(0.16 * tc), c);
		wlr_scene_rect_set_color(ov.pills[i].rim, c);
	}
	apply_pos();
	for (int i = 0; i < ov.n; i++) {
		struct thumb *th = &ov.th[i];
		struct wlr_box r = {
			(int)lerp(th->from.x, th->to.x, t), (int)lerp(th->from.y, th->to.y, t),
			(int)lerp(th->from.width, th->to.width, t), (int)lerp(th->from.height, th->to.height, t) };
		if (r.width < 1) r.width = 1;
		if (r.height < 1) r.height = 1;
		wlr_scene_node_set_position(&th->tree->node, r.x, r.y);
		wlr_scene_buffer_set_dest_size(th->buf, r.width, r.height);
		wlr_scene_rect_set_size(th->ph, r.width, r.height);
		int sig = 22;
		wlr_scene_shadow_set_size(th->shadow, r.width + sig * 2, r.height + sig * 2);
		wlr_scene_node_set_position(&th->shadow->node, -sig, -sig + 6);
		wlr_scene_shadow_set_color(th->shadow, (float[4]){ 0, 0, 0, (float)(0.45 * tc) });
		wlr_scene_rect_set_size(th->hl, r.width + 8, r.height + 8);
		wlr_scene_node_set_position(&th->hl->node, -4, -4);
		wlr_scene_rect_set_clipped_region(th->hl, (struct clipped_region){
			.corners = corner_radii_all(12), .area = { 4, 4, r.width, r.height } });
		if (th->label) {
			int lw = th->to.width < 120 ? 120 : th->to.width;
			wlr_scene_node_set_position(&th->label->node, (r.width - lw) / 2, r.height + 8);
			wlr_scene_buffer_set_opacity(th->label, (float)pow(tc, 4));
		}
		/* minimised windows also fade in from the taskbar */
		wlr_scene_buffer_set_opacity(th->buf, th->v->minimized ? (float)tc : 1.f);
	}
}

static void set_windows_hidden(bool hidden) {
	struct lumen_server *s = ov.s;
	for (int i = 0; i < LUMEN_WORKSPACES; i++)
		wlr_scene_node_set_enabled(&s->ws_tree[i]->node, !hidden && i == s->ws_current);
}

/* make the overview exist (windows hidden) at progress t without animating */
static void ensure_active(void) {
	if (ov.active) return;
	ov.active = true;
	ov.t = 0;
	ov.focus_on_close = NULL;
	anim_cancel(&ov, 2);
	ov.dragging = false;
	workspace_strip_sync(ov.s);
	ov.pos = ov.s->ws_current;
	build();
	set_windows_hidden(true);
	wlr_seat_pointer_clear_focus(ov.s->seat);
	ipc_state_changed(ov.s);
}

static void finish_closed(void) {
	anim_cancel(&ov, 2);
	teardown();
	ov.active = false;
	ov.pos = ov.s->ws_current;
	/* the desktop picked in the overview goes up on this monitor */
	struct lumen_output *fo = output_focused(ov.s);
	if (fo && fo->ws != ov.s->ws_current) workspace_assign(ov.s, fo, ov.s->ws_current);
	workspace_strip_sync(ov.s);
	struct lumen_view *f = ov.focus_on_close;
	ov.focus_on_close = NULL;
	if (f) focus_view(f);
	pointer_refocus(ov.s);
	ipc_state_changed(ov.s);
}

static void step(struct anim *a, double e) {
	ov.t = lerp(a->from[0], a->to[0], e);
	apply();
}

static void done(struct anim *a) {
	if (a->to[0] <= 0.0) finish_closed();
}

/* animate from the current progress to 0 or 1 */
static void settle(double target) {
	struct lumen_server *s = ov.s;
	double dist = fabs(target - ov.t);
	double dur = s->cfg.animations ? s->cfg.anim_ms * (0.55 + 0.75 * dist) : 1;
	struct anim *a = anim_start(&ov, 1, dur, target > 0.5 ? EASE_SPRING : EASE_OUT_EXPO, step, done);
	a->from[0] = ov.t;
	a->to[0] = target;
}

/* ------------------------------------------------------------------ API */
void overview_init(struct lumen_server *s) { ov.s = s; }

void overview_open(void) {
	ensure_active();
	settle(1.0);
}

void overview_close(struct lumen_view *focus) {
	if (!ov.active) return;
	ov.focus_on_close = focus;
	/* the picked window flies back on top of the others */
	for (int i = 0; focus && i < ov.n; i++)
		if (ov.th[i].v == focus) wlr_scene_node_raise_to_top(&ov.th[i].tree->node);
	if (ov.hovered >= 0) wlr_scene_node_set_enabled(&ov.th[ov.hovered].hl->node, false);
	settle(0.0);
}

void overview_toggle(void) {
	if (ov.active && ov.t > 0.5) overview_close(NULL);
	else overview_open();
}

/* interactive (touchpad) control */
void overview_set_t(double t) {
	ensure_active();
	anim_cancel(&ov, 1);
	/* a little rubber band past fully open */
	ov.t = t > 1 ? 1 + (t - 1) * 0.15 : (t < 0 ? 0 : t);
	apply();
}

void overview_release(double velocity) {
	if (!ov.active) return;
	double target = ov.t > 0.5 ? 1 : 0;
	if (velocity < -0.8) target = 1;       /* quick flick up */
	else if (velocity > 0.8) target = 0;   /* quick flick down */
	settle(target);
}

/* ---------------------------------------------------- sliding desktops */
static void pos_step(struct anim *a, double e) {
	ov.pos = lerp(a->from[0], a->to[0], e);
	apply_pos();
}

static void pos_done(struct anim *a) {
	ov.pos = a->to[0];
	apply_pos();
}

static void slide_to(double target, double speed) {
	struct lumen_server *s = ov.s;
	double dist = fabs(target - ov.pos);
	double dur = s->cfg.animations ? s->cfg.anim_ms * speed * (0.8 + 0.4 * fmin(dist, 2.0)) : 1;
	struct anim *a = anim_start(&ov, 2, dur, EASE_OUT_CUBIC, pos_step, pos_done);
	a->from[0] = ov.pos;
	a->to[0] = target;
}

static void set_current(int ws) {
	struct lumen_server *s = ov.s;
	if (ws == s->ws_current) return;
	if (ov.hovered >= 0) wlr_scene_node_set_enabled(&ov.th[ov.hovered].hl->node, false);
	ov.hovered = -1;
	s->ws_current = ws;
	ipc_state_changed(s);
}

/* desktop changed (pill click, Super+N, arrow keys): slide the pages over */
void overview_set_ws(int ws) {
	struct lumen_server *s = ov.s;
	if (ws < 0 || ws >= LUMEN_WORKSPACES) return;
	if (!ov.active) { s->ws_current = ws; ipc_state_changed(s); return; }
	set_current(ws);
	slide_to(ws, 1.0);
}

/* fingers sideways inside the overview: the pages follow 1:1 */
void overview_drag(double total_dx) {
	if (!ov.active) return;
	if (!ov.dragging) {
		anim_cancel(&ov, 2);
		ov.dragging = true;
		ov.drag_base = ov.pos;
	}
	double p = ov.drag_base - total_dx * 1.3 / ov.PW;
	double max = LUMEN_WORKSPACES - 1;
	if (p < 0) p = -pow(-p, 0.7) * 0.18;
	else if (p > max) p = max + pow(p - max, 0.7) * 0.18;
	ov.pos = p;
	apply_pos();
}

void overview_drag_end(double vx, bool cancelled) {
	if (!ov.active || !ov.dragging) return;
	ov.dragging = false;
	double base = round(ov.drag_base), target;
	double v = -vx * 1.3 / ov.PW * 1000;
	if (cancelled) target = base;
	else if (fabs(v) > 1.2) target = v > 0 ? floor(ov.pos) + 1 : ceil(ov.pos) - 1;
	else target = round(ov.pos);
	if (target > base + 1) target = base + 1;
	if (target < base - 1) target = base - 1;
	if (target < 0) target = 0;
	if (target > LUMEN_WORKSPACES - 1) target = LUMEN_WORKSPACES - 1;
	set_current((int)target);
	slide_to(target, 0.8);
}

/* windows came or went: rebuild in place, keeping the slide position */
static void rebuild(void) {
	double t = ov.t;
	teardown();
	build();
	ov.t = t;
	set_windows_hidden(true);
	apply();
}

void overview_views_changed(void) {
	if (!ov.active) return;
	rebuild();
}

void overview_view_updated(struct lumen_view *v) {
	if (!ov.active) return;
	for (int i = 0; i < ov.n; i++)
		if (ov.th[i].v == v) thumb_set_buffer(&ov.th[i]);
}

static int thumb_at(double x, double y) {
	if (fabs(ov.pos - ov.s->ws_current) > 0.05) return -1;   /* mid-slide */
	for (int i = ov.n - 1; i >= 0; i--) {
		if (ov.th[i].ws != ov.s->ws_current) continue;
		struct wlr_box b = ov.th[i].to;
		b.x -= 6; b.y -= 6; b.width += 12; b.height += 40;   /* include the title */
		if (wlr_box_contains_point(&b, x, y)) return i;
	}
	return -1;
}

void overview_motion(double x, double y) {
	if (!ov.active || ov.t < 0.9) return;
	int h = thumb_at(x, y);
	if (h == ov.hovered) return;
	if (ov.hovered >= 0) wlr_scene_node_set_enabled(&ov.th[ov.hovered].hl->node, false);
	if (h >= 0) wlr_scene_node_set_enabled(&ov.th[h].hl->node, true);
	ov.hovered = h;
}

void overview_click(double x, double y) {
	if (!ov.active) return;
	for (int i = 0; i < LUMEN_WORKSPACES; i++)
		if (wlr_box_contains_point(&ov.pills[i].box, x, y)) {
			overview_set_ws(i);
			return;
		}
	int h = thumb_at(x, y);
	overview_close(h >= 0 ? ov.th[h].v : NULL);
}

/* keyboard while open: Esc closes, Enter picks, typing starts a search */
bool overview_key(uint32_t sym) {
	if (!ov.active) return false;
	struct lumen_server *s = ov.s;
	if (sym == XKB_KEY_Escape) { overview_close(NULL); return true; }
	if (sym == XKB_KEY_Return || sym == XKB_KEY_KP_Enter) {
		int h = ov.hovered >= 0 ? ov.hovered : ov.n - 1;
		overview_close(h >= 0 ? ov.th[h].v : NULL);
		return true;
	}
	if (sym == XKB_KEY_Left || sym == XKB_KEY_Right) {
		overview_set_ws(s->ws_current + (sym == XKB_KEY_Right ? 1 : -1));
		return true;
	}
	if ((sym >= XKB_KEY_a && sym <= XKB_KEY_z) || (sym >= XKB_KEY_A && sym <= XKB_KEY_Z) ||
			(sym >= XKB_KEY_0 && sym <= XKB_KEY_9)) {
		/* type-to-search, like GNOME: hand the first letter to the launcher */
		overview_close(NULL);
		char cmd[400];
		if (strstr(s->cfg.launcher, "rofi") || strstr(s->cfg.launcher, "lumen-launcher"))
			snprintf(cmd, sizeof(cmd), "%s -filter '%c'", s->cfg.launcher, (char)sym);
		else
			snprintf(cmd, sizeof(cmd), "%s", s->cfg.launcher);
		spawn(cmd);
		return true;
	}
	return true;   /* swallow everything else while the overview is up */
}
