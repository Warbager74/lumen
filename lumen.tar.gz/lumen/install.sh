#!/usr/bin/env bash
# Lumen installer for Arch Linux (builds from this checkout).
#   ./install.sh            install deps (pacman), build, install to /usr
#   ./install.sh --no-deps  just build + install
#   ./install.sh --greeter  also install greetd + cage and switch the login screen to Lumen
set -euo pipefail
cd "$(dirname "$0")"
c() { printf '\e[1;38;5;111m::\e[0m %s\n' "$*"; }

want_greeter=0; [[ " $* " == *" --greeter "* ]] && want_greeter=1
if [[ " $* " != *" --no-deps "* ]]; then
  c "Installing repo dependencies"
  sudo pacman -S --needed --noconfirm base-devel meson ninja wayland-protocols git \
    wlroots0.20 scenefx xorg-xwayland libxcb xcb-util-wm wayland libinput libxkbcommon pixman cairo pango libdrm glslang \
    gtk4 gtk4-layer-shell python python-gobject rofi papirus-icon-theme inter-font noto-fonts-emoji \
    wireplumber brightnessctl playerctl networkmanager bluez-utils grim slurp wl-clipboard \
    udisks2 gvfs gvfs-mtp polkit ntfs-3g exfatprogs dosfstools \
    libnotify sound-theme-freedesktop gst-plugins-good gst-libav swaylock xdg-desktop-portal-wlr xdg-desktop-portal-gtk pipewire pipewire-pulse kitty fastfetch bash-completion
fi

# X11 apps (Steam, Minecraft launchers, Tk/IDLE …) need Xwayland, even on --no-deps updates
if ! command -v Xwayland >/dev/null 2>&1; then
  c "Installing Xwayland (needed for X11 apps like Steam)"
  sudo pacman -S --needed --noconfirm xorg-xwayland || true
fi

c "Building Lumen"
meson setup build --prefix=/usr --buildtype=release --wipe 2>/dev/null || meson setup build --prefix=/usr --buildtype=release
meson compile -C build
c "Installing (sudo)"
sudo meson install -C build
# precompiled Python: the shell, Settings and Files start faster
sudo python3 -m compileall -q /usr/lib/lumen >/dev/null 2>&1 || true
# refresh the icon cache, otherwise GTK can't see the new Lumen logo
sudo gtk-update-icon-cache -f -t /usr/share/icons/hicolor >/dev/null 2>&1 || true
sudo gtk-update-icon-cache -f -t /usr/share/icons/Lumen >/dev/null 2>&1 || true
sudo gtk-update-icon-cache -f -t /usr/share/icons/Lumen-Light >/dev/null 2>&1 || true

c "Seeding ~/.config/lumen (existing files are kept)"
mkdir -p ~/.config/lumen
for f in lumen.conf shell.json; do
  [[ -e ~/.config/lumen/$f ]] || cp "config/$f" ~/.config/lumen/
done
# power modes (Control Centre / battery menu): power-profiles-daemon, unless
# another power manager (tlp, tuned, auto-cpufreq) is already in charge
other_pm=""
for pm in tlp tuned auto-cpufreq; do pacman -Q "$pm" >/dev/null 2>&1 && other_pm="$pm"; done
if [[ -z "$other_pm" ]]; then
  [[ " $* " == *" --no-deps "* ]] || sudo pacman -S --needed --noconfirm power-profiles-daemon || true
  systemctl is-active power-profiles-daemon >/dev/null 2>&1 || sudo systemctl enable --now power-profiles-daemon 2>/dev/null || true
else
  c "Power modes: $other_pm manages power here, so the Power Saver/Balanced/Performance switch stays off"
fi
# Lumen Files opens folders (from apps, the browser's downloads, Super+E)
sudo rm -f /usr/share/applications/lumen-files.desktop   # renamed to org.lumen.Files.desktop
xdg-mime default org.lumen.Files.desktop inode/directory 2>/dev/null || true
# kitty: translucent glass theme. kitty.conf ends with two includes: Lumen's
# settings (last, so they win: an old "hide_window_decorations yes" would hide
# the window controls), then the colours lumen-theme writes for the accent and
# light mode, which only set colours.
mkdir -p ~/.config/kitty
touch ~/.config/kitty/kitty.conf
[ -e ~/.config/kitty/lumen-colors.conf ] || : > ~/.config/kitty/lumen-colors.conf
if [[ "$(grep -v '^\s*$' ~/.config/kitty/kitty.conf | tail -n2 | tr '\n' '|')" != "include /usr/share/lumen/skel/kitty-glass.conf|include lumen-colors.conf|" ]]; then
  sed -i '/kitty-glass\.conf/d; /lumen-colors\.conf/d' ~/.config/kitty/kitty.conf
  printf '%s\n' "include /usr/share/lumen/skel/kitty-glass.conf" "include lumen-colors.conf" >> ~/.config/kitty/kitty.conf
  c "kitty: Lumen's glass theme and colours are now the last lines of ~/.config/kitty/kitty.conf"
fi
# terminal look from the screenshots: ~/.bashrc and fastfetch (old ones backed up)
stamp=$(date +%Y%m%d-%H%M%S)
mkdir -p ~/.config/fastfetch
for pair in "config/bashrc:$HOME/.bashrc" "config/fastfetch.jsonc:$HOME/.config/fastfetch/config.jsonc"; do
  src=${pair%%:*}; dst=${pair#*:}
  if [[ -e "$dst" ]] && ! cmp -s "$src" "$dst"; then
    if ! grep -q "Lumen" "$dst" 2>/dev/null; then
      cp "$dst" "$dst.pre-lumen-$stamp"
      c "Backed up your old $(basename "$dst") to $dst.pre-lumen-$stamp"
    fi
  fi
  cp "$src" "$dst"
done
c "Shell: Lumen ~/.bashrc + fastfetch installed (your own additions go in ~/.bashrc.local)"
if (( want_greeter )); then
  c "Installing greetd + cage and switching the login screen to Lumen"
  sudo pacman -S --needed --noconfirm greetd cage
  sudo lumen-greeter-setup
  c "Done. Reboot to see the Lumen login screen (undo: sudo lumen-greeter-setup --revert)."
else
  c "Done. Pick “Lumen” in your display manager, or run  start-lumen  from a TTY."
  c "Want the matching login screen?  ./install.sh --no-deps --greeter"
fi
