"""Read/write Lumen's config files without clobbering the user's comments."""
import json
import os
import shutil
import socket
import subprocess

CONFIG_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "lumen")
SKEL_DIRS = ["/usr/share/lumen/skel", "/usr/local/share/lumen/skel",
             os.path.join(os.path.dirname(__file__), "..", "..", "config")]


def _skel(name):
    for d in SKEL_DIRS:
        p = os.path.join(d, name)
        if os.path.exists(p):
            return p
    return None


class LumenConf:
    """~/.config/lumen/lumen.conf — `key = value` lines, comments preserved."""

    def __init__(self, path=None):
        self.path = path or os.path.join(CONFIG_DIR, "lumen.conf")
        if not os.path.exists(self.path):
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            src = _skel("lumen.conf")
            if src:
                shutil.copy(src, self.path)
            else:
                open(self.path, "w").close()
        self.lines = open(self.path).read().splitlines()

    @staticmethod
    def _split(line):
        s = line.strip()
        if not s or s.startswith("#") or "=" not in s:
            return None, None
        k, v = s.split("=", 1)
        v = v.strip()
        # strip a trailing "  # comment" (a leading # is a colour)
        for i in range(1, len(v)):
            if v[i] == "#" and v[i - 1].isspace():
                v = v[:i].strip()
                break
        return k.strip(), v

    def get(self, key, default=None):
        for line in self.lines:
            k, v = self._split(line)
            if k == key:
                return v
        return default

    def get_bool(self, key, default=False):
        v = self.get(key)
        return default if v is None else v.lower() in ("true", "yes", "1", "on")

    def get_num(self, key, default):
        try:
            return type(default)(float(self.get(key)))
        except (TypeError, ValueError):
            return default

    def set(self, key, value):
        if isinstance(value, bool):
            value = "true" if value else "false"
        new = f"{key} = {value}"
        for i, line in enumerate(self.lines):
            k, _ = self._split(line)
            if k == key:
                self.lines[i] = new
                return
        self.lines.append(new)

    def get_list(self, key):
        return [v for k, v in map(self._split, self.lines) if k == key]

    def set_list(self, key, values):
        idx = [i for i, line in enumerate(self.lines) if self._split(line)[0] == key]
        at = idx[0] if idx else len(self.lines)
        for i in reversed(idx):
            del self.lines[i]
        for j, v in enumerate(values):
            self.lines.insert(at + j, f"{key} = {v}")

    def save(self):
        with open(self.path, "w") as f:
            f.write("\n".join(self.lines) + "\n")


def shell_config():
    path = os.path.join(CONFIG_DIR, "shell.json")
    data = {}
    src = _skel("shell.json")
    if src:
        try:
            data.update(json.load(open(src)))
        except (OSError, ValueError):
            pass
    try:
        data.update(json.load(open(path)))
    except (OSError, ValueError):
        pass
    return data


def save_shell_config(changes):
    path = os.path.join(CONFIG_DIR, "shell.json")
    try:
        data = json.load(open(path))
    except (OSError, ValueError):
        data = {}
    data.update(changes)
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def write_accent(accent, accent2):
    """the shell's user stylesheet: accent colours override the built-in ones"""
    path = os.path.join(CONFIG_DIR, "shell.css")
    keep = []
    if os.path.exists(path):
        keep = [l for l in open(path).read().splitlines()
                if not l.startswith("@define-color accent")]
    with open(path, "w") as f:
        f.write(f"@define-color accent {accent};\n@define-color accent2 {accent2};\n")
        f.write("\n".join(keep).strip() + ("\n" if keep else ""))


# ------------------------------------------------------------------ apply
def lumen_socket():
    if os.environ.get("LUMEN_SOCK"):
        return os.environ["LUMEN_SOCK"]
    rt = os.environ.get("XDG_RUNTIME_DIR", "/tmp")
    return f"{rt}/lumen-{os.environ.get('WAYLAND_DISPLAY', 'wayland-0')}.sock"


def compositor_request(cmd, timeout=1.0):
    """send one IPC command, return the reply line ('' if Lumen isn't running)"""
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect(lumen_socket())
            s.sendall((cmd + "\n").encode())
            data = b""
            while not data.endswith(b"\n") and len(data) < 1_000_000:
                chunk = s.recv(65536)
                if not chunk:
                    break
                data += chunk
            return data.decode(errors="replace").strip()
    except OSError:
        return ""


def reload_compositor():
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            s.connect(lumen_socket())
            s.sendall(b"reload\n")
            s.recv(16)
        return True
    except OSError:
        return False


def reload_shell():
    if shutil.which("lumen-shell"):
        subprocess.Popen(["lumen-shell", "--reload"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def run(*cmd, timeout=3):
    if not shutil.which(cmd[0]):
        return ""
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def spawn(cmd):
    subprocess.Popen(["/bin/sh", "-c", cmd], start_new_session=True,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
