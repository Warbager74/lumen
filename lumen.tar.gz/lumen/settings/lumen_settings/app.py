"""Lumen System Settings — one place for Wi-Fi, appearance, glass, taskbar,
keyboard, sound, startup apps, lock/login and system info. Changes apply live:
lumen.conf → compositor reload, shell.json/shell.css → shell reload."""
import glob
import json
import os
import re
import platform
import sys
import subprocess
import threading

# (a fixed GTK theme inherited from the session would pin our menus and entries to
# dark whatever Settings → Appearance says)
if os.environ.get("GTK_THEME", "").startswith("Adwaita"):
    os.environ.pop("GTK_THEME", None)

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, Gio, GLib, Gtk  # noqa: E402

from . import conf as C  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
VERSION = "0.1.0"

ACCENTS = [("Lumen", "#8aa4ff", "#b98cff"), ("Ocean", "#4fa8ff", "#43d6c9"), ("Rose", "#ff7aa8", "#ffb86b"),
           ("Mint", "#5ee0a0", "#43c6ff"), ("Sunset", "#ff8a5c", "#ff5f9e"), ("Graphite", "#c9ced8", "#8e96a8")]
LAYOUTS = ["us", "gb", "ca", "de", "fr", "es", "it", "pt", "br", "se", "no", "dk", "fi", "pl", "ru", "jp", "kr"]


# ------------------------------------------------------------------ widgets
def lbl(text="", cls=None, **kw):
    w = Gtk.Label(label=text, **kw)
    for c in (cls or "").split():
        w.add_css_class(c)
    return w


def vbox(spacing=0, cls=None, *children, **kw):
    b = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=spacing, **kw)
    for c in (cls or "").split():
        b.add_css_class(c)
    for ch in children:
        b.append(ch)
    return b


def hbox(spacing=0, cls=None, *children, **kw):
    b = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=spacing, **kw)
    for c in (cls or "").split():
        b.add_css_class(c)
    for ch in children:
        b.append(ch)
    return b


def group(title=None, *rows):
    g = vbox(0, "group")
    for i, r in enumerate(rows):
        if i:
            g.append(Gtk.Box(css_classes=["row-sep"]))
        g.append(r)
    out = vbox(6, "group-wrap")
    if title:
        out.append(lbl(title, "group-title", xalign=0))
    out.append(g)
    return out


def row(title, sub=None, widget=None, icon_name=None):
    r = hbox(12, "row")
    if icon_name:
        r.append(Gtk.Image.new_from_icon_name(icon_name))
    t = vbox(1, None, lbl(title, "row-title", xalign=0), hexpand=True, valign=Gtk.Align.CENTER)
    if sub:
        t.append(lbl(sub, "row-sub", xalign=0, wrap=True))
    r.append(t)
    if widget is not None:
        widget.set_valign(Gtk.Align.CENTER)
        r.append(widget)
    return r


def switch(active, cb):
    s = Gtk.Switch(active=active)
    s.connect("notify::active", lambda w, _p: cb(w.get_active()))
    return s


def slider(lo, hi, step, value, cb, fmt=None, width=220):
    sc = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, lo, hi, step)
    sc.set_value(value)
    sc.set_size_request(width, -1)
    sc.set_draw_value(fmt is not None)
    if fmt:
        sc.set_value_pos(Gtk.PositionType.RIGHT)
        sc.set_format_value_func(lambda _s, v: fmt(v))
    sc.connect("value-changed", lambda s: cb(s.get_value()))
    return sc


def pill_button(label, cb, cls="pill"):
    b = Gtk.Button(label=label)
    for c_ in cls.split():
        b.add_css_class(c_)
    b.connect("clicked", lambda *_: cb())
    return b


def dropdown(options, selected, cb):
    d = Gtk.DropDown.new_from_strings(options)
    if selected in options:
        d.set_selected(options.index(selected))
    d.connect("notify::selected", lambda w, _p: cb(options[w.get_selected()]))
    return d


# ------------------------------------------------------------------ app
class Settings:
    def __init__(self, app, preview=False):
        self.app, self.preview = app, preview
        self.conf = C.LumenConf()
        self.shell = C.shell_config()
        self._apply_src = None
        self.pages = [
            ("network", "Wi-Fi & Bluetooth", "network-wireless-symbolic", "#3b82f6,#60a5fa",
             self.page_network, "wifi wireless internet bluetooth network"),
            ("appearance", "Appearance", "preferences-desktop-wallpaper-symbolic", "#8b5cf6,#c084fc",
             self.page_appearance, "wallpaper accent color theme icons clock dark"),
            ("widgets", "Desktop Widgets", "view-grid-symbolic", "#10b981,#6ee7b7",
             self.page_widgets, "widgets clock weather calendar system media size position layout"),
            ("notifications", "Notifications", "preferences-system-notifications-symbolic", "#ef4444,#f97316",
             self.page_notifications, "notifications do not disturb dnd quiet hours focus sound popups banners alerts"),
            ("windows", "Windows", "focus-windows-symbolic", "#2563eb,#60a5fa",
             self.page_windows, "tiling autotiling snap layouts gaps controls maximize hyprland"),
            ("glass", "Glass & Motion", "weather-overcast-symbolic", "#06b6d4,#67e8f9",
             self.page_glass, "blur transparency corners shadow animation speed effects"),
            ("taskbar", "Taskbar", "view-app-grid-symbolic", "#64748b,#94a3b8",
             self.page_taskbar, "pinned apps dock taskbar start"),
            ("keyboard", "Keyboard & Mouse", "input-keyboard-symbolic", "#475569,#94a3b8",
             self.page_keyboard, "layout caps repeat scroll touchpad shortcuts keybindings"),
            ("sound", "Sound & Display", "audio-volume-high-symbolic", "#ef4444,#fb7185",
             self.page_sound, "volume brightness night shift display monitor rotate portrait scale resolution"),
            ("startup", "Startup Apps", "system-run-symbolic", "#f59e0b,#fbbf24",
             self.page_startup, "autostart login programs xwayland usb drives automount stick disk"),
            ("lock", "Lock & Login", "system-lock-screen-symbolic", "#334155,#64748b",
             self.page_lock, "lock screen login greeter password"),
            ("about", "About", "help-about-symbolic", "#6b7280,#9ca3af",
             self.page_about, "version system info hardware"),
        ]
        self.build()

    # ---------------------------------------------------------- apply
    def conf_set(self, key, value, list_=False):
        (self.conf.set_list if list_ else self.conf.set)(key, value)
        if self._apply_src:
            GLib.source_remove(self._apply_src)
        self._apply_src = GLib.timeout_add(250, self._flush)

    def reload_shell_soon(self):
        """bars and menus restyle too (the tint colours Lumen's own glass)"""
        if getattr(self, "_shell_src", None):
            GLib.source_remove(self._shell_src)

        def go():
            self._shell_src = None
            if not self.preview:
                C.reload_shell()
            return False
        self._shell_src = GLib.timeout_add(450, go)

    def _flush(self):
        self._apply_src = None
        if not self.preview:
            self.conf.save()
            C.reload_compositor()
        return False

    def shell_set(self, **changes):
        self.shell.update(changes)
        if not self.preview:
            C.save_shell_config(changes)
            C.reload_shell()

    # ---------------------------------------------------------- frame
    def build(self):
        self.win = Gtk.ApplicationWindow(application=self.app, title="System Settings")
        self.win.set_default_size(1000, 680)
        self.win.add_css_class("lumen-settings")
        self.win.set_titlebar(Gtk.Box(visible=False))   # we draw our own (macOS-style) chrome

        # sidebar
        lights = hbox(8, "lights", margin_start=18, margin_top=16, margin_bottom=10)
        for cls, act in (("close", self.win.close), ("min", self.win.minimize),
                         ("zoom", lambda: self.win.unmaximize() if self.win.is_maximized() else self.win.maximize())):
            b = Gtk.Button()
            b.add_css_class("light")
            b.add_css_class(cls)
            b.connect("clicked", lambda _b, a=act: a())
            lights.append(b)
        handle = Gtk.WindowHandle()
        handle.set_child(lights)
        self.search = Gtk.SearchEntry(placeholder_text="Search", margin_start=12, margin_end=12, margin_bottom=8)
        self.search.connect("search-changed", lambda *_: self.filter_sidebar())
        self.list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self.list.add_css_class("navigation")
        self.rows = {}
        for pid, name, icon_name, grad, _b, _kw in self.pages:
            ic = Gtk.Image.new_from_icon_name(icon_name)
            ic.set_halign(Gtk.Align.CENTER)
            ic.set_valign(Gtk.Align.CENTER)
            badge = Gtk.CenterBox(valign=Gtk.Align.CENTER, halign=Gtk.Align.START)
            badge.set_center_widget(ic)
            badge.add_css_class("badge")
            badge.add_css_class(f"badge-{pid}")
            badge.set_size_request(26, 26)
            r = Gtk.ListBoxRow()
            r.set_child(hbox(10, "nav-row", badge, lbl(name, xalign=0)))
            r.pid = pid
            self.list.append(r)
            self.rows[pid] = r
        self.list.connect("row-selected", lambda _l, r: r and self.show(r.pid))
        user = hbox(10, "me", lbl(self.initials(), "avatar"),
                    vbox(0, None, lbl(self.user_name(), "me-name", xalign=0),
                         lbl("Lumen account", "row-sub", xalign=0)), margin_start=12, margin_end=12)
        scroller = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        scroller.set_child(self.list)
        sidebar = vbox(0, "sidebar", handle, user, self.search, scroller)
        sidebar.set_size_request(260, -1)

        # content
        self.title = lbl("", "page-title", xalign=0, hexpand=True)
        head = Gtk.WindowHandle()
        head.set_child(hbox(0, "page-head", self.title))
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.NONE, vexpand=True)
        content = vbox(0, "content", head, self.stack, hexpand=True)
        root = hbox(0, "root", sidebar, content)
        self.win.set_child(root)
        self.root = root
        self.built = {}
        self.list.select_row(self.rows["appearance"])

    def show(self, pid):
        page = next(p for p in self.pages if p[0] == pid)
        changed = self.title.get_label() != page[1]
        self.title.set_label(page[1])
        if pid not in self.built:
            body = vbox(22, "page", margin_start=28, margin_end=28, margin_bottom=28)
            page[4](body)
            sc = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
            sc.set_child(body)
            self.stack.add_named(sc, pid)
            self.built[pid] = sc
        self.stack.set_visible_child_name(pid)
        if changed and not self.preview:
            self.animate_page(pid)

    def animate_page(self, pid):
        """the page's groups rise into place one after another (CSS: .rise).
        Classes go on before the first frame (no flash of the finished page) and
        come off the pages that are now hidden, so every visit plays again."""
        def kids(sc):
            body = sc.get_child().get_child() if isinstance(sc.get_child(), Gtk.Viewport) else sc.get_child()
            ch = body.get_first_child() if body is not None else None
            while ch is not None:
                yield ch
                ch = ch.get_next_sibling()
        for other, sc in self.built.items():
            if other != pid:
                for ch in kids(sc):
                    for c in [c for c in ch.get_css_classes() if c == "rise" or (len(c) == 2 and c[0] == "d")]:
                        ch.remove_css_class(c)
        sc = self.built.get(pid)
        if sc is None:
            return
        for i, ch in enumerate(kids(sc)):
            ch.add_css_class("rise")
            if i:
                ch.add_css_class(f"d{min(i, 6)}")
        # the title: two identical animations, flipped between, restart it every time
        swap = "swap-b" if self.title.has_css_class("swap-a") else "swap-a"
        self.title.remove_css_class("swap-a")
        self.title.remove_css_class("swap-b")
        self.title.add_css_class(swap)

    def refresh_pages(self):
        """drop built pages so the next look shows current values (the window is
        kept between openings so it appears instantly)"""
        for pid, sc in list(self.built.items()):
            self.stack.remove(sc)
            del self.built[pid]

    def filter_sidebar(self):
        q = self.search.get_text().strip().lower()
        for pid, name, _i, _g, _b, kw in self.pages:
            self.rows[pid].set_visible(not q or q in name.lower() or q in kw)

    def user_name(self):
        if self.preview:
            return "You"
        import pwd
        p = pwd.getpwuid(os.getuid())
        return (p.pw_gecos.split(",")[0] or p.pw_name).strip()

    def initials(self):
        return "".join(w[0] for w in self.user_name().split()[:2]).upper() or "?"

    # ---------------------------------------------------------- pages
    def page_network(self, body):
        wifi_on = C.run("nmcli", "radio", "wifi") != "disabled"
        self.nets = vbox(0, "group")
        status = lbl("Scanning…", "row-sub")
        body.append(group(None,
                          row("Wi-Fi", None, switch(wifi_on, lambda on: C.spawn(f"nmcli radio wifi {'on' if on else 'off'}")),
                              "network-wireless-symbolic")))
        body.append(vbox(6, "group-wrap", hbox(8, None, lbl("Networks", "group-title", xalign=0, hexpand=True),
                                                  pill_button("Refresh", lambda: self.scan_wifi(status))), self.nets, status))
        bt_on = "Powered: yes" in C.run("bluetoothctl", "show")
        body.append(group("Bluetooth",
                          row("Bluetooth", None, switch(bt_on, lambda on: C.spawn(f"bluetoothctl power {'on' if on else 'off'}")),
                              "bluetooth-active-symbolic"),
                          row("Devices", "Pair headphones, keyboards and more", pill_button("Open…", lambda: C.spawn(
                              "blueman-manager || overskride || bluetuith")))))
        body.append(group(None, row("Advanced network settings", "VPN, wired, proxies, static IPs",
                                    pill_button("Open…", lambda: C.spawn("nm-connection-editor")))))
        self.scan_wifi(status)

    def scan_wifi(self, status):
        def work():
            out = C.run("nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "dev", "wifi", "list", timeout=8)
            nets, seen = [], set()
            for line in out.splitlines():
                parts = line.replace("\\:", "\x00").split(":")
                if len(parts) < 4 or not parts[1] or parts[1] in seen:
                    continue
                seen.add(parts[1])
                nets.append((parts[0] == "*", parts[1].replace("\x00", ":"), int(parts[2] or 0), parts[3]))
            if self.preview:
                nets = [(True, "Lumen-5G", 92, "WPA2"), (False, "Neighbours", 61, "WPA2"),
                        (False, "CoffeeShop Guest", 38, "")]
            GLib.idle_add(self.fill_wifi, nets, status)
        threading.Thread(target=work, daemon=True).start()

    def fill_wifi(self, nets, status):
        child = self.nets.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.nets.remove(child)
            child = nxt
        status.set_label("" if nets else "No networks found (is NetworkManager running?)")
        for i, (cur, ssid, sig, sec) in enumerate(nets):
            if i:
                self.nets.append(Gtk.Box(css_classes=["row-sep"]))
            q = "excellent" if sig > 75 else "good" if sig > 50 else "ok" if sig > 25 else "weak"
            if cur:
                w = lbl("Connected", "row-sub")
            else:
                w = pill_button("Connect", lambda s=ssid, sec=sec: self.connect_wifi(s, sec))
            r = row(ssid, "Secured" if sec else "Open", w, f"network-wireless-signal-{q}-symbolic")
            self.nets.append(r)
        return False

    def connect_wifi(self, ssid, secured):
        if not secured:
            C.spawn(f"nmcli dev wifi connect '{ssid}'")
            return
        d = Gtk.Window(transient_for=self.win, modal=True, title=f"Join {ssid}")
        d.add_css_class("lumen-settings")
        pw = Gtk.PasswordEntry(show_peek_icon=True, placeholder_text="Password")
        def join():
            C.run("nmcli", "dev", "wifi", "connect", ssid, "password", pw.get_text(), timeout=30)
            d.close()
        pw.connect("activate", lambda *_: join())
        d.set_child(vbox(12, "dialog", lbl(f"Enter the password for “{ssid}”", "row-title"), pw,
                         hbox(8, None, Gtk.Box(hexpand=True), pill_button("Cancel", d.close),
                              pill_button("Join", join, "pill accent"))))
        d.present()

    def page_appearance(self, body):
        # wallpapers
        grid = Gtk.FlowBox(max_children_per_line=4, min_children_per_line=3, selection_mode=Gtk.SelectionMode.NONE,
                           row_spacing=12, column_spacing=12, homogeneous=True)
        walls = []
        bundled = os.path.abspath(os.path.join(HERE, "..", "..", "data", "wallpapers"))
        pats = [bundled + "/*.jpg"] if self.preview else []
        for pat in pats or ("/usr/share/backgrounds/**/*.jpg", "/usr/share/backgrounds/**/*.png",
                    os.path.expanduser("~/Pictures/Wallpapers/*.jpg"), os.path.expanduser("~/Pictures/Wallpapers/*.png"),
                    os.path.expanduser("~/Pictures/Wallpapers/*.mp4"), os.path.expanduser("~/Pictures/Wallpapers/*.webm"),
                    os.path.expanduser("~/Videos/Wallpapers/*.mp4"), os.path.expanduser("~/Videos/Wallpapers/*.webm")):
            # Lumen's own wallpapers first
            walls += glob.glob(pat, recursive=True)
        light = self.conf.get("color_scheme", "dark") == "light"
        # Lumen's own first, and of those the ones made for this mode
        walls.sort(key=lambda p: (0 if "/lumen" in p else 1, ("-light." in p) != light, p))
        cur = self.shell.get("wallpaper", "")
        if self.preview:
            cur = os.path.join(bundled, "lumen-flow.jpg")
        if cur and cur not in walls and os.path.exists(cur):
            walls.insert(0, cur)
        if not walls:
            local = os.path.abspath(os.path.join(HERE, "..", "..", "data", "wallpapers", "lumen-flow.jpg"))
            walls = [local] if os.path.exists(local) else []
        self.wall_tiles = []
        todo = []
        for path in walls[:16]:
            # The tiles fill in from small copies made on a worker thread (and kept
            # in ~/.cache/lumen/thumbs). Decoding sixteen full-size wallpapers
            # here held the page back by a few hundred ms, and kept them all
            # in memory at full size for as long as Settings stayed open.
            pic = Gtk.Picture()
            todo.append((path, pic))
            pic.set_content_fit(Gtk.ContentFit.COVER)
            pic.set_size_request(168, 96)
            tile = Gtk.Button(child=pic)
            tile.add_css_class("wall")
            if path == cur:
                tile.add_css_class("selected")
            tile.lumen_path = path
            tile.connect("clicked", lambda _b, p=path, t=tile: self.pick_wallpaper(p, t))
            grid.append(tile)
            self.wall_tiles.append(tile)
        load_thumbs(todo)
        add = pill_button("Add Picture or Video…", self.choose_wallpaper)
        body.append(vbox(8, "group-wrap", hbox(8, None, lbl("Wallpaper", "group-title", xalign=0, hexpand=True), add),
                         vbox(0, "group pad", grid)))

        # accent
        sw = hbox(14, "swatches")
        current = self.shell.get("accent", ACCENTS[0][1])
        auto = bool(self.shell.get("accent_auto"))
        self.swatch_btns = []
        # Auto: the two colours that stand out in the wallpaper (follows it when it changes)
        ab = Gtk.Button(tooltip_text="Auto: from the wallpaper", child=lbl("A", "sw-auto-label"))
        ab.add_css_class("swatch")
        ab.add_css_class("sw-auto")
        if auto:
            ab.add_css_class("selected")
        ab.connect("clicked", lambda b: self.pick_auto_accent(b))
        sw.append(ab)
        self.swatch_btns.append(ab)
        current = None if auto else current
        for name, a1, a2 in ACCENTS:
            b = Gtk.Button(tooltip_text=name)
            b.add_css_class("swatch")
            b.add_css_class("sw-" + name.lower())
            if a1 == current:
                b.add_css_class("selected")
            b.connect("clicked", lambda _b, a1=a1, a2=a2: self.pick_accent(a1, a2, _b))
            sw.append(b)
            self.swatch_btns.append(b)

        themes = sorted({os.path.basename(d) for base in ("/usr/share/icons", os.path.expanduser("~/.local/share/icons"))
                         for d in glob.glob(base + "/*") if os.path.exists(d + "/index.theme")
                         and not os.path.basename(d).lower().startswith(("default", "hicolor", "locolor"))
                         and "cursor" not in os.path.basename(d).lower()}) or ["Lumen"]
        # (Lumen-Light isn't a choice of its own: it is Lumen in light mode)
        themes = ["Lumen"] + [t for t in themes if t not in ("Lumen", "Lumen-Light")]   # Lumen's own set first
        seg = hbox(0, "segmented")
        light = self.conf.get("color_scheme", "dark") == "light"
        self.scheme_btns = {}
        first = None
        for key, label in (("dark", "Dark"), ("light", "Light")):
            b = Gtk.ToggleButton(label=label, active=(key == "light") == light)
            b.add_css_class("seg")
            if first is None:
                first = b
            else:
                b.set_group(first)
            b.connect("toggled", lambda btn, k=key: btn.get_active() and self.set_color_scheme(k))
            seg.append(b)
            self.scheme_btns[key] = b
        body.append(group("Style",
                          row("Appearance", "Dark or light glass, menus and windows. Apps that follow "
                              "the desktop setting switch with it.", seg),
                          row("Accent colour", "Buttons, highlights and the active-app pill. "
                              "A takes them from the wallpaper.", sw),
                          row("Match apps", "GTK and Qt apps, kitty, foot, ghostty, Firefox (pywalfox), Spotify "
                              "(spicetify) and Vesktop get a theme in these colours",
                              switch(self.shell.get("theme_apps", True), self.set_theme_apps)),
                          row("Icon theme", None, dropdown(themes, self.shell.get("icon_theme", "Lumen"),
                                                           lambda t: self.shell_set(icon_theme=t))),
                          row("24-hour clock", None, switch(self.shell.get("clock_24h", False),
                                                            lambda on: self.shell_set(clock_24h=on)))))


    def pick_wallpaper(self, path, tile):
        for t in self.wall_tiles:
            t.remove_css_class("selected")
        tile.add_css_class("selected")
        self.shell_set(wallpaper=path)
        if self.shell.get("accent_auto"):       # Auto accent: the colours follow the new picture

            def took():
                self.shell = C.shell_config()
                apply_accent(self.shell.get("accent", ACCENTS[0][1]), self.shell.get("accent2", ACCENTS[0][2]))
            self.run_theme(took)

    def choose_wallpaper(self):
        dlg = Gtk.FileDialog(title="Choose a wallpaper")
        f = Gtk.FileFilter()
        f.set_name("Pictures and videos")
        f.add_mime_type("image/*")
        f.add_mime_type("video/mp4")
        f.add_mime_type("video/webm")
        f.add_mime_type("video/x-matroska")
        f.add_mime_type("video/quicktime")
        filters = Gio.ListStore.new(Gtk.FileFilter)
        filters.append(f)
        dlg.set_filters(filters)

        def done(d, res):
            try:
                gf = d.open_finish(res)
            except GLib.Error:
                return
            self.shell_set(wallpaper=gf.get_path())
            if self.shell.get("accent_auto"):       # Auto accent: the colours follow the new picture

                def took():
                    self.shell = C.shell_config()
                    a1, a2 = self.shell.get("accent", ACCENTS[0][1]), self.shell.get("accent2", ACCENTS[0][2])
                    self.conf_set("accent", a1)
                    apply_accent(a1, a2)
                self.run_theme(took)
            self.built.pop("appearance", None)
            old = self.stack.get_child_by_name("appearance")
            if old:
                self.stack.remove(old)
            self.show("appearance")
        dlg.open(self.win, None, done)

    def set_color_scheme(self, scheme):
        """dark ⇄ light: the compositor (window glass, titles), the shell, this
        window and Files (they watch lumen.conf), then the apps (lumen-theme)"""
        if self.conf.get("color_scheme", "dark") == scheme:
            return
        self.conf_set("color_scheme", scheme)
        # Lumen's own wallpapers have a version for each mode: take the matching one
        cur = self.shell.get("wallpaper", "")
        m = re.match(r"^(lumen-(?:flow|dawn|ocean))(-light)?\.jpg$", os.path.basename(cur))
        if m and bool(m.group(2)) != (scheme == "light"):
            other = os.path.join(os.path.dirname(cur), m.group(1) + ("-light" if scheme == "light" else "") + ".jpg")
            if os.path.exists(other):
                self.shell["wallpaper"] = other
                if not self.preview:
                    C.save_shell_config({"wallpaper": other})
                for t in getattr(self, "wall_tiles", []):
                    (t.add_css_class if getattr(t, "lumen_path", None) == other else t.remove_css_class)("selected")
        if not self.preview:
            GLib.timeout_add(400, lambda: (C.reload_shell(), False)[1])
            GLib.timeout_add(700, lambda: (self.run_theme(), False)[1])

    def run_theme(self, then=None):
        """lumen-theme: the Auto accent and the app themes, off the main thread"""
        if self.preview:
            return
        tool = os.path.join(HERE, "..", "..", "bin", "lumen-theme")
        cmd = [tool] if os.path.exists(tool) else ["lumen-theme"]

        def work():
            try:
                subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
            except (OSError, subprocess.SubprocessError):
                pass
            if then:
                GLib.idle_add(lambda: (then(), False)[1])
        threading.Thread(target=work, daemon=True).start()

    def set_theme_apps(self, on):
        self.shell_set(theme_apps=on)
        if on:
            self.run_theme()

    def pick_auto_accent(self, btn):
        for b in self.swatch_btns:
            b.remove_css_class("selected")
        btn.add_css_class("selected")
        self.shell_set(accent_auto=True)

        def took():                      # the tool wrote the colours it found: show them here too
            self.shell = C.shell_config()
            a1, a2 = self.shell.get("accent", ACCENTS[0][1]), self.shell.get("accent2", ACCENTS[0][2])
            self.conf_set("accent", a1)
            apply_accent(a1, a2)
        self.run_theme(took)

    def pick_accent(self, a1, a2, btn):
        for b in self.swatch_btns:
            b.remove_css_class("selected")
        btn.add_css_class("selected")
        self.shell_set(accent=a1, accent2=a2, accent_auto=False)
        GLib.timeout_add(300, lambda: (self.run_theme(), False)[1])
        if not self.preview:
            C.write_accent(a1, a2)
            C.reload_shell()
        self.conf_set("accent", a1)   # the compositor's snap layouts / previews follow it
        apply_accent(a1, a2)

    def glass_style_card(self, style, title, sub):
        """a clickable mini-preview of a glass style"""
        da = Gtk.DrawingArea(content_width=196, content_height=104)

        def draw(_a, cr, w, h):
            import cairo, math
            # a colourful backdrop with stripes, so refraction is visible
            g = cairo.LinearGradient(0, 0, w, h)
            g.add_color_stop_rgb(0, 0.36, 0.30, 0.95)
            g.add_color_stop_rgb(0.55, 0.85, 0.35, 0.75)
            g.add_color_stop_rgb(1, 0.98, 0.62, 0.35)
            cr.set_source(g)
            cr.paint()
            cr.set_source_rgba(1, 1, 1, 0.22)
            for i in range(-4, 14):
                cr.rectangle(i * 18, 0, 6, h)
            cr.fill()
            x, y, pw, ph, r = 30, 22, w - 60, h - 44, 18

            def rr(inset=0):
                cr.new_sub_path()
                a, b, c2, d, rad = x + inset, y + inset, pw - 2 * inset, ph - 2 * inset, r - inset
                cr.arc(a + c2 - rad, b + rad, rad, -math.pi / 2, 0)
                cr.arc(a + c2 - rad, b + d - rad, rad, 0, math.pi / 2)
                cr.arc(a + rad, b + d - rad, rad, math.pi / 2, math.pi)
                cr.arc(a + rad, b + rad, rad, math.pi, 3 * math.pi / 2)
                cr.close_path()
            if style == "frosted":
                rr()
                cr.set_source_rgba(0.95, 0.95, 1, 0.55)
                cr.fill_preserve()
                cr.set_source_rgba(1, 1, 1, 0.6)
                cr.set_line_width(1)
                cr.stroke()
            else:
                # bent stripes in the rim + bright specular edge, clear middle
                cr.save()
                rr()
                cr.clip()
                cr.set_source_rgba(1, 1, 1, 0.10)
                cr.paint()
                cr.set_source_rgba(1, 1, 1, 0.30)
                for i in range(-4, 14):
                    sx = i * 18
                    cr.move_to(sx, y)
                    cr.curve_to(sx + 6, y + 6, sx + 3, y + ph - 6, sx + 9, y + ph)
                    cr.line_to(sx + 15, y + ph)
                    cr.curve_to(sx + 9, y + ph - 6, sx + 12, y + 6, sx + 6, y)
                cr.fill()
                cr.restore()
                lg = cairo.LinearGradient(x, y, x + pw, y + ph)
                lg.add_color_stop_rgba(0, 1, 1, 1, 0.95)
                lg.add_color_stop_rgba(0.45, 1, 1, 1, 0.15)
                lg.add_color_stop_rgba(1, 1, 1, 1, 0.55)
                rr(0.75)
                cr.set_source(lg)
                cr.set_line_width(1.5)
                cr.stroke()
        da.set_draw_func(draw)
        frame = vbox(8, None, da, lbl(title, "row-title", xalign=0), lbl(sub, "row-sub", xalign=0, wrap=True,
                                                                         max_width_chars=26))
        b = Gtk.Button(child=frame, css_classes=["style-card"])
        current = self.conf.get("glass_style", "frosted")
        if current == style:
            b.add_css_class("selected")
        b.connect("clicked", lambda *_: self.set_glass_style(style))
        self.style_cards[style] = b
        return b

    def set_glass_style(self, style):
        for k, b in self.style_cards.items():
            (b.add_css_class if k == style else b.remove_css_class)("selected")
        self.liquid_group.set_sensitive(style == "liquid")
        self.conf_set("glass_style", style)
        if not self.preview:   # the shell swaps its stylesheet after the compositor has the new mode
            GLib.timeout_add(400, lambda: (C.reload_shell(), False)[1])

    # ------------------------------------------------------------ widgets
    W_KINDS = (("clock", "Clock", "preferences-system-time-symbolic"),
               ("weather", "Weather", "weather-few-clouds-symbolic"),
               ("calendar", "Calendar", "x-office-calendar-symbolic"),
               ("system", "System", "utilities-system-monitor-symbolic"),
               ("media", "Now Playing", "audio-x-generic-symbolic"))
    W_SIZES = (("small", "Small", (1, 1)), ("wide", "Wide", (2, 1)), ("tall", "Tall", (1, 2)), ("large", "Large", (2, 2)))
    W_SHOWS = {
        "clock": {"small": "Time and date", "wide": "Day, time and full date", "tall": "Analog clock + time",
                  "large": "Big analog clock + time"},
        "weather": {"small": "Temperature and conditions", "wide": "Now + the next hours",
                    "tall": "Now + the next days", "large": "Hourly and 3-day forecast"},
        "calendar": {"small": "Today", "wide": "Today + this week", "tall": "This month",
                     "large": "This month, roomy"},
        "system": {"small": "CPU ring", "wide": "CPU, memory, disk, battery bars", "tall": "Bars + uptime and load",
                   "large": "Four rings"},
        "media": {"small": "Artwork and play/pause", "wide": "Song, artist and controls",
                  "tall": "Big artwork and controls", "large": "Big artwork and controls"},
    }

    def w_items(self):
        defaults = [{"kind": "clock", "size": "wide"}, {"kind": "weather", "size": "small"},
                    {"kind": "calendar", "size": "small"}, {"kind": "system", "size": "wide"},
                    {"kind": "media", "size": "wide"}]
        out = []
        for w in self.shell.get("widgets", defaults):
            if isinstance(w, str):
                w = next((d for d in defaults if d["kind"] == w), {"kind": w, "size": "small"})
            out.append({"kind": w.get("kind", "clock"), "size": w.get("size", "small")})
        return out

    def w_save(self, items=None, **extra):
        if items is not None:
            extra["widgets"] = items
        self.shell_set(**extra)
        self.w_refresh()

    @staticmethod
    def w_pack(items, cols, sizes):
        taken, out = set(), []
        for it in items:
            w, h = sizes.get(it["size"], (1, 1))
            w = min(w, cols)
            r = 0
            while True:
                spot = next((c for c in range(cols - w + 1)
                             if all((c + dx, r + dy) not in taken for dx in range(w) for dy in range(h))), None)
                if spot is not None:
                    break
                r += 1
            for dx in range(w):
                for dy in range(h):
                    taken.add((spot + dx, r + dy))
            out.append((spot, r, w, h))
        return out

    def page_widgets(self, body):
        # live layout preview: a mini desktop
        self.w_canvas = Gtk.DrawingArea(content_width=560, content_height=315, halign=Gtk.Align.CENTER)
        self.w_canvas.add_css_class("w-canvas")
        self.w_canvas.set_draw_func(self.w_draw)
        body.append(vbox(6, "group-wrap", lbl("Layout", "group-title", xalign=0), self.w_canvas))

        # position + columns
        pos = self.shell.get("widgets_position", "top-right")
        corners = Gtk.Grid(column_spacing=6, row_spacing=6)
        self.w_corner_btns = {}
        for i, (key, glyph) in enumerate((("top-left", "↖"), ("top-right", "↗"), ("bottom-left", "↙"),
                                          ("bottom-right", "↘"))):
            b = Gtk.ToggleButton(label=glyph, active=key == pos)
            b.add_css_class("corner-btn")
            b.connect("toggled", lambda w, k=key: w.get_active() and self.w_set_corner(k))
            self.w_corner_btns[key] = b
            corners.attach(b, i % 2, i // 2, 1, 1)
        cols = dropdown(["2", "3", "4"], str(self.shell.get("widgets_columns", 2)),
                        lambda v: self.w_save(widgets_columns=int(v)))
        body.append(group("Position",
                          row("Corner", "Where the widgets sit on your desktop", corners),
                          row("Columns", "How wide the grid is (in small squares)", cols)))

        # the widgets themselves
        self.w_list = vbox(0, "group")
        add_kind = dropdown([n for _k, n, _i in self.W_KINDS], "Clock", lambda v: None)
        self.w_add_dd = add_kind

        def add():
            name = self.W_KINDS[add_kind.get_selected()][0]
            self.w_save(self.w_items() + [{"kind": name, "size": "small"}])
        body.append(vbox(6, "group-wrap",
                         hbox(8, None, lbl("Widgets", "group-title", xalign=0, hexpand=True), add_kind,
                              pill_button("Add", add)),
                         self.w_list))

        loc = Gtk.Entry(text=self.shell.get("weather_location", ""), placeholder_text="Automatic", width_chars=16)
        loc.connect("activate", lambda e: self.shell_set(weather_location=e.get_text().strip()))
        ef = Gtk.EventControllerFocus()
        ef.connect("leave", lambda *_: self.shell_set(weather_location=loc.get_text().strip()))
        loc.add_controller(ef)
        body.append(group("Weather",
                          row("Location", "City name, or leave empty to detect it", loc),
                          row("Temperature", None, dropdown(
                              ["Celsius", "Fahrenheit"],
                              "Fahrenheit" if self.shell.get("weather_units", "c") == "f" else "Celsius",
                              lambda v: self.shell_set(weather_units="f" if v == "Fahrenheit" else "c")))))
        body.append(lbl("Widgets are glass like the rest of Lumen: they're Frosted or Liquid Glass "
                        "automatically, following Glass & Motion → Glass style.", "row-sub", xalign=0, wrap=True))
        self.w_refresh()

    def w_set_corner(self, key):
        for k, b in self.w_corner_btns.items():
            if k != key and b.get_active():
                b.set_active(False)
        self.w_save(widgets_position=key)

    def w_refresh(self):
        child = self.w_list.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.w_list.remove(child)
            child = nxt
        items = self.w_items()
        names = {k: (n, i) for k, n, i in self.W_KINDS}
        for idx, it in enumerate(items):
            if idx:
                self.w_list.append(Gtk.Box(css_classes=["row-sep"]))
            name, ic = names.get(it["kind"], (it["kind"], "image-missing"))
            seg = hbox(0, "segmented")
            for key, label, _wh in self.W_SIZES:
                b = Gtk.ToggleButton(label=label, active=key == it["size"])
                b.add_css_class("seg")
                b.connect("toggled", lambda w, i=idx, k=key: w.get_active() and self.w_resize(i, k))
                seg.append(b)
            up = Gtk.Button(icon_name="go-up-symbolic", sensitive=idx > 0, tooltip_text="Move up")
            down = Gtk.Button(icon_name="go-down-symbolic", sensitive=idx < len(items) - 1, tooltip_text="Move down")
            rm = Gtk.Button(icon_name="list-remove-symbolic", tooltip_text="Remove")
            for b in (up, down, rm):
                b.add_css_class("flat-icon")
            up.connect("clicked", lambda *_, i=idx: self.w_move(i, -1))
            down.connect("clicked", lambda *_, i=idx: self.w_move(i, 1))
            rm.connect("clicked", lambda *_, i=idx: self.w_remove(i))
            shows = self.W_SHOWS.get(it["kind"], {}).get(it["size"], "")
            r = row(name, shows, hbox(6, None, seg, up, down, rm), icon_name=ic)
            self.w_list.append(r)
        if not items:
            self.w_list.append(row("No widgets", "Pick one above and press Add"))
        if hasattr(self, "w_canvas"):
            self.w_canvas.queue_draw()

    def w_resize(self, i, size):
        items = self.w_items()
        items[i]["size"] = size
        self.w_save(items)

    def w_move(self, i, d):
        items = self.w_items()
        j = i + d
        if 0 <= j < len(items):
            items[i], items[j] = items[j], items[i]
            self.w_save(items)

    def w_remove(self, i):
        items = self.w_items()
        items.pop(i)
        self.w_save(items)

    def w_draw(self, _a, cr, W, H):
        """the desktop in miniature: top bar, taskbar and the packed widget grid"""
        import math
        acc = self.w_canvas.get_color()
        r = 14
        cr.new_sub_path()
        for (x, y, a0) in ((W - r, r, -math.pi / 2), (W - r, H - r, 0), (r, H - r, math.pi / 2), (r, r, math.pi)):
            cr.arc(x, y, r, a0, a0 + math.pi / 2)
        cr.close_path()
        cr.clip()
        import cairo
        g = cairo.LinearGradient(0, 0, W, H)
        g.add_color_stop_rgb(0, 0.20, 0.16, 0.42)
        g.add_color_stop_rgb(0.55, 0.42, 0.24, 0.52)
        g.add_color_stop_rgb(1, 0.80, 0.52, 0.42)
        cr.set_source(g)
        cr.paint()
        sc = W / 1920
        cr.set_source_rgba(1, 1, 1, 0.12)
        cr.rectangle(0, 0, W, 31 * sc)
        cr.fill()
        cr.rectangle(W * 0.3, H - 50 * sc, W * 0.4, 40 * sc)
        cr.fill()
        items = self.w_items()
        cols = int(self.shell.get("widgets_columns", 2))
        pos = self.shell.get("widgets_position", "top-right")
        sizes = {k: wh for k, _l, wh in self.W_SIZES}
        places = self.w_pack(items, cols, sizes)
        cell, gap = 150 * sc, 14 * sc
        full_w = cols * cell + (cols - 1) * gap
        rows = max([rr + hh for _c, rr, _w, hh in places], default=0)
        full_h = rows * (cell + gap) - gap
        ox = W - 22 * sc - full_w if pos.endswith("right") else 22 * sc
        oy = (31 + 14) * sc if pos.startswith("top") else H - (70 + 14) * sc - full_h
        names = {k: n for k, n, _i in self.W_KINDS}
        for it, (c, rr, w, h) in zip(items, places):
            pw, ph = w * cell + (w - 1) * gap, h * cell + (h - 1) * gap
            x = c * (cell + gap)
            if pos.endswith("right"):
                x = full_w - x - pw
            x, y = ox + x, oy + rr * (cell + gap)
            rad = 24 * sc
            cr.new_sub_path()
            for (cx, cy, a0) in ((x + pw - rad, y + rad, -math.pi / 2), (x + pw - rad, y + ph - rad, 0),
                                 (x + rad, y + ph - rad, math.pi / 2), (x + rad, y + rad, math.pi)):
                cr.arc(cx, cy, rad, a0, a0 + math.pi / 2)
            cr.close_path()
            cr.set_source_rgba(1, 1, 1, 0.20)
            cr.fill_preserve()
            cr.set_source_rgba(1, 1, 1, 0.55)
            cr.set_line_width(1)
            cr.stroke()
            cr.set_source_rgba(acc.red, acc.green, acc.blue, 1)
            cr.select_font_face("Inter", 0, 1)
            cr.set_font_size(max(7, 11 * sc * 2.2))
            label = names.get(it["kind"], it["kind"])
            ext = cr.text_extents(label)
            cr.set_source_rgba(1, 1, 1, 0.92)
            cr.move_to(x + (pw - ext.width) / 2 - ext.x_bearing, y + ph / 2 + ext.height / 2)
            cr.show_text(label)

    def page_glass(self, body):
        c = self.conf
        self.style_cards = {}
        liquid_ok = True
        cards = hbox(14, None, self.glass_style_card("frosted", "Frosted", "Soft, heavily blurred panes"))
        if liquid_ok:
            cards.append(self.glass_style_card("liquid", "Liquid Glass",
                                               "Clear, lens-like panes that bend what's behind them, like Apple's"))
        body.append(vbox(6, "group-wrap", lbl("Glass style", "group-title", xalign=0), cards))
        self.liquid_group = group("Liquid Glass",
            row("Edge thickness", "How wide the curved rim of each pane is",
                slider(8, 48, 1, c.get_num("liquid_rim", 28), lambda v: self.conf_set("liquid_rim", int(v)),
                       lambda v: f"{int(v)} px")),
            row("Refraction", "How strongly the background bends",
                slider(0, 3, 0.05, c.get_num("liquid_refraction", 1.0),
                       lambda v: self.conf_set("liquid_refraction", f"{v:.2f}"), lambda v: f"{v:.2f}")),
            row("Frost", "Blur behind menus and windows (bars stay clearer)",
                slider(0, 24, 1, c.get_num("liquid_frost", 10), lambda v: self.conf_set("liquid_frost", int(v)),
                       lambda v: "Clear" if v < 1 else f"{int(v)} px")),
            row("Highlight", "Brightness of the light-catching rim",
                slider(0, 1.5, 0.05, c.get_num("liquid_highlight", 0.9),
                       lambda v: self.conf_set("liquid_highlight", f"{v:.2f}"), lambda v: f"{v:.2f}")))
        self.liquid_group.set_sensitive(c.get("glass_style", "frosted") == "liquid")
        if liquid_ok:
            body.append(self.liquid_group)
        tint = c.get("glass_tint", "#1c1f2a8c").lstrip("#")
        tint_rgb, tint_a = tint[:6], (int(tint[6:8], 16) / 255 if len(tint) >= 8 else 0.55)
        body.append(group("Glass",
            row("Blur strength", "How soft things look through glass",
                slider(1, 12, 1, c.get_num("blur_radius", 6), lambda v: self.conf_set("blur_radius", int(v)),
                       lambda v: f"{int(v)}")),
            row("Blur quality", "More passes = smoother, heavier on the GPU",
                slider(1, 5, 1, c.get_num("blur_passes", 3), lambda v: self.conf_set("blur_passes", int(v)),
                       lambda v: f"{int(v)}")),
            row("Vibrancy", "Colour saturation behind glass",
                slider(1.0, 2.0, 0.05, c.get_num("blur_saturation", 1.35),
                       lambda v: self.conf_set("blur_saturation", f"{v:.2f}"), lambda v: f"{v:.2f}")),
            row("Window tint", "Lower = more see-through",
                slider(0, 100, 1, round(tint_a * 100),
                       lambda v: (self.conf_set("glass_tint", f"#{tint_rgb}{int(v * 2.55):02x}"),
                                  self.reload_shell_soon()),
                       lambda v: f"{int(v)}%"))))
        body.append(group("Shape",
            row("Corner radius", None, slider(0, 24, 1, c.get_num("corner_radius", 14),
                                              lambda v: self.conf_set("corner_radius", int(v)), lambda v: f"{int(v)} px")),
            row("Shadow size", None, slider(0, 40, 1, c.get_num("shadow_sigma", 14),
                                            lambda v: self.conf_set("shadow_sigma", int(v)), lambda v: f"{int(v)}"))))
        # one slider: slow … fast, and all the way right = animations off
        STEPS = [700, 600, 520, 450, 380, 320, 260, 210, 160]          # ms per notch
        def to_pos():
            if not c.get_bool("animations", True):
                return len(STEPS)
            ms = c.get_num("anim_ms", 380)
            return min(range(len(STEPS)), key=lambda i: abs(STEPS[i] - ms))

        def name(v):
            i = int(round(v))
            if i >= len(STEPS):
                return "Off"
            return ["Slowest", "Slower", "Slow", "Relaxed", "Normal", "Brisk", "Fast", "Faster", "Fastest"][i]

        def set_speed(v):
            i = int(round(v))
            if i >= len(STEPS):
                self.conf.set("animations", False)
                self.conf_set("anim_ms", c.get_num("anim_ms", 380))
            else:
                self.conf.set("animations", True)
                self.conf_set("anim_ms", STEPS[i])
        speed = slider(0, len(STEPS), 1, to_pos(), set_speed, name, width=260)
        speed.set_round_digits(0)
        speed.add_mark(4, Gtk.PositionType.BOTTOM, None)            # Normal
        speed.add_mark(len(STEPS), Gtk.PositionType.BOTTOM, None)   # Off
        body.append(group("Motion",
            row("Animation speed", "Windows, desktops, menus and the genie. All the way right turns "
                "animations off.", speed),
            row("Login and log out animation", "The Lumen mark fades into your desktop when you log in, "
                "and the desktop sinks back into it when you leave",
                switch(self.shell.get("startup_animation", True),
                       lambda on: self.shell_set(startup_animation=on)))))
        body.append(group("Performance",
            row("Keep Files and Settings ready", "Opens them instantly; they wait in the background (about 60 MB each)",
                switch(c.get_bool("preload_apps", True), lambda on: self.conf_set("preload_apps", on))),
            row("Performance mode", "For games and battery life: no blur, shadows, animations or moving "
                "wallpaper. Also in the Control Centre.",
                switch(c.get_bool("performance_mode", False), lambda on: self.conf_set("performance_mode", on)))))

    def taskbar_style_card(self, style, title, sub):
        """a clickable mini-desktop showing the taskbar's shape"""
        da = Gtk.DrawingArea(content_width=196, content_height=104)

        def draw(_a, cr, w, h):
            import cairo, math
            g = cairo.LinearGradient(0, 0, w, h)
            g.add_color_stop_rgb(0, 0.20, 0.18, 0.46)
            g.add_color_stop_rgb(0.55, 0.46, 0.30, 0.62)
            g.add_color_stop_rgb(1, 0.80, 0.50, 0.42)
            cr.set_source(g)
            cr.paint()
            cr.set_source_rgba(1, 1, 1, 0.16)          # the top bar
            cr.rectangle(0, 0, w, 7)
            cr.fill()

            def rr(x, y, pw, ph, r):
                cr.new_sub_path()
                cr.arc(x + pw - r, y + r, r, -math.pi / 2, 0)
                cr.arc(x + pw - r, y + ph - r, r, 0, math.pi / 2)
                cr.arc(x + r, y + ph - r, r, math.pi / 2, math.pi)
                cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
                cr.close_path()
            rr(22, 18, w - 76, 50, 5)                    # a window
            cr.set_source_rgba(1, 1, 1, 0.20)
            cr.fill()
            if style == "dock":
                bx, by, bw, bh, r = w / 2 - 54, h - 22, 108, 17, 7
            else:
                bx, by, bw, bh, r = 0, h - 16, w, 16, 0
            rr(bx, by, bw, bh, r) if r else cr.rectangle(bx, by, bw, bh)
            cr.set_source_rgba(0.95, 0.95, 1, 0.42)
            cr.fill_preserve()
            cr.set_source_rgba(1, 1, 1, 0.55)
            cr.set_line_width(1)
            cr.stroke()
            for i, col in enumerate(((0.75, 0.66, 1), (1, 0.62, 0.45), (0.45, 0.72, 1), (0.42, 0.90, 0.72),
                                     (0.62, 0.60, 1), (1, 0.55, 0.72))):
                cr.set_source_rgba(*col, 0.95)
                rr(w / 2 - 45 + i * 15.5, by + (bh - 10) / 2, 10, 10, 3)
                cr.fill()
        da.set_draw_func(draw)
        frame = vbox(8, None, da, lbl(title, "row-title", xalign=0), lbl(sub, "row-sub", xalign=0, wrap=True,
                                                                         max_width_chars=26))
        b = Gtk.Button(child=frame, css_classes=["style-card"])
        if (self.shell.get("taskbar_style") or "dock") == style:
            b.add_css_class("selected")

        def pick(_b):
            for k, w in self.bar_cards.items():
                (w.add_css_class if k == style else w.remove_css_class)("selected")
            self.shell_set(taskbar_style=style)
        b.connect("clicked", pick)
        self.bar_cards[style] = b
        return b

    def page_taskbar(self, body):
        self.bar_cards = {}
        body.append(vbox(6, "group-wrap", lbl("Shape", "group-title", xalign=0),
                         hbox(14, None,
                              self.taskbar_style_card("dock", "Floating dock", "An island that hugs your apps"),
                              self.taskbar_style_card("bar", "Full-width bar", "Edge to edge, like Windows 11"))))
        self.pins_group = vbox(0, "group")
        body.append(vbox(6, "group-wrap", hbox(8, None, lbl("Pinned apps", "group-title", xalign=0, hexpand=True),
                                                  pill_button("Add App…", self.add_pin)), self.pins_group))
        body.append(lbl("Tip: right-click any app on the taskbar to pin or unpin it.", "row-sub", xalign=0))
        body.append(group("Icon style",
            row("Glass tiles", "Seat every app icon on a frosted tile, so icons from different apps match Lumen",
                switch(bool(self.shell.get("icon_tiles", True)), lambda on: self.shell_set(icon_tiles=on)))))
        self.fill_pins()

    def fill_pins(self):
        child = self.pins_group.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.pins_group.remove(child)
            child = nxt
        pins = self.shell.get("pinned", [])
        for i, did in enumerate(pins):
            try:
                ai = Gio.DesktopAppInfo.new(did)
            except TypeError:
                ai = None
            name = ai.get_name() if ai else did.removesuffix(".desktop")
            if ai and ai.get_icon():
                img = Gtk.Image.new_from_gicon(ai.get_icon())
            else:
                theme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default())
                base = did.removesuffix(".desktop")
                img = Gtk.Image.new_from_icon_name(next((n for n in (base, base.lower(), base.split(".")[-1].lower())
                                                         if theme.has_icon(n)), "lumen-app-generic"))
            img.set_pixel_size(30)
            ctl = hbox(4)
            for ic, d in (("go-up-symbolic", -1), ("go-down-symbolic", 1)):
                b = Gtk.Button(icon_name=ic)
                b.add_css_class("icon-btn")
                b.set_sensitive(0 <= i + d < len(pins))
                b.connect("clicked", lambda _b, i=i, d=d: self.move_pin(i, d))
                ctl.append(b)
            rm = Gtk.Button(icon_name="list-remove-symbolic")
            rm.add_css_class("icon-btn")
            rm.connect("clicked", lambda _b, did=did: self.set_pins([p for p in pins if p != did]))
            ctl.append(rm)
            if i:
                self.pins_group.append(Gtk.Box(css_classes=["row-sep"]))
            r = hbox(12, "row", img, lbl(name, "row-title", xalign=0, hexpand=True), ctl)
            self.pins_group.append(r)
        if not pins:
            self.pins_group.append(row("Nothing pinned yet"))

    def set_pins(self, pins):
        self.shell_set(pinned=pins)
        self.fill_pins()

    def move_pin(self, i, d):
        pins = list(self.shell.get("pinned", []))
        pins[i], pins[i + d] = pins[i + d], pins[i]
        self.set_pins(pins)

    def add_pin(self):
        pop = Gtk.Window(transient_for=self.win, modal=True, title="Add App")
        pop.add_css_class("lumen-settings")
        pop.set_default_size(420, 520)
        q = Gtk.SearchEntry(placeholder_text="Search apps")
        lb = Gtk.ListBox()
        lb.add_css_class("navigation")
        apps = sorted((a for a in Gio.AppInfo.get_all() if a.should_show()), key=lambda a: a.get_name().lower())
        for a in apps:
            img = Gtk.Image.new_from_gicon(a.get_icon()) if a.get_icon() else Gtk.Image()
            img.set_pixel_size(24)
            r = Gtk.ListBoxRow()
            r.set_child(hbox(10, "nav-row", img, lbl(a.get_name(), xalign=0)))
            r.app = a
            lb.append(r)
        lb.set_filter_func(lambda r: q.get_text().lower() in r.app.get_name().lower())
        q.connect("search-changed", lambda *_: lb.invalidate_filter())

        def chosen(_l, r):
            pins = [p for p in self.shell.get("pinned", []) if p != r.app.get_id()] + [r.app.get_id()]
            self.set_pins(pins)
            pop.close()
        lb.connect("row-activated", chosen)
        sc = Gtk.ScrolledWindow(vexpand=True)
        sc.set_child(lb)
        pop.set_child(vbox(10, "dialog", q, sc))
        pop.present()

    def page_keyboard(self, body):
        c = self.conf
        layout = c.get("kb_layout", "us")
        opts = [o for o in (c.get("kb_options", "") or "").split(",") if o]

        def set_opt(opt, on):
            nonlocal opts
            opts = [o for o in opts if o != opt] + ([opt] if on else [])
            self.conf_set("kb_options", ",".join(opts))
        body.append(group("Keyboard",
            row("Layout", None, dropdown(sorted(set(LAYOUTS + [layout])), layout, lambda v: self.conf_set("kb_layout", v))),
            row("Caps Lock acts as Escape", None, switch("caps:escape" in opts, lambda on: set_opt("caps:escape", on))),
            row("Key repeat delay", None, slider(150, 800, 10, c.get_num("repeat_delay", 300),
                                                 lambda v: self.conf_set("repeat_delay", int(v)), lambda v: f"{int(v)} ms")),
            row("Key repeat rate", None, slider(10, 60, 1, c.get_num("repeat_rate", 30),
                                                lambda v: self.conf_set("repeat_rate", int(v)), lambda v: f"{int(v)}/s"))))
        body.append(group("Mouse & Touchpad",
            row("Touchpad: natural scrolling", "Content follows your fingers, like a phone",
                switch(c.get_bool("natural_scroll", True), lambda on: self.conf_set("natural_scroll", on))),
            row("Mouse: reverse scroll direction", "Turn on for natural scrolling on a mouse wheel too",
                switch(c.get_bool("mouse_natural_scroll", False),
                       lambda on: self.conf_set("mouse_natural_scroll", on))),
            row("Touchpad gestures", "Swipe up for the overview, sideways to switch desktops",
                switch(c.get_bool("gestures", True), lambda on: self.conf_set("gestures", on))),
            row("Gesture fingers", None, dropdown(["3", "4"], str(c.get_num("gesture_fingers", 3)),
                                                  lambda v: self.conf_set("gesture_fingers", int(v))))))
        body.append(lbl("Gestures: 3 fingers ↑ overview · ↓ close it · ← → switch desktops.   "
                        "4 fingers ↓ show the desktop · ↑ bring windows back · ← → previous / next window.   "
                        "Pinch in with 3 fingers: overview · pinch out: show the desktop.",
                        "row-sub", xalign=0, wrap=True))

        def app_entry(key, default):
            e = Gtk.Entry(text=c.get(key, default) or default, width_chars=22)
            e.connect("changed", lambda w: self.conf_set(key, w.get_text().strip() or default))
            return e
        body.append(group("Shortcut apps",
            row("Terminal", "Super + Q / Super + Return", app_entry("terminal", "kitty")),
            row("Browser", "Super + B", app_entry("browser", "firefox")),
            row("File manager", "Super + E", app_entry("file_manager", 'xdg-open "$HOME"'))))
        keys = [("Tap Super", "Start menu"), ("Super + Space / D", "Spotlight"), ("Super + Tab", "Overview"),
                ("Super + Q", "Terminal"), ("Super + B", "Browser (new window)"), ("Super + E", "Files"),
                ("Super + Esc", "Close window"), ("Super + F", "Maximise"), ("Super + M", "Minimise"),
                ("Super + V", "Clipboard history"), ("Super + Shift + V", "Float / tile window"), ("Super + 1…0", "Desktop 1–10 on this display"),
                ("Super + Shift + 1…0", "Move window to desktop"), ("Super + ← / →", "Previous / next desktop"),
                ("Alt + Tab", "Window switcher (hold Alt)"), ("Super + N", "Notification Centre"), ("Super + C", "Control Centre"), ("Super + L", "Lock"),
                ("Super + Shift + S · Print", "Screenshot (region)"),
                ("Super + S", "Show the desktop (again: bring the windows back)"),
                ("Super + T", "Keep the window on top"), ("Super + .", "Emoji"), ("Super + I", "System Settings"),
                ("Alt + F4", "Close window"), ("Ctrl + Alt + Del", "Log out · restart · shut down"),
                ("Drag window to top edge", "Snap layouts"), ("Hold a dragged window at a side edge", "Move it to the next desktop"), ("Hover the maximise button", "Snap layouts"),
                ("3-finger swipe up / down", "Open / close overview"),
                ("3-finger swipe left / right", "Switch desktop"),
                ("Super + Shift + R", "Reload settings")]
        body.append(group("Shortcuts", *[row(desc, None, lbl(k, "kbd")) for k, desc in keys]))

    def page_sound(self, body):
        vol = C.run("wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@")
        try:
            v = float(vol.split()[1])
        except (IndexError, ValueError):
            v = 0.5
        bri = C.run("brightnessctl", "-m")
        try:
            b = int(bri.split(",")[3].rstrip("%"))
        except (IndexError, ValueError):
            b = 80
        body.append(group("Sound",
            row("Output volume", None, slider(0, 100, 1, v * 100,
                                              lambda x: C.spawn(f"wpctl set-volume @DEFAULT_AUDIO_SINK@ {x / 100:.2f}"),
                                              lambda x: f"{int(x)}%")),
            row("Mute", None, switch("MUTED" in vol, lambda on: C.spawn(f"wpctl set-mute @DEFAULT_AUDIO_SINK@ {int(on)}"))),
            row("Devices & per-app volume", None, pill_button("Open…", lambda: C.spawn("pwvucontrol || pavucontrol")))))
        body.append(group("Display",
            row("Brightness", None, slider(2, 100, 1, b, lambda x: C.spawn(f"brightnessctl set {int(x)}%"),
                                           lambda x: f"{int(x)}%")),
            row("Night Shift", "Warmer colours in the evening (wlsunset)",
                switch(bool(C.run("pgrep", "-x", "wlsunset")),
                       lambda on: C.spawn("wlsunset -t 4000 &" if on else "pkill -x wlsunset"))),
            ))
        self.displays_section(body)

    # ------------------------------------------------------------ displays
    ORIENT = (("Landscape", 0), ("Portrait", 90), ("Landscape (flipped)", 180), ("Portrait (flipped)", 270))
    SCALES = ("1", "1.25", "1.5", "1.75", "2", "2.5", "3")

    def outputs(self):
        import json as _json
        if self.preview:
            return [{"name": "eDP-1", "description": "Built-in display", "width": 2560, "height": 1600,
                     "refresh": 120.0, "scale": 1.5, "transform": 0, "x": 0, "y": 0, "ws": 1,
                     "modes": ["2560x1600@120.00", "2560x1600@60.00", "1920x1200@60.00"]},
                    {"name": "DP-2", "description": "Dell U2723QE", "width": 3840, "height": 2160,
                     "refresh": 60.0, "scale": 1.5, "transform": 90, "x": 1707, "y": -480, "ws": 2,
                     "modes": ["3840x2160@60.00", "2560x1440@60.00", "1920x1080@60.00"]}]
        try:
            return _json.loads(C.compositor_request("outputs") or "{}").get("outputs", [])
        except ValueError:
            return []

    @staticmethod
    def logical(o):
        w, h = o["width"] / o["scale"], o["height"] / o["scale"]
        return (h, w) if o["transform"] in (90, 270) else (w, h)

    def displays_section(self, body):
        import copy
        self.outs = self.outputs()
        if not self.outs:
            body.append(group("Displays", row("No displays found", "Is Lumen running?")))
            return
        self.disp_saved = copy.deepcopy(self.outs)   # what's actually applied
        self.disp_box = vbox(22, None)
        body.append(self.disp_box)
        self.disp_countdown = None
        self.fill_displays()

    def fill_displays(self):
        """(re)build the Displays section from self.outs"""
        child = self.disp_box.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.disp_box.remove(child)
            child = nxt
        self.disp_canvas = Gtk.DrawingArea(content_width=620, content_height=280, halign=Gtk.Align.CENTER)
        self.disp_canvas.add_css_class("w-canvas")
        self.disp_canvas.set_draw_func(self.draw_displays)
        self.disp_drag = None          # (output, start x, start y) while dragging
        self.disp_view = None          # frozen canvas mapping while dragging
        g = Gtk.GestureDrag()
        g.connect("drag-begin", self.disp_drag_begin)
        g.connect("drag-update", self.disp_drag_update)
        g.connect("drag-end", self.disp_drag_end)
        self.disp_canvas.add_controller(g)
        hint = lbl("Drag the screens to arrange them the way they sit on your desk.", "row-sub", xalign=0.5)

        # Apply / Reset, then "Keep these settings?" with a countdown
        self.disp_msg = lbl("You have display changes that aren't applied yet.", "row-sub", xalign=0, hexpand=True,
                            wrap=True)
        self.disp_reset = pill_button("Reset", self.displays_reset)
        self.disp_apply = pill_button("Apply", self.displays_apply, "pill accent")
        self.disp_revert = pill_button("Revert", lambda: self.displays_revert(True))
        self.disp_keep = pill_button("Keep changes", self.displays_keep, "pill accent")
        for w in (self.disp_revert, self.disp_keep):
            w.set_visible(False)
        bar = hbox(10, "disp-bar", self.disp_msg, self.disp_reset, self.disp_apply, self.disp_revert, self.disp_keep)
        self.disp_bar = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN, transition_duration=200)
        self.disp_bar.set_child(bar)
        self.disp_box.append(vbox(6, "group-wrap", lbl("Displays", "group-title", xalign=0),
                                  self.disp_canvas, hint, self.disp_bar))
        for o in self.outs:
            rows = []
            cur_or = next((n for n, d in self.ORIENT if d == o["transform"]), "Landscape")
            rows.append(row("Orientation", "Turn a monitor on its side for portrait",
                            dropdown([n for n, _d in self.ORIENT], cur_or,
                                     lambda v, o=o: self.set_output(o, transform=dict(self.ORIENT)[v]))))
            modes = list(dict.fromkeys(o.get("modes", []))) or [f"{o['width']}x{o['height']}@{o['refresh']:.2f}"]
            cur_mode = f"{o['width']}x{o['height']}@{o['refresh']:.2f}"
            labels = [m.replace("@", " @ ").split(".")[0] + " Hz" for m in modes]
            cur_label = next((l for m, l in zip(modes, labels) if m == cur_mode), labels[0])
            rows.append(row("Resolution", None, dropdown(labels, cur_label,
                                                         lambda v, o=o, mm=modes, ll=labels:
                                                         self.set_output(o, mode=mm[ll.index(v)]))))
            sc = f"{o['scale']:g}"
            rows.append(row("Scale", "Bigger text and controls on high-resolution screens",
                            dropdown(list(self.SCALES), sc if sc in self.SCALES else "1",
                                     lambda v, o=o: self.set_output(o, scale=float(v)))))
            title = f"{o.get('description') or o['name']}  ·  {o['name']}"
            self.disp_box.append(group(title, *rows))
        self.disp_box.append(lbl("Each display shows its own desktop (Super+1…0). Press Apply to try changes: "
                                 "they go back by themselves after 15 seconds unless you keep them.",
                                 "row-sub", xalign=0, wrap=True))
        self.displays_sync_bar()

    # ------------------------------------------------ apply / keep / revert
    def displays_changed(self):
        strip = lambda outs: [self.output_line(o) for o in outs]
        return strip(self.outs) != strip(self.disp_saved)

    def displays_sync_bar(self):
        trying = self.disp_countdown is not None
        changed = self.displays_changed()
        for w in (self.disp_reset, self.disp_apply):
            w.set_visible(not trying)
        for w in (self.disp_revert, self.disp_keep):
            w.set_visible(trying)
        if not trying:
            self.disp_msg.set_label("You have display changes that aren't applied yet.")
        self.disp_bar.set_reveal_child(trying or changed)

    def displays_apply(self):
        self.normalize()
        lines = [self.output_line(o) for o in self.outs]
        if not self.preview:
            C.compositor_request("outputs-try 15 " + ";".join(lines))
        self.disp_left = 15
        self.disp_msg.set_label("Keep these display settings? Going back in 15 s…")
        self.disp_countdown = GLib.timeout_add(1000, self.displays_tick)   # precise: it is on screen
        self.displays_sync_bar()
        self.disp_canvas.queue_draw()

    def displays_tick(self):
        self.disp_left -= 1
        if self.disp_left <= 0:
            self.disp_countdown = None
            self.displays_revert(False)
            return False
        self.disp_msg.set_label(f"Keep these display settings? Going back in {self.disp_left} s…")
        return True

    def displays_keep(self):
        import copy
        if self.disp_countdown:
            GLib.source_remove(self.disp_countdown)
            self.disp_countdown = None
        lines = [self.output_line(o) for o in self.outs]
        names = {o["name"] for o in self.outs}
        keep = [l for l in self.conf.get_list("output") if l.split()[0] not in names]
        self.conf.set_list("output", keep + lines)
        if not self.preview:
            C.compositor_request("outputs-keep")
            self.conf.save()
        self.disp_saved = copy.deepcopy(self.outs)
        self.displays_sync_bar()

    def displays_revert(self, now):
        """back to the last kept layout (the compositor does it too, on its own clock)"""
        import copy
        if self.disp_countdown:
            GLib.source_remove(self.disp_countdown)
            self.disp_countdown = None
        if not self.preview:
            C.compositor_request("outputs-revert")
        self.outs = copy.deepcopy(self.disp_saved)
        self.fill_displays()

    def displays_reset(self):
        import copy
        self.outs = copy.deepcopy(self.disp_saved)
        self.fill_displays()

    # -------------------------------------------------- arrangement maths
    def box_of(self, o):
        w, h = self.logical(o)
        return [float(o["x"]), float(o["y"]), w, h]

    @staticmethod
    def _overlap(a, b):
        return a[0] < b[0] + b[2] - 0.5 and b[0] < a[0] + a[2] - 0.5 and \
            a[1] < b[1] + b[3] - 0.5 and b[1] < a[1] + a[3] - 0.5

    def snap_box(self, o, x, y):
        """put `o` at (x, y), then glue it to the nearest edge of another screen
        (touching, never overlapping), lining edges up when they're close"""
        w, h = self.logical(o)
        others = [self.box_of(t) for t in self.outs if t is not o]
        if not others:
            return 0.0, 0.0
        best = None
        for bx, by, bw, bh in others:
            cands = [(bx - w, y), (bx + bw, y), (x, by - h), (x, by + bh)]
            for cx, cy in cands:
                # keep it actually touching that side
                if cx in (bx - w, bx + bw):
                    cy = min(max(cy, by - h + 40), by + bh - 40)
                else:
                    cx = min(max(cx, bx - w + 40), bx + bw - 40)
                d = (cx - x) ** 2 + (cy - y) ** 2
                if best is None or d < best[0]:
                    best = (d, cx, cy)
        _, x, y = best
        # line up with a neighbour's edges when within 6% of a screen
        tol = 0.06 * max(w, h)
        for bx, by, bw, bh in others:
            for ex in (bx, bx + bw - w):
                if abs(x - ex) < tol and (abs(y + h - by) < 1 or abs(y - by - bh) < 1):
                    x = ex
            for ey in (by, by + bh - h, by + (bh - h) / 2):
                if abs(y - ey) < tol and (abs(x + w - bx) < 1 or abs(x - bx - bw) < 1):
                    y = ey
        # still overlapping something: slide right until clear
        mine = [x, y, w, h]
        for _ in range(16):
            hit = next((b for b in others if self._overlap(mine, b)), None)
            if not hit:
                break
            mine[0] = hit[0] + hit[2]
        return mine[0], mine[1]

    def normalize(self):
        """top-left screen at 0,0; whole pixels"""
        x0 = min(o["x"] for o in self.outs)
        y0 = min(o["y"] for o in self.outs)
        for o in self.outs:
            o["x"], o["y"] = int(round(o["x"] - x0)), int(round(o["y"] - y0))

    def repack(self, o, old_w, old_h):
        """`o` changed size (rotated / rescaled / new resolution): screens that were
        to its right or below it move with its edge, so nothing overlaps or gaps"""
        w, h = self.logical(o)
        dw, dh = w - old_w, h - old_h
        right_edge, bottom_edge = o["x"] + old_w, o["y"] + old_h
        for t in self.outs:
            if t is o:
                continue
            if t["x"] >= right_edge - 1:
                t["x"] += dw
            elif t["y"] >= bottom_edge - 1:
                t["y"] += dh
        for t in self.outs:           # anything still overlapping gets re-glued
            if t is not o and self._overlap(self.box_of(t), self.box_of(o)):
                t["x"], t["y"] = self.snap_box(t, t["x"], t["y"])

    def output_line(self, o):
        return (f"{o['name']} mode={o['width']}x{o['height']}@{o['refresh']:.2f} scale={o['scale']:g} "
                f"transform={o['transform']} pos={o['x']},{o['y']}")

    def apply_outputs(self):
        """changes are staged: redraw, and offer Apply / Reset"""
        self.normalize()
        self.disp_canvas.queue_draw()
        self.displays_sync_bar()

    def set_output(self, o, mode=None, scale=None, transform=None, pos=None):
        old_w, old_h = self.logical(o)
        if mode:
            w, rest = mode.split("x")
            h, r = rest.split("@")
            o["width"], o["height"], o["refresh"] = int(w), int(h), float(r)
        if scale:
            o["scale"] = scale
        if transform is not None:
            o["transform"] = transform
        if pos:
            o["x"], o["y"] = pos
        if (old_w, old_h) != self.logical(o):
            self.repack(o, old_w, old_h)
        self.apply_outputs()

    # ------------------------------------------------------ canvas + drag
    def disp_mapping(self, W, H):
        boxes = [self.box_of(o) for o in self.outs]
        x0 = min(b[0] for b in boxes); y0 = min(b[1] for b in boxes)
        x1 = max(b[0] + b[2] for b in boxes); y1 = max(b[1] + b[3] for b in boxes)
        # room around the screens so one can be dragged to any side
        pad_x, pad_y = (x1 - x0) * 0.12 + 60, (y1 - y0) * 0.12 + 60
        x0 -= pad_x; x1 += pad_x; y0 -= pad_y; y1 += pad_y
        k = min(W / max(1, x1 - x0), H / max(1, y1 - y0))
        ox = (W - (x1 - x0) * k) / 2 - x0 * k
        oy = (H - (y1 - y0) * k) / 2 - y0 * k
        return k, ox, oy

    def disp_hit(self, px, py):
        k, ox, oy = self.disp_view or self.disp_mapping(self.disp_canvas.get_width(), self.disp_canvas.get_height())
        for o in reversed(self.outs):
            x, y, w, h = self.box_of(o)
            if ox + x * k <= px <= ox + (x + w) * k and oy + y * k <= py <= oy + (y + h) * k:
                return o
        return None

    def disp_drag_begin(self, _g, px, py):
        if len(self.outs) < 2:
            return
        self.disp_view = self.disp_mapping(self.disp_canvas.get_width(), self.disp_canvas.get_height())
        o = self.disp_hit(px, py)
        self.disp_drag = (o, o["x"], o["y"]) if o else None
        if not o:
            self.disp_view = None

    def disp_drag_update(self, _g, dx, dy):
        if not self.disp_drag:
            return
        o, sx, sy = self.disp_drag
        k = self.disp_view[0]
        o["x"], o["y"] = sx + dx / k, sy + dy / k
        self.disp_canvas.queue_draw()

    def disp_drag_end(self, _g, dx, dy):
        if not self.disp_drag:
            return
        o, sx, sy = self.disp_drag
        k = self.disp_view[0]
        o["x"], o["y"] = self.snap_box(o, sx + dx / k, sy + dy / k)
        self.disp_drag = None
        self.disp_view = None
        self.apply_outputs()

    def draw_displays(self, _a, cr, W, H):
        """the monitors as they're arranged (rotation and scale included)"""
        import math
        k, ox, oy = self.disp_view or self.disp_mapping(W, H)
        acc = self.disp_canvas.get_color()
        dragging = self.disp_drag[0] if self.disp_drag else None
        order = [o for o in self.outs if o is not dragging] + ([dragging] if dragging else [])
        for o in order:
            x, y, w, h = self.box_of(o)
            rx, ry, rw, rh = ox + x * k + 2, oy + y * k + 2, w * k - 4, h * k - 4
            r = 9
            cr.new_sub_path()
            for (cx, cy, a0) in ((rx + rw - r, ry + r, -math.pi / 2), (rx + rw - r, ry + rh - r, 0),
                                 (rx + r, ry + rh - r, math.pi / 2), (rx + r, ry + r, math.pi)):
                cr.arc(cx, cy, r, a0, a0 + math.pi / 2)
            cr.close_path()
            cr.set_source_rgba(acc.red, acc.green, acc.blue, 0.42 if o is dragging else 0.26)
            cr.fill_preserve()
            cr.set_source_rgba(acc.red, acc.green, acc.blue, 0.95)
            cr.set_line_width(2 if o is dragging else 1.5)
            cr.stroke()
            cr.set_source_rgba(1, 1, 1, 0.95)
            cr.select_font_face("Inter", 0, 1)
            cr.set_font_size(12.5)
            lines = (o["name"], f"Desktop {o.get('ws', 1)}",
                     "Portrait" if o["transform"] in (90, 270) else "")
            for i, t in enumerate([t for t in lines if t]):
                e = cr.text_extents(t)
                cr.move_to(rx + (rw - e.width) / 2 - e.x_bearing, ry + rh / 2 - 10 + i * 17)
                cr.show_text(t)

    # ------------------------------------------------------------ windows
    def page_notifications(self, body):
        def app_icon_name(n):
            """the icon an app's notifications carry, or its .desktop icon"""
            ic = n.get("app_icon") or ""
            if ic and not ic.startswith(("/", "file://")):
                return ic
            for did in filter(None, [n.get("desktop_entry"), (n.get("app_name") or "").lower()]):
                try:
                    ai = Gio.DesktopAppInfo.new(did if did.endswith(".desktop") else did + ".desktop")
                except TypeError:
                    ai = None
                if ai and ai.get_icon():
                    return ai.get_icon().to_string()
            name = (n.get("app_name") or "").lower().replace(" ", "-")
            theme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default())
            return name if name and theme.has_icon(name) else None

        sh = self.shell
        sch = dict({"on": False, "from": "22:00", "to": "07:00"}, **(sh.get("dnd_schedule") or {}))
        times = [f"{h:02d}:{m:02d}" for h in range(24) for m in (0, 30)]

        def set_sch(**kw):
            sch.update(kw)
            self.shell_set(dnd_schedule=dict(sch))
        body.append(group("Do Not Disturb",
            row("Do Not Disturb", "Notifications still arrive in the Notification Centre, just without "
                "pop-ups or sounds. Urgent ones still show.",
                switch(bool(sh.get("dnd", False)), lambda on: self.shell_set(dnd=on))),
            row("Quiet hours", "Turn on Do Not Disturb automatically every day",
                switch(bool(sch["on"]), lambda on: set_sch(on=on))),
            row("From", None, dropdown(times, sch["from"], lambda v: set_sch(**{"from": v}))),
            row("Until", None, dropdown(times, sch["to"], lambda v: set_sch(to=v)))))
        body.append(group("Pop-ups",
            row("Play a sound", "A soft chime when a notification pops up",
                switch(bool(sh.get("notify_sound", True)), lambda on: self.shell_set(notify_sound=on))),
            row("Show for", "How long a pop-up stays before it moves to the Notification Centre",
                slider(3, 20, 1, float(sh.get("notify_timeout", 6)), lambda v: self.shell_set(notify_timeout=int(v)),
                       lambda v: f"{int(v)} s")),
            row("Try it", "Send a test notification",
                pill_button("Send", lambda: C.spawn("notify-send -a Lumen -i preferences-system-notifications "
                                                    "'Hello from Lumen' 'This is what notifications look like.'")))))
        rules = dict(sh.get("notify_apps") or {})
        apps = list(rules)
        icons = {}
        try:
            hist = os.path.join(os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache")),
                                "lumen", "notifications.json")
            for n in json.load(open(hist)).get("items", []):
                if n.get("app_name") and n["app_name"] not in apps:
                    apps.append(n["app_name"])
                if n.get("app_name") and n["app_name"] not in icons:
                    icons[n["app_name"]] = app_icon_name(n)
        except (OSError, ValueError, AttributeError):
            pass
        if self.preview and not apps:
            apps = ["Firefox", "Discord", "Spotify", "Lumen"]

        def set_rule(app, key, on):
            r = dict({"enabled": True, "popups": True, "sound": True}, **rules.get(app, {}))
            r[key] = on
            rules[app] = r
            self.shell_set(notify_apps=dict(rules))
            if key == "enabled":
                for w in sub_widgets.get(app, ()):
                    w.set_sensitive(on)
        sub_widgets = {}
        rows = []
        for app in sorted(apps, key=str.lower):
            r = dict({"enabled": True, "popups": True, "sound": True}, **rules.get(app, {}))
            pop = Gtk.CheckButton(label="Pop-ups", active=r["popups"])
            pop.connect("toggled", lambda b, a=app: set_rule(a, "popups", b.get_active()))
            snd = Gtk.CheckButton(label="Sound", active=r["sound"])
            snd.connect("toggled", lambda b, a=app: set_rule(a, "sound", b.get_active()))
            for w in (pop, snd):
                w.set_sensitive(r["enabled"])
            sub_widgets[app] = (pop, snd)
            sw = switch(r["enabled"], lambda on, a=app: set_rule(a, "enabled", on))
            ic = icons.get(app) or app_icon_name({"app_name": app})
            rows.append(row(app, None, hbox(14, None, pop, snd, sw), ic or "application-x-executable-symbolic"))
        if rows:
            body.append(group("Apps", *rows))
        else:
            body.append(group("Apps", row("No apps yet", "Apps show up here after they send a notification")))
        body.append(lbl("Super+N opens the Notification Centre (or click the bell in the top bar). "
                        "Hover a pop-up to keep it; click it to open what it's about.", "row-sub", xalign=0, wrap=True))

    def page_windows(self, body):
        c = self.conf
        body.append(group("Arrangement",
            row("Focus follows mouse", "The window under the pointer gets the keyboard (without coming to the front)",
                switch(c.get_bool("focus_follows_mouse", True),
                       lambda on: self.conf_set("focus_follows_mouse", on))),
            row("Autotiling", "Hyprland-style: new windows split the screen automatically. Super+Shift+V floats one.",
                switch(c.get_bool("tiling", False), lambda on: self.conf_set("tiling", on))),
            row("Snap layouts", "Drag a window to the top of the screen, or hover its maximise button",
                switch(c.get_bool("snapping", True), lambda on: self.conf_set("snapping", on))),
            row("Gaps", "Space between tiled and snapped windows",
                slider(0, 32, 1, c.get_num("gaps", 10), lambda v: self.conf_set("gaps", int(v)),
                       lambda v: f"{int(v)} px"))))
        body.append(group("Window controls",
            row("Position", "Windows-style on the right, or macOS-style on the left",
                dropdown(["Right (Windows)", "Left (macOS)"],
                         "Left (macOS)" if c.get("controls_side", "left") == "left" else "Right (Windows)",
                         lambda v: self.conf_set("controls_side", "left" if v.startswith("Left") else "right")))))
        body.append(lbl("Shortcuts: Super+Shift+V float/tile · drag a window onto another to swap them while tiling · "
                        "drag to a screen edge for half, a corner for a quarter.", "row-sub", xalign=0, wrap=True))

    def page_startup(self, body):
        self.auto_group = vbox(0, "group")
        add_entry = Gtk.Entry(placeholder_text="Command, e.g. nm-applet --indicator", hexpand=True)
        add_entry.connect("activate", lambda e: self.add_autostart(e))
        body.append(vbox(6, "group-wrap", lbl("Open at login", "group-title", xalign=0), self.auto_group,
                         hbox(8, "add-row", add_entry, pill_button("Add", lambda: self.add_autostart(add_entry)))))
        body.append(group("Compatibility",
            row("X11 apps (Xwayland)", "Steam, Discord and older apps. Takes effect at next login.",
                switch(self.conf.get_bool("xwayland", True), lambda on: self.conf_set("xwayland", on)))))
        body.append(group("Drives",
            row("Open USB drives when they are plugged in",
                "Sticks, disks, cards and phones are mounted and announced. Off: they wait in the Files sidebar.",
                switch(self.shell.get("automount", True), lambda on: self.shell_set(automount=on)))))
        self.fill_autostart()

    def fill_autostart(self):
        child = self.auto_group.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.auto_group.remove(child)
            child = nxt
        items = self.conf.get_list("autostart")
        for i, cmd in enumerate(items):
            rm = Gtk.Button(icon_name="list-remove-symbolic")
            rm.add_css_class("icon-btn")
            rm.connect("clicked", lambda _b, i=i: self.set_autostart(items[:i] + items[i + 1:]))
            if i:
                self.auto_group.append(Gtk.Box(css_classes=["row-sep"]))
            self.auto_group.append(row(cmd.split()[0].split("/")[-1], cmd, rm, "system-run-symbolic"))
        if not items:
            self.auto_group.append(row("Defaults", "lumen-shell (bars, menus and notifications) starts automatically"))

    def set_autostart(self, items):
        self.conf_set("autostart", items, list_=True)
        self.fill_autostart()

    def add_autostart(self, entry):
        cmd = entry.get_text().strip()
        if cmd:
            items = self.conf.get_list("autostart")
            if not items:   # first custom entry: keep the essentials Lumen would have started
                items = ["lumen-shell"]
            self.set_autostart(items + [cmd])
            entry.set_text("")

    def page_lock(self, body):
        body.append(group("Lock screen",
            row("Lock now", "Super + L", pill_button("Lock", lambda: C.spawn("lumen-lock"))),
            row("Lock after inactivity", "Uses swayidle", dropdown(["Never", "5 minutes", "10 minutes", "30 minutes"],
                self.shell.get("idle_lock", "Never"), self.set_idle))))
        enabled = os.path.islink("/etc/systemd/system/display-manager.service") and \
            "greetd" in os.readlink("/etc/systemd/system/display-manager.service")
        body.append(group("Login screen",
            row("Lumen login screen", "Enabled" if enabled else "Not active: run  sudo lumen-greeter-setup",
                lbl("On" if enabled else "Off", "row-sub")),
            row("Use my wallpaper on the login screen", "Asks for your password",
                pill_button("Apply", self.greeter_wallpaper)),
            row("Preview the login screen", "Opens a safe demo (password: lumen)",
                pill_button("Preview", lambda: C.spawn("lumen-greeter --demo")))))

    def set_idle(self, choice):
        self.shell_set(idle_lock=choice)
        mins = {"5 minutes": 5, "10 minutes": 10, "30 minutes": 30}.get(choice)
        C.spawn("pkill -x swayidle")
        items = [a for a in self.conf.get_list("autostart") if not a.startswith("swayidle")]
        if mins:
            cmd = f"swayidle -w timeout {mins * 60} lumen-lock before-sleep lumen-lock"
            C.spawn(cmd)
            items = (items or ["lumen-shell"]) + [cmd]
        self.conf_set("autostart", items, list_=True)

    def greeter_wallpaper(self):
        wall = self.shell.get("wallpaper", "/usr/share/backgrounds/lumen/lumen-flow.jpg")
        script = ("import json,os;p='/etc/lumen/greeter.json';os.makedirs('/etc/lumen',exist_ok=True);"
                  "d=json.load(open(p)) if os.path.exists(p) else {};"
                  f"d['wallpaper']={wall!r};json.dump(d,open(p,'w'),indent=2)")
        C.spawn(f"pkexec python3 -c {GLib.shell_quote(script)}")

    def page_about(self, body):
        osname = "Linux"
        try:
            for line in open("/etc/os-release"):
                if line.startswith("PRETTY_NAME="):
                    osname = line.split("=", 1)[1].strip().strip('"')
        except OSError:
            pass
        cpu = next((l.split(":", 1)[1].strip() for l in open("/proc/cpuinfo") if l.startswith("model name")), "Unknown")
        mem = next((int(l.split()[1]) for l in open("/proc/meminfo") if l.startswith("MemTotal")), 0) / 1048576
        gpu = next((l.split(": ", 1)[-1] for l in C.run("lspci").splitlines()
                    if " VGA " in l or "3D controller" in l), "Unknown")
        logo = Gtk.Image.new_from_icon_name("lumen-logo")
        for d in ("/usr/share", "/usr/local/share", os.path.join(os.path.dirname(__file__), "..", "..", "data")):
            p = os.path.join(d, "icons/hicolor/scalable/apps/lumen-logo.svg")
            if os.path.isfile(p):
                logo = Gtk.Image.new_from_file(p)
                break
        logo.set_pixel_size(88)
        hero = vbox(6, "hero", logo, lbl("Lumen", "hero-title"), lbl(f"Version {VERSION}", "row-sub"))
        body.append(hero)
        body.append(group(None,
            row("Computer name", None, lbl(platform.node(), "row-sub")),
            row("Operating system", None, lbl(osname, "row-sub")),
            row("Kernel", None, lbl(platform.release(), "row-sub")),
            row("Processor", None, lbl(cpu, "row-sub", ellipsize=3, max_width_chars=40)),
            row("Memory", None, lbl(f"{mem:.1f} GB", "row-sub")),
            row("Graphics", None, lbl(gpu, "row-sub", ellipsize=3, max_width_chars=40))))


# ------------------------------------------------------------------ styling
_accent = Gtk.CssProvider()


def apply_accent(a1, a2):
    css = f"@define-color accent {a1}; @define-color accent2 {a2};"
    if hasattr(_accent, "load_from_string"):
        _accent.load_from_string(css)
    else:
        _accent.load_from_data(css.encode(), -1)


# ------------------------------------------------------------ window corners
# This app draws its own window, so its corners have to agree with what the
# compositor draws around and behind it (shadow cut-out, frost, the Liquid Glass
# lens): the same radius as Settings → Glass & Motion → Corner radius, and none
# at all when the window is maximised or fullscreen. Otherwise the glass shows
# as a little square poking out past a rounder corner.
_corners = {"prov": None, "mon": None, "src": 0}


def corner_radius():
    r = 14
    for path in (os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "lumen", "lumen.conf"),
                 "/etc/lumen/lumen.conf"):
        try:
            with open(path) as f:
                for line in f:
                    k, eq, v = line.partition("=")
                    if eq and k.strip() == "corner_radius":
                        r = int(float(v.split("#")[0].strip()))
            break
        except (OSError, ValueError):
            continue
    return max(0, min(24, r))


VIDEO_EXT = (".mp4", ".webm", ".mkv", ".mov", ".m4v", ".avi", ".gif")


def thumb_of(path):
    """a small copy of a wallpaper (a still, for a video) in ~/.cache/lumen/thumbs;
    made once per file. Runs on a worker thread. None: show the file itself."""
    import hashlib
    try:
        st = os.stat(path)
    except OSError:
        return None
    if path.lower().endswith(VIDEO_EXT):
        tool = os.path.join(HERE, "..", "..", "bin", "lumen-theme")
        try:
            got = subprocess.run([tool if os.path.exists(tool) else "lumen-theme", "--thumb", path],
                                 capture_output=True, text=True, timeout=40).stdout.strip()
        except (OSError, subprocess.SubprocessError):
            got = ""
        return got if got and os.path.exists(got) else None
    d = os.path.join(os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"), "lumen", "thumbs")
    key = hashlib.sha1(f"{os.path.abspath(path)}:{st.st_mtime_ns}:{st.st_size}".encode()).hexdigest()[:24]
    out = os.path.join(d, key + ".jpg")
    if os.path.exists(out) and os.path.getsize(out) > 0:
        return out
    try:
        gi.require_version("GdkPixbuf", "2.0")
        from gi.repository import GdkPixbuf
        os.makedirs(d, exist_ok=True)
        pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, 512, 512, True)
        if pb.get_has_alpha():
            return None                      # (keeps its transparency: shown as it is)
        tmp = out + f".{os.getpid()}.part"
        pb.savev(tmp, "jpeg", ["quality"], ["86"])
        os.replace(tmp, out)
        return out
    except Exception:   # noqa: BLE001 — an unreadable picture just shows nothing
        return None


def load_thumbs(todo):
    """fill wallpaper tiles in the background: [(file, Gtk.Picture)]"""
    def work():
        for path, pic in todo:
            small = thumb_of(path)
            try:
                tex = Gdk.Texture.new_from_filename(small or path) if (small or not path.lower().endswith(VIDEO_EXT)) else None
            except GLib.Error:
                tex = None

            def show(pic=pic, tex=tex, path=path):
                if tex is not None:
                    pic.set_paintable(tex)
                elif path.lower().endswith(VIDEO_EXT):     # no tool for stills here: the video itself
                    media = Gtk.MediaFile.new_for_filename(path)
                    media.set_muted(True)
                    pic.set_paintable(media)
                return False
            GLib.idle_add(show)
    threading.Thread(target=work, daemon=True).start()


_look = {"prov": None, "light": None}


def light_mode():
    """Settings → Appearance → Light (lumen.conf: color_scheme = light)"""
    v = "dark"
    for path in (os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "lumen", "lumen.conf"),
                 "/etc/lumen/lumen.conf"):
        try:
            with open(path) as f:
                for line in f:
                    k, eq, val = line.partition("=")
                    if eq and k.strip() == "color_scheme":
                        v = val.split("#")[0].strip().lower()
            break
        except OSError:
            continue
    return (os.environ.get("LUMEN_SCHEME") or v) == "light"


def apply_icons():
    """the chosen icon theme; in light mode its light version (follows the mode live)"""
    st = Gtk.Settings.get_default()
    sh = C.shell_config()
    theme = sh.get("icon_theme") or "Lumen"
    if theme == "Papirus-Dark" and not sh.get("lumen_icons_v1"):
        theme = "Lumen"
    lit = {"Lumen": "Lumen-Light", "Papirus-Dark": "Papirus-Light"}.get(theme) if light_mode() else None
    for t in filter(None, (lit, theme, "Lumen", "Papirus-Dark")):
        if os.path.isdir(f"/usr/share/icons/{t}") or os.path.isdir(os.path.join(HERE, "..", "..", "data", "icons", t)):
            if st.get_property("gtk-icon-theme-name") != t:
                st.set_property("gtk-icon-theme-name", t)
            break


def apply_scheme():
    """dark or light: our own sheet and GTK's (menus, entries, scrollbars); follows
    the setting live, with the corner radius (see apply_corners)"""
    light = light_mode()
    if _look["prov"] is None:
        _look["prov"] = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), _look["prov"],
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    if _look["light"] != light:
        _look["light"] = light
        alt = os.path.join(HERE, "style-light.css")
        _look["prov"].load_from_path(alt if light and os.path.exists(alt) else os.path.join(HERE, "style.css"))
        st = Gtk.Settings.get_default()
        if st.get_property("gtk-application-prefer-dark-theme") != (not light):
            st.set_property("gtk-application-prefer-dark-theme", not light)
        if _look.get("icons"):
            apply_icons()
        _look["icons"] = True


def apply_corners():
    apply_scheme()
    r = corner_radius()
    c = "window.lumen-settings"
    css = (f"{c}.csd, {c} .root {{ border-radius: {r}px; }}\n"
           f"{c} .sidebar {{ border-radius: {max(0, r - 1)}px 0 0 {max(0, r - 1)}px; }}\n"
           f"{c} .content {{ border-radius: 0 {max(0, r - 1)}px {max(0, r - 1)}px 0; }}\n"
           f"{c}.maximized, {c}.fullscreen, {c}.maximized .root, {c}.fullscreen .root, {c}.maximized .sidebar, {c}.fullscreen .sidebar, {c}.maximized .content, {c}.fullscreen .content "
           "{ border-radius: 0; }\n")
    if _corners["prov"] is None:
        _corners["prov"] = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), _corners["prov"],
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 2)
        # follow the slider live
        conf = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "lumen", "lumen.conf")
        try:
            mon = Gio.File.new_for_path(conf).monitor_file(Gio.FileMonitorFlags.NONE, None)

            def changed(*_a):
                if _corners["src"]:
                    GLib.source_remove(_corners["src"])
                _corners["src"] = GLib.timeout_add(200, lambda: (_corners.update(src=0), apply_corners(), False)[2])
            mon.connect("changed", changed)
            _corners["mon"] = mon
        except GLib.Error:
            pass
    p = _corners["prov"]
    p.load_from_string(css) if hasattr(p, "load_from_string") else p.load_from_data(css.encode(), -1)


def load_css():
    display = Gdk.Display.get_default()
    apply_scheme()
    Gtk.StyleContext.add_provider_for_display(display, _accent, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)
    sh = C.shell_config()
    apply_accent(sh.get("accent", ACCENTS[0][1]), sh.get("accent2", ACCENTS[0][2]))
    apply_corners()
    st = Gtk.Settings.get_default()
    try:      # follow Settings → Glass & Motion: no motion when animations are off / Performance mode
        conf = C.LumenConf()
        st.set_property("gtk-enable-animations",
                        conf.get_bool("animations", True) and not conf.get_bool("performance_mode", False))
    except Exception:   # noqa: BLE001
        pass
    apply_icons()
    # (only real changes: each one makes GTK read the whole icon theme again)
    dev_icons = os.path.abspath(os.path.join(HERE, "..", "..", "data", "icons"))
    th = Gtk.IconTheme.get_for_display(display)
    if os.path.isdir(dev_icons) and dev_icons not in [os.path.abspath(p) for p in (th.get_search_path() or [])]:
        th.add_search_path(dev_icons)


def main():
    args = sys.argv[1:]
    if "--preview" in args:
        from .preview import render
        return render(args)
    app = Gtk.Application(application_id="dev.lumen.Settings")
    # (no bundled resources: with a resource path GTK waits for the icon theme at
    # startup, then drops it and reads it again — half a second of launch)
    app.set_resource_base_path(None)
    state = {"service": "--service" in args, "css": False}

    def make():
        """the window, built once and kept: closing only hides it"""
        if not state["css"]:
            load_css()
            state["css"] = True
        s = state.get("s")
        if s is None:
            s = Settings(app)
            state["s"] = s

            def close_request(w):
                w.set_visible(False)
                GLib.idle_add(lambda: (s.refresh_pages(), False)[1])
                return True
            s.win.connect("close-request", close_request)
        return s

    def window(page=None):
        s = make()
        if page in s.rows:
            s.list.select_row(s.rows[page])
        # pages were dropped while hidden (fresh values): build the one on show
        row = s.list.get_selected_row()
        if row is not None and row.pid not in s.built:
            s.show(row.pid)
        s.win.present()

    def startup(a):
        # resident after the window closes (and preloaded at login), so opening
        # Settings is instant: `lumen-settings` asks this process over D-Bus
        a.hold()
        act = Gio.SimpleAction.new("page", GLib.VariantType.new("s"))
        act.connect("activate", lambda _a, v: window(v.get_string()))
        a.add_action(act)

    def activate(a):
        if state["service"]:
            state["service"] = False     # the login preload: build the window, keep it hidden
            make()
            return
        window(next((x.split("=", 1)[1] for x in args if x.startswith("--page=")), None))
        args[:] = [x for x in args if not x.startswith("--page=")]
    app.connect("startup", startup)
    app.connect("activate", activate)
    return app.run([sys.argv[0]])
