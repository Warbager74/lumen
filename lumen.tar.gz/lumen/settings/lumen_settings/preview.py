"""Offscreen render of the Settings window for screenshots/docs:
lumen-settings --preview out.png [--page glass] [--backdrop desk.png --at X,Y]"""
import os
import tempfile

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Graphene", "1.0")
from gi.repository import GLib, Graphene, Gtk  # noqa: E402

from . import app as A  # noqa: E402


def render(args):
    out = args[args.index("--preview") + 1]
    page = args[args.index("--page") + 1] if "--page" in args else "appearance"
    backdrop = args[args.index("--backdrop") + 1] if "--backdrop" in args else None
    at = tuple(int(v) for v in args[args.index("--at") + 1].split(",")) if "--at" in args else (420, 150)
    A.load_css()
    s = A.Settings(None, preview=True)
    s.list.select_row(s.rows[page])
    s.win.set_default_size(1000, int(os.environ.get("LUMEN_PREVIEW_H", "680")))
    s.win.present()
    loop = GLib.MainLoop()
    tmp = tempfile.mkdtemp()

    def shoot():
        w, h = s.root.get_width(), s.root.get_height()
        p = Gtk.WidgetPaintable.new(s.root)
        snap = Gtk.Snapshot()
        p.snapshot(snap, w, h)
        tex = s.win.get_renderer().render_texture(snap.to_node(), Graphene.Rect().init(0, 0, w, h))
        raw = os.path.join(tmp, "win.png")
        tex.save_to_png(raw)
        if backdrop:
            composite(raw, backdrop, at, out)
        else:
            os.replace(raw, out)
        print("wrote", out)
        loop.quit()
        return False
    GLib.timeout_add(2500, shoot)
    loop.run()
    return 0


def composite(win_png, backdrop, at, out):
    """emulate Lumen: blur the desktop under the window where it's ≥20% opaque"""
    from PIL import Image, ImageDraw, ImageEnhance, ImageFilter
    bg = Image.open(backdrop).convert("RGBA")
    win = Image.open(win_png).convert("RGBA")
    x, y = at
    blur = ImageEnhance.Color(bg.filter(ImageFilter.GaussianBlur(24))).enhance(1.35)
    mask = Image.new("L", bg.size, 0)
    mask.paste(win.getchannel("A").point(lambda a: 255 if a > 51 else 0), (x, y))
    canvas = Image.composite(blur, bg, mask)
    shadow = Image.new("RGBA", bg.size, (0, 0, 0, 0))
    ImageDraw.Draw(shadow).rounded_rectangle((x, y + 6, x + win.width, y + win.height + 6), 16, fill=(0, 0, 0, 120))
    canvas = Image.alpha_composite(Image.alpha_composite(canvas, shadow.filter(ImageFilter.GaussianBlur(14))),
                                   Image.alpha_composite(Image.new("RGBA", bg.size), _place(win, bg.size, x, y)))
    canvas.convert("RGB").save(out, quality=94)


def _place(img, size, x, y):
    from PIL import Image
    layer = Image.new("RGBA", size)
    layer.paste(img, (x, y))
    return layer
