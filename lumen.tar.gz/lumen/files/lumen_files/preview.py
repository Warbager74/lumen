"""Offscreen render of a Files window (docs / screenshots):
lumen-files --preview out.png [--path DIR] [--view list]"""
import os

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Graphene", "1.0")
from gi.repository import GLib, Graphene, Gtk  # noqa: E402

from . import app as A  # noqa: E402


def render(args):
    out = args[args.index("--preview") + 1]
    path = args[args.index("--path") + 1] if "--path" in args else GLib.get_home_dir()
    A.load_css()
    w = A.FilesWindow(None, path, preview=True)
    if "--view" in args and args[args.index("--view") + 1] == "list":
        w.list_btn.set_active(True)
    w.win.set_default_size(1100, 700)
    w.win.present()
    loop = GLib.MainLoop()

    def select_some():
        if w.sorted.get_n_items() > 3:
            w.sel.select_item(2, True)
        return False

    def shoot():
        win_w, win_h = w.root.get_width(), w.root.get_height()
        p = Gtk.WidgetPaintable.new(w.root)
        snap = Gtk.Snapshot()
        p.snapshot(snap, win_w, win_h)
        tex = w.win.get_renderer().render_texture(snap.to_node(), Graphene.Rect().init(0, 0, win_w, win_h))
        tex.save_to_png(out)
        print("wrote", out)
        loop.quit()
        return False
    GLib.timeout_add(1500, select_some)
    GLib.timeout_add(3500, shoot)
    loop.run()
    return 0
