"""Lumen Files — a macOS-style file manager with layered, floating glass.

Layers (back to front): the translucent window body, a floating sidebar card,
a floating toolbar, and an elevated content sheet; icons lift on hover. Built on
Gtk.GridView / Gtk.ColumnView over Gtk.DirectoryList, so big folders stay fast.

Keys: Enter open · Backspace / Alt+← back · Alt+→ forward · Alt+↑ up ·
Ctrl+L type a path · Ctrl+F search · Ctrl+H hidden files · Ctrl+C/X/V ·
Delete move to Trash · F2 rename · Ctrl+Shift+N new folder · Ctrl+1/2 views
"""
import json
import stat
import os
import shlex
import subprocess
import sys
import threading
import time

# (a fixed GTK theme inherited from the session would pin our menus and entries to
# dark whatever Settings → Appearance says)
if os.environ.get("GTK_THEME", "").startswith("Adwaita"):
    os.environ.pop("GTK_THEME", None)

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, Gio, GLib, GObject, Gtk, Pango  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ATTRS = ",".join(("standard::name", "standard::display-name", "standard::type", "standard::icon",
                  "standard::size", "standard::is-hidden", "standard::content-type", "standard::is-backup",
                  "time::modified", "thumbnail::path", "standard::symbolic-icon"))
TILE = 96


# ------------------------------------------------------------------ helpers
def lbl(text="", cls=None, **kw):
    w = Gtk.Label(label=text, **kw)
    for c in (cls or "").split():
        w.add_css_class(c)
    return w


def hbox(sp=0, cls=None, *kids, **kw):
    b = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=sp, **kw)
    for c in (cls or "").split():
        b.add_css_class(c)
    for k in kids:
        b.append(k)
    return b


def vbox(sp=0, cls=None, *kids, **kw):
    b = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=sp, **kw)
    for c in (cls or "").split():
        b.add_css_class(c)
    for k in kids:
        b.append(k)
    return b


def replay(widget, base):
    """restart a CSS keyframe animation: flips between two identical classes
    (base-a / base-b), which GTK sees as a new animation every time"""
    a, b = base + "-a", base + "-b"
    for other in [c for c in widget.get_css_classes() if c.endswith(("-a", "-b")) and c not in (a, b)]:
        widget.remove_css_class(other)
    if widget.has_css_class(a):
        widget.remove_css_class(a)
        widget.add_css_class(b)
    else:
        widget.remove_css_class(b)
        widget.add_css_class(a)


def icon_btn(name, tip, cb, cls="tb"):
    b = Gtk.Button(icon_name=name, tooltip_text=tip)
    b.add_css_class(cls)
    b.connect("clicked", lambda *_: cb())
    return b


def rect(x, y, w=1, h=1):
    """a Gdk.Rectangle (PyGObject ignores arguments to its constructor)"""
    r = Gdk.Rectangle()
    r.x, r.y, r.width, r.height = int(x), int(y), int(w), int(h)
    return r


def settle_menu(pop):
    """A menu's separators are counted a few frames after it opens; a popover
    on a grid or list isn't sized again by then, and its last row ended up cut
    off. For half a second: when the menu wants more room than it has, present
    it again."""
    left = [36]

    def tick(_w, _clock):
        left[0] -= 1
        try:
            sw = pop.get_first_child().get_first_child()
            inner = sw.get_child() if isinstance(sw, Gtk.ScrolledWindow) else None
            if inner is not None and pop.get_mapped() and \
                    inner.measure(Gtk.Orientation.VERTICAL, -1)[1] > sw.get_height() + 1:
                pop.present()
        except (AttributeError, TypeError):
            return False
        return left[0] > 0
    pop.add_tick_callback(tick)


def human_size(n):
    for unit in ("bytes", "KB", "MB", "GB", "TB"):
        if n < 1000 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "bytes" else f"{n:.1f} {unit}"
        n /= 1000.0
    return ""


def when(info):
    dt = info.get_modification_date_time()
    if dt is None:
        return ""
    now = GLib.DateTime.new_now_local()
    local = dt.to_local()
    if local.format("%Y%m%d") == now.format("%Y%m%d"):
        return "Today at " + local.format("%-I:%M %p")
    if local.get_year() == now.get_year():
        return local.format("%b %-d at %-I:%M %p")
    return local.format("%b %-d, %Y")


def kind_of(info):
    if info.get_file_type() == Gio.FileType.DIRECTORY:
        return "Folder"
    ct = info.get_content_type() or ""
    return Gio.content_type_get_description(ct) if ct else "Document"


def xdg_dir(kind, fallback):
    d = GLib.get_user_special_dir(kind)
    return d or os.path.join(GLib.get_home_dir(), fallback)


# -------------------------------------------------------------- thumbnails
class Thumbs:
    """small previews for images, loaded off the main thread and cached"""

    def __init__(self):
        self.cache, self.pending, self.lock = {}, set(), threading.Lock()

    def get(self, path, size, done):
        key = (path, size)
        if key in self.cache:
            return self.cache[key]
        with self.lock:
            if key in self.pending:
                return None
            self.pending.add(key)

        def work():
            tex = None
            try:
                if os.path.getsize(path) < 40_000_000:
                    pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, size * 2, size * 2, True)
                    pb = pb.apply_embedded_orientation() or pb
                    tex = Gdk.Texture.new_for_pixbuf(pb)
            except (GLib.Error, OSError):
                tex = None
            self.cache[key] = tex
            with self.lock:
                self.pending.discard(key)
            if tex is not None:
                GLib.idle_add(lambda: (done(), False)[1])
        threading.Thread(target=work, daemon=True).start()
        return None


THUMBS = Thumbs()
IMAGE_TYPES = ("image/png", "image/jpeg", "image/gif", "image/webp", "image/bmp", "image/svg+xml",
               "image/tiff", "image/x-icon", "image/avif", "image/heif")


# what a new window starts like: how the last one was left (view, hidden files, size)
STATE_FILE = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "lumen", "files.json")


def load_state():
    try:
        with open(STATE_FILE) as f:
            st = json.load(f)
        return st if isinstance(st, dict) else {}
    except (OSError, ValueError):
        return {}


def save_state(**changes):
    st = load_state()
    if all(st.get(k) == v for k, v in changes.items()):
        return
    st.update(changes)
    try:
        os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
        tmp = STATE_FILE + ".part"
        with open(tmp, "w") as f:
            json.dump(st, f)
        os.replace(tmp, STATE_FILE)
    except OSError:
        pass


# -------------------------------------------------------------------- window
class FilesWindow:
    def __init__(self, app, path=None, preview=False):
        self.app, self.preview = app, preview
        self.history, self.future = [], []
        self.cwd = None
        st = {} if preview else load_state()
        self._state = st
        self.show_hidden = bool(st.get("hidden", False))
        self.view_mode = "list" if st.get("view") == "list" else "grid"
        self._typed, self._typed_at = "", 0.0     # type-ahead: letters typed over the file view
        self.clip = None          # ("copy"|"cut", [Gio.File])
        self._fresh = {}          # file name → until when its tile may still pop in
        self._cells = []          # the tiles and list rows we made (the views recycle them)
        self._quiet = 0           # no per-item pops before this time (a whole folder is arriving)
        self._seen = None         # names showing right now (None: not known, take stock first)
        self._last_q = ""
        self.build()
        self.go(Gio.File.new_for_path(path or GLib.get_home_dir()), remember=False)

    # ---------------------------------------------------------------- build
    def build(self):
        self.win = Gtk.ApplicationWindow(application=self.app, title="Files") if self.app else Gtk.Window(title="Files")
        size = self._state.get("size")
        if isinstance(size, list) and len(size) == 2 and all(isinstance(v, int) and 480 <= v <= 6000 for v in size):
            self.win.set_default_size(*size)
        else:
            self.win.set_default_size(1100, 700)
        self.win.add_css_class("lumen-files")
        self.win.set_titlebar(Gtk.Box(visible=False))       # own macOS-style chrome

        # -- sidebar (floating card)
        lights = hbox(8, "lights", margin_start=16, margin_top=14, margin_bottom=12)
        for cls, act in (("close", self.win.close), ("min", self.win.minimize),
                         ("zoom", lambda: self.win.unmaximize() if self.win.is_maximized() else self.win.maximize())):
            b = Gtk.Button()
            b.add_css_class("light")
            b.add_css_class(cls)
            b.connect("clicked", lambda _b, a=act: a())
            lights.append(b)
        handle = Gtk.WindowHandle(child=lights)
        self.places = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self.places.add_css_class("places")
        self.places.connect("row-activated", lambda _l, r: self.on_place(r))
        sb_scroll = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, vexpand=True, child=self.places)
        self.sidebar = vbox(0, "sidebar", handle, sb_scroll)
        self.sidebar.set_size_request(210, -1)
        self.vm = None if self.preview else Gio.VolumeMonitor.get()
        self.fill_places()
        if self.vm is not None:
            # USB sticks, disks, cards, phones: there as soon as they are plugged in
            for sig in ("mount-added", "mount-removed", "mount-changed", "volume-added", "volume-removed",
                        "volume-changed", "drive-connected", "drive-disconnected"):
                self.vm.connect(sig, lambda *_: self.devices_changed())

        # -- toolbar (floating pill row)
        self.back_btn = icon_btn("go-previous-symbolic", "Back", self.back)
        self.fwd_btn = icon_btn("go-next-symbolic", "Forward", self.forward)
        nav = hbox(2, "pill nav", self.back_btn, self.fwd_btn)
        self.crumbs = hbox(2, "crumbs", hexpand=True)
        self.path_entry = Gtk.Entry(hexpand=True, visible=False)
        self.path_entry.add_css_class("path-entry")
        self.path_entry.connect("activate", self.on_path_entry)
        ef = Gtk.EventControllerFocus()
        ef.connect("leave", lambda *_: self.hide_path_entry())
        self.path_entry.add_controller(ef)
        crumb_wrap = hbox(0, "pill crumb-pill", self.crumbs, self.path_entry, hexpand=True)
        # one click anywhere on the path bar (beside the folder names, or on the
        # current folder's name) turns it into a text field
        g = Gtk.GestureClick(button=1)
        g.connect("released", lambda g, n, x, y: self.show_path_entry())
        crumb_wrap.add_controller(g)
        crumb_wrap.set_cursor(Gdk.Cursor.new_from_name("text", None))
        crumb_wrap.set_tooltip_text("Click to type a path")
        pk = Gtk.EventControllerKey()
        pk.connect("key-pressed", self.on_path_key)
        self.path_entry.add_controller(pk)
        self.grid_btn = Gtk.ToggleButton(icon_name="view-grid-symbolic", active=True, tooltip_text="Icons")
        self.list_btn = Gtk.ToggleButton(icon_name="view-list-symbolic", tooltip_text="List")
        self.list_btn.set_group(self.grid_btn)
        for b in (self.grid_btn, self.list_btn):
            b.add_css_class("tb")
        self.grid_btn.connect("toggled", lambda b: b.get_active() and self.set_view("grid"))
        self.list_btn.connect("toggled", lambda b: b.get_active() and self.set_view("list"))
        views = hbox(2, "pill seg", self.grid_btn, self.list_btn)
        self.search = Gtk.SearchEntry(placeholder_text="Search", width_chars=16)
        self.search.add_css_class("search")
        self.search.connect("search-changed", lambda *_: self.on_search())
        menu = icon_btn("view-more-symbolic", "More", self.more_menu)
        self.more = menu
        toolbar = Gtk.WindowHandle(child=hbox(10, "toolbar", nav, crumb_wrap, views, self.search, menu))

        # -- model: directory → filter (hidden, search) → sort (folders first) → selection
        self.dirlist = Gtk.DirectoryList(attributes=ATTRS, monitored=True)
        self.dirlist.connect("notify::loading", lambda *_: self.update_status())
        self.filter = Gtk.CustomFilter.new(self.keep, None)
        filtered = Gtk.FilterListModel(model=self.dirlist, filter=self.filter)
        filtered.connect("items-changed", self.on_arrivals)
        self.filtered = filtered
        sorter = Gtk.CustomSorter.new(self.compare, None)
        self.sorted = Gtk.SortListModel(model=filtered, sorter=sorter)
        # (on the last model in the chain: asked any earlier, the count is still the old
        # one, and a file created in an empty folder left "This folder is empty" showing)
        self.sorted.connect("items-changed", lambda *_: self.update_status())
        self.sel = Gtk.MultiSelection(model=self.sorted)
        self.sel.connect("selection-changed", lambda *_: self.update_status())

        # -- icon grid
        gf = Gtk.SignalListItemFactory()
        gf.connect("setup", self.grid_setup)
        gf.connect("bind", self.grid_bind)
        self.grid = Gtk.GridView(model=self.sel, factory=gf, max_columns=30, min_columns=2,
                                 enable_rubberband=True)
        self.grid.add_css_class("icons")
        self.grid.connect("activate", lambda _v, pos: self.open_at(pos))

        # -- list
        self.list = Gtk.ColumnView(model=self.sel, show_row_separators=False, enable_rubberband=True)
        self.list.add_css_class("rows")
        self.list.connect("activate", lambda _v, pos: self.open_at(pos))
        for title, fn, expand in (("Name", self.col_name, True), ("Date Modified", self.col_date, False),
                                  ("Size", self.col_size, False), ("Kind", self.col_kind, False)):
            f = Gtk.SignalListItemFactory()
            f.connect("setup", self.col_setup if title != "Name" else self.name_setup)
            f.connect("bind", fn)
            c = Gtk.ColumnViewColumn(title=title, factory=f, expand=expand, resizable=True)
            if not expand:
                c.set_fixed_width(170 if title == "Date Modified" else 110)
            self.list.append_column(c)

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, vexpand=True)
        self.stack.add_named(Gtk.ScrolledWindow(child=self.grid), "grid")
        self.stack.add_named(Gtk.ScrolledWindow(child=self.list), "list")
        self.empty = vbox(8, "empty", Gtk.Image(icon_name="folder-open-symbolic", pixel_size=56),
                          lbl("This folder is empty", "empty-title"), valign=Gtk.Align.CENTER)
        self.stack.add_named(self.empty, "empty")

        self.status = lbl("", "status", xalign=0, hexpand=True)
        self.free = lbl("", "status", xalign=1)
        sheet = vbox(0, "sheet", self.stack, hbox(8, "statusbar", self.status, self.free))
        self.sheet = sheet
        main = vbox(10, "main", toolbar, sheet, hexpand=True)

        root = hbox(10, "root", self.sidebar, main)
        self.root = root
        self.toast = lbl("", "toast", halign=Gtk.Align.CENTER, valign=Gtk.Align.END, visible=False)
        ov = Gtk.Overlay(child=root)
        ov.add_overlay(self.toast)
        self.win.set_child(ov)

        # context menu + clicks on the empty area
        for view in (self.grid, self.list):
            g = Gtk.GestureClick(button=3)
            g.connect("pressed", lambda g, n, x, y, v=view: self.context(v, x, y))
            view.add_controller(g)
        keys = Gtk.EventControllerKey()
        keys.connect("key-pressed", self.on_key)
        self.win.add_controller(keys)
        if self.view_mode == "list":
            self.list_btn.set_active(True)
        if not self.preview:
            self.win.connect("close-request", self.on_close)
        # drop files in from other apps → copy here
        drop = Gtk.DropTarget.new(Gdk.FileList, Gdk.DragAction.COPY | Gdk.DragAction.MOVE)
        drop.connect("drop", self.on_drop)
        self.sheet.add_controller(drop)

    # ---------------------------------------------------------------- places
    def fill_places(self):
        child = self.places.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.places.remove(child)
            child = nxt
        home = GLib.get_home_dir()
        fav = [("Home", home, "user-home-symbolic"),
               ("Desktop", xdg_dir(GLib.UserDirectory.DIRECTORY_DESKTOP, "Desktop"), "user-desktop-symbolic"),
               ("Documents", xdg_dir(GLib.UserDirectory.DIRECTORY_DOCUMENTS, "Documents"), "folder-documents-symbolic"),
               ("Downloads", xdg_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD, "Downloads"), "folder-download-symbolic"),
               ("Pictures", xdg_dir(GLib.UserDirectory.DIRECTORY_PICTURES, "Pictures"), "folder-pictures-symbolic"),
               ("Music", xdg_dir(GLib.UserDirectory.DIRECTORY_MUSIC, "Music"), "folder-music-symbolic"),
               ("Videos", xdg_dir(GLib.UserDirectory.DIRECTORY_VIDEOS, "Videos"), "folder-videos-symbolic")]
        self.place_header("Favourites")
        for name, path, ic in fav:
            if os.path.isdir(path) or name == "Home":
                self.place_row(name, Gio.File.new_for_path(path), ic)
        self.place_header("Locations")
        self.place_row("Computer", Gio.File.new_for_path("/"), "drive-harddisk-symbolic")
        for name, gicon, vol, mount in self.devices():
            self.device_row(name, gicon, vol, mount)
        self.place_row("Trash", Gio.File.new_for_uri("trash:///"), "user-trash-symbolic")

    # --------------------------------------------------------------- devices
    def devices(self):
        """what is plugged in: [(name, icon, volume or None, mount or None)].
        A volume is a partition of a stick / disk / card, mounted or not; a mount
        without one is a phone, a camera or a network share."""
        if self.vm is None:
            return []
        out = []
        for vol in self.vm.get_volumes():
            out.append((vol.get_name(), vol.get_symbolic_icon(), vol, vol.get_mount()))
        for m in self.vm.get_mounts():
            if m.get_volume() is None and not m.is_shadowed():
                out.append((m.get_name(), m.get_symbolic_icon(), None, m))
        return out

    def devices_changed(self):
        """(a stick arriving sends a handful of these at once)"""
        if getattr(self, "_dev_src", None):
            return

        def now():
            self._dev_src = None
            # the folder we are in went away with its drive: back home
            if self.cwd is not None and self.cwd.get_path() and not self.cwd.query_exists(None):
                self.go(Gio.File.new_for_path(GLib.get_home_dir()))
            self.fill_places()
            self.highlight_place()
            return False
        self._dev_src = GLib.timeout_add(120, now)

    def device_row(self, name, gicon, vol, mount):
        r = Gtk.ListBoxRow()
        r.target = mount.get_root() if mount is not None else None
        r.volume = vol
        img = Gtk.Image(icon_name="drive-removable-media-symbolic")
        if gicon is not None:
            img.set_from_gicon(gicon)
        row = hbox(10, "place", img, lbl(name, xalign=0, hexpand=True, ellipsize=Pango.EllipsizeMode.END))
        if mount is None:
            row.add_css_class("unmounted")       # there, not opened yet: a click mounts it
        drive = (vol.get_drive() if vol is not None else None) or (mount.get_drive() if mount is not None else None)
        if (mount is not None and (mount.can_unmount() or mount.can_eject())) or \
                (vol is not None and vol.can_eject()) or (drive is not None and (drive.can_eject() or drive.can_stop())):
            row.append(icon_btn("media-eject-symbolic", "Eject", lambda: self.eject(vol, mount), cls="eject"))
        r.set_child(row)
        self.places.append(r)

    def on_place(self, row):
        if getattr(row, "target", None) is not None:
            self.go(row.target)
        elif getattr(row, "volume", None) is not None:
            self.mount_volume(row.volume)

    def mount_volume(self, vol):
        name = vol.get_name()
        self.say(f"Opening {name}…", 30)

        def done(v, res):
            try:
                v.mount_finish(res)
            except GLib.Error as e:
                # (already told the user, e.g. a cancelled password prompt)
                handled = e.matches(Gio.io_error_quark(), Gio.IOErrorEnum.FAILED_HANDLED)
                already = e.matches(Gio.io_error_quark(), Gio.IOErrorEnum.ALREADY_MOUNTED)
                if not already:
                    if handled:
                        self.toast.set_visible(False)
                    else:
                        self.say(e.message, 4)
                    return
            m = v.get_mount()
            if m is not None:
                self.say(f"{name} is ready", 1.6)
                self.go(m.get_root())
        vol.mount(Gio.MountMountFlags.NONE, Gtk.MountOperation.new(self.win), None, done)

    def eject(self, vol, mount):
        """unmount, and for a stick or a USB disk switch it off: safe to pull out"""
        name = (mount or vol).get_name()
        drive = (vol.get_drive() if vol is not None else None) or (mount.get_drive() if mount is not None else None)
        root = mount.get_root() if mount is not None else None
        if root is not None and self.cwd is not None and (self.cwd.equal(root) or self.cwd.has_prefix(root)):
            self.go(Gio.File.new_for_path(GLib.get_home_dir()))     # we'd keep it busy ourselves
        self.say(f"Ejecting {name}…", 30)
        op = Gtk.MountOperation.new(self.win)
        flags = Gio.MountUnmountFlags.NONE

        def finished(fin, what):
            def cb(obj, res):
                try:
                    getattr(obj, fin)(res)
                    self.say(f"You can remove {name} now" if what else f"{name} is closed", 4)
                except GLib.Error as e:
                    if not e.matches(Gio.io_error_quark(), Gio.IOErrorEnum.FAILED_HANDLED):
                        self.say(e.message, 5)
                self.devices_changed()
            return cb
        if drive is not None and drive.can_stop():
            drive.stop(flags, op, None, finished("stop_finish", True))
        elif drive is not None and drive.can_eject():
            drive.eject_with_operation(flags, op, None, finished("eject_with_operation_finish", True))
        elif mount is not None and mount.can_eject():
            mount.eject_with_operation(flags, op, None, finished("eject_with_operation_finish", True))
        elif vol is not None and vol.can_eject():
            vol.eject_with_operation(flags, op, None, finished("eject_with_operation_finish", True))
        elif mount is not None and mount.can_unmount():
            mount.unmount_with_operation(flags, op, None, finished("unmount_with_operation_finish", False))

    def place_header(self, text):
        r = Gtk.ListBoxRow(selectable=False, activatable=False)
        r.set_child(lbl(text, "place-head", xalign=0))
        self.places.append(r)

    def place_row(self, name, gfile, ic):
        r = Gtk.ListBoxRow()
        r.target = gfile
        r.set_child(hbox(10, "place", Gtk.Image(icon_name=ic), lbl(name, xalign=0, ellipsize=Pango.EllipsizeMode.END)))
        self.places.append(r)

    def highlight_place(self):
        row = self.places.get_first_child()
        hit = None
        while row:
            t = getattr(row, "target", None)
            if t is not None and self.cwd is not None and t.equal(self.cwd):
                hit = row
            row = row.get_next_sibling()
        if hit:
            self.places.select_row(hit)
        else:
            self.places.unselect_all()

    # ------------------------------------------------------------- navigate
    def go(self, gfile, remember=True, direction=1):
        if gfile is None:
            return
        if self.cwd is not None and not self.cwd.equal(gfile) and not self.preview:
            # the folder's contents glide in: from the right going deeper, from the left going back
            if self.cwd.has_prefix(gfile):
                direction = -1
            replay(self.stack, "arrive-fwd" if direction > 0 else "arrive-back")
            replay(self.crumbs, "arrive-fwd" if direction > 0 else "arrive-back")
        if remember and self.cwd is not None and not self.cwd.equal(gfile):
            self.history.append(self.cwd)
            self.future.clear()
        self.cwd = gfile
        self.hush(700)
        self._fresh.clear()
        self._last_q = ""
        self.dirlist.set_file(gfile)
        self.search.set_text("")
        name = gfile.get_basename() or "/"
        if gfile.get_uri() == "trash:///":
            name = "Trash"
        elif gfile.get_path() == GLib.get_home_dir():
            name = "Home"
        self.win.set_title(name)
        self.build_crumbs()
        self.highlight_place()
        self.back_btn.set_sensitive(bool(self.history))
        self.fwd_btn.set_sensitive(bool(self.future))
        self.update_free()

    def back(self):
        if self.history:
            self.future.append(self.cwd)
            self.go(self.history.pop(), remember=False, direction=-1)
            self.back_btn.set_sensitive(bool(self.history))
            self.fwd_btn.set_sensitive(True)

    def forward(self):
        if self.future:
            self.history.append(self.cwd)
            self.go(self.future.pop(), remember=False)
            self.back_btn.set_sensitive(True)
            self.fwd_btn.set_sensitive(bool(self.future))

    def up(self):
        p = self.cwd.get_parent() if self.cwd else None
        if p:
            self.go(p)

    def build_crumbs(self):
        child = self.crumbs.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.crumbs.remove(child)
            child = nxt
        parts, f = [], self.cwd
        home = Gio.File.new_for_path(GLib.get_home_dir())
        while f is not None:
            if f.equal(home):
                parts.append(("Home", f, "user-home-symbolic"))
                break
            if f.get_uri() == "trash:///":
                parts.append(("Trash", f, "user-trash-symbolic"))
                break
            parent = f.get_parent()
            parts.append((f.get_basename() if parent else "Computer", f, None if parent else "drive-harddisk-symbolic"))
            f = parent
        parts.reverse()
        for i, (name, gf, ic) in enumerate(parts[-5:]):
            if i:
                self.crumbs.append(Gtk.Image(icon_name="go-next-symbolic", css_classes=["crumb-sep"]))
            b = Gtk.Button()
            b.add_css_class("crumb")
            if gf.equal(self.cwd):
                b.add_css_class("current")
            kids = [Gtk.Image(icon_name=ic)] if ic else []
            b.set_child(hbox(6, None, *kids, lbl(name, ellipsize=Pango.EllipsizeMode.MIDDLE, max_width_chars=22)))
            if gf.equal(self.cwd):
                # the folder you are in: clicking its name lets you type a path
                b.connect("clicked", lambda _b: self.show_path_entry())
                b.set_tooltip_text("Click to type a path")
                b.set_cursor(Gdk.Cursor.new_from_name("text", None))
            else:
                b.connect("clicked", lambda _b, gf=gf: self.go(gf))
            self.crumbs.append(b)

    def show_path_entry(self):
        self.crumbs.set_visible(False)
        self.path_entry.set_visible(True)
        if _motion_on():
            replay(self.path_entry, "fade-in")
        here = self.cwd.get_path() or self.cwd.get_uri()
        self.path_entry.set_text(here if here.endswith("/") or "://" in here else here + "/")
        self.path_entry.set_width_chars(min(64, max(30, len(here) + 8)))
        self.path_entry.grab_focus()
        self.path_entry.select_region(0, -1)        # typing replaces it; End keeps it to extend

    def hide_path_entry(self):
        self.path_entry.set_visible(False)
        self.crumbs.set_visible(True)
        if _motion_on():
            replay(self.crumbs, "fade-in")

    def _typed_path(self, text):
        """what was typed, as a file: ~ and $VARS expand, relative paths start here"""
        t = os.path.expandvars(os.path.expanduser(text.strip()))
        base = self.cwd.get_path()
        if "://" in t or not base:
            return t, Gio.File.new_for_commandline_arg(t)
        return t, Gio.File.new_for_commandline_arg_and_cwd(t, base)

    def on_path_entry(self, e):
        t, gf = self._typed_path(e.get_text())
        if not t:
            return self.hide_path_entry()
        kind = gf.query_file_type(Gio.FileQueryInfoFlags.NONE, None)
        if kind == Gio.FileType.DIRECTORY:
            self.hide_path_entry()
            self.go(gf)
        elif kind != Gio.FileType.UNKNOWN and gf.get_parent() is not None:
            self.hide_path_entry()          # a file: its folder, with the file selected
            self.go(gf.get_parent())
            name = gf.get_basename()
            GLib.timeout_add(350, lambda: (self.select_named(name), False)[1])
        else:
            replay(self.path_entry, "shake")
            self.say(f"No folder “{t}”")

    def select_named(self, name):
        for k in range(self.sel.get_n_items()):
            if self.sel.get_item(k).get_name() == name:
                self.sel.select_item(k, True)
                view = self.grid if self.stack.get_visible_child_name() == "grid" else self.list
                try:
                    view.scroll_to(k, Gtk.ListScrollFlags.NONE, None)       # GTK ≥ 4.12
                except (AttributeError, TypeError):
                    pass
                return True
        return False

    def on_path_key(self, _c, kv, _code, _state):
        """Esc: back to the folder names. Tab: finish the folder name being typed."""
        if kv == Gdk.KEY_Escape:
            self.hide_path_entry()
            return True
        if kv not in (Gdk.KEY_Tab, Gdk.KEY_ISO_Left_Tab):
            return False
        text = self.path_entry.get_text()
        head, _sep, part = text.rpartition("/")
        _t, folder = self._typed_path((head + "/") if _sep else ".")
        try:
            names = sorted(n for n in os.listdir(folder.get_path())
                           if os.path.isdir(os.path.join(folder.get_path(), n))
                           and n.lower().startswith(part.lower()) and (part.startswith(".") or not n.startswith(".")))
        except (OSError, TypeError):
            names = []
        if not names:
            replay(self.path_entry, "shake")
            return True
        common = os.path.commonprefix([n.lower() for n in names])
        done = names[0] if len(names) == 1 else names[0][:len(common)]
        new = (head + "/" if _sep else "") + done + ("/" if len(names) == 1 else "")
        if len(names) > 1 and len(done) <= len(part):
            self.say("  ·  ".join(names[:6]) + (" …" if len(names) > 6 else ""), 3.2)
        self.path_entry.set_text(new)
        self.path_entry.set_position(-1)
        return True

    # ------------------------------------------------------------ model glue
    def keep(self, info, _data=None):
        if not self.show_hidden and (info.get_is_hidden() or info.get_is_backup()):
            return False
        q = self.search.get_text().strip().lower() if hasattr(self, "search") else ""
        return not q or q in info.get_display_name().lower()

    def on_search(self):
        """typing narrows or widens the view: say which, so only the files that
        really come or go change (and the ones that come pop in)"""
        q = self.search.get_text().strip().lower()
        old, self._last_q = self._last_q, q
        if q == old:
            return
        if q.startswith(old):
            change = Gtk.FilterChange.MORE_STRICT
        elif old.startswith(q):
            change = Gtk.FilterChange.LESS_STRICT
        else:
            change = Gtk.FilterChange.DIFFERENT
            self.hush(250)
        self.filter.changed(change)

    def hush(self, ms):
        """a whole view-full is arriving: no per-file pops for a moment, then take stock"""
        self._quiet = max(self._quiet, GLib.get_monotonic_time() + ms * 1000)
        self._seen = None
        GLib.timeout_add(ms + 60, self.take_stock)

    def take_stock(self):
        if GLib.get_monotonic_time() < self._quiet:
            return False
        if self.dirlist.is_loading():
            return True                       # a big folder: ask again shortly
        n = self.filtered.get_n_items()
        self._seen = {self.filtered.get_item(i).get_name() for i in range(n)} if n <= 3000 else None
        return False

    def on_arrivals(self, model, pos, _removed, added):
        """files that just appeared (created, pasted, extracted, matching the search
        again, hidden files switched on) pop into place"""
        now = GLib.get_monotonic_time()
        n = model.get_n_items()
        if now < self._quiet or self.preview or self.dirlist.is_loading() or n > 3000 or not _motion_on():
            self._seen = None
            return
        if self._seen is not None and 0 < added <= 60:
            if len(self._fresh) > 400:
                self._fresh = {k: v for k, v in self._fresh.items() if v > now}
            # the change is reported as a range that can include files which were
            # already showing: only the ones that weren't are new
            for i in range(pos, min(pos + added, n)):
                name = model.get_item(i).get_name()
                if name not in self._seen:
                    self._fresh[name] = now + 600_000
        self._seen = {model.get_item(i).get_name() for i in range(n)}

    def greet(self, widget, info):
        """called when a tile / row is bound: pop in if its file is new here"""
        widget.remove_css_class("leaving")
        name = info.get_name()
        until = self._fresh.get(name)
        if until and until > GLib.get_monotonic_time():
            if getattr(widget, "popped_for", None) != name:   # (bound again mid-pop: let it finish)
                widget.popped_for = name
                replay(widget, "tile-in")
        elif getattr(widget, "popped_for", None) is not None:
            widget.popped_for = None                           # recycled for a file that was already here
            widget.remove_css_class("tile-in-a")
            widget.remove_css_class("tile-in-b")

    def vanish(self, infos, then):
        """the tiles of these files shrink away, then `then` really removes them"""
        if self.preview or not _motion_on():
            return then()
        names = {i.get_name() for i in infos}
        hit = []
        for c in self._cells:
            info, w = getattr(c, "info", None), getattr(c, "anim", None)
            if info is not None and w is not None and info.get_name() in names and w.get_mapped():
                w.add_css_class("leaving")
                hit.append(w)
        if not hit:
            return then()

        def fin():
            then()
            # whatever couldn't be removed after all comes back
            GLib.timeout_add(900, lambda: ([w.remove_css_class("leaving") for w in hit], False)[1])
            return False
        GLib.timeout_add(150, fin)

    def compare(self, a, b, _data=None):
        da = a.get_file_type() == Gio.FileType.DIRECTORY
        db = b.get_file_type() == Gio.FileType.DIRECTORY
        if da != db:
            return -1 if da else 1
        na, nb = a.get_display_name().lower(), b.get_display_name().lower()
        return (na > nb) - (na < nb)

    def info_at(self, pos):
        return self.sorted.get_item(pos)

    def file_of(self, info):
        return info.get_attribute_object("standard::file")

    def selected(self):
        bits = self.sel.get_selection()
        out = []
        ok, it, pos = Gtk.BitsetIter.init_first(bits)
        while ok:
            info = self.info_at(pos)
            if info is not None:
                out.append(info)
            ok, pos = it.next()
        return out

    # ---------------------------------------------------------------- tiles
    def grid_setup(self, _f, item):
        img = Gtk.Image(pixel_size=64, css_classes=["tile-icon"])
        pic = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True, visible=False,
                          css_classes=["tile-thumb"], halign=Gtk.Align.CENTER)
        pic.set_overflow(Gtk.Overflow.HIDDEN)
        pic.set_size_request(84, 60)
        name = lbl("", "tile-name", wrap=True, wrap_mode=Pango.WrapMode.WORD_CHAR, lines=2,
                   ellipsize=Pango.EllipsizeMode.MIDDLE, justify=Gtk.Justification.CENTER, max_width_chars=16,
                   width_chars=12)
        t = vbox(6, "tile", img, pic, name)
        t.set_size_request(TILE + 16, -1)
        t.img, t.pic, t.name = img, pic, name
        t.anim = t
        self._cells.append(t)
        item.set_child(t)

    def grid_bind(self, _f, item):
        info = item.get_item()
        t = item.get_child()
        t.info = info
        t.name.set_label(info.get_display_name())
        t.set_tooltip_text(info.get_display_name())
        self.set_icon(info, t.img, t.pic, 64)
        self.greet(t, info)

    def set_icon(self, info, img, pic, size):
        img.set_from_gicon(info.get_icon())
        img.set_visible(True)
        was = getattr(pic, "showing", None) if pic is not None else None
        if pic is not None:
            pic.set_visible(False)
            pic.showing = None
        ct = info.get_content_type() or ""
        gf = self.file_of(info)
        path = gf.get_path() if gf else None
        thumb = info.get_attribute_byte_string("thumbnail::path")
        if pic is not None and path and (thumb or ct in IMAGE_TYPES):
            tex = THUMBS.get(thumb or path, size, self.refresh_thumbs)
            if tex is not None:
                pic.set_paintable(tex)
                pic.set_visible(True)
                img.set_visible(False)
                pic.showing = thumb or path
                if was != pic.showing and not self.preview:
                    replay(pic, "thumb-in")      # a thumbnail that just loaded fades in

    def refresh_thumbs(self):
        """a thumbnail is ready: update the tiles on screen (GTK won't re-bind
        unchanged items, so walk the visible tiles ourselves)"""
        def walk(w):
            c = w.get_first_child()
            while c:
                if hasattr(c, "pic") and getattr(c, "info", None) is not None:
                    self.set_icon(c.info, c.img, c.pic, 64)
                else:
                    walk(c)
                c = c.get_next_sibling()
        walk(self.grid)

    # ----------------------------------------------------------------- list
    def name_setup(self, _f, item):
        img = Gtk.Image(pixel_size=20)
        cell = hbox(10, "row-name", img, lbl("", xalign=0, ellipsize=Pango.EllipsizeMode.END))
        cell.anim = None
        self._cells.append(cell)
        item.set_child(cell)

    def col_setup(self, _f, item):
        item.set_child(lbl("", "dim", xalign=0, ellipsize=Pango.EllipsizeMode.END))

    def col_name(self, _f, item):
        info = item.get_item()
        box = item.get_child()
        img, name = box.get_first_child(), box.get_last_child()
        box.info = info
        img.set_from_gicon(info.get_icon())
        name.set_label(info.get_display_name())
        # the whole row is what moves: cell → row (GTK's own widgets, found once it's in the list)
        row = box.get_parent().get_parent() if box.get_parent() is not None else None
        box.anim = row
        if row is not None:
            self.greet(row, info)

    def col_date(self, _f, item):
        item.get_child().set_label(when(item.get_item()))

    def col_size(self, _f, item):
        info = item.get_item()
        item.get_child().set_label("—" if info.get_file_type() == Gio.FileType.DIRECTORY else human_size(info.get_size()))

    def col_kind(self, _f, item):
        item.get_child().set_label(kind_of(item.get_item()))

    def set_view(self, mode):
        self.view_mode = mode
        self.update_status()
        if not self.preview:
            save_state(view=mode)

    def on_close(self, *_a):
        """the next window opens at this one's size"""
        if not self.win.is_maximized() and not self.win.is_fullscreen():
            w, h = self.win.get_width(), self.win.get_height()
            if w >= 480 and h >= 320:
                save_state(size=[w, h])
        return False

    def type_ahead(self, ch):
        """letters typed over the files: jump to the first name that starts with them
        (keep typing within a second to narrow it down, like Finder and Explorer)"""
        now = time.monotonic()
        self._typed = (self._typed if now - self._typed_at < 1.0 else "") + ch.lower()
        self._typed_at = now
        n = self.sel.get_n_items()
        first = None
        for k in range(n):
            name = self.sel.get_item(k).get_display_name().lower()
            if name.startswith(self._typed):
                first = k
                break
        if first is None:      # nothing starts with it: a name that contains it
            for k in range(n):
                if self._typed in self.sel.get_item(k).get_display_name().lower():
                    first = k
                    break
        if first is None:
            return False
        self.sel.select_item(first, True)
        view = self.grid if self.stack.get_visible_child_name() == "grid" else self.list
        try:
            view.scroll_to(first, Gtk.ListScrollFlags.FOCUS, None)      # GTK ≥ 4.12
        except (AttributeError, TypeError):
            pass
        return True

    # ---------------------------------------------------------------- status
    def update_status(self):
        n = self.sorted.get_n_items()
        loading = self.dirlist.is_loading()
        if n == 0 and not loading:
            self.stack.set_visible_child_name("empty")
        else:
            self.stack.set_visible_child_name(self.view_mode)
        sel = self.sel.get_selection().get_size()
        text = f"{n} item{'s' if n != 1 else ''}"
        if sel:
            text += f", {sel} selected"
        if loading:
            text += " · loading…"
        self.status.set_label(text)

    def update_free(self):
        if self.preview or self.cwd is None:
            self.free.set_label("128.4 GB available" if self.preview else "")
            return

        def work():
            try:
                fi = self.cwd.query_filesystem_info("filesystem::free", None)
                txt = human_size(fi.get_attribute_uint64("filesystem::free")) + " available"
            except GLib.Error:
                txt = ""
            GLib.idle_add(lambda: (self.free.set_label(txt), False)[1])
        threading.Thread(target=work, daemon=True).start()

    def say(self, text, secs=2.4):
        self.toast.set_label(text)
        self.toast.set_visible(True)
        replay(self.toast, "toast-in")
        if getattr(self, "_toast_src", None):
            GLib.source_remove(self._toast_src)
        def hide():
            self._toast_src = None
            self.toast.set_visible(False)
            return False
        self._toast_src = GLib.timeout_add(int(secs * 1000), hide)

    # ------------------------------------------------------------------ open
    def open_at(self, pos):
        info = self.info_at(pos)
        if info:
            self.open_info(info)

    def open_info(self, info):
        gf = self.file_of(info)
        if info.get_file_type() == Gio.FileType.DIRECTORY or (gf and gf.get_uri().startswith("trash:")
                                                               and info.get_file_type() == Gio.FileType.DIRECTORY):
            self.go(gf)
            return
        try:
            Gio.AppInfo.launch_default_for_uri(gf.get_uri(), None)
        except GLib.Error as e:
            self.say(f"No app can open “{info.get_display_name()}”")
            print(e, file=sys.stderr)

    def open_with(self, info, app):
        try:
            app.launch([self.file_of(info)], None)
        except GLib.Error:
            self.say(f"Couldn't open with {app.get_name()}")

    # ------------------------------------------------------------ file ops
    def copy(self, cut=False):
        files = [self.file_of(i) for i in self.selected()]
        if not files:
            return
        self.clip = ("cut" if cut else "copy", files)
        # also put them on the system clipboard (other file managers / apps)
        prov = Gdk.ContentProvider.new_for_value(Gdk.FileList.new_from_list(files))
        self.win.get_clipboard().set_content(prov)
        self.say(f"{'Cut' if cut else 'Copied'} {len(files)} item{'s' if len(files) != 1 else ''}")

    def paste(self):
        if not self.clip:
            self.say("Nothing to paste")
            return
        mode, files = self.clip
        self.transfer(files, self.cwd, move=(mode == "cut"))
        if mode == "cut":
            self.clip = None

    def transfer(self, files, dest_dir, move=False):
        verb = "Moving" if move else "Copying"
        self.say(f"{verb} {len(files)} item{'s' if len(files) != 1 else ''}…", 30)

        def unique(target):
            if not target.query_exists(None):
                return target
            base, n = target.get_basename(), 2
            stem, ext = os.path.splitext(base)
            while True:
                cand = target.get_parent().get_child(f"{stem} {n}{ext}")
                if not cand.query_exists(None):
                    return cand
                n += 1

        def copy_tree(src, dst):
            t = src.query_file_type(Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, None)
            if t == Gio.FileType.DIRECTORY:
                dst.make_directory_with_parents(None)
                for ch in src.enumerate_children("standard::name", Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, None):
                    copy_tree(src.get_child(ch.get_name()), dst.get_child(ch.get_name()))
            else:
                src.copy(dst, Gio.FileCopyFlags.NOFOLLOW_SYMLINKS | Gio.FileCopyFlags.ALL_METADATA, None, None)

        def work():
            err = None
            for f in files:
                try:
                    dst = unique(dest_dir.get_child(f.get_basename()))
                    if move:
                        try:
                            f.move(dst, Gio.FileCopyFlags.NONE, None, None)
                            continue
                        except GLib.Error:
                            pass   # across filesystems: copy, then remove
                        copy_tree(f, dst)
                        subprocess.run(["gio", "remove", "-rf", f.get_uri()], check=False)
                    else:
                        copy_tree(f, dst)
                except GLib.Error as e:
                    err = e.message
            GLib.idle_add(lambda: (self.say(err or "Done"), False)[1])
        threading.Thread(target=work, daemon=True).start()

    def trash(self):
        infos = self.selected()
        if not infos:
            return

        def really():
            n = 0
            for i in infos:
                try:
                    self.file_of(i).trash(None)
                    n += 1
                except GLib.Error as e:
                    self.say(e.message)
            if n:
                self.say(f"Moved {n} item{'s' if n != 1 else ''} to the Trash")
        self.vanish(infos, really)

    # ------------------------------------------------ archives / delete
    def extract(self, infos=None):
        """Extract into a folder named after the archive (never spills loose files)"""
        infos = infos or [i for i in self.selected() if is_archive(i)]
        if not infos:
            return
        jobs = []
        for i in infos:
            src = self.file_of(i).get_path()
            if not src:
                continue
            stem = archive_stem(i.get_name())
            dst, n = os.path.join(os.path.dirname(src), stem), 2
            while os.path.exists(dst):
                dst = os.path.join(os.path.dirname(src), f"{stem} ({n})")
                n += 1
            jobs.append((src, dst))
        self.say("Extracting…", 30)

        def work():
            errs = []
            for src, dst in jobs:
                os.makedirs(dst, exist_ok=True)
                r = run_extract(src, dst)
                if r:
                    errs.append(f"{os.path.basename(src)}: {r}")
                    try:
                        if not os.listdir(dst):
                            os.rmdir(dst)
                    except OSError:
                        pass
            msg = errs[0] if errs else (f"Extracted to “{os.path.basename(jobs[0][1])}”" if len(jobs) == 1
                                        else f"Extracted {len(jobs)} archives")
            GLib.idle_add(lambda: (self.say(msg), False)[1])
        threading.Thread(target=work, daemon=True).start()

    def compress(self):
        infos = self.selected()
        if not infos:
            return
        base = self.cwd.get_path()
        if not base:
            return
        names = [i.get_name() for i in infos]
        stem = os.path.splitext(names[0])[0] if len(names) == 1 and infos[0].get_file_type() != Gio.FileType.DIRECTORY \
            else (names[0] if len(names) == 1 else "Archive")
        out, n = os.path.join(base, stem + ".zip"), 2
        while os.path.exists(out):
            out = os.path.join(base, f"{stem} ({n}).zip")
            n += 1
        self.say("Compressing…", 30)

        def work():
            tool = "bsdtar" if shutil_which("bsdtar") else None
            if tool:
                cmd = ["bsdtar", "-a", "-cf", out, "-C", base, "--"] + names
            else:
                cmd = ["zip", "-qr", out, "--"] + names
            r = subprocess.run(cmd, cwd=base, capture_output=True, text=True)
            msg = f"Created “{os.path.basename(out)}”" if r.returncode == 0 else (r.stderr.strip() or "Couldn't compress")
            GLib.idle_add(lambda: (self.say(msg), False)[1])
        threading.Thread(target=work, daemon=True).start()

    def delete_forever(self):
        infos = self.selected()
        if not infos:
            return
        what = f"“{infos[0].get_display_name()}”" if len(infos) == 1 else f"{len(infos)} items"
        pop = Gtk.Popover(has_arrow=True)
        go = Gtk.Button(label="Delete")
        go.add_css_class("danger")
        cancel = Gtk.Button(label="Cancel")
        cancel.connect("clicked", lambda *_: pop.popdown())

        def really(*_):
            pop.popdown()
            files = [self.file_of(i) for i in infos]

            def work():
                err = None
                for f in files:
                    r = subprocess.run(["gio", "remove", "-f", "-r", f.get_uri()], capture_output=True, text=True)
                    if r.returncode != 0:
                        err = r.stderr.strip() or "Couldn't delete"
                GLib.idle_add(lambda: (self.say(err or f"Deleted {what}"), False)[1])
            self.vanish(infos, lambda: threading.Thread(target=work, daemon=True).start())
        go.connect("clicked", really)
        pop.set_child(vbox(10, "rename", lbl(f"Delete {what} permanently?", "pop-title", xalign=0),
                           lbl("This can't be undone.", "dim", xalign=0), hbox(8, None, cancel, go)))
        pop.set_parent(self.sheet)
        pop.set_pointing_to(rect(self.sheet.get_width() // 2, 40))
        pop.connect("closed", lambda p: GLib.idle_add(p.unparent))
        pop.popup()
        go.grab_focus()

    def empty_trash(self):
        subprocess.Popen(["gio", "trash", "--empty"])
        self.say("Emptying the Trash…")

    def new_folder(self):
        base, n = "untitled folder", 2
        target = self.cwd.get_child(base)
        while target.query_exists(None):
            target = self.cwd.get_child(f"{base} {n}")
            n += 1
        try:
            target.make_directory(None)
            GLib.timeout_add(250, lambda: (self.rename_file(target), False)[1])
        except GLib.Error as e:
            self.say(e.message)

    def new_document(self):
        base, n = "untitled", 2
        target = self.cwd.get_child(base + ".txt")
        while target.query_exists(None):
            target = self.cwd.get_child(f"{base} {n}.txt")
            n += 1
        try:
            target.create(Gio.FileCreateFlags.NONE, None).close(None)
            GLib.timeout_add(250, lambda: (self.rename_file(target), False)[1])
        except GLib.Error as e:
            self.say(e.message)

    def duplicate(self):
        files = [self.file_of(i) for i in self.selected()]
        if files:
            self.transfer(files, self.cwd)      # same folder: "name 2"

    def put_back(self):
        """in the Trash: back to where it was deleted from"""
        uris = [self.file_of(i).get_uri() for i in self.selected()]

        def work():
            bad = 0
            for u in uris:
                bad += subprocess.run(["gio", "trash", "--restore", u], check=False,
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode != 0
            GLib.idle_add(lambda: (self.say("Couldn't put everything back" if bad else "Put back"), False)[1])
        if uris:
            threading.Thread(target=work, daemon=True).start()

    def set_as_wallpaper(self, info):
        path = self.file_of(info).get_path()
        if not path:
            return
        cfg = os.path.join(GLib.get_user_config_dir(), "lumen", "shell.json")
        try:
            with open(cfg) as f:
                data = json.load(f)
        except (OSError, ValueError):
            data = {}
        data["wallpaper"] = path
        try:
            os.makedirs(os.path.dirname(cfg), exist_ok=True)
            with open(cfg, "w") as f:
                json.dump(data, f, indent=2)
        except OSError as e:
            self.say(str(e))
            return
        # the shell shows it; lumen-theme lets an Auto accent follow it
        subprocess.Popen(["sh", "-c", "lumen-shell --reload; lumen-theme"], start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.say("Wallpaper set")

    def properties(self):
        """Get Info: what it is, how big, where, when, who may do what"""
        infos = self.selected()
        gf = self.file_of(infos[0]) if len(infos) == 1 else self.cwd
        many = infos if len(infos) > 1 else None
        try:
            info = gf.query_info(ATTRS + ",time::created,time::access,unix::mode,owner::user,owner::group,"
                                 "standard::symlink-target,access::can-write", Gio.FileQueryInfoFlags.NONE, None)
        except GLib.Error as e:
            self.say(e.message)
            return
        is_dir = info.get_file_type() == Gio.FileType.DIRECTORY
        title = f"{len(many)} items" if many else (info.get_display_name() or gf.get_basename() or "/")
        img = Gtk.Image(pixel_size=48)
        if many:
            img.set_from_icon_name("folder-documents")
        elif info.get_icon() is not None:
            img.set_from_gicon(info.get_icon())
        grid = Gtk.Grid(column_spacing=14, row_spacing=6)
        rows = []

        def row(key, value):
            if value in (None, ""):
                return None
            k = lbl(key, "info-key", xalign=1, yalign=0)
            v = lbl(str(value), "info-val", xalign=0, wrap=True, selectable=True, max_width_chars=34)
            v.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
            grid.attach(k, 0, len(rows), 1, 1)
            grid.attach(v, 1, len(rows), 1, 1)
            rows.append(v)
            return v
        size_lbl = None
        if many:
            size_lbl = row("Size", "Working it out…")
            row("Where", gf.get_path() or gf.get_uri())
        else:
            row("Kind", kind_of(info))
            size_lbl = row("Size", "Working it out…" if is_dir else
                           f"{human_size(info.get_size())} ({info.get_size():,} bytes)")
            parent = gf.get_parent()
            row("Where", (parent.get_path() or parent.get_uri()) if parent else "")
            if info.has_attribute("standard::symlink-target"):
                row("Link to", info.get_symlink_target())
            row("Modified", when(info))
            cr = info.get_creation_date_time() if hasattr(info, "get_creation_date_time") else None
            row("Created", cr.to_local().format("%b %-d, %Y at %-I:%M %p") if cr else None)
            ct = info.get_content_type() or ""
            path = gf.get_path()
            if ct.startswith("image/") and path:
                fmt = GdkPixbuf.Pixbuf.get_file_info(path)
                if fmt and fmt[0] is not None:
                    row("Dimensions", f"{fmt[1]} × {fmt[2]}")
            if info.has_attribute("unix::mode"):
                mode = info.get_attribute_uint32("unix::mode")
                row("Owner", ":".join(x for x in (info.get_attribute_string("owner::user"),
                                                   info.get_attribute_string("owner::group")) if x))
                row("Permissions", f"{stat.filemode(mode)[1:]}  ({mode & 0o777:o})")
                if not is_dir and info.get_file_type() == Gio.FileType.REGULAR and path:
                    exe = Gtk.CheckButton(label="Allow running as a program", active=bool(mode & 0o111))

                    def toggled(b):
                        try:
                            m = os.stat(path).st_mode
                            os.chmod(path, (m | ((m & 0o444) >> 2)) if b.get_active() else (m & ~0o111))
                        except OSError as e:
                            self.say(e.strerror or str(e))
                    exe.connect("toggled", toggled)
                    grid.attach(exe, 1, len(rows), 1, 1)
                    rows.append(exe)
        pop = Gtk.Popover(has_arrow=True)
        pop.add_css_class("info")
        pop.set_child(vbox(12, "info-card", hbox(12, None, img, lbl(title, "info-title", xalign=0, wrap=True,
                                                                     max_width_chars=28)), grid))
        pop.set_parent(self.sheet)
        pop.set_pointing_to(rect(self.sheet.get_width() // 2, 40))
        alive = [True]
        pop.connect("closed", lambda p: (alive.__setitem__(0, False), GLib.idle_add(p.unparent)))
        pop.popup()
        # (GTK selects the text of the first selectable label when it takes the focus)
        GLib.idle_add(lambda: ([v.select_region(0, 0) for v in rows if isinstance(v, Gtk.Label)], False)[1])
        roots = [self.file_of(i).get_path() for i in many] if many else ([gf.get_path()] if is_dir else [])
        roots = [r for r in roots if r]
        if not roots:
            if size_lbl is not None and (many or is_dir):
                size_lbl.set_label("—")
            return

        def work():
            total = count = 0
            for root in roots:
                if not os.path.isdir(root) or os.path.islink(root):
                    try:
                        total += os.lstat(root).st_size
                        count += 1
                    except OSError:
                        pass
                    continue
                for d, _dirs, names in os.walk(root, onerror=lambda _e: None):
                    if not alive[0]:
                        return
                    for n in names:
                        try:
                            total += os.lstat(os.path.join(d, n)).st_size
                            count += 1
                        except OSError:
                            pass
            GLib.idle_add(lambda: (alive[0] and size_lbl.set_label(
                f"{human_size(total)} · {count:,} file{'s' if count != 1 else ''}"), False)[1])
        threading.Thread(target=work, daemon=True).start()

    def rename(self):
        infos = self.selected()
        if len(infos) == 1:
            self.rename_file(self.file_of(infos[0]))

    def rename_file(self, gf):
        pop = Gtk.Popover(has_arrow=True)
        e = Gtk.Entry(text=gf.get_basename(), width_chars=28)
        stem = os.path.splitext(gf.get_basename())[0]

        def done(*_):
            new = e.get_text().strip()
            pop.popdown()
            if new and new != gf.get_basename() and "/" not in new:
                try:
                    gf.set_display_name(new, None)
                except GLib.Error as err:
                    self.say(err.message)
        e.connect("activate", done)
        pop.set_child(vbox(8, "rename", lbl("Rename", "pop-title", xalign=0), e))
        pop.set_parent(self.sheet)
        pop.set_pointing_to(rect(self.sheet.get_width() // 2, 40))
        pop.connect("closed", lambda p: GLib.idle_add(p.unparent))
        pop.popup()
        e.grab_focus()
        e.select_region(0, len(stem))

    def copy_path(self):
        files = [self.file_of(i) for i in self.selected()] or [self.cwd]
        txt = "\n".join(f.get_path() or f.get_uri() for f in files)
        self.win.get_clipboard().set(txt)
        self.say("Path copied")

    def open_terminal(self):
        term = os.environ.get("TERMINAL", "kitty")
        path = self.cwd.get_path() or GLib.get_home_dir()
        subprocess.Popen(["sh", "-c", f"cd {shlex.quote(path)} && exec {term}"], start_new_session=True)

    def on_drop(self, _t, value, _x, _y):
        files = value.get_files() if hasattr(value, "get_files") else []
        files = [f for f in files if not (f.get_parent() and f.get_parent().equal(self.cwd))]
        if files:
            self.transfer(files, self.cwd)
        return True

    # ------------------------------------------------------------ menus
    def item_at(self, view, x, y):
        """the file under the pointer (grid tile or list row), or None"""
        w = view.pick(x, y, Gtk.PickFlags.DEFAULT)
        while w is not None and w is not view:
            if getattr(w, "info", None) is not None:
                return w.info
            w = w.get_parent()
        return None

    def context(self, view, x, y):
        # right-clicking a file that isn't selected selects just it (Finder/Explorer)
        hit = self.item_at(view, x, y)
        if hit is not None and hit not in self.selected():
            for k in range(self.sel.get_n_items()):
                if self.sel.get_item(k) is hit:
                    self.sel.select_item(k, True)
                    break
        elif hit is None:
            self.sel.unselect_all()
        items = self.selected()
        menu = Gio.Menu()
        actions = Gio.SimpleActionGroup()

        def act(name, cb, section, label):
            a = Gio.SimpleAction.new(name, None)
            a.connect("activate", lambda *_: cb())
            actions.add_action(a)
            section.append(label, f"f.{name}")
        s1, s2, s3 = Gio.Menu(), Gio.Menu(), Gio.Menu()
        if items:
            act("open", lambda: [self.open_info(i) for i in items], s1, "Open")
            if len(items) == 1 and items[0].get_file_type() != Gio.FileType.DIRECTORY:
                ow = Gio.Menu()
                ct = items[0].get_content_type() or ""
                for k, app in enumerate(Gio.AppInfo.get_recommended_for_type(ct)[:8]):
                    a = Gio.SimpleAction.new(f"ow{k}", None)
                    a.connect("activate", lambda *_a, app=app: self.open_with(items[0], app))
                    actions.add_action(a)
                    ow.append(app.get_name(), f"f.ow{k}")
                if ow.get_n_items():
                    s1.append_submenu("Open With", ow)
            act("copy", lambda: self.copy(False), s2, "Copy")
            act("cut", lambda: self.copy(True), s2, "Cut")
            if len(items) == 1:
                act("rename", self.rename, s2, "Rename…")
            act("path", self.copy_path, s2, "Copy Path")
            if any(is_archive(i) for i in items):
                act("extract", lambda: self.extract([i for i in items if is_archive(i)]), s2, "Extract Here")
            act("compress", self.compress, s2, "Compress to .zip")
            act("dup", self.duplicate, s2, "Duplicate")
            ct0 = items[0].get_content_type() or ""
            if len(items) == 1 and ct0.startswith(("image/", "video/")):
                act("wall", lambda: self.set_as_wallpaper(items[0]), s2, "Set as Wallpaper")
            if self.cwd.get_uri().startswith("trash:"):
                act("back", self.put_back, s3, "Put Back")
            else:
                act("trash", self.trash, s3, "Move to Trash")
            act("delete", self.delete_forever, s3, "Delete Permanently…")
            act("getinfo", self.properties, s3, "Get Info")
        else:
            act("newf", self.new_folder, s1, "New Folder")
            act("newd", self.new_document, s1, "New Document")
            act("paste", self.paste, s1, "Paste")
            act("term", self.open_terminal, s2, "Open in Terminal")
            act("path", self.copy_path, s2, "Copy Path")
            act("hidden", self.toggle_hidden, s2, "Hide Hidden Files" if self.show_hidden else "Show Hidden Files")
            if self.cwd.get_uri() == "trash:///":
                act("empty", self.empty_trash, s3, "Empty Trash")
            act("getinfo", self.properties, s3, "Get Info")
        for s in (s1, s2, s3):
            if s.get_n_items():
                menu.append_section(None, s)
        pop = Gtk.PopoverMenu.new_from_model(menu)
        pop.add_css_class("ctx")
        pop.insert_action_group("f", actions)
        pop.set_parent(view)
        pop.set_has_arrow(False)
        # top-left corner at the pointer (a popover is centred on its point otherwise)
        pop.set_position(Gtk.PositionType.BOTTOM)
        pop.set_halign(Gtk.Align.START)
        pop.set_offset(0, 2)
        pop.set_pointing_to(rect(int(x), int(y)))
        pop.connect("closed", lambda p: GLib.idle_add(p.unparent))
        pop.popup()
        settle_menu(pop)

    def more_menu(self):
        menu = Gio.Menu()
        actions = Gio.SimpleActionGroup()
        for name, label, cb in (("newf", "New Folder", self.new_folder),
                                ("newd", "New Document", self.new_document),
                                ("hidden", "Show Hidden Files" if not self.show_hidden else "Hide Hidden Files",
                                 self.toggle_hidden),
                                ("term", "Open in Terminal", self.open_terminal),
                                ("win", "New Window", lambda: FilesWindow(self.app, self.cwd.get_path()).win.present())):
            a = Gio.SimpleAction.new(name, None)
            a.connect("activate", lambda *_a, cb=cb: cb())
            actions.add_action(a)
            menu.append(label, f"m.{name}")
        pop = Gtk.PopoverMenu.new_from_model(menu)
        pop.insert_action_group("m", actions)
        pop.set_parent(self.more)
        pop.connect("closed", lambda p: GLib.idle_add(p.unparent))
        pop.popup()

    def toggle_hidden(self):
        self.show_hidden = not self.show_hidden
        if not self.preview:
            save_state(hidden=self.show_hidden)
        self.filter.changed(Gtk.FilterChange.LESS_STRICT if self.show_hidden else Gtk.FilterChange.MORE_STRICT)
        self.say("Showing hidden files" if self.show_hidden else "Hiding hidden files")

    # ------------------------------------------------------------- keyboard
    def on_key(self, _c, kv, _code, state):
        ctrl = state & Gdk.ModifierType.CONTROL_MASK
        alt = state & Gdk.ModifierType.ALT_MASK
        shift = state & Gdk.ModifierType.SHIFT_MASK
        focus = self.win.get_focus()
        typing = isinstance(focus, (Gtk.Text, Gtk.Entry)) or (focus and isinstance(focus.get_parent(), Gtk.Entry))
        K = Gdk
        if ctrl and kv in (K.KEY_l, K.KEY_L):
            self.show_path_entry()
        elif ctrl and kv in (K.KEY_f, K.KEY_F):
            self.search.grab_focus()
        elif ctrl and kv in (K.KEY_h, K.KEY_H):
            self.toggle_hidden()
        elif ctrl and shift and kv in (K.KEY_n, K.KEY_N):
            self.new_folder()
        elif ctrl and kv == K.KEY_1:
            self.grid_btn.set_active(True)
        elif ctrl and kv == K.KEY_2:
            self.list_btn.set_active(True)
        elif typing:
            return False
        elif (alt and kv == K.KEY_Left) or kv == K.KEY_BackSpace:
            self.back()
        elif alt and kv == K.KEY_Right:
            self.forward()
        elif alt and kv == K.KEY_Up:
            self.up()
        elif ctrl and kv in (K.KEY_c, K.KEY_C):
            self.copy(False)
        elif ctrl and kv in (K.KEY_x, K.KEY_X):
            self.copy(True)
        elif ctrl and kv in (K.KEY_v, K.KEY_V):
            self.paste()
        elif kv == K.KEY_Delete and shift:
            self.delete_forever()
        elif kv == K.KEY_Delete:
            self.trash()
        elif kv == K.KEY_F2:
            self.rename()
        elif (ctrl and kv in (K.KEY_i, K.KEY_I)) or (alt and kv in (K.KEY_Return, K.KEY_KP_Enter)):
            self.properties()
        elif ctrl and kv in (K.KEY_d, K.KEY_D):
            self.duplicate()
        elif ctrl and kv in (K.KEY_n, K.KEY_N):
            FilesWindow(self.app, self.cwd.get_path()).win.present()
        elif ctrl and kv in (K.KEY_w, K.KEY_W):
            self.win.close()
        elif ctrl and kv in (K.KEY_a, K.KEY_A):
            self.sel.select_all()
        elif kv == K.KEY_F5 or (ctrl and kv in (K.KEY_r, K.KEY_R)):
            self.go(self.cwd, remember=False, direction=0)
        elif kv == K.KEY_Escape:
            self.sel.unselect_all()
            self._typed = ""
        elif not ctrl and not alt:
            ch = chr(Gdk.keyval_to_unicode(kv)) if Gdk.keyval_to_unicode(kv) else ""
            if not ch.isprintable() or ch.isspace() or not ch:
                return False
            return self.type_ahead(ch)
        else:
            return False
        return True


# ------------------------------------------------------------- archives
ARCHIVE_TYPES = {"application/zip", "application/x-tar", "application/gzip", "application/x-compressed-tar",
                 "application/x-bzip2-compressed-tar", "application/x-xz-compressed-tar",
                 "application/x-zstd-compressed-tar", "application/x-7z-compressed", "application/vnd.rar",
                 "application/x-rar", "application/x-rar-compressed", "application/x-xz", "application/x-bzip2",
                 "application/zstd", "application/java-archive", "application/x-lzma-compressed-tar"}
ARCHIVE_EXTS = (".tar.gz", ".tar.xz", ".tar.bz2", ".tar.zst", ".tgz", ".txz", ".tbz2", ".zip", ".7z", ".rar",
                ".tar", ".jar")


def is_archive(info):
    if info.get_file_type() == Gio.FileType.DIRECTORY:
        return False
    name = info.get_name().lower()
    return (info.get_content_type() or "") in ARCHIVE_TYPES or name.endswith(ARCHIVE_EXTS)


def archive_stem(name):
    low = name.lower()
    for ext in sorted(ARCHIVE_EXTS, key=len, reverse=True):
        if low.endswith(ext):
            return name[: -len(ext)] or name
    return os.path.splitext(name)[0] or name


def shutil_which(cmd):
    import shutil
    return shutil.which(cmd)


def run_extract(src, dst):
    """extract `src` into `dst`; '' on success, else a short error"""
    low = src.lower()
    if low.endswith(".7z") and shutil_which("7z"):
        cmd = ["7z", "x", "-y", f"-o{dst}", src]
    elif low.endswith(".rar") and shutil_which("unrar"):
        cmd = ["unrar", "x", "-o+", src, dst + "/"]
    elif shutil_which("bsdtar"):
        cmd = ["bsdtar", "-xf", src, "-C", dst]
    elif low.endswith(".zip") and shutil_which("unzip"):
        cmd = ["unzip", "-q", "-o", src, "-d", dst]
    else:
        cmd = ["tar", "-xf", src, "-C", dst]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        return (r.stderr.strip().splitlines() or ["couldn't extract"])[-1][:120]
    # an archive holding a single folder of the same name: don't nest it twice
    try:
        inner = os.listdir(dst)
        if len(inner) == 1 and os.path.isdir(os.path.join(dst, inner[0])) and inner[0] == os.path.basename(dst):
            tmp = dst + ".lumen-tmp"
            os.rename(os.path.join(dst, inner[0]), tmp)
            os.rmdir(dst)
            os.rename(tmp, dst)
    except OSError:
        pass
    return ""


# ----------------------------------------------------------------------- app
_motion_cache = [0, True]


def _motion_on():
    """Settings → Glass & Motion: no motion when animations are off or in Performance mode"""
    now = GLib.get_monotonic_time()
    if now - _motion_cache[0] < 2_000_000:
        return _motion_cache[1]
    _motion_cache[0] = now
    _motion_cache[1] = _motion_read()
    return _motion_cache[1]


def _motion_read():
    vals = {}
    try:
        with open(os.path.expanduser("~/.config/lumen/lumen.conf")) as f:
            for line in f:
                k, eq, v = line.partition("=")
                if eq and k.strip() in ("animations", "performance_mode"):
                    vals[k.strip()] = v.split(" #")[0].strip().lower()
    except OSError:
        pass
    return vals.get("animations", "true") != "false" and vals.get("performance_mode", "false") != "true"


# ------------------------------------------------------------ window corners
# This app draws its own window, so its corners have to agree with what the
# compositor draws around and behind it (shadow cut-out, frost, the Liquid Glass
# lens): the same radius as Settings → Glass & Motion → Corner radius, and none
# at all when the window is maximised or fullscreen. Otherwise the glass shows
# as a little square poking out past a rounder corner.
_corners = {"prov": None, "mon": None, "src": 0}


def corner_radius():
    r = 14
    for path in (os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "lumen", "lumen.conf"),
                 "/etc/lumen/lumen.conf"):
        try:
            with open(path) as f:
                for line in f:
                    k, eq, v = line.partition("=")
                    if eq and k.strip() == "corner_radius":
                        r = int(float(v.split("#")[0].strip()))
            break
        except (OSError, ValueError):
            continue
    return max(0, min(24, r))


_look = {"prov": None, "light": None}


def light_mode():
    """Settings → Appearance → Light (lumen.conf: color_scheme = light)"""
    v = "dark"
    for path in (os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "lumen", "lumen.conf"),
                 "/etc/lumen/lumen.conf"):
        try:
            with open(path) as f:
                for line in f:
                    k, eq, val = line.partition("=")
                    if eq and k.strip() == "color_scheme":
                        v = val.split("#")[0].strip().lower()
            break
        except OSError:
            continue
    return (os.environ.get("LUMEN_SCHEME") or v) == "light"


def apply_icons():
    """the shell's icon theme (Lumen inherits Papirus for folders and file
    types); in light mode its light version. Follows the setting live."""
    st = Gtk.Settings.get_default()
    th = Gtk.IconTheme.get_for_display(Gdk.Display.get_default())
    try:   # follow the shell's icon theme (Lumen inherits Papirus for folders and file types)
        with open(os.path.expanduser("~/.config/lumen/shell.json")) as f:
            want = json.load(f).get("icon_theme") or "Lumen"
    except (OSError, ValueError):
        want = "Lumen"
    here_icons = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "data", "icons")
    roots = ["/usr/share/icons", "/usr/local/share/icons", os.path.expanduser("~/.local/share/icons"), here_icons]
    roots += [os.path.join(d, "icons") for d in os.environ.get("XDG_DATA_DIRS", "").split(":") if d]
    # (only real changes: each one makes GTK read the whole icon theme again)
    if os.path.isdir(here_icons) and os.path.abspath(here_icons) not in [os.path.abspath(p) for p in
                                                                         (th.get_search_path() or [])]:
        th.add_search_path(here_icons)
    lit = {"Lumen": "Lumen-Light", "Papirus-Dark": "Papirus-Light"}.get(want) if light_mode() else None
    for theme in filter(None, (lit, want, "Lumen", "Papirus-Dark")):
        if any(os.path.isdir(os.path.join(b, theme)) for b in roots):
            if st.get_property("gtk-icon-theme-name") != theme:
                st.set_property("gtk-icon-theme-name", theme)
            break


def apply_scheme():
    """dark or light: our own sheet and GTK's (menus, entries, scrollbars); follows
    the setting live, with the corner radius (see apply_corners)"""
    light = light_mode()
    if _look["prov"] is None:
        _look["prov"] = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), _look["prov"],
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    if _look["light"] != light:
        _look["light"] = light
        alt = os.path.join(HERE, "style-light.css")
        _look["prov"].load_from_path(alt if light and os.path.exists(alt) else os.path.join(HERE, "style.css"))
        st = Gtk.Settings.get_default()
        if st.get_property("gtk-application-prefer-dark-theme") != (not light):
            st.set_property("gtk-application-prefer-dark-theme", not light)
        if _look.get("icons"):
            apply_icons()
        _look["icons"] = True


def apply_corners():
    apply_scheme()
    r = corner_radius()
    c = "window.lumen-files"
    css = (f"{c}.csd, {c} .root {{ border-radius: {r}px; }}\n"
           f"{c}.maximized, {c}.fullscreen, {c}.maximized .root, {c}.fullscreen .root "
           "{ border-radius: 0; }\n")
    if _corners["prov"] is None:
        _corners["prov"] = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), _corners["prov"],
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 2)
        # follow the slider live
        conf = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "lumen", "lumen.conf")
        try:
            mon = Gio.File.new_for_path(conf).monitor_file(Gio.FileMonitorFlags.NONE, None)

            def changed(*_a):
                if _corners["src"]:
                    GLib.source_remove(_corners["src"])
                _corners["src"] = GLib.timeout_add(200, lambda: (_corners.update(src=0), apply_corners(), False)[2])
            mon.connect("changed", changed)
            _corners["mon"] = mon
        except GLib.Error:
            pass
    p = _corners["prov"]
    p.load_from_string(css) if hasattr(p, "load_from_string") else p.load_from_data(css.encode(), -1)


def load_css():
    apply_scheme()
    # the user's accent colour from Lumen
    user = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "lumen", "shell.css")
    if os.path.exists(user):
        up = Gtk.CssProvider()
        try:
            up.load_from_string("\n".join(l for l in open(user).read().splitlines() if l.startswith("@define-color")))
        except AttributeError:
            pass
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), up, Gtk.STYLE_PROVIDER_PRIORITY_USER)
    apply_corners()
    st = Gtk.Settings.get_default()
    st.set_property("gtk-enable-animations", _motion_on())
    apply_icons()


class App(Gtk.Application):
    def __init__(self, service=False):
        super().__init__(application_id="org.lumen.Files", flags=Gio.ApplicationFlags.HANDLES_OPEN)
        # (no bundled resources: with a resource path GTK waits for the icon theme
        # at startup, then drops it and reads it again — half a second of launch)
        self.set_resource_base_path(None)
        Gtk.Window.set_default_icon_name("lumen-files")
        self.service = service          # preloaded at login: no window until asked
        self.connect("startup", self.on_startup)
        self.connect("activate", lambda *_: self.on_activate())
        self.connect("open", lambda _a, files, _n, _h: [self.new_window(f.get_path()) for f in files])

    def on_startup(self, *_):
        # stay running after the last window closes: the next open is instant
        # (`lumen-files` asks this process over D-Bus instead of starting Python)
        self.hold()
        load_css()
        self._css = True

    def on_activate(self):
        if self.service:
            self.service = False         # the preload's own activation: stay hidden
            return
        self.new_window(None)

    def new_window(self, path):
        if not getattr(self, "_css", False):
            load_css()
            self._css = True
        if path and not os.path.isdir(path):
            path = os.path.dirname(path)
        FilesWindow(self, path).win.present()


def main():
    if "--preview" in sys.argv:
        from .preview import render
        return render(sys.argv)
    service = "--service" in sys.argv
    return App(service).run([a for a in sys.argv if a != "--service"])
