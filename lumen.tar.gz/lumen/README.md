# Lumen

**A liquid-glass Wayland desktop for Arch Linux**: its own compositor, its own shell,
a macOS-style menu bar on top, a Windows 11-style taskbar on the bottom, and a glass
Spotlight-style launcher.

![Lumen desktop](docs/screenshots/desktop.jpg)

| Start menu | Control Centre | Spotlight |
|---|---|---|
| ![](docs/screenshots/start.jpg) | ![](docs/screenshots/control.jpg) | ![](docs/screenshots/spotlight.jpg) |

## What's in the box

```
lumen/
├── compositor/        lumen: the Wayland compositor (C, wlroots 0.20 + SceneFX 0.5)
│   └── src/           main · view (windows/workspaces) · layers · input · anim · ipc · text · config
├── shell/lumen_shell  lumen-shell: menu bar, taskbar, Start, Control Centre, menus, wallpaper (GTK4 + layer-shell)
├── rofi/lumen.rasi    glass theme for rofi (the fallback launcher)
├── bin/               lumenctl · lumen-shell · start-lumen · lumen-screenshot · lumen-lock
├── config/            default lumen.conf, shell.json, kitty-glass.conf, bashrc, fastfetch
├── data/              session file, wallpaper ("Flow", procedurally generated), logo
├── PKGBUILD           makepkg package (lumen-desktop-git)
└── install.sh         one-shot build + install on Arch
```

```
 ┌──────────── lumen-shell (GTK4, wlr-layer-shell) ────────────┐
 │  menu bar · taskbar · Start · Control Centre · menus · wall │──┐ JSON over
 └─────────────────────────────────────────────────────────────┘  │ $XDG_RUNTIME_DIR/lumen-*.sock
 ┌──────────────── lumen (compositor) ─────────────────────────┐◄─┘   (lumenctl uses it too)
 │ xdg-shell windows → glass frame, rim light, shadow, traffic │
 │ lights, title  ·  layer-shell → backdrop blur, slide-in     │
 │ animation engine (spring / expo / cubic) · 4 workspaces     │
 │ SceneFX renderer (blur, rounded corners, shadows) on wlroots│
 └─────────────────────────────────────────────────────────────┘
```

### Compositor (`lumen`)
- **Liquid glass:** every window sits on a blurred, saturated, tinted glass body with a 1px
  specular rim, a soft drop shadow (dimmer when unfocused), and 14px rounded corners.
  Translucent apps (e.g. kitty at 55% opacity) become frosted glass.
- **Server-side mac titlebars** (xdg-decoration) with real traffic lights: close,
  minimize and zoom. Double-click the titlebar to zoom; drag a zoomed window to tear it off.
- **Every surface from layer-shell gets backdrop blur:** bars, menus, rofi, notifications.
  Only drawn pixels blur (`ignore_transparent`), so pill shapes stay crisp.
- **Animations:** spring-physics window open, fade-and-sink close, minimize into the taskbar,
  expo restore, spring zoom/unzoom, sliding workspace switch, and bars and menus that spring in from their edge.
- Workspaces, Alt-Tab, Super+drag move / Super+right-drag resize, edge and corner resize,
  **XWayland** (X11 apps like Steam get the same glass frames; apps that draw their own titlebar
  keep theirs; menus and tooltips float undecorated), foreign-toplevel (external docks work), screencopy (`grim`), data-control (clipboard managers),
  fractional scale, gamma control, idle notify/inhibit, cursor-shape, dmabuf, VT switching.

### Shell (`lumen-shell`)
- **Menu bar:** Lumen menu (Sleep, Restart, Shut Down, Lock, Log Out), the focused app's
  name in bold, Go/Window/Help menus, animated workspace dots, now playing, battery, Wi-Fi,
  volume, search, Control Centre, clock.
- **Taskbar:** centered Start, search pill, task view, pinned and running apps with
  springy indicator pills (wide gradient pill = focused). Click a focused app to minimize it;
  with several windows, clicks cycle them. On the right: tray, status cluster, two-line clock, notifications,
  and show-desktop.
- **Start menu:** search, Pinned / All apps, Recommended (your real recent files), user and power.
- **Control Centre:** Wi-Fi, Bluetooth, Do Not Disturb, Night Shift, Screenshot, brightness and
  volume sliders, media controls.

## Install (Arch)

```sh
git clone https://github.com/YOURNAME/lumen && cd lumen
./install.sh          # pacman deps + build + install (no AUR needed)
```
or `makepkg -si` with the included PKGBUILD. Then pick **Lumen** in your display manager
(GDM/SDDM/ly), or run `start-lumen` from a TTY.

Dependencies (all in the official repos): `wlroots0.20`, `scenefx` (0.5), `gtk4`, `gtk4-layer-shell`,
`xorg-xwayland`, `python-gobject`, `rofi` (≥ 2.0 has native Wayland; only the fallback launcher now), `sound-theme-freedesktop`, `papirus-icon-theme`,
`inter-font`, `wireplumber`, `brightnessctl`, `playerctl`, `networkmanager`, `grim`, `slurp`, `wl-clipboard`, `swaylock`.

## System Settings

`lumen-settings` (Lumen menu → System Settings…, or search "Settings"): Wi-Fi & Bluetooth,
Appearance (wallpapers, accent colour, icon theme, 24h clock), Glass & Motion (blur strength,
quality, vibrancy, window tint, corner radius, shadows, animation speed), Taskbar (pinned apps),
Keyboard & Mouse (layout, Caps→Esc, key repeat, natural scroll, shortcut list), Sound & Display,
Startup Apps (+ Xwayland toggle), Lock & Login, About. Changes apply live.

![Settings](docs/screenshots/settings.jpg)

## Taskbar

Two shapes, picked in Settings → Taskbar (`"taskbar_style"` in `shell.json`):

- **Floating dock** (default): a glass island that hugs your apps and floats above the bottom edge.
- **Full-width bar**: edge to edge, like Windows 11.

Either way: Start, a Search pill, then pinned and running apps. A dot under an icon means it is
running, a wide accent pill means it has focus. Buttons are kept between updates, so the pills
glide instead of popping, apps slide in when they open and out when they close, and an app's icon
bounces while it starts. Hover an app for live window previews, right-click for its jump list
(pin/unpin, windows, move to a desktop), middle-click for a new window.

**Folder fan.** Middle-click the Files icon and your folders spring out of the dock in a fan,
like a stack on macOS: Home nearest the dock, then Downloads, Documents, Desktop, Pictures, Music
and Videos, then your sidebar bookmarks (up to nine), with an arrow at the top that opens Files
itself. Click one to open it there; middle-click again, Esc or a click elsewhere folds the fan
back. (Middle-click on any other app still opens a new window.)

## Icons

Lumen has its own icon theme (`Lumen`, the default; Settings → Appearance → Icon theme):

- **Apps**: 75 original glass designs covering ~540 app icon names (browsers, editors, chat, games,
  media, office, tools). Each shows what the app *does* in its own colours, on Lumen's dark glass
  tile. They are Lumen's own drawings, not the apps' logos.
- **Folders**: glass folders (Documents, Downloads, Music, Pictures, Videos, Desktop, Home,
  Templates, Public, network, code, games, favourites) and a glass bin.

Anything the set doesn't cover falls back to Papirus. `tools/make-icons.py` regenerates the theme;
add an app by adding its icon name to the list there.

## Light mode

Settings → Appearance → **Appearance: Dark / Light** (also a tile in the Control Centre, "light
mode" in Spotlight, or `lumenctl shell light` / `dark`). It switches while you watch:

- **Lumen itself:** bars, menus, widgets, Files, Settings and the login screen change to pale glass
  with dark ink, in Frosted and in Liquid Glass (whose panes turn milky, so dark text reads on any
  wallpaper).
- **Windows:** the glass of windows Lumen decorates turns pale and their titles dark. Over a
  see-through app's own colour (a terminal), the title is whichever of white and dark reads on it.
- **Apps:** GTK apps, Firefox, Chromium and Electron apps follow the desktop setting
  (`org.gnome.desktop.interface color-scheme`) while running; with **Match apps** on, kitty, foot,
  ghostty, Qt (qt5ct/qt6ct) and the rest get a light theme from `lumen-theme`.

The setting is `color_scheme = light` in `lumen.conf`. The light sheets (`style-light.css`) are
generated from the dark ones by `tools/make-light-css.py`; corrections by hand live in
`*-light-extra.css`. A glass tint or title colour you chose yourself is kept in both modes.

The icons follow as well: in light mode the Lumen icon theme becomes **Lumen-Light** (the same
glass icons on pale tiles, also for other GTK apps), and Papirus-Dark becomes Papirus-Light.
Both sets come from `tools/make-icons.py`.

Lumen's own wallpapers (Flow, Dawn, Ocean) each have a light version; if you are using one of
them, switching the mode switches the picture too. Your own pictures are left alone. The light
ones are made by `tools/make_light_wallpapers.py`.

## The everyday things

- **Volume / brightness keys** show the new level in a small glass pill above the taskbar
  (mute and the microphone-mute key too).
- **Right click on the desktop**: Files, Terminal, Change Wallpaper, Edit Widgets, Light / Dark
  Mode, Show All Windows, Screenshot, Settings.
- **Super+S** shows the desktop and brings the windows back; **Super+T** keeps a window on top
  of the others (also "Keep on Top" in a taskbar icon's menu); **Alt+F4** closes;
  **Ctrl+Alt+Del** opens log out / restart / shut down; **Super+I** opens Settings.
- **Super+.** opens the emoji picker: type to search, Enter or a click puts the emoji into the
  window you were typing in (and on the clipboard). Needs `noto-fonts-emoji` (installed by
  `install.sh`).
- **Lumen Files**: New Document, Duplicate (Ctrl+D), Get Info (Ctrl+I: kind, size, folder
  totals, dates, owner, permissions, "allow running as a program"), Set as Wallpaper for
  pictures and videos, and Put Back in the Trash.

## USB drives

Plug in a stick, a disk, a card or a phone and it is mounted, a notification offers to open it,
and it appears under Locations in Lumen Files with an eject button (which unmounts it and, for a
stick or a USB disk, switches it off so it is safe to pull out). Drives that aren't mounted yet
are listed dimmed: a click opens them. Settings → Startup Apps → Drives turns the automatic part
off (`"automount": false` in `shell.json`). This uses `udisks2` and `gvfs` (installed by
`install.sh`, with `gvfs-mtp` for phones and the NTFS / exFAT / FAT tools).

## One colour scheme everywhere

Settings → Appearance → **Accent colour** has an **A** swatch: Auto takes the two colours that
stand out in your wallpaper and follows it when you change the picture. A video wallpaper is
judged by a still from it (made with ffmpegthumbnailer, ffmpeg or GStreamer, whichever is there,
and kept in `~/.cache/lumen/thumbs`). With **Match apps** on
(the default), `lumen-theme` also writes a theme in the current colours for the apps it finds:
GTK 3/4, qt5ct/qt6ct, kitty, foot, ghostty, Firefox through pywalfox (pywal's colour cache),
Spotify through spicetify, and Vesktop/Vencord. It writes only its own files (`lumen-colors.*`,
`Lumen`) plus one line in each app's config so the app reads them, and keeps a `*.lumen-backup`
of any config it touches the first time. `lumen-theme --print` shows the palette without
changing anything.

## Motion

Everything that changes state eases into it, and everything follows Settings → Glass & Motion →
Animation speed (all the way right, or Performance mode, turns it all off):

- At login the Lumen mark comes up on black, then the wallpaper fades in beneath it and settles
  while the mark blooms away; the bars slide in and the dock's icons rise one after another. It
  takes about a second, plays once per login (never when the shell reloads or a screen is plugged
  in) and has its own switch: Settings → Glass & Motion → *Startup animation*
  (`"startup_animation"` in `shell.json`).
- Leaving mirrors arriving: Log Out, Restart and Shut Down sink the desktop to black while the
  mark gathers and dims, and only then end the session (Super+Shift+E too; press it twice, or use
  Super+Shift+Esc, to leave at once). The login screen fades up out of black, and after you sign
  in it fades back to black before the desktop's own startup begins, so nothing cuts.
- Changing the glass style pours one into the other: for most of a second the screen fills with
  liquid from the bottom (or drains), a lit, sloshing surface crossing every pane, while the
  shell's fills and the bar's capsule shape flow across in the same time.
- The taskbar's two shapes are one pane: switching between the dock and the full-width bar
  stretches or gathers it with the icons staying centred. Other settings that change colours
  (accent, tint) flow to their new values, and a changed widget layout arrives card by card.
- Panels that close (Spotlight, a bar when the shell restarts) fade and sink back instead of
  vanishing; Spotlight lifts into place when it opens. The app name in the top bar settles in
  when you switch apps.
- Menus and panels grow out of the thing that opened them with a soft spring and tuck back quickly.
- Start's tiles rise in one after another; the Start orb turns while the menu is open.
- Settings pages rise in group by group; Files glides a folder's contents in from the side you
  are heading to (right going deeper, left going back).
- A screen's desktops are one long line. Leave a window hanging over the edge and the part that
  hangs over is on the next desktop too, at the opposite edge, and it slides across in one piece
  when you switch. Click that part and the window belongs to the desktop you clicked it on. (With
  a second monitor to the left or right, that edge leads to the other screen instead, so those
  screens keep separate desktops.)
- Windows glide to their place when maximised, restored, snapped or tiled (a spring that settles
  without wobbling); desktops slide with a quick start and a long soft landing.
- A window's shadow and its controls ease between focused and background, so focus-follows-mouse
  never flashes.

## Login screen (replaces SDDM)

The login screen shows your wallpaper as it is, with the time large over it, the account on a
card of glass and a small dock for the session and power buttons. The glass follows the selected
account's desktop: Frosted or Liquid Glass, its accent colours and its wallpaper (the shell leaves
a small note in `/var/tmp` for it, since the login screen can't read home folders). Everything
arrives in turn, and logging in fades to black before the desktop's own startup begins.

`lumen-greeter` is a glass login screen for **greetd**, running inside `cage`: blurred
wallpaper, big clock, account avatars, a password pill that shakes on a typo, 2FA/extra PAM
prompts, a session picker (it remembers your last one), and Sleep / Restart / Shut Down.

```sh
sudo pacman -S greetd cage
sudo lumen-greeter-setup            # disables your current DM (e.g. sddm), enables greetd
reboot
sudo lumen-greeter-setup --revert   # puts SDDM back
```
Try it first without changing anything: `lumen-greeter --demo` (the demo password is `lumen`).
Settings live in `/etc/lumen/greeter.json` (copy `/usr/share/lumen/greeter.json`).
Avatars come from `/var/lib/AccountsService/icons/<user>` or a world-readable `~/.face`.
Only Wayland sessions are listed.

![Login screen](docs/screenshots/greeter.jpg)

## Liquid Glass

Settings → **Glass & Motion → Glass style** switches between **Frosted** and **Liquid Glass**.
Liquid Glass is Apple-style: every pane is a thick, clear lens. The middle
magnifies slightly, the curved rim squeezes and bends what's behind it (with colour fringes),
a light-catching edge runs all the way round, and floating panes cast a soft shadow. The taskbar
becomes a floating capsule. Translucent apps (kitty with `background_opacity`, …) and every
titlebar are glass too.

How it works: the compositor renders the scene with every glass item invisible, then goes
bottom → top. For each item it captures what's under it, draws the lens (GLES2 shader,
`compositor/src/liquid_gl.c`) and redraws the item's own content crisp on top, plus anything
stacked above it. So text is never distorted, and glass over glass shows the right thing. The
shell streams its pane shapes over IPC (`glass NS …`).

```ini
glass_style = liquid
liquid_rim = 28            # curved rim width
liquid_refraction = 1.0    # 0 … 3
liquid_frost = 10          # blur behind menus/windows
liquid_highlight = 0.9
```

If the GPU refuses any part of it, Lumen logs it and falls back to frosted glass for the session.

The rim squeezes a long stretch of what is behind a pane into a few pixels. Each rim pixel
averages the whole stretch it covers (and the colour fringes are taken from that same soft
image), so text or fine detail behind an edge shows up as a smooth glassy smear, never as
sparkling garbage. A see-through app under Lumen's titlebar (kitty with `background_opacity`)
is drawn as one pane: the titlebar takes the app's own background colour and the rim light goes
on over the app's content, instead of a light titlebar sitting on a dark box with square corners.

## Mouse & touchpad

Settings → Keyboard & Mouse has separate scroll directions: natural scrolling for touchpads
(on by default) and *Mouse: reverse scroll direction* for wheels (off by default). Both apply
immediately to devices that are already plugged in. (`natural_scroll` / `mouse_natural_scroll`
in `lumen.conf`.)

## Clipboard history

**Super+V** opens your last 60 copies — text, links and images (screenshots included). Type to
filter, arrows + Enter (or a click) pastes into the window you were in, Delete removes one.
Password managers' secrets are never stored. History lives in `~/.cache/lumen/clipboard`.

## Performance mode

For games and battery life: no blur, shadows, animations or moving wallpaper. One click in the
Control Centre (the ⚡ tile) or Settings → Glass & Motion. Fullscreen games are also left alone:
a game that minimises itself when it loses focus (GLFW/SDL "auto-iconify") isn't minimised
when you Alt+Tab to another monitor, the mouse pointer is hidden while a game captures it, and
games can re-centre the cursor (`pointer-warp`).

## Video wallpapers

Pick an `.mp4`/`.webm` in Settings → Appearance (Add Picture or Video…, or drop files in
`~/Pictures/Wallpapers` / `~/Videos/Wallpapers`). It loops silently and pauses on any screen
showing a fullscreen app, and in Performance mode.

## Instant Files & Settings

Lumen Files and Settings stay ready in the background (about 60 MB each), so they open
instantly; `lumen-files` / `lumen-settings` hand the request to the running app over D-Bus.
Turn it off in Settings → Glass & Motion → *Keep Files and Settings ready*.

## Screen sharing

Discord/Vesktop, OBS, browsers and Zoom share your screen through the desktop portal.
Lumen ships the portal setup (`lumen-portals.conf`, run at every login by `lumen-portals`), so
when an app asks to share, your cursor becomes a picker: **click the monitor to share**. The
wlroots portal shares whole monitors (not single windows).

## Games

Lumen supports pointer lock and raw mouse motion (`pointer-constraints` + `relative-pointer`),
so games can capture the mouse for mouse-look or keep it inside their window: native Wayland
games, and XWayland/Steam/Proton/Minecraft alike.

## Multiple displays

Each display shows its own desktop (10 in total). Super+1…0 switches the display under the
pointer; picking a desktop that's already up on another display takes you there. Settings →
Sound & Display → Displays shows your screens to scale: **drag them** to match your desk (they
snap edge to edge and never overlap), and set orientation (landscape / portrait), resolution and
scale per screen. Turning one to portrait moves its neighbours along, so nothing ends up cut off. Changes
are staged until you press **Apply**; then you get 15 seconds to choose **Keep changes**, or
everything goes back by itself (the compositor runs that timer, so it works even if the screen
goes blank or Settings is closed).
It's saved as `output = NAME mode=… scale=… transform=… pos=X,Y` lines in `lumen.conf`.

## Windows

- **Snap layouts** (Windows 11): drag a window to the top of a display and a layout bar drops
  down. Drop on a zone, or on the first block to maximise. Hover a window's maximise button for
  the same layouts. Dragging to a side snaps to half, a corner to a quarter.
- **Drag between desktops**: hold a dragged window against the left or right edge of the
  screen (where there's no other monitor) and it flies off to the previous / next desktop;
  the desktop you're on stays put, and a small notification says where it went. On multiple
  monitors just carry it across: it joins whatever desktop that monitor shows. A quick drop at
  a side edge still snaps to half.
- **Focus follows mouse** (on by default, Settings → Windows): the window under the pointer
  gets the keyboard, without being raised.
- **Drag and drop** between and inside apps (files out of Lumen Files, browser tabs, selected
  text): the thing you drag follows the cursor and lands on whatever you drop it on.
- **Held buttons stay put**: while a mouse button is down, the pointer belongs to the window it
  was pressed in. Dragging a scrollbar or a selection past the window's edge keeps working and
  never hands focus to the window underneath.
- **Genie animations**: windows flow out of their taskbar icon when they open or come back
  from being minimised, and pour back into it when minimised (Settings → Glass & Motion →
  Animations turns all motion off).
- **Autotiling** (Settings → Windows): Hyprland-style dwindle. New windows split the screen,
  Super+Shift+V floats one, and dragging a tiled window onto another swaps them.
- **Touchpad**: 3 fingers ↑ overview, ← → desktops; 4 fingers ↓ show the desktop, ↑ bring windows
  back, ← → previous / next window; 3-finger pinch in = overview, pinch out = show desktop.
- **Window controls**: macOS traffic-light colours with Windows 11 manners. They sit on the left
  like macOS and Lumen Files (close, minimise, maximise), show thin glyphs on hover, and the one
  under the pointer becomes a rounded button. Settings → Windows can move them to the right.

## If something crashes

The session log is `~/.local/state/lumen/lumen.log` (the previous session's is `lumen.log.old`).
If Lumen ever crashes, the end of that file has a backtrace; `coredumpctl info lumen` shows
the same. Send either along with what you were doing.

## Notifications

Lumen has its own notification service (it replaces mako/dunst; the shell owns
`org.freedesktop.Notifications`, so every app's notifications land here):

- **Pop-ups** slide in at the top right as frosted glass cards. They show the app icon, title, body (bold/italic/links), image previews, action
  buttons and **inline reply** for apps that support it. They stack up to four, stay while you
  hover, and fade out after 6 s (adjustable). Urgent ones stay until you dismiss them.
- **Notification Centre**: the bell in the top bar, or Super+N. History is grouped by app,
  with long groups folded ("Show 3 more") and Clear / Clear all. It's kept across restarts.
  The bell shows a dot for unread notifications.
- **Do Not Disturb**: from the Centre, the Control Centre or Settings, plus **quiet hours**
  (e.g. 22:00–07:00). Notifications still arrive, just silently; urgent ones still show.
- **Settings → Notifications**: sound on/off, how long pop-ups stay, a test button, and per-app
  rules (allow, pop-ups, sound).

## Terminal

`install.sh` sets up the terminal look from the screenshots: `~/.bashrc` (a `~ ❯` prompt in
the accent colours, git branch, a red arrow after a failed command, window titles like
`~ — fastfetch`) and `~/.config/fastfetch/config.jsonc` (you@host, accent keys and a row of glass
dots). Your previous files are saved next to them as `*.pre-lumen-DATE`. Put personal additions
in `~/.bashrc.local`, which is kept across updates. The kitty theme include is kept as the last
line of `kitty.conf`, so Lumen's titlebar and window controls aren't hidden by older settings.

## Spotlight

Super+Space opens a search bar in the middle of the screen; it is a panel of the shell, so it is
there at once. Type and results grow out underneath. Five categories along the bottom (Ctrl+Tab
or Shift+←/→, or click):

- **All:** apps, open windows, recent files, sums (`12*(3+4)`, Enter copies the answer), things
  the system can do by name (Lock Screen, Sleep, Log Out, Restart, Shut Down, Light/Dark Mode,
  Screenshot, Do Not Disturb, Empty Trash; "reboot" and "power off" work too) and a web search.
- **Apps:** every installed app, best match first; with nothing typed, the whole list.
- **Run:** commands from your PATH; whatever you typed can be run as it stands, arguments and all.
- **Windows:** every open window on every desktop; Enter switches to it.
- **Files:** your home folder, or any path you type (`~/Doc`, `/etc/`). Enter on a folder goes
  into it, on a file opens it.

Matching is fuzzy ("fx" finds Firefox). ↑/↓ or Tab move a highlight that glides between rows (the
list scrolls, also with the wheel and Page Up/Down); Enter opens; Esc or a click outside closes.
A row whose result changes while you type settles in rather than swapping. `lumen-launcher` asks
the running shell for it and falls back to rofi when the shell isn't running (or when given rofi
arguments); another launcher set as `launcher` in `lumen.conf` is started instead.

## Lumen Files

A macOS-style file manager with layered depth: a floating sidebar card, toolbar pills, an elevated
content sheet, and icons that lift on hover. It has icon and list views, image thumbnails, a
breadcrumb path, search, hidden files (Ctrl+H), copy/cut/paste, rename (F2), Trash (Delete), Open
With, drag-in from other apps, and mounted drives. It's the default for Super+E and for opening
folders.

**Typing a path:** click the path bar (beside the folder names, or on the name of the folder you
are in) or press Ctrl+L, and it becomes a text field with the current path selected. `~`, `$VARS`
and paths relative to the current folder work; Tab finishes a folder name (or lists the
candidates); Enter goes there; a file's path opens its folder with the file selected; Esc cancels.

**Also:** start typing over the files to jump to a name (keep typing to narrow it down); Ctrl+N
new window, Ctrl+W close, Ctrl+A select all, F5 reload, Esc clear the selection. A new window opens
the way the last one was left: icon or list view, hidden files, size.

Things move here too: a folder's contents (and the breadcrumbs) glide in from the side you are
heading to; files that appear (created, pasted, extracted, matching the search again) pop into
place; files you trash or delete shrink away first; thumbnails fade in as they load; switching
between icons and list cross-fades.

## Desktop widgets

Clock, Weather (wttr.in, no account), Calendar, System and Now Playing, as glass cards on the
desktop. Like Apple's, each comes in four sizes that show different things:

| | Small (square) | Wide | Tall | Large |
|---|---|---|---|---|
| Clock | time + date | day, time, full date | analog + time | big analog + time |
| Weather | temp + conditions | now + next hours | now + next days | hourly + 3-day |
| Calendar | today | today + this week | month | month, roomy |
| System | CPU ring | 4 bars | bars + uptime/load | 4 rings |
| Now Playing | art + play | song + controls | big art + controls | big art + controls |

**Settings → Desktop Widgets** has a live layout preview. Pick a corner (↖ ↗ ↙ ↘) and the
number of columns, add, remove, reorder and resize widgets, and set the weather city and units.
Widgets pack into the grid like iOS. They're frosted or Liquid Glass automatically, following
the system glass style.

## Keys & gestures

| Keys | Action |
|---|---|
| tap **Super** | Start menu |
| Super + Space / D | Spotlight |
| Super + S | show the desktop (again: the windows come back) |
| Super + T | keep the window on top of the others |
| Super + . | emoji picker (types into the window you were in) |
| Super + I | System Settings |
| Alt + F4 | close window |
| Ctrl + Alt + Del | log out · restart · shut down |
| Super + Tab | Overview (all windows) |
| Super + Q · Return | terminal |
| Super + B | browser (a new window if it's already open) |
| Super + E | Lumen Files |
| Super + Esc / W | close window (animated) |
| Super + F · F11 | maximise · fullscreen |
| Super + M / H | minimise |
| Super + V | clipboard history (text + images; Enter pastes) |
| Super + Shift + V | float / tile the window (autotiling) |
| Super + 1…0 | desktop 1–10 on the display under the pointer |
| Super + Shift + 1…0 | move window to desktop 1–10 |
| Super + ← / → | previous / next desktop |
| Super + Shift + ← / → | take the window along to the previous / next desktop |
| Super + Ctrl + ← / → | snap the window to the left / right half |
| Super + ↑ · ↓ | maximise · restore (again: minimise) |
| Alt + Tab | window switcher with live previews (hold Alt, Tab / Shift+Tab / arrows, release to switch, Esc cancels, Delete closes) |
| Super + A · C · N | Start menu · Control Centre · Notification Centre |
| Super + L | lock screen |
| Super + Shift + S · Print | region screenshot |
| Super + Shift + R | reload config |
| Super + Shift + E | quit Lumen |
| Super + drag / right-drag | move / resize |
| drag a window to the top edge | Windows 11 snap layouts (or hover its maximise button) |
| drag to a side / corner | snap to a half / quarter |

**Touchpad (3 fingers, GNOME-style):** swipe **up** for the overview (follows your fingers),
swipe **down** to close it, swipe **left/right** to move between desktops. In the overview: click a
window to pick it, click a desktop pill to switch, start typing to search, Esc to leave.
Pinch and other gestures still go to apps (e.g. pinch-zoom in Firefox).

## Configure
- `~/.config/lumen/lumen.conf`: blur, tint, radius, shadow, animation speed, keyboard, autostart
- `~/.config/lumen/shell.json`: pinned apps, wallpaper, icon theme, 24h clock
- `~/.config/lumen/shell.css`: optional overrides layered on the built-in stylesheet
- `lumenctl state | subscribe | workspace N | focus ID | toggle ID | close ID | move ID WS | place ID X Y | snap ID left|right | overview | lock | reload | quit | stats`

## Status: read this
Lumen 0.1 is a **first, untested build**. It was written and checked in a sandbox where
compiling the graphics stack wasn't allowed, so:
- The compositor **compiles and links** cleanly against wlroots 0.20.2 and SceneFX 0.5.0.
  It has **not been run on real hardware yet**: the build machine had no GPU/DRM device, which
  SceneFX needs. Expect a round of fixes on first boot.
- The shell runs (GTK 4.14), and the screenshots are its real widgets. Window frames and blur
  in the screenshots are reproduced offscreen to match what the compositor draws.
- XWayland starts lazily the first time an X11 app launches (`xwayland = false` turns it off).
- Known gaps: one wallpaper and bar set per
  monitor but window placement assumes the monitor under the cursor, no global app menus
  (Wayland has no standard for them; the Window/Go menus act on the focused window), and the
  lock screen relies on swaylock.

Debug a session with `lumen -d 2> ~/lumen.log`.

MIT licensed.
