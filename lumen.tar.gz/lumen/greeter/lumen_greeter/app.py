"""lumen-greeter: a liquid-glass login screen for greetd.

Runs fullscreen inside a kiosk compositor (cage). The glass look doesn't depend
on compositor blur: the greeter blurs the wallpaper itself."""
import glob
import json
import os
import pwd
import sys
import threading
import time

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, Gio, GLib, Gtk  # noqa: E402

from .greetd import FakeGreetd, Greetd, GreetdError  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
STATE_DIR = os.environ.get("LUMEN_GREETER_STATE", "/var/cache/lumen-greeter")
CONFIG = "/etc/lumen/greeter.json"
DEFAULTS = {
    "wallpaper": "/usr/share/backgrounds/lumen/lumen-flow.jpg",
    "default_session": "lumen",
    "clock_24h": False,
    "min_uid": 1000,
}


def load_config():
    cfg = dict(DEFAULTS)
    try:
        with open(CONFIG) as f:
            cfg.update(json.load(f))
    except (OSError, ValueError):
        pass
    if not os.path.exists(cfg["wallpaper"]):
        cfg["wallpaper"] = os.path.abspath(os.path.join(HERE, "..", "..", "data", "wallpapers", "lumen-flow.jpg"))
    return cfg


# --------------------------------------------------------------- system data
def list_users(min_uid=1000):
    out = []
    for p in pwd.getpwall():
        if min_uid <= p.pw_uid < 60000 and not p.pw_shell.endswith(("nologin", "false")):
            out.append({"name": p.pw_name, "real": (p.pw_gecos.split(",")[0] or p.pw_name).strip(),
                        "home": p.pw_dir})
    return sorted(out, key=lambda u: u["name"])


def avatar_path(user):
    for p in (f"/var/lib/AccountsService/icons/{user['name']}", os.path.join(user["home"], ".face"),
              os.path.join(user["home"], ".face.icon")):
        if os.path.isfile(p) and os.access(p, os.R_OK):
            return p
    return None


def list_sessions():
    """Wayland sessions from /usr/share/wayland-sessions (key = desktop file stem)."""
    out = {}
    for path in sorted(glob.glob("/usr/share/wayland-sessions/*.desktop")):
        kf = GLib.KeyFile()
        try:
            kf.load_from_file(path, GLib.KeyFileFlags.NONE)
            name = kf.get_locale_string("Desktop Entry", "Name", None)
            exe = kf.get_string("Desktop Entry", "Exec")
        except GLib.Error:
            continue
        try:
            if kf.get_boolean("Desktop Entry", "Hidden") or kf.get_boolean("Desktop Entry", "NoDisplay"):
                continue
        except GLib.Error:
            pass
        try:
            names = kf.get_string("Desktop Entry", "DesktopNames")
        except GLib.Error:
            names = name
        key = os.path.basename(path)[:-8]
        exe = " ".join(w for w in exe.split() if not (w.startswith("%") and len(w) == 2))
        out[key] = {"name": name, "exec": exe, "desktop": names.replace(";", ":").strip(":")}
    return out


class State:
    def __init__(self):
        self.path = os.path.join(STATE_DIR, "state.json")
        try:
            self.data = json.load(open(self.path))
        except (OSError, ValueError):
            self.data = {}

    def save(self):
        try:
            os.makedirs(STATE_DIR, exist_ok=True)
            with open(self.path, "w") as f:
                json.dump(self.data, f)
        except OSError:
            pass   # read-only state dir: just don't remember


# --------------------------------------------------------------- widgets
def lbl(text="", cls=None, **kw):
    w = Gtk.Label(label=text, **kw)
    for c in (cls or "").split():
        w.add_css_class(c)
    return w


def avatar_widget(user, size, cls="avatar"):
    path = avatar_path(user) if user else None
    if path:
        pic = Gtk.Picture.new_for_filename(path)
        pic.set_content_fit(Gtk.ContentFit.COVER)
        pic.set_size_request(size, size)
        frame = Gtk.Box(halign=Gtk.Align.CENTER)
        frame.add_css_class(cls)
        frame.add_css_class("photo")
        frame.set_overflow(Gtk.Overflow.HIDDEN)
        frame.append(pic)
        return frame
    initials = "".join(p[0] for p in (user["real"] if user else "?").split()[:2]).upper() or "?"
    a = lbl(initials, cls, halign=Gtk.Align.CENTER)
    a.set_size_request(size, size)
    return a


def user_prefs(user):
    """What this account's desktop looks like (glass style, accents, wallpaper):
    the shell leaves a small note for the login screen, which can't read home
    folders. Only a note that really belongs to that account is believed."""
    out = {}
    try:
        import pwd
        uid = pwd.getpwnam(user["name"]).pw_uid
        path = f"/var/tmp/lumen-greeter-{uid}.json"
        st = os.stat(path)
        if st.st_uid == uid and st.st_size < 4096:
            with open(path) as f:
                data = json.load(f)
            if data.get("glass_style") in ("liquid", "frosted"):
                out["glass_style"] = data["glass_style"]
            if data.get("color_scheme") in ("light", "dark"):
                out["color_scheme"] = data["color_scheme"]
            for k in ("accent", "accent2"):
                v = data.get(k)
                if isinstance(v, str) and len(v) == 7 and v[0] == "#" and all(c in "0123456789abcdefABCDEF" for c in v[1:]):
                    out[k] = v
            w = data.get("wallpaper")
            if isinstance(w, str) and w.lower().endswith((".jpg", ".jpeg", ".png", ".webp")) and os.access(w, os.R_OK):
                out["wallpaper"] = w
    except (KeyError, OSError, ValueError, ImportError):
        pass
    return out


def glass_textures(path):
    """the wallpaper twice: as it is (Liquid Glass looks through clear glass) and
    softened (Frosted). The soft one is made by shrinking and growing the picture,
    once, so nothing has to be blurred while the screen is up."""
    from gi.repository import GdkPixbuf
    try:
        sharp = Gdk.Texture.new_from_filename(path)
        small = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, 64, 64, True)
        soft = small.scale_simple(small.get_width() * 6, small.get_height() * 6, GdkPixbuf.InterpType.BILINEAR)
        soft.saturate_and_pixelate(soft, 1.35, False)
        return sharp, Gdk.Texture.new_for_pixbuf(soft)
    except GLib.Error:
        return None, None


class Backdrop(Gtk.Widget):
    """the piece of wallpaper behind a pane, drawn exactly where the screen's own
    wallpaper is (so the pane reads as glass), clipped to the pane's corners"""

    def __init__(self, greeter, radius):
        super().__init__()
        self.g, self.radius, self.at = greeter, radius, (0, 0)

    def do_snapshot(self, snap):
        from gi.repository import Graphene, Gsk
        g = self.g
        tex = g.textures[0 if g.glass == "liquid" else 1]
        w, h = self.get_width(), self.get_height()
        W, H = g.root.get_width(), g.root.get_height()
        if tex is None or w < 2 or h < 2 or W < 2 or H < 2:
            return
        tw, th = tex.get_intrinsic_width(), tex.get_intrinsic_height()
        k = max(W / tw, H / th)                      # the same "cover" fit as the background
        x0, y0 = (W - tw * k) / 2, (H - th * k) / 2
        z = 1.06 if g.glass == "liquid" else 1.0     # clear glass magnifies a little, about its centre
        ox, oy = self.at
        cx, cy = ox + w / 2, oy + h / 2
        rect = Graphene.Rect().init((x0 - cx) * z + cx - ox, (y0 - cy) * z + cy - oy, tw * k * z, th * k * z)
        clip = Gsk.RoundedRect()
        clip.init_from_rect(Graphene.Rect().init(0, 0, w, h), self.radius)
        snap.push_rounded_clip(clip)
        snap.append_texture(tex, rect)
        snap.pop()


class GlassPane(Gtk.Overlay):
    """A panel of glass. Behind its content sits the wallpaper itself, lined up
    with the one on the screen: softened for Frosted, clear and slightly
    magnified for Liquid Glass (a lens). CSS adds the tint, rim and highlights."""

    def __init__(self, greeter, child, cls, radius):
        super().__init__(halign=Gtk.Align.CENTER)
        self.g = greeter
        self.back = Backdrop(greeter, radius)
        self.set_child(self.back)
        child.add_css_class("pane")
        self.add_overlay(child)
        self.set_measure_overlay(child, True)
        for c in ("glasspane", cls):
            self.add_css_class(c)
        self._key = None
        self.add_tick_callback(self.follow)

    def follow(self, *_a):
        root = self.g.root
        ok, b = self.compute_bounds(root)
        if ok:
            key = (root.get_width(), root.get_height(), round(b.origin.x), round(b.origin.y),
                   self.g.glass, self.g.tex_serial)
            if key != self._key:                      # moved, resized, or another look: draw again
                self._key = key
                self.back.at = (b.origin.x, b.origin.y)
                self.back.queue_draw()
        return True


class Greeter:
    def __init__(self, app, demo=False, preview=False):
        self.app, self.demo, self.preview = app, demo, preview
        self.cfg = load_config()
        self.state = State()
        self.users = list_users(self.cfg["min_uid"])
        if not self.users or demo or preview:
            self.users = self.users or [{"name": "you", "real": "You", "home": "/nonexistent"}]
        self.sessions = list_sessions()
        if not self.sessions:
            self.sessions = {"lumen": {"name": "Lumen", "exec": "start-lumen", "desktop": "Lumen"}}
        last = self.state.data.get("user")
        self.user = next((u for u in self.users if u["name"] == last), self.users[0])
        self.busy = False
        self.client = None
        self.pending = None
        # until an account says otherwise: greeter.json's "glass_style" (frosted)
        self.default_glass = os.environ.get("LUMEN_GREETER_GLASS") or self.cfg.get("glass_style", "frosted")
        self.glass = self.default_glass
        self.wallpaper = self.cfg["wallpaper"]
        self.textures = glass_textures(self.wallpaper)
        self.tex_serial = 0
        self._accent = None
        self.build()

    # ---------------------------------------------------------------- UI
    def build(self):
        self.win = Gtk.Window(application=self.app, title="Lumen")
        self.win.set_decorated(False)
        self.win.add_css_class("greeter")

        root = Gtk.Overlay()
        bg = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True)
        if self.textures[0] is not None:
            bg.set_paintable(self.textures[0])
        else:
            bg.set_filename(self.wallpaper)
        bg.add_css_class("bg")
        self.bg = bg
        root.set_child(bg)
        shade = Gtk.Box(hexpand=True, vexpand=True)
        shade.add_css_class("shade")
        root.add_overlay(shade)
        self.root = root

        self.ui = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True, vexpand=True)
        self.ui.add_css_class("ui")
        root.add_overlay(self.ui)

        # the time, large and light, over the picture itself
        top = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, halign=Gtk.Align.CENTER, margin_top=74)
        self.date = lbl("", "date")
        self.clock = lbl("", "clock")
        top.append(self.date)
        top.append(self.clock)
        self.ui.append(top)
        self.ui.append(Gtk.Box(vexpand=True))

        # the account, on a card of glass
        self.card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.card.add_css_class("account")
        self.avatar_slot = Gtk.Box(halign=Gtk.Align.CENTER)
        self.card.append(self.avatar_slot)
        self.name = lbl("", "name")
        self.card.append(self.name)

        pill = Gtk.Overlay(halign=Gtk.Align.CENTER)
        self.pw = Gtk.PasswordEntry(show_peek_icon=False, placeholder_text="Enter Password")
        self.pw.add_css_class("password")
        self.pw.set_size_request(288, 42)
        self.pw.connect("activate", lambda *_: self.submit())
        self.pw.connect("changed", lambda *_: self.go.set_visible(bool(self.pw.get_text()) and not self.busy))
        pill.set_child(self.pw)
        self.go = Gtk.Button(icon_name="go-next-symbolic", halign=Gtk.Align.END, valign=Gtk.Align.CENTER)
        self.go.add_css_class("go")
        self.go.set_visible(False)
        self.go.connect("clicked", lambda *_: self.submit())
        pill.add_overlay(self.go)
        self.spinner = Gtk.Spinner(halign=Gtk.Align.END, valign=Gtk.Align.CENTER, margin_end=12)
        pill.add_overlay(self.spinner)
        self.pill = pill
        self.card.append(pill)

        self.msg = lbl("", "msg")
        self.card.append(self.msg)

        # other users
        self.others = Gtk.Box(halign=Gtk.Align.CENTER, spacing=18)
        self.others.add_css_class("others")
        self.card.append(self.others)
        self.card_pane = GlassPane(self, self.card, "card-pane", 30)
        self.ui.append(self.card_pane)
        self.ui.append(Gtk.Box(vexpand=True))

        # a dock, like the desktop's: the session on the left, power on the right
        dock = Gtk.Box(spacing=6)
        dock.add_css_class("dock")
        self.session_btn = Gtk.MenuButton(valign=Gtk.Align.CENTER, direction=Gtk.ArrowType.UP)
        self.session_btn.add_css_class("session")
        pop = Gtk.Popover()
        pop.add_css_class("glass-pop")
        lst = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        for key, s in self.sessions.items():
            b = Gtk.Button(label=s["name"])
            b.add_css_class("pop-item")
            b.connect("clicked", lambda _b, k=key: (self.set_session(k), pop.popdown()))
            lst.append(b)
        pop.set_child(lst)
        self.session_btn.set_popover(pop)
        dock.append(self.session_btn)
        sep = Gtk.Box(valign=Gtk.Align.CENTER)
        sep.add_css_class("dock-sep")
        dock.append(sep)
        for icon, label, cmd in (("weather-clear-night-symbolic", "Sleep", "systemctl suspend"),
                                 ("system-reboot-symbolic", "Restart", "systemctl reboot"),
                                 ("system-shutdown-symbolic", "Shut Down", "systemctl poweroff")):
            b = Gtk.Button(icon_name=icon, tooltip_text=label, valign=Gtk.Align.CENTER)
            b.add_css_class("power")
            b.connect("clicked", lambda _b, c=cmd: self.power(c))
            dock.append(b)
        self.dock_pane = GlassPane(self, dock, "dock-pane", 26)
        self.dock_pane.set_margin_bottom(26)
        self.ui.append(self.dock_pane)
        self.win.add_css_class(self.glass)

        k = Gtk.EventControllerKey()
        k.connect("key-pressed", self.on_key)
        self.win.add_controller(k)
        self.win.set_child(root)

        self.select_user(self.user, animate=False)
        self.tick()
        GLib.timeout_add_seconds(1, self.tick)

    def tick(self):
        now = time.localtime()
        self.date.set_label(time.strftime("%A, %B %-d", now))
        self.clock.set_label(time.strftime("%H:%M" if self.cfg["clock_24h"] else "%-I:%M", now))
        return True

    def set_session(self, key):
        self.session = key
        self.session_btn.set_label(self.sessions[key]["name"])

    def apply_prefs(self, user):
        """the login screen takes on the look of the account that is selected"""
        pr = user_prefs(user)
        glass = pr.get("glass_style", self.default_glass)
        if glass != self.glass:
            self.win.remove_css_class(self.glass)
            self.glass = glass
            self.win.add_css_class(glass)
            self.tex_serial += 1
        set_scheme(pr.get("color_scheme", os.environ.get("LUMEN_GREETER_SCHEME", "dark")) == "light")
        wall = pr.get("wallpaper", self.cfg["wallpaper"])
        if wall != self.wallpaper:
            tex = glass_textures(wall)
            if tex[0] is not None:
                self.wallpaper, self.textures = wall, tex
                self.bg.set_paintable(tex[0])
                self.tex_serial += 1
        if "accent" in pr:
            css = f"@define-color accent {pr['accent']}; @define-color accent2 {pr.get('accent2', pr['accent'])};"
            if self._accent is None:
                self._accent = Gtk.CssProvider()
                Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), self._accent,
                                                          Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)
            self._accent.load_from_string(css) if hasattr(self._accent, "load_from_string") \
                else self._accent.load_from_data(css.encode(), -1)

    def select_user(self, user, animate=True):
        self.cancel()
        self.user = user
        self.apply_prefs(user)
        child = self.avatar_slot.get_first_child()
        if child:
            self.avatar_slot.remove(child)
        av = avatar_widget(user, 112)
        if animate:
            av.add_css_class("pop-in")
        self.avatar_slot.append(av)
        self.name.set_label(user["real"])
        self.msg.set_label("")
        self.pw.set_text("")
        self.pw.set_property("placeholder-text", "Enter Password")
        remembered = self.state.data.get("sessions", {}).get(user["name"])
        key = remembered if remembered in self.sessions else (
            self.cfg["default_session"] if self.cfg["default_session"] in self.sessions else next(iter(self.sessions)))
        self.set_session(key)
        # row of the other accounts
        child = self.others.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.others.remove(child)
            child = nxt
        for u in self.users:
            if u is user:
                continue
            col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            col.append(avatar_widget(u, 52, "avatar small"))
            col.append(lbl(u["real"], "other-name"))
            b = Gtk.Button(child=col)
            b.add_css_class("other")
            b.connect("clicked", lambda _b, uu=u: self.select_user(uu))
            self.others.append(b)
        GLib.idle_add(self.focus_password)

    def focus_password(self):
        self.pw.grab_focus()
        self.pw.set_position(-1)
        return False

    def on_key(self, ctrl, keyval, keycode, state):
        if keyval == Gdk.KEY_Escape:
            self.pw.set_text("")
            self.msg.set_label("")
            return True
        return False

    # ---------------------------------------------------------------- auth
    def set_busy(self, busy):
        self.busy = busy
        self.pw.set_sensitive(not busy)
        self.go.set_visible(not busy and bool(self.pw.get_text()))
        self.spinner.set_visible(busy)
        self.spinner.set_spinning(busy)

    def connect_client(self):
        if self.client is None:
            self.client = FakeGreetd() if (self.demo or self.preview) else Greetd()
        return self.client

    def cancel(self):
        if self.client is not None:
            self.client.cancel()
        self.pending = None

    def submit(self):
        if self.busy:
            return
        secret = self.pw.get_text()
        self.set_busy(True)
        self.msg.set_label("")

        def work():
            try:
                c = self.connect_client()
                if self.pending is None:
                    r = c.create_session(self.user["name"])
                else:
                    r = self.pending
                # walk the PAM conversation: answer the first secret/visible prompt with
                # what was typed, acknowledge info/error messages
                answered = False
                while r.get("type") == "auth_message":
                    kind = r["auth_message_type"]
                    if kind in ("secret", "visible"):
                        if answered:   # a second prompt (2FA, expired password…): ask the user
                            GLib.idle_add(self.prompt_more, r)
                            return
                        r = c.respond(secret)
                        answered = True
                    else:
                        GLib.idle_add(self.msg.set_label, r["auth_message"].strip())
                        r = c.respond(None)
                if r.get("type") == "success":
                    GLib.idle_add(self.authenticated)
                else:
                    c.cancel()
                    GLib.idle_add(self.failed, r.get("description", "Authentication failed"))
            except (OSError, GreetdError) as e:
                self.client = None
                GLib.idle_add(self.failed, str(e))
        threading.Thread(target=work, daemon=True).start()

    def prompt_more(self, r):
        self.pending = r
        self.set_busy(False)
        self.pw.set_text("")
        self.pw.set_property("placeholder-text", r["auth_message"].strip().rstrip(":") or "Enter Code")
        self.focus_password()

    def failed(self, why):
        self.pending = None
        self.set_busy(False)
        self.pw.set_text("")
        self.pw.set_property("placeholder-text", "Enter Password")
        self.msg.set_label("Incorrect password" if "auth" in why.lower() else why)
        self.pill.remove_css_class("shake")
        GLib.idle_add(lambda: (self.pill.add_css_class("shake"), False)[1])
        GLib.timeout_add(600, lambda: (self.pill.remove_css_class("shake"), False)[1])
        self.pw.grab_focus()

    def authenticated(self):
        s = self.sessions[self.session]
        env = ["XDG_SESSION_TYPE=wayland", f"XDG_SESSION_DESKTOP={self.session}",
               f"XDG_CURRENT_DESKTOP={s['desktop']}"]
        try:
            r = self.client.start_session(["/bin/sh", "-c", s["exec"]], env)
        except (OSError, GreetdError) as e:
            return self.failed(str(e))
        if r.get("type") != "success":
            return self.failed(r.get("description", "Could not start session"))
        self.state.data["user"] = self.user["name"]
        self.state.data.setdefault("sessions", {})[self.user["name"]] = self.session
        self.state.save()
        self.leave()

    LEAVE_MS = 640    # the fade below, plus a frame or two so black is really on screen

    def leave(self, then=None):
        """Logging in: the clock and the account fade away and the wallpaper sinks to
        black, then the greeter goes. The session comes up on black as well (and
        raises the Lumen mark out of it), so nothing cuts from one to the other."""
        self.ui.add_css_class("leaving")
        self.win.add_css_class("leaving")
        GLib.timeout_add(self.LEAVE_MS, lambda: ((then or self.app.quit)(), False)[1])

    def power(self, cmd):
        if self.demo or self.preview:
            print("would run:", cmd)
            return
        Gio.Subprocess.new(cmd.split(), Gio.SubprocessFlags.NONE)


# ------------------------------------------------------------------- app
_look = {"prov": None, "light": None}


def set_scheme(light):
    """dark or light, like the account that is selected (its shell leaves a note)"""
    if _look["prov"] is None:
        _look["prov"] = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), _look["prov"],
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    if _look["light"] == light:
        return
    _look["light"] = light
    alt = os.path.join(HERE, "style-light.css")
    _look["prov"].load_from_path(alt if light and os.path.exists(alt) else os.path.join(HERE, "style.css"))
    st = Gtk.Settings.get_default()
    if st.get_property("gtk-application-prefer-dark-theme") != (not light):
        st.set_property("gtk-application-prefer-dark-theme", not light)


def load_css():
    set_scheme(os.environ.get("LUMEN_GREETER_SCHEME", "dark") == "light")
    st = Gtk.Settings.get_default()
    st.set_property("gtk-entry-select-on-focus", False)   # typing never lands on a selection
    st.set_property("gtk-im-module", "gtk-im-context-simple")
    for theme in ("Papirus-Dark", "Adwaita"):
        if os.path.isdir(f"/usr/share/icons/{theme}"):
            if st.get_property("gtk-icon-theme-name") != theme:
                st.set_property("gtk-icon-theme-name", theme)
            break


def render_preview(g, out, state):
    gi.require_version("Graphene", "1.0")
    from gi.repository import Graphene
    W, H = 1920, 1080
    g.win.set_default_size(W, H)
    g.root.set_size_request(W, H)
    g.win.present()
    loop = GLib.MainLoop()

    def snap():
        if state == "typing":
            g.pw.set_text("lumen")
            g.pw.select_region(-1, -1)
            g.pw.set_position(-1)
        elif state == "wrong":
            g.msg.set_label("Incorrect password")
        GLib.timeout_add(400, shoot)
        return False

    def shoot():
        p = Gtk.WidgetPaintable.new(g.root)
        s = Gtk.Snapshot()
        p.snapshot(s, W, H)
        tex = g.win.get_renderer().render_texture(s.to_node(), Graphene.Rect().init(0, 0, W, H))
        tex.save_to_png(out)
        print("wrote", out)
        loop.quit()
        return False
    GLib.timeout_add(1500, snap)
    loop.run()


def main():
    args = sys.argv[1:]
    demo = "--demo" in args
    if "--preview" in args:
        out = args[args.index("--preview") + 1]
        state = args[args.index("--state") + 1] if "--state" in args else "idle"
        load_css()
        g = Greeter(None, preview=True)
        if "--users" in args:   # sample accounts to show the switcher
            g.users = [{"name": n.lower(), "real": n, "home": "/nonexistent"}
                       for n in args[args.index("--users") + 1].split(",")]
            g.select_user(g.users[0], animate=False)
        render_preview(g, out, state)
        return 0

    app = Gtk.Application(application_id="dev.lumen.Greeter", flags=Gio.ApplicationFlags.NON_UNIQUE)
    app.set_resource_base_path(None)   # (or GTK reads the icon theme twice at startup)

    def activate(a):
        load_css()
        g = Greeter(a, demo=demo)
        g.win.fullscreen()
        g.win.present()
    app.connect("activate", activate)
    return app.run([sys.argv[0]])
