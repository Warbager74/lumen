"""Minimal greetd IPC client (see greetd_ipc: u32 native-endian length + JSON).

Requests : create_session{username} · post_auth_message_response{response}
           start_session{cmd, env} · cancel_session
Responses: success · error{error_type, description}
           auth_message{auth_message_type: visible|secret|info|error, auth_message}
"""
import json
import os
import socket
import struct
import time


class GreetdError(Exception):
    pass


class Greetd:
    def __init__(self, path=None):
        path = path or os.environ.get("GREETD_SOCK")
        if not path:
            raise GreetdError("GREETD_SOCK is not set — is lumen-greeter running under greetd?")
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect(path)

    def _recv_exact(self, n):
        buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise GreetdError("greetd closed the connection")
            buf += chunk
        return buf

    def request(self, msg: dict) -> dict:
        body = json.dumps(msg).encode()
        self.sock.sendall(struct.pack("=I", len(body)) + body)
        (length,) = struct.unpack("=I", self._recv_exact(4))
        return json.loads(self._recv_exact(length))

    def create_session(self, username):
        return self.request({"type": "create_session", "username": username})

    def respond(self, response):
        return self.request({"type": "post_auth_message_response", "response": response})

    def start_session(self, cmd, env):
        return self.request({"type": "start_session", "cmd": cmd, "env": env})

    def cancel(self):
        try:
            return self.request({"type": "cancel_session"})
        except (OSError, GreetdError):
            return None


class FakeGreetd:
    """Demo backend for --demo / --preview: password is 'lumen'."""

    def __init__(self):
        self.stage = None

    def create_session(self, username):
        self.stage = "pw"
        return {"type": "auth_message", "auth_message_type": "secret", "auth_message": "Password: "}

    def respond(self, response):
        time.sleep(0.8)
        if self.stage == "pw" and response == "lumen":
            self.stage = "ok"
            return {"type": "success"}
        self.stage = None
        return {"type": "error", "error_type": "auth_error", "description": "Authentication failed"}

    def start_session(self, cmd, env):
        print("would start:", cmd, env)
        return {"type": "success"}

    def cancel(self):
        self.stage = None
        return {"type": "success"}
