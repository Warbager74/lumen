#!/usr/bin/env python3
"""Generate the Lumen icon theme (data/icons/Lumen).

Every icon is an original Lumen design, built from the same parts as the
Lumen Files icon: a dark squircle tile lit by a soft glow, and a glyph made
of frosted glass panes with a white sheen and a lens highlight. Apps get a
symbol for what they *do* (a globe for a browser, brackets for a code
editor...) in their own colour pair, not a copy of their brand mark.

Run:  python3 tools/make-icons.py      (rewrites data/icons/Lumen)
"""
import os
import re
import shutil

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "data", "icons", "Lumen")


# ------------------------------------------------------------------ palette
P = {
    "lumen":   ("#9fb4ff", "#b98cff"),
    "amber":   ("#ffb35c", "#ff5f8f"),
    "sky":     ("#6fc3ff", "#5a7dff"),
    "teal":    ("#5ee6d0", "#3d8bff"),
    "ember":   ("#ff8a5c", "#e8466a"),
    "violet":  ("#a98bff", "#6b5cff"),
    "indigo":  ("#8f95ff", "#5865f2"),
    "rose":    ("#ff8fb8", "#c86bff"),
    "mint":    ("#7cf0b0", "#2fb5a0"),
    "lime":    ("#c4f06a", "#4cc38a"),
    "gold":    ("#ffd66b", "#ff9a3d"),
    "coral":   ("#ff7a6b", "#ff3d6e"),
    "ocean":   ("#5cc8ff", "#2f6bff"),
    "slate":   ("#b8c2e0", "#7783a8"),
    "cyan":    ("#6ff0ff", "#3d9bff"),
    "orchid":  ("#e08bff", "#8a5cff"),
    "steel":   ("#8fb0d8", "#4f6fa8"),
    "sun":     ("#ffcf5c", "#ff7a3d"),
}


def defs(a, b):
    return f"""<defs>
    <linearGradient id="tile" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#2a2f4a"/><stop offset="1" stop-color="#151827"/>
    </linearGradient>
    <radialGradient id="glow" cx=".3" cy=".15" r=".9">
      <stop offset="0" stop-color="{a}" stop-opacity=".42"/><stop offset=".6" stop-color="{b}" stop-opacity=".12"/>
      <stop offset="1" stop-color="{b}" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="front" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="{a}"/><stop offset="1" stop-color="{b}"/>
    </linearGradient>
    <linearGradient id="back" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="{b}"/><stop offset="1" stop-color="{b}" stop-opacity=".7"/>
    </linearGradient>
    <linearGradient id="dark" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#3a3f5e"/><stop offset="1" stop-color="#1e2236"/>
    </linearGradient>
    <linearGradient id="sheen" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset=".38" stop-color="#fff" stop-opacity=".08"/>
      <stop offset="1" stop-color="#fff" stop-opacity="0"/>
    </linearGradient>
    <linearGradient id="paper" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#dfe4f7"/>
    </linearGradient>
    <linearGradient id="rim" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#fff" stop-opacity=".35"/><stop offset="1" stop-color="#fff" stop-opacity=".04"/>
    </linearGradient>
    <filter id="drop" x="-20%" y="-20%" width="140%" height="150%">
      <feGaussianBlur in="SourceAlpha" stdDeviation="3"/>
      <feOffset dy="4"/>
      <feComponentTransfer><feFuncA type="linear" slope=".45"/></feComponentTransfer>
      <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>"""


TILE = """<rect x="6" y="6" width="116" height="116" rx="28" fill="url(#tile)"/>
  <rect x="6" y="6" width="116" height="116" rx="28" fill="url(#glow)"/>
  <rect x="6.75" y="6.75" width="114.5" height="114.5" rx="27.25" fill="none" stroke="url(#rim)" stroke-width="1.5"/>"""


def glass(shape):
    """a frosted pane: colour fill + sheen + a bright top edge (shape is an SVG
    element string without fill, e.g. '<rect x=.. />')"""
    filled = shape.replace("/>", ' fill="url(#front)"/>', 1)
    sheen = shape.replace("/>", ' fill="url(#sheen)"/>', 1)
    return f'<g filter="url(#drop)">{filled}{sheen}</g>'


def lens(cx, cy, rx=12, ry=3):
    return f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="#fff" opacity=".35"/>'


W = 'fill="none" stroke-linecap="round" stroke-linejoin="round"'


# ------------------------------------------------------------------ glyphs
def g_globe(v="plain"):
    s = glass('<circle cx="64" cy="64" r="34"/>')
    s += f'<g {W} stroke="#fff" stroke-width="2.4" opacity=".55">' \
         '<ellipse cx="64" cy="64" rx="14" ry="33"/><path d="M31 64h66M36 48h56M36 80h56"/></g>'
    s += lens(52, 40, 12, 4)
    if v == "orbit":      # a ring swinging round the globe with a little moon
        s += '<g transform="rotate(-24 64 64)">' \
             '<ellipse cx="64" cy="64" rx="50" ry="15" fill="none" stroke="url(#paper)" stroke-width="4" ' \
             'stroke-dasharray="118 22" stroke-dashoffset="-6"/></g>' \
             '<circle cx="106" cy="44" r="7" fill="url(#paper)" filter="url(#drop)"/>'
    elif v == "needle":   # compass needle
        s += '<g filter="url(#drop)"><path d="M64 36l9 28h-18z" fill="url(#paper)"/>' \
             '<path d="M64 92l-9-28h18z" fill="#fff" opacity=".45"/><circle cx="64" cy="64" r="4.5" fill="url(#back)"/></g>'
    elif v == "shield":   # a privacy shield badge
        s += '<g filter="url(#drop)"><path d="M92 70l16 6v12c0 9-7 15-16 18-9-3-16-9-16-18V76z" fill="url(#paper)"/>' \
             '<path d="M86 88l5 5 9-10" fill="none" stroke="url(#back)" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/></g>'
    elif v == "spark":    # a four-point star
        s += '<path d="M98 22q3 13 14 15q-11 3-14 15q-3-12-14-15q11-2 14-15z" fill="url(#paper)" filter="url(#drop)"/>'
    return s


def g_code(v="plain"):
    s = '<rect x="30" y="24" width="72" height="56" rx="12" fill="url(#back)" opacity=".7" filter="url(#drop)"/>' \
        if v == "stack" else ""
    s += glass('<rect x="22" y="32" width="84" height="66" rx="14"/>')
    s += '<path d="M22.8 45a13 13 0 0 1 13-12.2h56.4a13 13 0 0 1 13 12.2" fill="none" stroke="#fff" stroke-opacity=".75" stroke-width="1.6"/>'
    s += f'<g {W} stroke="#fff" stroke-width="7"><path d="M52 52L40 65l12 13M76 52l12 13-12 13"/></g>'
    s += '<path d="M69 48L59 82" stroke="url(#paper)" stroke-width="5.5" stroke-linecap="round" opacity=".85"/>'
    return s + lens(44, 40)


def g_terminal(v="plain"):
    s = '<g filter="url(#drop)"><rect x="20" y="28" width="88" height="72" rx="14" fill="url(#dark)"/>' \
        '<rect x="20" y="28" width="88" height="72" rx="14" fill="url(#sheen)" opacity=".5"/>' \
        '<path d="M20 42a14 14 0 0 1 14-14h60a14 14 0 0 1 14 14z" fill="url(#front)"/></g>'
    s += '<g fill="#fff" opacity=".85"><circle cx="32" cy="35" r="2.6"/><circle cx="41" cy="35" r="2.6"/><circle cx="50" cy="35" r="2.6"/></g>'
    if v == "python":     # an interactive prompt: >>> and a line of input
        s += f'<g {W} stroke="url(#front)" stroke-width="5"><path d="M32 58l7 6-7 6M45 58l7 6-7 6M58 58l7 6-7 6"/></g>' \
             '<rect x="32" y="80" width="40" height="5" rx="2.5" fill="url(#paper)" opacity=".8"/>' \
             '<rect x="76" y="80" width="18" height="5" rx="2.5" fill="url(#front)" opacity=".8"/>'
    else:
        s += f'<g {W} stroke="url(#front)" stroke-width="7"><path d="M36 58l13 12-13 12"/></g>' \
             '<rect x="56" y="78" width="26" height="6" rx="3" fill="url(#paper)"/>'
    return s


def g_bubble(v="dots"):
    if v == "round":
        shape = '<path d="M64 26c21 0 38 15 38 34s-17 34-38 34c-5 0-10-1-14-2.6L30 100l5-17c-6-6-9-14-9-23 0-19 17-34 38-34z"/>'
    else:
        shape = '<path d="M38 28h52a14 14 0 0 1 14 14v30a14 14 0 0 1-14 14H58l-18 14v-14h-2a14 14 0 0 1-14-14V42a14 14 0 0 1 14-14z"/>'
    s = glass(shape) + lens(48, 38)
    if v == "dots":
        s += '<g fill="url(#paper)"><circle cx="48" cy="57" r="6"/><circle cx="64" cy="57" r="6"/><circle cx="80" cy="57" r="6"/></g>'
    elif v == "send":
        s += '<path d="M44 58l38-14-12 34-8-14z" fill="url(#paper)"/><path d="M62 64l20-20" stroke="url(#back)" stroke-width="3" stroke-linecap="round"/>'
    elif v == "round":
        s += '<g fill="url(#paper)"><rect x="48" y="52" width="32" height="5" rx="2.5"/><rect x="48" y="62" width="22" height="5" rx="2.5"/></g>'
    elif v == "hash":
        s += f'<g {W} stroke="url(#paper)" stroke-width="5"><path d="M56 44l-4 28M74 44l-4 28M47 52h32M45 64h32"/></g>'
    return s


def g_controller(v="plain"):
    s = ""
    if v == "stack":
        s += '<rect x="30" y="28" width="68" height="30" rx="15" fill="url(#back)" opacity=".65" filter="url(#drop)"/>'
    s += glass('<path d="M40 42h48c14 0 22 10 24 26l2 14c1 9-4 15-11 15-6 0-9-4-13-9l-4-5H42l-4 5c-4 5-7 9-13 9-7 0-12-6-11-15l2-14c2-16 10-26 24-26z"/>')
    s += '<path d="M40 43h48" stroke="#fff" stroke-opacity=".75" stroke-width="1.6" stroke-linecap="round"/>'
    s += '<g fill="url(#paper)"><rect x="34" y="60" width="20" height="6.5" rx="3"/><rect x="40.75" y="53.25" width="6.5" height="20" rx="3"/></g>'
    s += '<g fill="url(#paper)"><circle cx="82" cy="58" r="4.6"/><circle cx="92" cy="68" r="4.6"/></g>' \
         '<g fill="#fff" opacity=".5"><circle cx="72" cy="68" r="4.6"/><circle cx="82" cy="78" r="4.6"/></g>'
    if v == "bolt":
        s += '<path d="M100 18l-12 18h9l-5 14 14-20h-9z" fill="url(#paper)" filter="url(#drop)"/>'
    return s + lens(50, 47, 10, 2.6)


def g_cube(v="plain"):
    s = '<g filter="url(#drop)">' \
        '<path d="M64 24l36 20v40L64 104 28 84V44z" fill="url(#back)"/>' \
        '<path d="M28 44l36 20v40L28 84z" fill="url(#front)"/>' \
        '<path d="M64 64l36-20v40L64 104z" fill="url(#back)" opacity=".85"/>' \
        '<path d="M64 24l36 20-36 20-36-20z" fill="url(#paper)"/>' \
        '<path d="M28 44l36 20v40L28 84z" fill="url(#sheen)"/></g>'
    # carved block seams: it's built from smaller cubes
    s += '<g fill="none" stroke="#fff" stroke-opacity=".45" stroke-width="1.8">' \
         '<path d="M46 54v40M28 64l36 20M82 54v40M64 84l36-20"/></g>' \
         '<g fill="none" stroke="url(#back)" stroke-opacity=".35" stroke-width="1.8"><path d="M46 34l36 20M82 34L46 54"/></g>'
    if v == "spark":
        s += '<path d="M104 18q2.5 10 11 12q-8.5 2-11 12q-2.5-10-11-12q8.5-2 11-12z" fill="#fff" opacity=".9"/>'
    return s


def g_note(v="plain"):
    s = glass('<circle cx="64" cy="64" r="36"/>')
    s += '<circle cx="64" cy="64" r="26" fill="none" stroke="#fff" stroke-opacity=".25" stroke-width="1.5"/>' + lens(50, 38, 13, 3.6)
    s += '<g fill="url(#paper)" filter="url(#drop)"><path d="M58 44l24-6v8l-18 4.6V80h-6z"/>' \
         '<ellipse cx="52" cy="81" rx="9" ry="7" transform="rotate(-18 52 81)"/></g>'
    return s


def g_play(v="screen"):
    if v == "film":
        s = glass('<rect x="22" y="30" width="84" height="68" rx="14"/>')
        s += '<g fill="#fff" opacity=".5">' + "".join(
            f'<rect x="28" y="{y}" width="7" height="6" rx="1.5"/><rect x="93" y="{y}" width="7" height="6" rx="1.5"/>'
            for y in (38, 51, 64, 77, 88)) + '</g>'
        s += '<rect x="40" y="38" width="48" height="52" rx="6" fill="url(#dark)" opacity=".55"/>'
        s += '<path d="M56 50l20 14-20 14z" fill="url(#paper)"/>'
    elif v == "round":
        s = glass('<circle cx="64" cy="64" r="36"/>') + lens(50, 38, 13, 3.6)
        s += '<path d="M54 46l28 18-28 18z" fill="url(#paper)" filter="url(#drop)" stroke="url(#paper)" stroke-width="4" stroke-linejoin="round"/>'
    else:
        s = glass('<rect x="20" y="30" width="88" height="62" rx="14"/>') + lens(42, 38)
        s += '<rect x="48" y="96" width="32" height="5" rx="2.5" fill="url(#paper)" opacity=".7"/>'
        s += '<path d="M56 48l24 13-24 13z" fill="url(#paper)" filter="url(#drop)" stroke="url(#paper)" stroke-width="4" stroke-linejoin="round"/>'
    return s


def g_record():
    s = glass('<circle cx="64" cy="64" r="36"/>') + lens(50, 38, 13, 3.6)
    s += '<circle cx="64" cy="64" r="22" fill="none" stroke="url(#paper)" stroke-width="4.5"/>' \
         '<circle cx="64" cy="64" r="12" fill="url(#paper)" filter="url(#drop)"/>'
    s += '<g fill="#fff" opacity=".6"><circle cx="64" cy="35" r="3"/><circle cx="93" cy="64" r="3"/><circle cx="64" cy="93" r="3"/><circle cx="35" cy="64" r="3"/></g>'
    return s


def g_brush(v="brush"):
    s = '<path d="M30 92c-6 0-8-6-8-6 6-2 7-9 10-14 4-6 12-7 17-2s4 13-2 17c-5 3-9 5-17 5z" fill="url(#front)" filter="url(#drop)"/>'
    if v == "pen":   # a pen nib drawing a curve, with its anchor handles
        s = '<path d="M24 96C40 60 70 98 98 54" fill="none" stroke="url(#front)" stroke-width="5" stroke-linecap="round" opacity=".9"/>' \
            '<g fill="url(#paper)" filter="url(#drop)"><rect x="18" y="90" width="12" height="12" rx="3"/><rect x="92" y="48" width="12" height="12" rx="3"/></g>' \
            '<g filter="url(#drop)"><path d="M66 24l22 22-14 26-24 6 6-24z" fill="url(#front)"/>' \
            '<path d="M66 24l22 22-14 26-24 6 6-24z" fill="url(#sheen)"/>' \
            '<path d="M56 78l12-12" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/><circle cx="68" cy="66" r="4" fill="#fff"/></g>'
        return s
    s += '<g filter="url(#drop)"><rect x="58" y="16" width="16" height="64" rx="8" transform="rotate(42 66 48)" fill="url(#paper)"/>' \
         '<rect x="58" y="56" width="16" height="16" rx="3" transform="rotate(42 66 48)" fill="url(#back)"/></g>'
    s += '<rect x="60" y="20" width="5" height="34" rx="2.5" transform="rotate(42 66 48)" fill="#fff" opacity=".9"/>'
    if v == "palette":
        s += '<g filter="url(#drop)"><circle cx="96" cy="88" r="11" fill="url(#front)"/><circle cx="96" cy="88" r="11" fill="url(#sheen)"/></g>'
    return s


def g_orbit():
    s = glass('<circle cx="62" cy="66" r="28"/>') + lens(52, 48, 10, 3)
    s += '<g transform="rotate(-20 64 64)"><ellipse cx="64" cy="64" rx="48" ry="16" fill="none" stroke="url(#paper)" ' \
         'stroke-width="4.5" stroke-dasharray="104 30" stroke-dashoffset="-10"/></g>'
    s += '<circle cx="62" cy="66" r="10" fill="url(#paper)" opacity=".9"/><circle cx="62" cy="66" r="5" fill="url(#back)"/>'
    return s


def g_doc(v="lines"):
    s = '<g filter="url(#drop)"><path d="M34 18h40l22 22v62a10 10 0 0 1-10 10H34a10 10 0 0 1-10-10V28a10 10 0 0 1 10-10z" fill="url(#paper)"/>' \
        '<path d="M74 18v14a8 8 0 0 0 8 8h14z" fill="url(#front)"/></g>'
    s += '<rect x="24" y="96" width="72" height="16" rx="0" fill="url(#front)" opacity="0"/>'
    if v == "lines":
        s += '<g fill="url(#front)"><rect x="36" y="50" width="48" height="5" rx="2.5"/><rect x="36" y="62" width="40" height="5" rx="2.5" opacity=".75"/>' \
             '<rect x="36" y="74" width="46" height="5" rx="2.5" opacity=".6"/><rect x="36" y="86" width="28" height="5" rx="2.5" opacity=".45"/></g>'
    elif v == "grid":
        s += '<g fill="url(#front)">' + "".join(
            f'<rect x="{x}" y="{y}" width="14" height="9" rx="2" opacity="{o}"/>'
            for y, o in ((50, 1), (63, .7), (76, .55), (89, .4)) for x in (35, 52, 69)) + '</g>'
    elif v == "slides":
        s += '<rect x="34" y="50" width="52" height="36" rx="5" fill="url(#front)"/>' \
             '<g fill="#fff"><rect x="42" y="68" width="7" height="12" rx="1.5"/><rect x="53" y="62" width="7" height="18" rx="1.5"/>' \
             '<rect x="64" y="56" width="7" height="24" rx="1.5"/></g>' \
             '<rect x="46" y="92" width="28" height="4" rx="2" fill="url(#front)" opacity=".5"/>'
    elif v == "shapes":
        s += '<circle cx="48" cy="64" r="11" fill="url(#front)"/><path d="M70 86l12-22 12 22z" fill="url(#front)" opacity=".7"/>' \
             '<rect x="38" y="80" width="18" height="14" rx="3" fill="url(#front)" opacity=".5"/>'
    elif v == "stack":
        s += '<g fill="url(#front)"><rect x="36" y="50" width="22" height="18" rx="4"/><rect x="62" y="50" width="22" height="18" rx="4" opacity=".7"/>' \
             '<rect x="36" y="72" width="22" height="18" rx="4" opacity=".55"/><rect x="62" y="72" width="22" height="18" rx="4" opacity=".4"/></g>'
    elif v == "pencil":
        s += '<g fill="url(#front)" opacity=".7"><rect x="36" y="50" width="40" height="5" rx="2.5"/><rect x="36" y="62" width="32" height="5" rx="2.5"/>' \
             '<rect x="36" y="74" width="24" height="5" rx="2.5"/></g>' \
             '<g filter="url(#drop)" transform="rotate(45 86 78)"><rect x="80" y="50" width="12" height="40" rx="3" fill="url(#front)"/>' \
             '<rect x="80" y="50" width="12" height="40" rx="3" fill="url(#sheen)"/><path d="M80 90h12l-6 10z" fill="url(#paper)"/></g>'
    return s


def g_mail():
    s = glass('<rect x="18" y="34" width="92" height="62" rx="14"/>') + lens(40, 42)
    s += f'<g {W} stroke="url(#paper)" stroke-width="5"><path d="M28 46l36 26 36-26"/></g>' \
         '<path d="M30 88l22-18M98 88L76 70" stroke="#fff" stroke-opacity=".45" stroke-width="3" stroke-linecap="round"/>'
    return s


def g_wave():
    s = glass('<rect x="20" y="30" width="88" height="68" rx="16"/>') + lens(42, 38)
    hs = (10, 22, 34, 18, 44, 28, 14, 36, 22, 12)
    s += '<g fill="url(#paper)">' + "".join(
        f'<rect x="{30 + i * 7.4:.1f}" y="{64 - h / 2:.1f}" width="4.4" height="{h}" rx="2.2"/>' for i, h in enumerate(hs)) + '</g>'
    return s


def g_download():
    s = glass('<circle cx="64" cy="62" r="34"/>') + lens(50, 38, 12, 3.4)
    s += f'<g {W} stroke="url(#paper)" stroke-width="7"><path d="M64 44v32M50 64l14 14 14-14"/></g>'
    s += '<rect x="36" y="102" width="56" height="6" rx="3" fill="url(#front)" opacity=".8"/>'
    return s


def g_speaker():
    s = '<g filter="url(#drop)"><path d="M28 52h14l20-16v56L42 76H28a6 6 0 0 1-6-6V58a6 6 0 0 1 6-6z" fill="url(#front)"/>' \
        '<path d="M28 52h14l20-16v56L42 76H28a6 6 0 0 1-6-6V58a6 6 0 0 1 6-6z" fill="url(#sheen)"/></g>'
    s += f'<g {W} stroke="url(#paper)" stroke-width="5.5"><path d="M74 52a16 16 0 0 1 0 24"/><path d="M84 42a30 30 0 0 1 0 44" opacity=".7"/>' \
         '<path d="M94 32a44 44 0 0 1 0 64" opacity=".45"/></g>'
    return s


def g_calc():
    s = glass('<rect x="28" y="18" width="72" height="92" rx="16"/>') + lens(48, 26, 10, 2.6)
    s += '<rect x="38" y="28" width="52" height="20" rx="6" fill="url(#dark)" opacity=".7"/>' \
         '<rect x="64" y="36" width="20" height="5" rx="2.5" fill="url(#paper)"/>'
    s += '<g fill="url(#paper)">' + "".join(
        f'<rect x="{x}" y="{y}" width="12" height="10" rx="3" opacity="{.95 if c < 2 else .55}"/>'
        for r, y in enumerate((56, 70, 84)) for c, x in enumerate((38, 58, 78))) + '</g>'
    return s


def g_photo():
    s = glass('<rect x="20" y="28" width="88" height="72" rx="16"/>')
    s += '<path d="M28 92l24-30 16 18 10-12 22 24z" fill="url(#paper)" opacity=".9"/>' \
         '<path d="M28 92l24-30 16 18" fill="none" stroke="#fff" stroke-width="2" stroke-linejoin="round"/>' \
         '<circle cx="84" cy="48" r="8" fill="url(#paper)"/>' + lens(42, 36)
    return s


def g_pulse():
    s = glass('<rect x="20" y="28" width="88" height="72" rx="16"/>') + lens(42, 36)
    s += '<g fill="none" stroke="#fff" stroke-opacity=".25" stroke-width="1.2"><path d="M28 48h72M28 64h72M28 80h72"/></g>'
    s += f'<path d="M28 68h16l6-16 10 30 8-22 6 8h26" {W} stroke="url(#paper)" stroke-width="5.5"/>'
    return s


def g_box():
    s = '<g filter="url(#drop)"><path d="M24 46h80v48a12 12 0 0 1-12 12H36a12 12 0 0 1-12-12z" fill="url(#front)"/>' \
        '<path d="M24 46h80v48a12 12 0 0 1-12 12H36a12 12 0 0 1-12-12z" fill="url(#sheen)"/>' \
        '<path d="M28 26h72l8 20H20z" fill="url(#back)"/><path d="M28 26h72l8 20H20z" fill="url(#sheen)"/></g>'
    s += '<g fill="url(#paper)"><rect x="58" y="46" width="12" height="8" rx="2"/><rect x="58" y="58" width="12" height="8" rx="2" opacity=".75"/>' \
         '<rect x="58" y="70" width="12" height="8" rx="2" opacity=".55"/><rect x="54" y="82" width="20" height="14" rx="4"/></g>'
    return s


def g_bag():
    s = f'<path d="M50 44V38a14 14 0 0 1 28 0v6" {W} stroke="url(#paper)" stroke-width="6"/>'
    s += glass('<path d="M30 44h68l-4 50a14 14 0 0 1-14 13H48a14 14 0 0 1-14-13z"/>') + lens(48, 52)
    s += '<path d="M64 62l4 9 10 1-7.5 7 2 10-8.5-5-8.5 5 2-10-7.5-7 10-1z" fill="url(#paper)"/>'
    return s


def g_bottle():
    s = '<rect x="54" y="14" width="20" height="12" rx="4" fill="url(#paper)" filter="url(#drop)"/>'
    s += glass('<path d="M56 26h16v14c12 5 20 14 20 28v26a14 14 0 0 1-14 14H50a14 14 0 0 1-14-14V68c0-14 8-23 20-28z"/>')
    s += '<path d="M38 74c10-6 18 6 26 0s16-6 24 0v20a12 12 0 0 1-12 12H50a12 12 0 0 1-12-12z" fill="#fff" opacity=".25"/>' + lens(52, 54, 8, 3)
    return s


def g_gear():
    import math
    pts = []
    for i in range(16):
        r = 40 if i % 2 == 0 else 31
        a = math.pi * 2 * (i - .5) / 16
        a2 = math.pi * 2 * (i + .5) / 16
        pts.append(f"{64 + r * math.cos(a):.1f} {64 + r * math.sin(a):.1f}")
        pts.append(f"{64 + r * math.cos(a2):.1f} {64 + r * math.sin(a2):.1f}")
    s = glass(f'<path d="M{" L".join(pts)}z" stroke="url(#front)" stroke-width="6" stroke-linejoin="round"/>')
    s += '<circle cx="64" cy="64" r="14" fill="url(#dark)"/><circle cx="64" cy="64" r="14" fill="none" stroke="url(#paper)" stroke-width="4"/>' + lens(50, 36, 10, 3)
    return s


def g_notebook():
    s = '<rect x="34" y="20" width="66" height="90" rx="12" fill="url(#back)" opacity=".7" filter="url(#drop)"/>'
    s += glass('<rect x="26" y="18" width="66" height="90" rx="12"/>') + lens(44, 26, 10, 2.6)
    s += '<g fill="url(#paper)"><rect x="38" y="40" width="40" height="5" rx="2.5"/><rect x="38" y="52" width="32" height="5" rx="2.5" opacity=".75"/>' \
         '<rect x="38" y="64" width="36" height="5" rx="2.5" opacity=".6"/></g>'
    s += '<path d="M76 18h12v32l-6-5-6 5z" fill="url(#paper)" filter="url(#drop)"/>'
    return s


def g_monitor():
    s = glass('<rect x="18" y="26" width="92" height="62" rx="12"/>') + lens(40, 34)
    s += '<rect x="56" y="88" width="16" height="12" fill="url(#back)"/><rect x="42" y="100" width="44" height="7" rx="3.5" fill="url(#paper)" filter="url(#drop)"/>'
    s += '<g fill="url(#paper)" opacity=".9"><rect x="30" y="38" width="30" height="20" rx="4"/><rect x="66" y="38" width="32" height="38" rx="4" opacity=".6"/>' \
         '<rect x="30" y="62" width="30" height="14" rx="4" opacity=".7"/></g>'
    return s


def g_calendar():
    s = '<g filter="url(#drop)"><rect x="22" y="26" width="84" height="80" rx="16" fill="url(#paper)"/>' \
        '<path d="M22 42a16 16 0 0 1 16-16h52a16 16 0 0 1 16 16v8H22z" fill="url(#front)"/>' \
        '<path d="M22 42a16 16 0 0 1 16-16h52a16 16 0 0 1 16 16v8H22z" fill="url(#sheen)"/></g>'
    s += '<g fill="#fff" opacity=".9"><rect x="40" y="18" width="7" height="18" rx="3.5"/><rect x="81" y="18" width="7" height="18" rx="3.5"/></g>'
    s += '<g fill="url(#back)">' + "".join(
        f'<rect x="{x}" y="{y}" width="11" height="9" rx="3" opacity="{o}"/>'
        for y, o in ((60, .55), (74, .55), (88, .35)) for x in (34, 50, 66, 82)) + '</g>'
    s += '<rect x="48" y="72" width="15" height="13" rx="4.5" fill="url(#front)"/>'
    return s


def g_clock():
    s = glass('<circle cx="64" cy="64" r="38"/>') + lens(50, 36, 14, 4)
    s += '<circle cx="64" cy="64" r="29" fill="url(#paper)" filter="url(#drop)"/>'
    s += '<g fill="url(#back)" opacity=".55"><circle cx="64" cy="40" r="2.4"/><circle cx="88" cy="64" r="2.4"/>' \
         '<circle cx="64" cy="88" r="2.4"/><circle cx="40" cy="64" r="2.4"/></g>'
    s += '<g fill="none" stroke-linecap="round"><path d="M64 64V46" stroke="#2a2f4a" stroke-width="5"/>' \
         '<path d="M64 64l14 9" stroke="#2a2f4a" stroke-width="4"/><path d="M64 64l-9 15" stroke="url(#front)" stroke-width="2.4"/></g>' \
         '<circle cx="64" cy="64" r="3.6" fill="url(#front)"/>'
    return s


def g_camera(v="photo"):
    if v == "call":   # a video call: a lens and a little flag of video
        s = glass('<rect x="16" y="36" width="68" height="56" rx="16"/>') + lens(36, 44)
        s += '<g filter="url(#drop)"><path d="M86 56l22-14a3 3 0 0 1 5 2.5v39a3 3 0 0 1-5 2.5L86 72z" fill="url(#paper)"/></g>'
        s += '<circle cx="50" cy="64" r="14" fill="url(#paper)"/><circle cx="50" cy="64" r="7" fill="url(#back)"/>'
        return s
    s = '<rect x="44" y="26" width="34" height="16" rx="6" fill="url(#back)" filter="url(#drop)"/>'
    s += glass('<rect x="18" y="36" width="92" height="64" rx="16"/>') + lens(40, 44)
    s += '<circle cx="64" cy="68" r="21" fill="url(#paper)" filter="url(#drop)"/><circle cx="64" cy="68" r="13" fill="url(#dark)"/>' \
         '<circle cx="64" cy="68" r="7" fill="url(#front)"/><circle cx="59" cy="63" r="3" fill="#fff" opacity=".8"/>' \
         '<circle cx="96" cy="50" r="4" fill="url(#paper)"/>'
    return s


def g_map():
    s = '<g filter="url(#drop)"><path d="M20 38l28-10 32 10 28-10v62l-28 10-32-10-28 10z" fill="url(#front)"/>' \
        '<path d="M20 38l28-10 32 10 28-10v62l-28 10-32-10-28 10z" fill="url(#sheen)"/>' \
        '<path d="M48 28v62M80 38v62" stroke="#fff" stroke-opacity=".45" stroke-width="2"/></g>'
    s += '<path d="M26 82c14-10 20 6 34-6s20-2 42-22" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="3" stroke-dasharray="1 7" stroke-linecap="round"/>'
    s += '<g filter="url(#drop)"><path d="M72 22c-11 0-19 8-19 19 0 14 19 31 19 31s19-17 19-31c0-11-8-19-19-19z" fill="url(#paper)"/>' \
         '<circle cx="72" cy="41" r="7.5" fill="url(#back)"/></g>'
    return s


def g_weather():
    s = '<g filter="url(#drop)"><circle cx="80" cy="46" r="22" fill="url(#front)"/><circle cx="80" cy="46" r="22" fill="url(#sheen)"/></g>'
    s += '<g filter="url(#drop)"><path d="M40 98a20 20 0 0 1-2-39.900a26 26 0 0 1 49.500 6.500A17 17 0 0 1 86 98z" fill="url(#paper)"/></g>'
    s += '<path d="M40 60a26 26 0 0 1 30-12" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"/>'
    return s


def g_key():
    s = glass('<path d="M64 20l36 12v26c0 24-15 41-36 50-21-9-36-26-36-50V32z"/>') + lens(52, 32, 10, 3)
    s += '<g filter="url(#drop)"><circle cx="64" cy="54" r="10" fill="none" stroke="url(#paper)" stroke-width="6.5"/>' \
         '<path d="M64 64v24M64 76h9M64 86h7" fill="none" stroke="url(#paper)" stroke-width="6.5" stroke-linecap="round"/></g>'
    return s


def g_disk():
    s = glass('<rect x="20" y="30" width="88" height="68" rx="16"/>') + lens(42, 38)
    s += '<circle cx="58" cy="62" r="22" fill="url(#dark)" opacity=".55"/><circle cx="58" cy="62" r="22" fill="none" stroke="url(#paper)" stroke-width="2.4" opacity=".8"/>' \
         '<circle cx="58" cy="62" r="6" fill="url(#paper)"/>' \
         '<path d="M58 62l26 14" stroke="url(#paper)" stroke-width="5" stroke-linecap="round" filter="url(#drop)"/>'
    s += '<g fill="url(#paper)"><circle cx="94" cy="44" r="3.4"/><circle cx="94" cy="86" r="3.4" opacity=".5"/></g>'
    return s


def g_printer():
    s = '<rect x="38" y="20" width="52" height="30" rx="6" fill="url(#paper)" filter="url(#drop)"/>'
    s += glass('<rect x="18" y="42" width="92" height="46" rx="14"/>') + lens(40, 50)
    s += '<g filter="url(#drop)"><rect x="36" y="70" width="56" height="38" rx="6" fill="url(#paper)"/></g>' \
         '<g fill="url(#back)" opacity=".6"><rect x="44" y="80" width="40" height="4" rx="2"/><rect x="44" y="90" width="28" height="4" rx="2"/></g>' \
         '<circle cx="94" cy="56" r="4" fill="url(#paper)"/>'
    return s


def g_people():
    s = '<g filter="url(#drop)"><circle cx="82" cy="50" r="13" fill="url(#back)"/><path d="M60 98c0-14 10-24 22-24s22 10 22 24z" fill="url(#back)"/></g>'
    s += '<g filter="url(#drop)"><circle cx="52" cy="46" r="16" fill="url(#front)"/><circle cx="52" cy="46" r="16" fill="url(#sheen)"/>' \
         '<path d="M24 102c0-17 12-30 28-30s28 13 28 30z" fill="url(#front)"/><path d="M24 102c0-17 12-30 28-30s28 13 28 30z" fill="url(#sheen)"/></g>'
    return s + lens(46, 36, 8, 2.6)


def g_help():
    s = glass('<circle cx="64" cy="64" r="36"/>') + lens(50, 38, 13, 3.6)
    s += '<path d="M52 54a12 12 0 1 1 18 10c-4 3-6 5-6 10" fill="none" stroke="url(#paper)" stroke-width="7" stroke-linecap="round" filter="url(#drop)"/>' \
         '<circle cx="64" cy="87" r="4.6" fill="url(#paper)"/>'
    return s


def g_type():
    s = glass('<rect x="20" y="24" width="88" height="80" rx="18"/>') + lens(42, 32)
    s += '<g filter="url(#drop)" fill="none" stroke="url(#paper)" stroke-linecap="round" stroke-linejoin="round">' \
         '<path d="M38 86l18-46 18 46M44 72h24" stroke-width="7"/>' \
         '<path d="M92 66a9 10 0 1 0 0 14zM92 60v26" stroke-width="5"/></g>'
    return s


def g_drop():
    s = glass('<path d="M64 18c16 20 30 34 30 52a30 30 0 0 1-60 0c0-18 14-32 30-52z"/>')
    s += '<path d="M48 72a16 16 0 0 0 12 15" fill="none" stroke="#fff" stroke-width="4.5" stroke-linecap="round" opacity=".7"/>'
    s += '<g filter="url(#drop)"><circle cx="92" cy="92" r="13" fill="url(#paper)"/><circle cx="92" cy="92" r="7" fill="url(#back)"/></g>'
    return s


def g_files():
    return None   # copied from lumen-files.svg


GLYPHS = {k[2:]: v for k, v in globals().items() if k.startswith("g_")}


# ------------------------------------------------------------------ apps
# (glyph, variant, palette): [icon names used by .desktop files]
APPS = [
    (("globe", "orbit", "amber"), ["firefox", "org.mozilla.firefox", "firefox-developer-edition", "firefox-esr", "firefox-nightly"]),
    (("globe", "needle", "sky"), ["chromium", "org.chromium.Chromium", "chromium-browser"]),
    (("globe", "needle", "teal"), ["google-chrome", "com.google.Chrome", "google-chrome-stable", "google-chrome-unstable"]),
    (("globe", "shield", "ember"), ["brave", "brave-browser", "brave-desktop", "com.brave.Browser"]),
    (("globe", "shield", "ocean"), ["librewolf", "io.gitlab.librewolf-community"]),
    (("globe", "spark", "slate"), ["zen-browser", "zen", "app.zen_browser.zen"]),
    (("globe", "spark", "coral"), ["vivaldi", "com.vivaldi.Vivaldi", "vivaldi-stable"]),
    (("globe", "plain", "sky"), ["org.gnome.Epiphany", "web-browser", "internet-web-browser", "microsoft-edge", "opera", "falkon", "org.kde.falkon", "qutebrowser"]),

    (("code", "plain", "ocean"), ["code", "vscode", "visual-studio-code", "com.visualstudio.code", "visual-studio-code-insiders", "code-insiders"]),
    (("code", "plain", "teal"), ["code-oss", "com.visualstudio.code.oss", "vscodium", "com.vscodium.codium", "codium"]),
    (("code", "stack", "violet"), ["cursor", "co.anysphere.cursor"]),
    (("code", "stack", "slate"), ["zed", "dev.zed.Zed", "zed-preview"]),
    (("code", "plain", "gold"), ["sublime-text", "com.sublimetext.three", "sublime_text"]),
    (("code", "stack", "orchid"), ["jetbrains-toolbox", "intellij-idea-community", "idea", "pycharm", "pycharm-community", "clion", "webstorm", "android-studio"]),
    (("code", "plain", "lime"), ["nvim", "neovide", "vim", "gvim"]),

    (("bubble", "dots", "indigo"), ["discord", "com.discordapp.Discord", "discord-canary", "discord-ptb", "vesktop", "dev.vencord.Vesktop", "webcord", "armcord", "legcord"]),
    (("bubble", "send", "sky"), ["telegram", "org.telegram.desktop", "telegramdesktop", "telegram-desktop"]),
    (("bubble", "round", "ocean"), ["signal-desktop", "org.signal.Signal", "signal"]),
    (("bubble", "hash", "mint"), ["element-desktop", "im.riot.Riot", "io.element.Element", "element"]),
    (("bubble", "hash", "orchid"), ["slack", "com.slack.Slack"]),
    (("bubble", "round", "mint"), ["whatsapp", "whatsapp-for-linux", "com.github.eneshecan.WhatsAppForLinux", "zapzap", "com.rtosta.zapzap"]),

    (("controller", "stack", "steel"), ["steam", "com.valvesoftware.Steam", "steam-native", "steam-runtime"]),
    (("controller", "bolt", "gold"), ["lutris", "net.lutris.Lutris"]),
    (("controller", "plain", "coral"), ["heroic", "com.heroicgameslauncher.hgl"]),
    (("controller", "plain", "violet"), ["itch", "io.itch.itch", "retroarch", "org.libretro.RetroArch"]),
    (("bottle", "plain", "rose"), ["com.usebottles.bottles", "bottles"]),

    (("cube", "spark", "lumen"), ["org.prismlauncher.PrismLauncher", "prismlauncher", "minecraft", "minecraft-launcher",
                                  "com.mojang.Minecraft", "org.polymc.PolyMC", "polymc", "multimc", "atlauncher",
                                  "com.atlauncher.ATLauncher", "org.fn2.FjordLauncher"]),
    (("cube", "plain", "mint"), ["com.modrinth.ModrinthApp", "modrinth-app", "ModrinthApp"]),
    (("cube", "plain", "ocean"), ["lunarclient", "lunar-client", "com.lunarclient.LunarClient"]),

    (("note", "plain", "mint"), ["spotify", "spotify-client", "com.spotify.Client", "spotify-launcher"]),
    (("note", "plain", "rose"), ["org.gnome.Rhythmbox3", "rhythmbox", "org.kde.elisa", "elisa", "io.bassi.Amberol", "amberol",
                                 "strawberry", "org.strawberrymusicplayer.strawberry", "audacious", "multimedia-audio-player", "lollypop"]),
    (("play", "round", "sun"), ["vlc", "org.videolan.VLC"]),
    (("play", "screen", "violet"), ["mpv", "io.mpv.Mpv", "io.github.celluloid_player.Celluloid", "celluloid",
                                    "org.gnome.Totem", "totem", "smplayer", "haruna", "org.kde.haruna", "multimedia-video-player"]),
    (("play", "screen", "coral"), ["youtube", "freetube", "io.freetubeapp.FreeTube"]),
    (("play", "film", "orchid"), ["kdenlive", "org.kde.kdenlive", "org.shotcut.Shotcut", "shotcut", "openshot", "org.openshot.OpenShot", "davinci-resolve", "pitivi"]),
    (("record", "plain", "coral"), ["com.obsproject.Studio", "obs", "obs-studio", "com.obsproject.Studio.desktop"]),
    (("wave", "plain", "sun"), ["audacity", "org.audacityteam.Audacity", "ardour", "org.tenacityaudio.Tenacity", "tenacity"]),

    (("brush", "palette", "amber"), ["gimp", "org.gimp.GIMP", "gimp-2.10", "gimp-3.0"]),
    (("brush", "palette", "rose"), ["krita", "org.kde.krita"]),
    (("brush", "pen", "slate"), ["inkscape", "org.inkscape.Inkscape"]),
    (("orbit", "plain", "sun"), ["blender", "org.blender.Blender"]),

    (("doc", "lines", "ocean"), ["libreoffice-writer", "org.libreoffice.LibreOffice.writer", "libreoffice-main", "onlyoffice-desktopeditors", "wps-office2019-wpsmain"]),
    (("doc", "grid", "mint"), ["libreoffice-calc", "org.libreoffice.LibreOffice.calc", "wps-office2019-etmain"]),
    (("doc", "slides", "sun"), ["libreoffice-impress", "org.libreoffice.LibreOffice.impress", "wps-office2019-wppmain"]),
    (("doc", "shapes", "gold"), ["libreoffice-draw", "org.libreoffice.LibreOffice.draw"]),
    (("doc", "stack", "lumen"), ["libreoffice-startcenter", "org.libreoffice.LibreOffice", "libreoffice"]),
    (("doc", "pencil", "sky"), ["org.gnome.TextEditor", "gnome-text-editor", "accessories-text-editor", "text-editor",
                                "org.gnome.gedit", "gedit", "mousepad", "org.xfce.mousepad", "kate", "org.kde.kate",
                                "kwrite", "org.kde.kwrite", "xed", "leafpad", "featherpad"]),
    (("doc", "lines", "coral"), ["org.gnome.Evince", "evince", "okular", "org.kde.okular", "zathura", "org.pwmt.zathura",
                                 "org.gnome.Papers", "atril", "xreader"]),
    (("notebook", "plain", "violet"), ["obsidian", "md.obsidian.Obsidian", "joplin", "notion-app", "logseq", "com.logseq.Logseq", "simplenote"]),

    (("mail", "plain", "sky"), ["thunderbird", "org.mozilla.Thunderbird", "net.thunderbird.Thunderbird", "org.gnome.Geary", "geary",
                                "org.gnome.Evolution", "evolution", "mail-client", "internet-mail", "betterbird", "mailspring"]),

    (("terminal", "plain", "lumen"), ["kitty", "Alacritty", "alacritty", "foot", "footclient", "org.codeberg.dnkl.foot",
                                      "org.wezfurlong.wezterm", "wezterm", "org.gnome.Terminal", "gnome-terminal",
                                      "org.gnome.Console", "org.kde.konsole", "konsole", "com.mitchellh.ghostty", "ghostty",
                                      "utilities-terminal", "xterm", "terminator", "tilix", "com.gexperts.Tilix", "xfce4-terminal",
                                      "org.xfce.terminal", "st", "urxvt", "blackbox", "com.raggesilver.BlackBox", "ptyxis", "org.gnome.Ptyxis"]),
    (("terminal", "python", "gold"), ["idle", "idle3", "idle-python3", "python", "python3", "org.python.IDLE",
                                      "idle-python3.12", "idle-python3.13", "idle-python3.14", "thonny", "org.thonny.Thonny"]),

    (("download", "plain", "mint"), ["qbittorrent", "org.qbittorrent.qBittorrent", "transmission", "transmission-gtk", "transmission-qt",
                                     "com.transmissionbt.Transmission", "deluge", "fragments", "de.haeckerfelix.Fragments", "ktorrent", "org.kde.ktorrent"]),
    (("speaker", "plain", "teal"), ["pavucontrol", "org.pulseaudio.pavucontrol", "multimedia-volume-control", "com.saivert.pwvucontrol",
                                    "pwvucontrol", "helvum", "org.pipewire.Helvum", "easyeffects", "com.github.wwmm.easyeffects"]),
    (("calc", "plain", "slate"), ["org.gnome.Calculator", "gnome-calculator", "accessories-calculator", "qalculate", "qalculate-gtk",
                                  "io.github.Qalculate", "galculator", "kcalc", "org.kde.kcalc", "calculator"]),
    (("photo", "plain", "teal"), ["org.gnome.Loupe", "loupe", "org.gnome.eog", "eog", "image-viewer", "gwenview", "org.kde.gwenview",
                                  "imv", "feh", "ristretto", "org.xfce.ristretto", "nomacs", "qimgv", "gthumb", "org.gnome.gThumb",
                                  "shotwell", "org.gnome.Shotwell", "multimedia-photo-viewer"]),
    (("pulse", "plain", "mint"), ["org.gnome.SystemMonitor", "gnome-system-monitor", "utilities-system-monitor", "htop", "btop",
                                  "io.missioncenter.MissionCenter", "missioncenter", "plasma-systemmonitor", "org.kde.plasma-systemmonitor",
                                  "ksysguard", "resources", "net.nokyan.Resources", "nvtop"]),
    (("box", "plain", "gold"), ["org.gnome.FileRoller", "file-roller", "ark", "org.kde.ark", "xarchiver", "engrampa", "peazip",
                                "io.github.peazip.PeaZip", "org.gnome.ArchiveManager", "utilities-file-archiver"]),
    (("bag", "plain", "lumen"), ["pamac", "pamac-manager", "system-software-install", "org.gnome.Software", "gnome-software",
                                 "octopi", "plasmadiscover", "org.kde.discover", "io.github.flattool.Warehouse", "bazaar"]),
    (("monitor", "plain", "steel"), ["virt-manager", "org.virt_manager.virt-manager", "virtualbox", "org.virtualbox.VirtualBox",
                                     "gnome-boxes", "org.gnome.Boxes", "remmina", "org.remmina.Remmina", "vmware-workstation",
                                     "preferences-desktop-display", "nwg-displays", "arandr"]),
    (("calendar", "plain", "coral"), ["org.gnome.Calendar", "gnome-calendar", "calendar", "office-calendar", "korganizer",
                                      "org.kde.korganizer", "x-office-calendar", "io.elementary.calendar", "kalendar", "org.kde.merkuro.calendar"]),
    (("clock", "plain", "slate"), ["org.gnome.clocks", "gnome-clocks", "clock", "kclock", "org.kde.kclock", "preferences-system-time", "kalarm", "org.kde.kalarm"]),
    (("camera", "photo", "steel"), ["org.gnome.Snapshot", "snapshot", "camera", "cheese", "org.gnome.Cheese", "camera-photo", "kamoso", "org.kde.kamoso",
                                    "accessories-camera", "applets-screenshooter", "org.gnome.Screenshot", "gnome-screenshot", "flameshot",
                                    "org.flameshot.Flameshot", "spectacle", "org.kde.spectacle", "lumen-screenshot"]),
    (("camera", "call", "ocean"), ["zoom", "Zoom", "us.zoom.Zoom", "teams", "teams-for-linux", "com.github.IsmaelMartinez.teams_for_linux",
                                   "skypeforlinux", "com.skype.Client", "jitsi-meet", "org.jitsi.jitsi-meet", "webex", "camera-video"]),
    (("map", "plain", "mint"), ["org.gnome.Maps", "gnome-maps", "maps", "marble", "org.kde.marble", "qgis", "org.qgis.qgis"]),
    (("weather", "plain", "sky"), ["org.gnome.Weather", "gnome-weather", "weather", "kweather", "org.kde.kweather", "weather-app", "indicator-weather"]),
    (("key", "plain", "mint"), ["org.keepassxc.KeePassXC", "keepassxc", "bitwarden", "com.bitwarden.desktop", "org.gnome.seahorse.Application",
                                "seahorse", "1password", "com.onepassword.OnePassword", "proton-pass", "enpass", "kwalletmanager", "kwalletmanager5",
                                "org.gnome.World.Secrets", "secrets", "dialog-password", "protonvpn", "protonvpn-app", "mullvad-vpn", "nordvpn"]),
    (("disk", "plain", "slate"), ["org.gnome.DiskUtility", "gnome-disks", "gnome-disk-utility", "gparted", "org.gnome.baobab", "baobab",
                                  "partitionmanager", "org.kde.partitionmanager", "filelight", "org.kde.filelight", "drive-harddisk",
                                  "timeshift", "timeshift-gtk", "deja-dup", "org.gnome.DejaDup"]),
    (("printer", "plain", "steel"), ["printer", "system-config-printer", "org.gnome.SimpleScan", "simple-scan", "scanner", "skanlite",
                                     "org.kde.skanlite", "cups", "print-manager"]),
    (("people", "plain", "amber"), ["org.gnome.Contacts", "gnome-contacts", "contacts", "kaddressbook", "org.kde.kaddressbook", "x-office-address-book",
                                    "system-users", "preferences-system-users"]),
    (("help", "plain", "sky"), ["help-browser", "org.gnome.Yelp", "yelp", "khelpcenter", "org.kde.khelpcenter", "system-help", "help-contents"]),
    (("type", "plain", "rose"), ["org.gnome.font-viewer", "gnome-font-viewer", "font-manager", "org.gnome.FontManager", "preferences-desktop-font",
                                 "org.gnome.Characters", "gnome-characters", "accessories-character-map", "kcharselect", "org.kde.kcharselect",
                                 "accessories-dictionary", "goldendict", "org.gnome.Dictionary"]),
    (("drop", "plain", "orchid"), ["org.gnome.ColorPicker", "gcolor3", "nl.hjdskes.gcolor3", "color-picker", "kcolorchooser", "org.kde.kcolorchooser",
                                   "preferences-color", "com.github.finefindus.eyedropper", "eyedropper", "hyprpicker", "gpick"]),
    (("gear", "plain", "lumen"), ["lumen-settings", "preferences-system", "org.gnome.Settings", "gnome-settings",
                                  "systemsettings", "preferences-desktop", "org.gnome.tweaks", "nwg-look", "qt5ct", "qt6ct", "lxappearance"]),
    (("files", "plain", "lumen"), ["lumen-files", "org.lumen.Files", "system-file-manager", "org.gnome.Nautilus", "nautilus",
                                   "thunar", "org.xfce.thunar", "org.kde.dolphin", "dolphin", "pcmanfm", "pcmanfm-qt", "nemo",
                                   "caja", "spacefm", "file-manager", ]),
]


# ------------------------------------------------------------------ places
# Folders are glass too: a deeper back sheet, a page peeking out, and a front
# pane that catches the light — the Lumen Files icon, without the tile.
FOLDER_DEFS = """<defs>
    <linearGradient id="back" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#7189ee"/><stop offset="1" stop-color="#565ec6"/>
    </linearGradient>
    <linearGradient id="front" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#a6baff"/><stop offset=".55" stop-color="#9197ff"/><stop offset="1" stop-color="#bb8fff"/>
    </linearGradient>
    <linearGradient id="sheen" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#fff" stop-opacity=".50"/><stop offset=".4" stop-color="#fff" stop-opacity=".06"/>
      <stop offset="1" stop-color="#fff" stop-opacity="0"/>
    </linearGradient>
    <linearGradient id="paper" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#dfe4f7"/>
    </linearGradient>
    <filter id="drop" x="-20%" y="-20%" width="140%" height="150%">
      <feGaussianBlur in="SourceAlpha" stdDeviation="2.4"/>
      <feOffset dy="3"/>
      <feComponentTransfer><feFuncA type="linear" slope=".38"/></feComponentTransfer>
      <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>"""

FOLDER_BODY = """<path d="M12 30a10 10 0 0 1 10-10h25a9 9 0 0 1 7 3.300l5.200 6.700H106a10 10 0 0 1 10 10v58a10 10 0 0 1-10 10H22a10 10 0 0 1-10-10z" fill="url(#back)" filter="url(#drop)"/>
  <rect x="24" y="38" width="80" height="44" rx="6" fill="url(#paper)" transform="rotate(-2.500 64 60)" filter="url(#drop)"/>
  <g filter="url(#drop)">
    <path d="M8 60a10 10 0 0 1 10-10h92a10 10 0 0 1 10 10v36a12 12 0 0 1-12 12H20a12 12 0 0 1-12-12z" fill="url(#front)"/>
    <path d="M8 60a10 10 0 0 1 10-10h92a10 10 0 0 1 10 10v36a12 12 0 0 1-12 12H20a12 12 0 0 1-12-12z" fill="url(#sheen)"/>
    <path d="M9 60a9 9 0 0 1 9-9h92a9 9 0 0 1 9 9" fill="none" stroke="#fff" stroke-opacity=".8" stroke-width="1.6" stroke-linecap="round"/>
    <ellipse cx="34" cy="61" rx="15" ry="3.400" fill="#fff" opacity=".32"/>
  </g>"""

EW = 'fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" opacity=".92"'
EMBLEMS = {
    None: "",
    "documents": f'<g {EW}><path d="M52 68h24M52 79h24M52 90h14"/></g>',
    "download": f'<g {EW}><path d="M64 66v22M54 79l10 10 10-10"/></g>',
    "music": '<g fill="#fff" opacity=".92"><path d="M60 66l18-4.500v6l-13 3.300V88h-5z"/><ellipse cx="56" cy="89" rx="7" ry="5.500" transform="rotate(-18 56 89)"/></g>',
    "pictures": '<g fill="#fff" opacity=".92"><path d="M44 94l14-18 9 10 6-7 12 15z"/><circle cx="76" cy="68" r="5"/></g>',
    "videos": '<path d="M56 67l22 12-22 12z" fill="#fff" opacity=".92" stroke="#fff" stroke-width="4" stroke-linejoin="round"/>',
    "desktop": f'<g {EW}><rect x="46" y="64" width="36" height="22" rx="4"/><path d="M56 95h16"/></g>',
    "home": '<path d="M64 62l19 15h-5v16H69V83H59v10H50V77h-5z" fill="#fff" opacity=".92" stroke="#fff" stroke-width="2" stroke-linejoin="round"/>',
    "templates": f'<g {EW} stroke-dasharray="1 9"><rect x="48" y="64" width="32" height="28" rx="5"/></g>',
    "public": '<g fill="#fff" opacity=".92"><circle cx="56" cy="71" r="6.500"/><path d="M44 94c0-8 5-13 12-13s12 5 12 13z"/><circle cx="76" cy="73" r="5"/><path d="M70 94c0-6 2-10 6-10s9 4 9 10z"/></g>',
    "remote": f'<g {EW}><circle cx="64" cy="79" r="14"/><path d="M50 79h28M64 65c-7 8-7 20 0 28M64 65c7 8 7 20 0 28" stroke-width="3"/></g>',
    "code": f'<g {EW}><path d="M56 70l-9 9 9 9M72 70l9 9-9 9"/></g>',
    "games": '<g fill="#fff" opacity=".92"><rect x="42" y="68" width="44" height="24" rx="12"/></g><g fill="url(#back)"><rect x="50" y="78" width="12" height="4" rx="2"/><rect x="54" y="74" width="4" height="12" rx="2"/><circle cx="74" cy="77" r="2.600"/><circle cx="79" cy="83" r="2.600"/></g>',
    "favorites": '<path d="M64 63l5.200 10.500 11.600 1.700-8.400 8.200 2 11.600L64 89.500 53.600 95l2-11.600-8.400-8.200 11.600-1.700z" fill="#fff" opacity=".92"/>',
}

PLACES = [
    (None, ["folder", "inode-directory", "folder-open", "folder-drag-accept", "folder-visiting", "folder-new"]),
    ("documents", ["folder-documents", "folder-documents-open"]),
    ("download", ["folder-download", "folder-downloads", "folder-download-open"]),
    ("music", ["folder-music", "folder-music-open", "folder-sound"]),
    ("pictures", ["folder-pictures", "folder-pictures-open", "folder-image", "folder-images"]),
    ("videos", ["folder-videos", "folder-videos-open", "folder-video"]),
    ("desktop", ["user-desktop", "folder-desktop", "desktop"]),
    ("home", ["user-home", "folder-home", "go-home-folder"]),
    ("templates", ["folder-templates"]),
    ("public", ["folder-publicshare", "folder-public"]),
    ("remote", ["folder-remote", "network-workgroup", "folder-network", "network-server"]),
    ("code", ["folder-git", "folder-code", "folder-development", "folder-projects", "folder-script"]),
    ("games", ["folder-games", "folder-steam"]),
    ("favorites", ["folder-favorites", "folder-bookmark", "user-bookmarks", "folder-important", "folder-recent",
                   "document-open-recent"]),
]


def folder_svg(emblem):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128">\n'
            f'  <!-- Lumen icon theme: glass folder ({emblem or "plain"}) -->\n  {FOLDER_DEFS}\n'
            f'  {FOLDER_BODY}\n  {EMBLEMS[emblem]}\n</svg>\n')


def trash_svg(full):
    paper = ('<g filter="url(#drop)"><rect x="46" y="18" width="30" height="34" rx="5" fill="url(#paper)" transform="rotate(-12 61 35)"/>'
             '<rect x="60" y="22" width="26" height="30" rx="5" fill="#e9ecfb" transform="rotate(14 73 37)"/></g>') if full else ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128">\n'
            f'  <!-- Lumen icon theme: glass bin -->\n  {FOLDER_DEFS}\n  {paper}\n'
            '  <path d="M26 46h76l-6 60a12 12 0 0 1-12 11H44a12 12 0 0 1-12-11z" fill="url(#back)" filter="url(#drop)"/>\n'
            '  <g filter="url(#drop)"><path d="M26 46h76l-6 60a12 12 0 0 1-12 11H44a12 12 0 0 1-12-11z" fill="url(#front)" opacity=".92"/>'
            '<path d="M26 46h76l-6 60a12 12 0 0 1-12 11H44a12 12 0 0 1-12-11z" fill="url(#sheen)"/></g>\n'
            '  <g fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="4" stroke-linecap="round"><path d="M48 62l3 40M64 62v40M80 62l-3 40"/></g>\n'
            '  <g filter="url(#drop)"><rect x="18" y="34" width="92" height="14" rx="7" fill="url(#paper)"/>'
            + ('' if full else '<rect x="50" y="24" width="28" height="12" rx="5" fill="none" stroke="url(#paper)" stroke-width="5"/>') +
            '</g>\n</svg>\n')


def build(glyph, variant, pal):
    a, b = P[pal]
    fn = GLYPHS[glyph]
    try:
        body = fn(variant)
    except TypeError:
        body = fn()
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128">\n'
            f'  <!-- Lumen icon theme: original design ({glyph}/{variant}) -->\n  {defs(a, b)}\n'
            f'  {TILE}\n  <g transform="translate(64 66) scale(1.04) translate(-64 -64)">{body}</g>\n</svg>\n')


def lighten(svg):
    """the same icon on a pale tile, for light mode (the glyph keeps its colours;
    a tile-coloured tint and a darker rim keep white parts readable)"""
    svg = svg.replace('<stop offset="0" stop-color="#2a2f4a"/><stop offset="1" stop-color="#151827"/>',
                      '<stop offset="0" stop-color="#fbfbfe"/><stop offset="1" stop-color="#dfe3f1"/>', 1)
    svg = svg.replace('<stop offset="0" stop-color="#fff" stop-opacity=".35"/><stop offset="1" stop-color="#fff" stop-opacity=".04"/>',
                      '<stop offset="0" stop-color="#fff" stop-opacity=".9"/><stop offset="1" stop-color="#5a6288" stop-opacity=".22"/>', 1)
    svg = svg.replace('<stop offset="0" stop-color="#3a4170"/><stop offset="1" stop-color="#232846"/>',
                      '<stop offset="0" stop-color="#fbfbfe"/><stop offset="1" stop-color="#dfe3f1"/>', 1)   # the generic tile
    # the glow: a little stronger, so the tile takes the app's colour
    svg = re.sub(r'(<radialGradient id="glow".*?stop-opacity=")\.4\d?(".*?stop-opacity=")\.12(")',
                 r'\g<1>.50\g<2>.26\g<3>', svg, count=1, flags=re.S)
    return svg


def main():
    write(OUT, "Lumen", "Lumen's glass icons (falls back to Papirus)", "Papirus-Dark,Adwaita,hicolor", lambda x: x)
    write(OUT + "-Light", "Lumen-Light", "Lumen's glass icons on light tiles, for light mode",
          "Papirus-Light,Papirus,Adwaita,hicolor", lighten)


def write(OUT, name, comment, inherits, tile):
    if os.path.isdir(OUT):
        shutil.rmtree(OUT)
    apps = os.path.join(OUT, "scalable", "apps")
    os.makedirs(apps)
    files_svg = open(os.path.join(ROOT, "data", "icons", "hicolor", "scalable", "apps", "lumen-files.svg")).read()
    n = 0
    seen = set()
    for (glyph, variant, pal), names in APPS:
        svg = tile(files_svg if glyph == "files" else build(glyph, variant, pal))
        for nm in names:
            if nm in seen:
                raise SystemExit(f"duplicate icon name {nm}")
            seen.add(nm)
            with open(os.path.join(apps, nm + ".svg"), "w") as f:
                f.write(svg)
            n += 1
    if name != "Lumen":     # the tile for apps without an icon of their own (hicolor has the dark one)
        gen = open(os.path.join(ROOT, "data", "icons", "hicolor", "scalable", "apps", "lumen-app-generic.svg")).read()
        with open(os.path.join(apps, "lumen-app-generic.svg"), "w") as f:
            f.write(tile(gen))
    places = os.path.join(OUT, "scalable", "places")
    os.makedirs(places)
    m = 0
    for emblem, names in PLACES:
        svg = folder_svg(emblem)
        for nm in names:
            with open(os.path.join(places, nm + ".svg"), "w") as f:
                f.write(svg)
            m += 1
    for full, names in ((False, ["user-trash", "trashcan_empty", "edittrash"]), (True, ["user-trash-full", "trashcan_full"])):
        for nm in names:
            with open(os.path.join(places, nm + ".svg"), "w") as f:
                f.write(trash_svg(full))
            m += 1
    with open(os.path.join(OUT, "index.theme"), "w") as f:
        f.write(f"[Icon Theme]\nName={name}\nComment={comment}\n"
                f"Inherits={inherits}\nDirectories=scalable/apps,scalable/places\n\n"
                "[scalable/apps]\nSize=128\nMinSize=8\nMaxSize=512\nType=Scalable\nContext=Applications\n\n"
                "[scalable/places]\nSize=128\nMinSize=8\nMaxSize=512\nType=Scalable\nContext=Places\n")
    print(f"wrote {n} app icons ({len(APPS)} designs) and {m} folder icons to {OUT}")


if __name__ == "__main__":
    main()
