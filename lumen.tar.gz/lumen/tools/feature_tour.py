"""Lumen feature tour — Apple-style reveal.
Composites the real shell renders with the compositor's own easing curves and
SceneFX-style backdrop blur (recomputed every frame under each moving layer)."""
import math, os, shutil, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont

W, H, FPS = 1920, 1080, 30
OUT = sys.argv[1]
L = "/tmp/L"
FONT = "/usr/share/fonts/opentype/inter/"
def font(w, size): return ImageFont.truetype(FONT + f"InterDisplay-{w}.otf", size)

# ------------------------------------------------------------------ easing
def ease(kind, t):
    t = max(0.0, min(1.0, t))
    if kind == "expo": return 1 if t >= 1 else 1 - 2 ** (-10 * t)
    if kind == "cubic": return 4*t*t*t if t < .5 else 1 - (-2*t + 2) ** 3 / 2
    if kind == "out": return 1 - (1 - t) ** 3
    if kind == "spring":
        if t >= 1: return 1.0
        z, w = 0.62, 13.0; wd = w * math.sqrt(1 - z*z); x = t * 1.15
        return 1 - math.exp(-z*w*x) * (math.cos(wd*x) + (z*w/wd) * math.sin(wd*x))
    return t
def prog(t, start, dur, kind="out"): return ease(kind, (t - start) / dur)

# ------------------------------------------------------------------ assets
def load(path): return Image.open(path).convert("RGBA")
def maskof(path): return Image.open(path).split()[-1].point(lambda a: 255 if a > 8 else 0)
wall = Image.open("/home/claude/lumen/data/wallpapers/lumen-flow.jpg").convert("RGB")
s = max(W / wall.width, H / wall.height)
wall = wall.resize((round(wall.width*s), round(wall.height*s)), Image.LANCZOS).crop((0, 0, W, H)).convert("RGBA")
def layerset(name, i): return (load(f"{L}/{name}/ui{i}.png"), maskof(f"{L}/{name}/mask{i}.png"))
FILES, TERM, CHROME = layerset("desk", 0), layerset("desk", 1), layerset("desk", 2)
CHROME2 = layerset("ws2", 2)
POP = {p: layerset(p, 3) for p in ("start", "control", "calendar", "logo", "window")}

def split_chrome(ch, top):
    ui, m = ch
    box = (0, 0, W, 40) if top else (0, H - 56, W, H)
    u = Image.new("RGBA", (W, H)); u.paste(ui.crop(box), box[:2])
    mm = Image.new("L", (W, H)); mm.paste(m.crop(box), box[:2])
    return (u, mm)
TOPBAR, TASKBAR = split_chrome(CHROME, True), split_chrome(CHROME, False)

rofi_rect = (620, 185, 1300, 675)
def rofi_layer(path):
    im = Image.open(path).convert("RGBA").crop(rofi_rect)
    m = Image.new("L", im.size, 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, im.width - 1, im.height - 1), 22, fill=255)
    im.putalpha(m)
    return im
ROFI_EMPTY, ROFI_FI = rofi_layer("/tmp/rofi_empty.png"), rofi_layer("/tmp/rofi_fi.png")

# ------------------------------------------------------------------ compositor
def fade(img, a):
    if a >= 0.999: return img
    r = img.copy(); r.putalpha(r.getchannel("A").point(lambda v: int(v * a))); return r

def shifted(img, dx, dy, mode):
    if not dx and not dy: return img
    out = Image.new(mode, (W, H)); out.paste(img, (int(dx), int(dy))); return out

def backdrop_blur(canvas):
    small = canvas.convert("RGB").resize((W // 2, H // 2), Image.BILINEAR).filter(ImageFilter.GaussianBlur(12))
    return ImageEnhance.Color(small).enhance(1.35).resize((W, H), Image.BILINEAR).convert("RGBA")

def compose(layers, base=None):
    """layers: [(ui, mask, dx, dy, alpha)] bottom→top"""
    canvas = base if base is not None else wall
    for ui, m, dx, dy, a in layers:
        if a <= 0.01: continue
        ui, m = shifted(ui, dx, dy, "RGBA"), shifted(m, dx, dy, "L")
        if a < 0.999: m = m.point(lambda v: int(v * min(1, a * 1.3)))
        canvas = Image.composite(backdrop_blur(canvas), canvas, m)
        canvas = Image.alpha_composite(canvas, fade(ui, a))
    return canvas

def camera(img, z=1.0, cx=W/2, cy=H/2):
    if abs(z - 1) < 1e-3: return img
    cw, ch = W / z, H / z
    x0 = min(max(cx - cw/2, 0), W - cw); y0 = min(max(cy - ch/2, 0), H - ch)
    return img.resize((W, H), Image.BICUBIC, box=(x0, y0, x0 + cw, y0 + ch))

# ------------------------------------------------------------------ type
def text_layer(lines, p, rise=26):
    """Apple-style blur-in: fades, rises and sharpens. lines: [(text, font, alpha, gap)]"""
    lay = Image.new("RGBA", (W, H))
    d = ImageDraw.Draw(lay)
    heights = [d.textbbox((0, 0), t, font=f)[3] + g for t, f, _, g in lines]
    y = (H - sum(heights)) / 2 + (1 - p) * rise
    for (t, f, a, g), h in zip(lines, heights):
        tw = d.textlength(t, font=f)
        d.text(((W - tw) / 2, y), t, font=f, fill=(255, 255, 255, int(255 * a * p)))
        y += h
    if p < 0.999: lay = lay.filter(ImageFilter.GaussianBlur((1 - p) * 14))
    return lay

def caption(img, title, sub, p, top=False, right=False):
    """keynote-style caption over a soft scrim (bottom-left, or top-left)"""
    if p <= 0.01: return img
    lay = Image.new("RGBA", (W, H))
    scrim = np.zeros((H, W), np.uint8)
    rows = np.arange(H)
    ramp = (np.clip((260 - rows) / 230, 0, 1) if top else np.clip((rows - (H - 380)) / 300, 0, 1)) ** 1.4 * 150 * p
    scrim[:] = ramp[:, None].astype(np.uint8)
    lay = Image.alpha_composite(lay, Image.merge("RGBA", [Image.new("L", (W, H), 0)] * 3 + [Image.fromarray(scrim)]))
    d = ImageDraw.Draw(lay)
    dy = (1 - p) * 18
    ty = 70 if top else H - 228
    ft, fs = font("SemiBold", 64), font("Regular", 30)
    xt = W - 96 - d.textlength(title, font=ft) if right else 96
    xs = W - 98 - d.textlength(sub, font=fs) if right else 98
    d.text((xt, ty + dy), title, font=ft, fill=(255, 255, 255, int(255 * p)))
    d.text((xs, ty + 82 + dy), sub, font=fs, fill=(255, 255, 255, int(170 * p)))
    return Image.alpha_composite(img, lay)

def dim(img, amount, blur=0):
    if blur: img = img.filter(ImageFilter.GaussianBlur(blur))
    return Image.alpha_composite(img, Image.new("RGBA", (W, H), (6, 7, 14, int(255 * amount))))

BLACK = Image.new("RGBA", (W, H), (0, 0, 0, 255))

# ------------------------------------------------------------------ timeline
frames = []
def seg(seconds, fn):
    n = int(round(seconds * FPS))
    for k in range(n): frames.append((fn, k / FPS))

DESK = lambda: [(*FILES, 0, 0, 1), (*TERM, 0, 0, 1), (*CHROME, 0, 0, 1)]
_desk_cache = {}
def desk_still():
    if "d" not in _desk_cache: _desk_cache["d"] = compose(DESK())
    return _desk_cache["d"]

# 1 — intro: black, "Lumen" blurs in
def s_intro(t):
    p1 = prog(t, 0.5, 1.4); p2 = prog(t, 1.6, 1.2); out = 1 - prog(t, 3.6, 0.8, "cubic")
    lay = text_layer([("Lumen", font("SemiBold", 168), 1, 48),
                      ("Liquid glass. Built for Arch.", font("Regular", 46), p2 / max(p1, 1e-3) if p1 > 0 else 0, 0)], p1)
    return Image.alpha_composite(BLACK, fade(lay, out))
seg(4.4, s_intro)

# 2 — reveal: wallpaper rises from black, bars glide in
def s_reveal(t):
    pw = prog(t, 0.0, 2.6, "out")
    base = camera(wall, 1.14 - 0.14 * pw)
    pt, pb = prog(t, 1.7, 0.75, "spring"), prog(t, 2.0, 0.75, "spring")
    img = compose([(*TOPBAR, 0, -44 * (1 - pt), min(1, pt * 1.5)),
                   (*TASKBAR, 0, 64 * (1 - pb), min(1, pb * 1.5))], base=base)
    return Image.alpha_composite(img, Image.new("RGBA", (W, H), (0, 0, 0, int(255 * (1 - pw)))))
seg(3.6, s_reveal)

# 3 — title card, then windows spring open
def s_glass_title(t):
    bars = compose([(*CHROME, 0, 0, 1)]) if "bars" not in _desk_cache else _desk_cache["bars"]
    _desk_cache["bars"] = bars
    pin = prog(t, 0, 0.9); pout = prog(t, 2.0, 0.7, "cubic")
    a = pin * (1 - pout)
    bg = dim(bars, 0.42 * a)
    lay = text_layer([("Glass that breathes.", font("SemiBold", 96), 1, 0)], pin)
    return Image.alpha_composite(bg, fade(lay, 1 - pout))
seg(2.7, s_glass_title)

def s_open(t):
    pf = prog(t, 0.0, 0.46, "spring"); pt = prog(t, 0.35, 0.46, "spring")
    img = compose([(*FILES, 0, 34 * (1 - pf), min(1, max(0, pf))),
                   (*TERM, 0, 34 * (1 - pt), min(1, max(0, pt))),
                   (*CHROME, 0, 0, 1)])
    return caption(img, "Spring-loaded windows", "Every window opens with real physics.", prog(t, 0.6, 0.7))
seg(2.6, s_open)

# 4 — live blur: slow push into the overlap
def s_blur(t):
    z = 1 + 0.75 * prog(t, 0.2, 2.6, "cubic") - 0.75 * prog(t, 4.0, 1.4, "cubic")
    img = camera(desk_still(), z, 900, 420)
    a = prog(t, 0.4, 0.7) * (1 - prog(t, 4.2, 0.5))
    return caption(img, "Live backdrop blur", "Windows, bars, menus — all frosted in real time.", a)
seg(5.6, s_blur)

# 5 — minimise into the taskbar, restore
drop = 0.6 * (1080 - 330)
def s_minimize(t):
    pm = prog(t, 0.5, 0.38, "cubic"); pr = prog(t, 1.6, 0.38, "expo")
    a = (1 - pm) + pr; dy = drop * pm * (1 - pr)
    img = compose([(*FILES, 0, 0, 1), (*TERM, 0, dy, min(1, a)), (*CHROME, 0, 0, 1)])
    return caption(img, "Minimise with a flourish", "Windows sink into the taskbar — and spring back.", prog(t, 0.0, 0.6) * (1 - prog(t, 2.9, 0.4)))
seg(3.3, s_minimize)

# 6 — spaces: slide to desktop 2 and back
def s_spaces(t):
    go = prog(t, 0.6, 0.44, "expo"); back = prog(t, 2.1, 0.44, "expo")
    off = (W + 60) * (go - back)
    wins = compose([(*FILES, -off, 0, 1), (*TERM, -off, 0, 1)])
    chrome_mix = Image.blend(CHROME[0], CHROME2[0], go * (1 - back))
    img = compose([(chrome_mix, CHROME[1], 0, 0, 1)], base=wins)
    return caption(img, "Spaces", "Four desktops. Super + 1–4, or a glance at the dots.", prog(t, 0, 0.6) * (1 - prog(t, 2.9, 0.4)))
seg(3.3, s_spaces)

# popups: spring in, hold with a camera drift, glide out
def popup_scene(name, dy_in, z_to, cx, cy, title, sub, hold=2.4, top=False, right=False):
    ui, m = POP[name]
    def fn(t):
        pin = prog(t, 0.2, 0.5, "spring"); pout = prog(t, 0.2 + hold, 0.28, "cubic")
        a = min(1, max(0, pin)) * (1 - pout)
        dy = dy_in * (1 - pin) + dy_in * 0.5 * pout
        img = compose([(ui, m, 0, dy, a)], base=desk_still())
        z = 1 + (z_to - 1) * prog(t, 0, hold + 0.5, "cubic")
        img = camera(img, z, cx, cy)
        return caption(img, title, sub, prog(t, 0.3, 0.6) * (1 - pout), top=top, right=right)
    seg(hold + 0.6, fn)

popup_scene("start", 70, 1.06, 960, 700, "Start, reimagined", "Search, pins and recent files.", right=True)
popup_scene("control", -50, 1.28, 1700, 300, "Control Centre", "Wi-Fi, Bluetooth, Focus, brightness, sound, now playing.")

# 7 — Spotlight via rofi
def s_spot(t):
    pin = prog(t, 0.2, 0.45, "spring"); pout = prog(t, 3.0, 0.28, "cubic")
    a = min(1, max(0, pin)) * (1 - pout)
    typed = prog(t, 1.5, 0.25)
    rf = Image.blend(ROFI_EMPTY, ROFI_FI, typed) if 0 < typed < 1 else (ROFI_FI if typed >= 1 else ROFI_EMPTY)
    sc = 0.94 + 0.06 * pin
    w, h = int(rf.width * sc), int(rf.height * sc)
    r = fade(rf.resize((w, h), Image.BICUBIC), a)
    lay = Image.new("RGBA", (W, H)); lay.paste(r, (960 - w // 2, 430 - h // 2))
    base = desk_still()
    m = lay.getchannel("A").point(lambda v: 255 if v > 8 else 0)
    img = Image.alpha_composite(Image.composite(backdrop_blur(base), base, m), lay)
    return caption(img, "Spotlight", "A glass rofi theme. Super + Space, start typing.", prog(t, 0.3, 0.6) * (1 - pout))
seg(3.5, s_spot)

# 8 — menus montage
def s_menus(t):
    seq = [("logo", 0.0), ("window", 1.25), ("calendar", 2.5)]
    img = desk_still()
    for name, st in seq:
        pin = prog(t, st, 0.3, "spring"); pout = prog(t, st + 1.0, 0.2, "cubic")
        a = min(1, max(0, pin)) * (1 - pout)
        if a > 0.01:
            ui, m = POP[name]
            dy = (-24 if name != "calendar" else 40) * (1 - pin)
            img = compose([(ui, m, 0, dy, a)], base=img)
    return caption(img, "Menus with manners", "The Lumen menu, window controls, and a glass calendar.", prog(t, 0, 0.6) * (1 - prog(t, 3.4, 0.4)))
seg(3.8, s_menus)

# 9 — close: window fades and settles
def s_close(t):
    pc = prog(t, 0.3, 0.21, "cubic")
    return compose([(*FILES, 0, 0, 1), (*TERM, 0, 18 * pc, 1 - pc), (*CHROME, 0, 0, 1)])
_close_last = {}
seg(1.0, s_close)

# 10 — "and so much more" grid
FEATURES = ["XWayland", "Alt-Tab", "Night Shift", "Screenshots", "Glass notifications",
            "Lock screen", "Fractional scaling", "Live config reload", "Media keys"]
def s_more(t):
    if "nowin" not in _desk_cache:
        _desk_cache["nowin"] = compose([(*FILES, 0, 0, 1), (*CHROME, 0, 0, 1)])
    a = prog(t, 0, 0.8)
    bg = dim(_desk_cache["nowin"].filter(ImageFilter.GaussianBlur(18 * a)), 0.55 * a)
    lay = text_layer([("And so much more.", font("SemiBold", 84), 1, 0)], prog(t, 0.2, 0.9), rise=20)
    lay = Image.fromarray(np.roll(np.asarray(lay), -170, axis=0))
    d = ImageDraw.Draw(lay)
    f = font("Medium", 40)
    for i, word in enumerate(FEATURES):
        c, r = i % 3, i // 3
        p = prog(t, 0.9 + i * 0.12, 0.6)
        x = 960 + (c - 1) * 470; y = 520 + r * 92 + (1 - p) * 16
        tw = d.textlength(word, font=f)
        d.text((x - tw / 2, y), word, font=f, fill=(255, 255, 255, int(235 * p)))
    out = 1 - prog(t, 3.9, 0.6, "cubic")
    return Image.alpha_composite(bg, fade(lay, out))
seg(4.5, s_more)

# 11 — end card
def s_end(t):
    if "nowin" not in _desk_cache: s_more(0)
    bg = dim(_desk_cache["nowin"].filter(ImageFilter.GaussianBlur(18)), 0.55)
    p1 = prog(t, 0.2, 1.2); p2 = prog(t, 1.2, 1.0)
    lay = text_layer([("Lumen", font("SemiBold", 168), 1, 30),
                      ("Free and open source.  ./install.sh", font("Regular", 42), p2 / max(p1, 1e-3) if p1 > 0 else 0, 0)], p1)
    img = Image.alpha_composite(bg, lay)
    return Image.alpha_composite(img, Image.new("RGBA", (W, H), (0, 0, 0, int(255 * prog(t, 3.6, 1.0, "cubic")))))
seg(4.8, s_end)

# ------------------------------------------------------------------ render
if __name__ == "__main__":
    only = os.environ.get("ONLY")       # e.g. ONLY=120 renders one frame for checking
    rng = os.environ.get("RANGE")       # e.g. RANGE=0:700 renders a slice (no encode)
    os.makedirs("/tmp/tour", exist_ok=True)
    if only: idx = [int(only)]
    elif rng:
        a0, b0 = map(int, rng.split(":")); idx = range(a0, min(b0, len(frames)))
    else:
        shutil.rmtree("/tmp/tour", ignore_errors=True); os.makedirs("/tmp/tour"); idx = range(len(frames))
    for i in idx:
        fn, t = frames[i]
        fn(t).convert("RGB").save(f"/tmp/tour/{i:05d}.png" if not only else OUT)
        if not only and i % 150 == 0: print("frame", i, "/", len(frames), flush=True)
    if os.environ.get("ENCODE") or (not only and not rng):
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-framerate", str(FPS), "-i", "/tmp/tour/%05d.png",
                        "-vf", "format=yuv420p", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                        "-movflags", "+faststart", OUT], check=True)
        print("wrote", OUT, len(frames) / FPS, "s")
