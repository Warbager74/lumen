#!/usr/bin/env python3
"""Light mode: write style-light.css next to every style.css.

Lumen's sheets are drawn for dark glass: white text, faint white lifts and
hairlines, deep translucent bodies. This turns each one into its light
counterpart by what a colour is used for, not by its value:

  text            white ink          → dark ink (white stays on accent-filled things)
  fills           dark glass         → pale glass, a little more opaque
                  faint white lift   → a stronger white lift (cards stay lighter than their pane)
  borders         white hairline     → dark hairline
  shadows         inset white light  → brighter;  dark drop shadows → much softer

Whatever the rules can't get right is corrected by hand in light-extra.css
(same folder), which is appended. Run after changing any style.css:

  tools/make-light-css.py
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHEETS = ["shell/lumen_shell/style.css", "shell/lumen_shell/liquid.css", "files/lumen_files/style.css",
          "settings/lumen_settings/style.css", "greeter/lumen_greeter/style.css"]
INK = (24, 26, 40)

COLOR = re.compile(r"rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+)\s*)?\)"
                   r"|#([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b"
                   r"|(?<![\w-])(white|black)(?![\w-])")


def parse(m):
    if m.group(1) is not None:
        return int(m.group(1)), int(m.group(2)), int(m.group(3)), float(m.group(4)) if m.group(4) else 1.0
    if m.group(5):
        h = m.group(5)
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), int(h[6:8], 16) / 255 if len(h) == 8 else 1.0
    return (255, 255, 255, 1.0) if m.group(6) == "white" else (0, 0, 0, 1.0)


def out(r, g, b, a):
    a = max(0.0, min(1.0, a))
    if a >= 0.999:
        return f"rgb({r}, {g}, {b})"
    return f"rgba({r}, {g}, {b}, {a:.3f})".replace("0.", "0.", 1)


def kind(r, g, b):
    lo, hi = min(r, g, b), max(r, g, b)
    if hi == 0:
        return "black"
    if lo >= 205 and hi - lo <= 40:
        return "white"
    if hi <= 105 and hi - lo <= 45:
        return "dark"
    return "colour"


def pale(r, g, b):
    """a dark neutral glass colour as its pale counterpart (cool, like the dark one)"""
    lv = int(244 - ((r + g + b) / 3) * 0.55)
    return max(0, lv - 3), max(0, lv - 1), min(255, lv + 5)


def recolor(value, role, keep_white):
    def one(m, inset=False):
        r, g, b, a = parse(m)
        k = kind(r, g, b)
        if role == "text":
            if k == "white" and not keep_white:
                return out(*INK, 0.92 if a >= 0.9 else a + 0.05)
            return m.group(0)
        if role == "fill":
            if k == "white":
                if a > 0.6:
                    return m.group(0)
                return out(255, 255, 255, min(0.92, 0.22 + a * 3.2))
            if k == "dark":
                return out(*pale(r, g, b), a if a >= 0.9 else min(0.9, a + 0.2))
            if k == "black":
                return out(0, 0, 0, a * 0.35)
            return m.group(0)
        if role == "sheen":
            if k == "white":
                return out(255, 255, 255, min(0.85, a * 2.6))
            if k == "dark":
                return out(*pale(r, g, b), a if a >= 0.9 else min(0.9, a + 0.2))
            if k == "black":
                return out(0, 0, 0, a * 0.35)
            return m.group(0)
        if role == "line":
            if k == "white":
                return out(*INK, max(0.07, a * 0.8)) if a < 0.9 else m.group(0)
            if k in ("black", "dark"):
                return out(r, g, b, a * 0.5)
            return m.group(0)
        if role == "shadow":
            if k == "white":
                return out(255, 255, 255, min(0.85, a * 3.2)) if inset else m.group(0)
            if k in ("black", "dark"):
                return out(0, 0, 0, a * (0.5 if inset else 0.42))
            return m.group(0)
        return m.group(0)

    if role == "text" and not keep_white:
        # pastel accents can't be read as text on pale glass: deepen them
        value = re.sub(r"(?<![\w(])@(accent2?)\b(?!\s*,)", r"shade(@\1, 0.68)", value)
    if role == "shadow":
        parts, depth, cur = [], 0, ""
        for ch in value:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            if ch == "," and depth == 0:
                parts.append(cur)
                cur = ""
            else:
                cur += ch
        parts.append(cur)
        return ",".join(COLOR.sub(lambda m, i=("inset" in p): one(m, i), p) for p in parts)
    return COLOR.sub(one, value)


def role_of(prop, value):
    p = prop.strip().lower()
    if p in ("color", "caret-color", "-gtk-secondary-caret-color", "text-decoration-color"):
        return "text"
    if p.startswith("background"):
        return "sheen" if "gradient" in value else "fill"
    if p.startswith("border") and "radius" not in p and "spacing" not in p or p.startswith("outline"):
        return "line"
    if p in ("box-shadow", "text-shadow", "-gtk-icon-shadow"):
        return "shadow"
    return None


def split_decls(body):
    decls, depth, cur = [], 0, ""
    for ch in body:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == ";" and depth == 0:
            decls.append(cur)
            cur = ""
        else:
            cur += ch
    return decls, cur


def filled_with_colour(decls):
    """does this rule paint an accent (or any saturated colour) behind its text?"""
    for d in decls:
        if ":" not in d:
            continue
        prop, value = d.split(":", 1)
        if not prop.strip().lower().startswith("background"):
            continue
        if "@accent" in value:
            return True
        for m in COLOR.finditer(value):
            r, g, b, a = parse(m)
            if kind(r, g, b) == "colour" and a > 0.5 and max(r, g, b) - min(r, g, b) > 60:
                return True
    return False


def convert_block(body):
    decls, tail = split_decls(body)
    keep_white = filled_with_colour(decls)
    res = []
    for d in decls:
        if ":" not in d:
            res.append(d)
            continue
        prop, value = d.split(":", 1)
        role = role_of(prop, value)
        res.append(prop + ":" + (recolor(value, role, keep_white) if role else value))
    return ";".join(res) + (";" if decls else "") + tail


def convert(text):
    res, i, n = "", 0, len(text)
    while i < n:
        j = text.find("{", i)
        if j < 0:
            res += defines(text[i:])
            break
        head = text[i:j]
        # find the matching brace
        depth, k = 1, j + 1
        while k < n and depth:
            if text[k] == "{":
                depth += 1
            elif text[k] == "}":
                depth -= 1
            k += 1
        body = text[j + 1:k - 1]
        res += defines(head) + "{"
        res += convert(body) if "{" in body else convert_block(body)
        res += "}"
        i = k
    return res


def defines(text):
    def one(m):
        name, value = m.group(1), m.group(2)
        if name.startswith("fg"):
            return f"@define-color {name} {recolor(value, 'text', False)};"
        if name in ("glass", "glass_hi", "rim"):
            return f"@define-color {name} {recolor(value, 'fill', False)};"
        return m.group(0)
    return re.sub(r"@define-color\s+(\w+)\s+([^;]+);", one, text)


def strip_comments(text):
    return re.sub(r"/\*.*?\*/", "", text, flags=re.S)


def main():
    for rel in SHEETS:
        src = os.path.join(ROOT, rel)
        dst = src[:-4] + "-light.css"
        extra = os.path.join(os.path.dirname(src), os.path.basename(src)[:-4] + "-light-extra.css")
        css = convert(strip_comments(open(src).read()))
        css = re.sub(r"\n\s*\n+", "\n", css).strip() + "\n"
        head = (f"/* Light mode of {os.path.basename(src)} — written by tools/make-light-css.py, do not edit.\n"
                f" * Corrections by hand go in {os.path.basename(extra)}. */\n")
        if os.path.exists(extra):
            css += "\n/* ---- by hand ---- */\n" + open(extra).read()
        with open(dst, "w") as f:
            f.write(head + css)
        print("wrote", os.path.relpath(dst, ROOT))
    return 0


if __name__ == "__main__":
    sys.exit(main())
