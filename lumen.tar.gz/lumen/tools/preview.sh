#!/bin/sh
# Render the shell offscreen (no compositor needed): tools/preview.sh out.jpg [start|control|calendar|logo|window]
# Needs: python-gobject, gtk4, python-pillow, xorg-server-xvfb
cd "$(dirname "$0")/../shell"
OPEN=""; [ -n "$2" ] && OPEN="--open $2"
GSK_RENDERER=cairo xvfb-run -a -s "-screen 0 1920x1080x24" python3 -m lumen_shell --preview "$1" $OPEN
