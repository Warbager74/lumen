# Generates Lumen's original "Flow" wallpaper: soft liquid ribbons of colour.
import numpy as np
from PIL import Image, ImageFilter
import sys
W, H = 2560, 1440
y, x = np.mgrid[0:H, 0:W].astype(np.float32)
u, v = x / W, y / H
# domain warp gives the liquid, folded look
wu = u + 0.08*np.sin(6.0*v + 1.3) + 0.05*np.sin(11.0*u*v + 0.4)
wv = v + 0.07*np.sin(5.0*u + 2.1) + 0.04*np.cos(9.0*u - 3.0*v)
base = np.stack([0.035 + 0.02*v, 0.04 + 0.01*u, 0.10 + 0.05*(1-v)], -1)
img = base.copy()
blobs = [  # (cx, cy, sx, sy, rgb, strength)
    (0.22, 0.30, 0.22, 0.16, (0.42, 0.25, 0.95), 1.0),
    (0.70, 0.28, 0.25, 0.14, (0.10, 0.55, 1.00), 0.95),
    (0.55, 0.72, 0.30, 0.15, (0.95, 0.35, 0.70), 0.85),
    (0.88, 0.80, 0.18, 0.18, (1.00, 0.62, 0.25), 0.75),
    (0.10, 0.85, 0.20, 0.14, (0.10, 0.85, 0.75), 0.65),
    (0.42, 0.48, 0.12, 0.30, (0.55, 0.40, 1.00), 0.55),
]
for cx, cy, sx, sy, rgb, k in blobs:
    d = ((wu-cx)/sx)**2 + ((wv-cy)/sy)**2
    g = np.exp(-d) * k
    img += g[..., None] * np.array(rgb, np.float32) * 0.85
# ribbon highlights along iso-lines of the warp field
rib = np.exp(-((np.sin(14*wu + 9*wv) * 0.5 + 0.5 - 0.5)**2) / 0.002) * 0.10
img += rib[..., None] * np.array([0.8, 0.85, 1.0], np.float32) * (0.4 + v[..., None])
img = img / (1 + img)            # filmic tonemap
img = np.clip(img * 1.35, 0, 1) ** 0.95
out = Image.fromarray((img * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(6))
grain = (np.random.default_rng(7).normal(0, 2.2, (H, W, 1))).astype(np.float32)
arr = np.clip(np.asarray(out).astype(np.float32) + grain, 0, 255).astype(np.uint8)
Image.fromarray(arr).save(sys.argv[1], quality=93)
