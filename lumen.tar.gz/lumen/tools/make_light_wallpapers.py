# Lumen's light-mode wallpapers: the same liquid ribbons as Flow / Dawn / Ocean,
# on a bright ground in pastel colours.   tools/make_light_wallpapers.py OUTDIR
import sys
import numpy as np
from PIL import Image, ImageFilter
W, H = 2560, 1440
y, x = np.mgrid[0:H, 0:W].astype(np.float32)
u, v = x / W, y / H
SETS = {
    "lumen-flow-light": ((0.96, 0.96, 0.99), 1.3, [
        (0.22, 0.30, 0.24, 0.18, (0.74, 0.66, 1.00), 0.95), (0.70, 0.28, 0.27, 0.16, (0.60, 0.80, 1.00), 0.90),
        (0.55, 0.72, 0.32, 0.17, (1.00, 0.72, 0.86), 0.85), (0.88, 0.80, 0.20, 0.20, (1.00, 0.84, 0.66), 0.80),
        (0.10, 0.85, 0.22, 0.16, (0.62, 0.94, 0.88), 0.70), (0.42, 0.48, 0.14, 0.32, (0.80, 0.74, 1.00), 0.55)]),
    "lumen-dawn-light": ((0.99, 0.96, 0.94), 2.1, [
        (0.20, 0.75, 0.30, 0.20, (1.00, 0.76, 0.62), 0.95), (0.65, 0.60, 0.30, 0.18, (1.00, 0.66, 0.74), 0.90),
        (0.85, 0.25, 0.24, 0.20, (0.84, 0.74, 1.00), 0.80), (0.35, 0.22, 0.26, 0.16, (1.00, 0.90, 0.66), 0.85),
        (0.55, 0.40, 0.14, 0.30, (1.00, 0.80, 0.84), 0.50)]),
    "lumen-ocean-light": ((0.94, 0.97, 0.99), 0.4, [
        (0.25, 0.30, 0.28, 0.18, (0.56, 0.84, 1.00), 0.95), (0.72, 0.35, 0.26, 0.18, (0.58, 0.94, 0.90), 0.90),
        (0.50, 0.75, 0.34, 0.18, (0.66, 0.76, 1.00), 0.85), (0.88, 0.82, 0.20, 0.18, (0.74, 0.96, 0.82), 0.75),
        (0.10, 0.78, 0.20, 0.18, (0.80, 0.86, 1.00), 0.70)]),
}
for name, (ground, ph, blobs) in SETS.items():
    wu = u + 0.08*np.sin(6.0*v + ph) + 0.05*np.sin(11.0*u*v + 0.4)
    wv = v + 0.07*np.sin(5.0*u + ph + 0.8) + 0.04*np.cos(9.0*u - 3.0*v)
    img = np.broadcast_to(np.array(ground, np.float32), (H, W, 3)).copy()
    for cx, cy, sx, sy, rgb, k in blobs:
        g = np.clip(np.exp(-(((wu-cx)/sx)**2 + ((wv-cy)/sy)**2)) * k, 0, 1)[..., None]
        img = img * (1 - g) + np.array(rgb, np.float32) * g
    rib = np.exp(-((np.sin(14*wu + 9*wv) * 0.5)**2) / 0.002) * 0.16
    img = img + rib[..., None] * (1 - img) * (0.5 + 0.5*v[..., None])      # white ribbons
    # a little more colour than the blend leaves: pastel, not washed out
    grey = img.mean(axis=2, keepdims=True)
    img = grey + (img - grey) * 1.45 - 0.035 * (1 - v[..., None] * 0.5)
    out = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(6))
    grain = np.random.default_rng(7).normal(0, 1.6, (H, W, 1)).astype(np.float32)
    arr = np.clip(np.asarray(out).astype(np.float32) + grain, 0, 255).astype(np.uint8)
    Image.fromarray(arr).save(f"{sys.argv[1]}/{name}.jpg", quality=92)
    print("wrote", name)
